var t, I = /* @__PURE__ */ new Map(), o = /* @__PURE__ */ new Map(), p = /* @__PURE__ */ new Map(), d = class r extends Array {
  constructor(...e) {
    super(...e), this.optsMap = /* @__PURE__ */ new Map(), this.isShow = (a) => {
      var s;
      const i = this.optsMap.get(a);
      return (s = i == null ? void 0 : i.show) !== null && s !== void 0 ? s : !0;
    };
  }
  clear() {
    this.splice(0, this.length);
  }
  add(e, a) {
    if (this.push(e), e !== r.DIVIDER) {
      var s;
      this.optsMap.set(e, { show: (s = a == null ? void 0 : a.show) !== null && s !== void 0 ? s : !0 });
    }
  }
  addDivider(e) {
    this.push(e ? `${r.DIVIDER_LABEL_PREFIX}${e}` : r.DIVIDER);
  }
  isDivider(e) {
    return e === r.DIVIDER || e.startsWith(r.DIVIDER_LABEL_PREFIX);
  }
  getDividerLabel(e) {
    return e.startsWith(r.DIVIDER_LABEL_PREFIX) ? e.slice(r.DIVIDER_LABEL_PREFIX.length) : "";
  }
};
t = d;
t.DIVIDER = "divider";
t.DIVIDER_LABEL_PREFIX = `${t.DIVIDER}:`;
var D = new d();
export {
  D as i,
  o as n,
  p as r,
  I as t
};
