import { a as i } from "./objectSpread2-B0BetFB8.mjs";
import "./base-node-CKuyN1x8.mjs";
import { t as d } from "./NodeContainer-zpIyuhKY.mjs";
import { t as n } from "./NodeKVS-CRVYjcYN.mjs";
import { t as s } from "./useNode-lPs0rKwe.mjs";
import { computed as m, createBlock as v, createVNode as _, defineComponent as c, guardReactiveProps as f, normalizeProps as S, openBlock as q, unref as r, withCtx as N } from "vue";
var y = /* @__PURE__ */ c({
  __name: "SqlNode",
  props: {
    node: {
      type: Object,
      required: !0
    },
    graph: {
      type: Object,
      required: !0
    }
  },
  setup(l) {
    const { $properties: o, getInputParamKVItem: a, getOutputParamKVItem: p } = s(l), u = m(() => {
      var e, t;
      return [
        a({
          label: "输入变量",
          emptyAction: "hidden"
        }),
        {
          label: "数据源",
          emptyAction: "tip",
          value: (e = o.value) === null || e === void 0 || (e = e.options) === null || e === void 0 || (e = e.sql) === null || e === void 0 ? void 0 : e.dataSourceName,
          emptyTip: "数据源尚未填写"
        },
        {
          label: "自定义SQL",
          emptyAction: "tip",
          value: (t = o.value) === null || t === void 0 || (t = t.options) === null || t === void 0 || (t = t.sql) === null || t === void 0 ? void 0 : t.outputSql,
          emptyTip: "自定义SQL尚未填写"
        },
        p({ label: "输出变量" })
      ];
    });
    return (e, t) => (q(), v(r(d), S(f(e.$props)), {
      default: N(() => [_(r(n), { kvs: u.value }, null, 8, ["kvs"])]),
      _: 1
    }, 16));
  }
}), A = /* @__PURE__ */ i({ default: () => b }), b = y;
export {
  A as n,
  b as t
};
