import { a as ge, n as ye, t as D } from "./objectSpread2-B0BetFB8.mjs";
import { t as _e } from "./_plugin-vue_export-helper-Dj7HTbfw.mjs";
import { t as be } from "./asyncToGenerator-BkhZtDh9.mjs";
import { t as G } from "./VarTextarea-BzeLBgKt.mjs";
import { t as ke } from "./VarListPicker-CrG8EHn2.mjs";
import { t as Me } from "./VarListShow-Dg1oan43.mjs";
import { t as xe } from "./useSettings-Cq_-E7Ut.mjs";
import "./Vars-Cgan49KR.mjs";
import { t as Pe } from "./LLMModelSelect-BRPxeDUM.mjs";
import { t as Se } from "./StructuredFieldEditor-Dg1Yz5QC.mjs";
import { Card as Oe, Checkbox as Ce, InputNumber as we, Space as Re, Switch as Ae, Textarea as Le } from "ant-design-vue/es";
import { Fragment as M, computed as Ie, createBlock as x, createCommentVNode as P, createElementBlock as S, createElementVNode as n, createTextVNode as Ue, createVNode as o, defineComponent as Ne, isRef as c, normalizeClass as w, onMounted as Ve, openBlock as i, ref as R, renderList as he, resolveComponent as Fe, toDisplayString as A, unref as l, watch as j, withCtx as u } from "vue";
import { getFileAccessHttpUrl as ze } from "/@/utils/common/compUtils";
import { useModal as q } from "/@/components/Modal";
import { CloseCircleOutlined as Te, PlusCircleOutlined as qe } from "@ant-design/icons-vue";
import Ee from "/@/views/super/airag/aiapp/components/AiAppGeneratedPromptModal.vue";
import Be from "/@/views/super/airag/aiapp/components/AiAppAddMcpModal.vue";
import De from "/@/views/super/airag/aiapp/components/AiAppPromptMarketModal.vue";
import { queryById as Ge } from "/@/views/super/airag/aiprompts/AiragPrompts.api";
import je from "/@/views/super/airag/aimcp/imgs/mcpLogo.png";
ye();
var He = { class: "llm-setting" }, Je = { class: "setting-item" }, $e = { class: "setting-item" }, Ke = { class: "setting-item" }, Qe = { class: "label flex-space-between" }, We = { class: "prompt-ref-area" }, Xe = { class: "prompt-ref-info" }, Ye = { class: "ref-name" }, Ze = { class: "setting-item" }, et = {
  class: "setting-item",
  style: { "margin-top": "18px" }
}, tt = { class: "setting-item" }, lt = { class: "knowledge-list" }, nt = { class: "flex" }, ot = ["src"], st = ["title"], at = { class: "flex" }, rt = { style: { "margin-top": "8px" } }, it = { class: "setting-item" }, ut = { class: "label flex-space-between" }, dt = { class: "setting-item" }, pt = /* @__PURE__ */ Ne({
  __name: "LLMSetting",
  props: {
    type: {
      type: String,
      required: !0
    },
    node: {
      type: Object,
      required: !0
    },
    properties: {
      type: Object,
      required: !0
    },
    isSilentMode: {
      type: Boolean,
      required: !0
    },
    setProperties: {
      type: Function,
      required: !0
    }
  },
  setup(H) {
    const J = [{
      field: "text",
      name: "回复内容",
      type: "string"
    }], $ = H, [K, Q] = q(), [W, X] = q(), [Y, L] = q(), { inputParams: I, inputVarsOptions: E, outputParams: O, prevVariables: Z, createOptionRef: r, isReadOnly: a } = xe($), U = r("model"), N = r("history"), g = r("messages[0].content"), V = r("messages[1].content"), h = r("systemPromptMode"), y = r("systemPromptRefId"), F = r("systemPromptRefName"), p = Ie(() => h.value === "ref"), _ = R(""), b = R(!1), C = r("plugins"), d = R([]), z = r("showToolExecution"), k = r("structuredOutput"), T = r("structuredOutputFields"), v = R([]);
    Ve(be(function* () {
      if (C.value && Array.isArray(C.value) && (d.value = C.value.map((t) => ({
        id: t.pluginId,
        name: t.pluginName,
        icon: t.icon
      }))), Array.isArray(T.value) && (v.value = T.value.map((t) => D({}, t))), p.value && y.value) try {
        const t = yield Ge(y.value);
        _.value = (t == null ? void 0 : t.content) || "";
      } catch (t) {
      }
    })), j(d, (t) => {
      C.value = t.map((e) => ({
        pluginId: e.id,
        pluginName: e.name,
        category: "mcp"
      }));
    }, { deep: !0 }), j(k, (t) => {
      t ? ee() : O.value = J;
    });
    function ee() {
      O.value = v.value.filter((t) => !!t.field).map((t) => ({
        field: t.field,
        name: t.name || t.field,
        type: t.type || "string"
      }));
    }
    function te(t) {
      Array.isArray(t) && (v.value = t), T.value = v.value.map((e) => D({}, e)), O.value = v.value.filter((e) => !!e.field).map((e) => ({
        field: e.field,
        name: e.name || e.field,
        type: e.type || "string"
      }));
    }
    function le() {
      a.value || (b.value = !1, L.openModal(!0, {}));
    }
    function ne() {
      a.value || L.openModal(!0, {});
    }
    function oe() {
      a.value || (p.value ? (h.value = "fill", y.value = "", F.value = "", _.value = "") : (b.value = !0, L.openModal(!0, {})));
    }
    function se(t) {
      if (!t) {
        b.value = !1;
        return;
      }
      p.value || b.value ? (h.value = "ref", y.value = t.id, F.value = t.name, _.value = t.content || "", b.value = !1) : g.value = t.content;
    }
    function ae() {
      a.value || Q.openModal(!0, {});
    }
    function re(t) {
      g.value = t;
    }
    function ie() {
      if (a.value) return;
      const t = d.value.map((e) => e.id);
      X.openModal(!0, {
        pluginIds: t,
        pluginDataList: d.value
      });
    }
    function ue(t, e) {
      d.value = e;
    }
    function de(t) {
      if (a.value) return;
      const e = d.value.findIndex((m) => m.id === t);
      e > -1 && d.value.splice(e, 1);
    }
    function pe(t) {
      return t ? ze(t) : je;
    }
    return (t, e) => {
      const m = Fe("Icon"), f = Re, ve = Le, me = we, B = Oe, ce = Ce, fe = Ae;
      return i(), S(M, null, [
        n("div", He, [
          n("div", Je, [e[8] || (e[8] = n("div", { class: "label" }, "输入变量", -1)), o(l(ke), {
            vars: l(I),
            "onUpdate:vars": e[0] || (e[0] = (s) => c(I) ? I.value = s : null),
            prevVariables: l(Z),
            readonly: l(a)
          }, null, 8, [
            "vars",
            "prevVariables",
            "readonly"
          ])]),
          n("div", $e, [e[9] || (e[9] = n("div", { class: "label" }, "模型", -1)), o(Pe, {
            model: l(U),
            "onUpdate:model": e[1] || (e[1] = (s) => c(U) ? U.value = s : null),
            readonly: l(a)
          }, null, 8, ["model", "readonly"])]),
          n("div", Ke, [n("div", Qe, [e[12] || (e[12] = n("div", null, "系统提示", -1)), o(f, { size: 8 }, {
            default: u(() => [o(f, {
              class: w(["gen-prompt-btn", { disabled: l(a) }]),
              onClick: oe,
              size: 4
            }, {
              default: u(() => [o(m, { icon: p.value ? "mdi:pencil-outline" : "mdi:link-variant" }, null, 8, ["icon"]), n("span", null, A(p.value ? "手动输入" : "关联提示词"), 1)]),
              _: 1
            }, 8, ["class"]), p.value ? P("", !0) : (i(), S(M, { key: 0 }, [o(f, {
              class: w(["gen-prompt-btn", { disabled: l(a) }]),
              onClick: le,
              size: 4
            }, {
              default: u(() => [o(m, { icon: "mdi:format-list-bulleted" }), e[10] || (e[10] = n("span", null, "选择", -1))]),
              _: 1
            }, 8, ["class"]), o(f, {
              class: w(["gen-prompt-btn", { disabled: l(a) }]),
              onClick: ae,
              size: 4
            }, {
              default: u(() => [o(m, { icon: "mdi:star-four-points" }), e[11] || (e[11] = n("span", null, "生成", -1))]),
              _: 1
            }, 8, ["class"])], 64))]),
            _: 1
          })]), p.value ? (i(), S(M, { key: 1 }, [n("div", We, [n("div", Xe, [o(m, {
            icon: "mdi:link-variant",
            class: "ref-icon"
          }), n("span", Ye, A(l(F) || "未关联提示词"), 1)]), o(f, {
            class: w(["gen-prompt-btn", { disabled: l(a) }]),
            onClick: ne,
            size: 4
          }, {
            default: u(() => [o(m, { icon: "mdi:pencil-outline" }), n("span", null, A(l(y) ? "更换" : "选择"), 1)]),
            _: 1
          }, 8, ["class"])]), _.value ? (i(), x(ve, {
            key: 0,
            value: _.value,
            "auto-size": {
              minRows: 3,
              maxRows: 8
            },
            readonly: !0,
            class: "prompt-ref-preview"
          }, null, 8, ["value"])) : P("", !0)], 64)) : (i(), x(l(G), {
            key: 0,
            value: l(g),
            "onUpdate:value": e[2] || (e[2] = (s) => c(g) ? g.value = s : null),
            height: 140,
            varsOptions: l(E),
            readonly: l(a),
            placeholder: "请输入提示内容。非必填，可用于给大模型定义角色与任务。按下 '/' 可以选择变量"
          }, null, 8, [
            "value",
            "varsOptions",
            "readonly"
          ]))]),
          n("div", Ze, [e[13] || (e[13] = n("div", { class: "label" }, "用户提示", -1)), o(l(G), {
            value: l(V),
            "onUpdate:value": e[3] || (e[3] = (s) => c(V) ? V.value = s : null),
            height: 140,
            varsOptions: l(E),
            readonly: l(a),
            placeholder: "请输入你的提示词。按下 '/' 可以选择变量"
          }, null, 8, [
            "value",
            "varsOptions",
            "readonly"
          ])]),
          n("div", et, [o(f, null, {
            default: u(() => [
              e[14] || (e[14] = n("span", null, "保留", -1)),
              o(me, {
                value: l(N),
                "onUpdate:value": e[4] || (e[4] = (s) => c(N) ? N.value = s : null),
                min: 0,
                style: { width: "120px" },
                disabled: l(a)
              }, null, 8, ["value", "disabled"]),
              e[15] || (e[15] = n("span", null, "条历史记录", -1))
            ]),
            _: 1
          })]),
          n("div", tt, [
            e[18] || (e[18] = n("div", { class: "label" }, "MCP", -1)),
            n("div", lt, [(i(!0), S(M, null, he(d.value, (s) => (i(), x(B, {
              key: s.id,
              "body-style": { padding: "10px 12px" },
              hoverable: "",
              class: "knowledge-card"
            }, {
              default: u(() => [n("div", nt, [
                n("img", {
                  class: "knowledge-img",
                  src: pe(s.icon),
                  alt: "mcp"
                }, null, 8, ot),
                n("div", {
                  class: "knowledge-name ellipsis",
                  title: s.name
                }, A(s.name), 9, st),
                l(a) ? P("", !0) : (i(), x(l(Te), {
                  key: 0,
                  class: "knowledge-icon",
                  onClick: (mt) => de(s.id)
                }, null, 8, ["onClick"]))
              ])]),
              _: 2
            }, 1024))), 128)), l(a) ? P("", !0) : (i(), x(B, {
              key: 0,
              "body-style": { padding: "10px 12px" },
              hoverable: "",
              class: "knowledge-card",
              onClick: ie
            }, {
              default: u(() => [n("div", at, [o(l(qe), { style: {
                "font-size": "30px",
                color: "#1890ff"
              } }), e[16] || (e[16] = n("div", { class: "knowledge-name" }, "添加MCP", -1))])]),
              _: 1
            }))]),
            n("div", rt, [o(ce, {
              checked: l(z),
              "onUpdate:checked": e[5] || (e[5] = (s) => c(z) ? z.value = s : null),
              disabled: l(a)
            }, {
              default: u(() => [...e[17] || (e[17] = [Ue("展示工具调用过程（仅流式输出）", -1)])]),
              _: 1
            }, 8, ["checked", "disabled"])])
          ]),
          n("div", it, [n("div", ut, [e[19] || (e[19] = n("div", null, "结构化输出", -1)), o(fe, {
            checked: l(k),
            "onUpdate:checked": e[6] || (e[6] = (s) => c(k) ? k.value = s : null),
            disabled: l(a),
            size: "small"
          }, null, 8, ["checked", "disabled"])]), l(k) ? (i(), S(M, { key: 0 }, [e[20] || (e[20] = n("div", { class: "structured-tip" }, "启用后将自动向提示词注入 JSON 格式要求，LLM 返回的各字段可直接作为输出变量被下游节点引用。嵌套对象以整体存储，子字段需用代码节点解析。", -1)), o(Se, {
            fields: v.value,
            "onUpdate:fields": [e[7] || (e[7] = (s) => v.value = s), te],
            readonly: l(a)
          }, null, 8, ["fields", "readonly"])], 64)) : P("", !0)]),
          n("div", dt, [e[21] || (e[21] = n("div", { class: "label" }, "输出变量", -1)), o(l(Me), { vars: l(O) }, null, 8, ["vars"])])
        ]),
        o(Ee, {
          onRegister: l(K),
          onOk: re
        }, null, 8, ["onRegister"]),
        o(Be, {
          onRegister: l(W),
          onSuccess: ue
        }, null, 8, ["onRegister"]),
        o(De, {
          onRegister: l(Y),
          onSelect: se
        }, null, 8, ["onRegister"])
      ], 64);
    };
  }
}), Vt = /* @__PURE__ */ ge({ default: () => vt }), vt = /* @__PURE__ */ _e(pt, [["__scopeId", "data-v-bcdfb11d"]]);
export {
  Vt as n,
  vt as t
};
