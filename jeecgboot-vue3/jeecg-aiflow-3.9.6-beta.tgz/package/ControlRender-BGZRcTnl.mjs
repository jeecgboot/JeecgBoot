import { a as R } from "./objectSpread2-B0BetFB8.mjs";
import { Divider as z, Tooltip as x } from "ant-design-vue/es";
import { Fragment as p, Teleport as $, computed as A, createBlock as b, createCommentVNode as B, createElementBlock as i, createElementVNode as N, createVNode as r, defineComponent as T, normalizeClass as f, onUnmounted as V, openBlock as l, ref as n, renderList as E, resolveComponent as I, withCtx as L } from "vue";
var w = { class: "control-box" }, D = ["data-idx"], F = ["title", "onClick"], H = /* @__PURE__ */ T({
  __name: "ControlRender",
  emits: ["register", "reset-graph"],
  setup(j, { emit: k }) {
    const a = k, d = n(!1), c = n(), t = n(null);
    a("register", { mount(e, _) {
      t.value = e, c.value = _, e.on("history:change", v), d.value = !0;
    } });
    const u = n(!1), s = n(!1), y = A(() => [
      {
        key: "zoom-out",
        icon: "ant-design:zoom-out-outlined",
        title: "缩小视图",
        onClick: () => {
          var e;
          return (e = t.value) === null || e === void 0 ? void 0 : e.zoom(!1);
        }
      },
      {
        key: "zoom-in",
        icon: "ant-design:zoom-in-outlined",
        title: "放大视图",
        onClick: () => {
          var e;
          return (e = t.value) === null || e === void 0 ? void 0 : e.zoom(!0);
        }
      },
      {
        key: "reset",
        icon: "arcticons:screenshottile",
        title: "恢复视图尺寸",
        onClick: () => a("reset-graph")
      },
      { type: "divider" },
      {
        key: "undo",
        icon: "ci:undo",
        title: "撤销",
        disabled: !u.value,
        onClick: () => {
          var e;
          return (e = t.value) === null || e === void 0 ? void 0 : e.undo();
        }
      },
      {
        key: "redo",
        icon: "ci:redo",
        title: "重做",
        disabled: !s.value,
        onClick: () => {
          var e;
          return (e = t.value) === null || e === void 0 ? void 0 : e.redo();
        }
      }
    ]);
    function v({ data: e }) {
      u.value = e.undoAble, s.value = e.redoAble;
    }
    return V(() => {
      var e;
      (e = t.value) === null || e === void 0 || e.off("history:change", v);
    }), (e, _) => {
      const C = z, h = I("Icon"), g = x;
      return d.value ? (l(), b($, {
        key: 0,
        to: c.value
      }, [N("div", w, [(l(!0), i(p, null, E(y.value, (o, m) => (l(), i(p, { key: o.key || m }, [o.type === "divider" ? (l(), i("div", {
        key: 0,
        class: "control-divider",
        "data-idx": m
      }, [r(C, { type: "vertical" })], 8, D)) : (l(), i("div", {
        key: 1,
        class: f(["control-item", { disabled: o.disabled }]),
        title: o.title,
        onClick: o.onClick
      }, [r(g, { title: o.title }, {
        default: L(() => [r(h, {
          icon: o.icon,
          size: 18,
          class: f(`icon-${o.key}`)
        }, null, 8, ["icon", "class"])]),
        _: 2
      }, 1032, ["title"])], 10, F))], 64))), 128))])], 8, ["to"])) : B("", !0);
    };
  }
}), K = /* @__PURE__ */ R({ default: () => U }), U = H;
export {
  K as n,
  U as t
};
