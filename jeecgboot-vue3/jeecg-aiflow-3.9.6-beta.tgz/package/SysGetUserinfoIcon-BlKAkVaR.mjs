import { a as o } from "./objectSpread2-B0BetFB8.mjs";
import { t as r } from "./NodeIcon-Dt_fCcq_.mjs";
import { createBlock as e, openBlock as c } from "vue";
var m = /* @__PURE__ */ o({ default: () => t }), t = {
  __name: "SysGetUserinfoIcon",
  setup(a) {
    return (n, s) => (c(), e(r, {
      icon: "mdi:account-circle",
      color: "#13c2c2"
    }));
  }
};
export {
  t as n,
  m as t
};
