import { a as e } from "./objectSpread2-B0BetFB8.mjs";
import { t } from "./NodeIcon-Dt_fCcq_.mjs";
import { createBlock as a, defineComponent as o, openBlock as r } from "vue";
var n = /* @__PURE__ */ o({
  __name: "ImageGenerateIcon",
  setup(p) {
    return (c, m) => (r(), a(t, {
      icon: "mdi:image-plus-outline",
      color: "#eb4db2"
    }));
  }
}), i = /* @__PURE__ */ e({ default: () => _ }), _ = n;
export {
  i as n,
  _ as t
};
