import { a as z } from "./objectSpread2-B0BetFB8.mjs";
import { t as G } from "./_plugin-vue_export-helper-Dj7HTbfw.mjs";
import { t as L } from "./VarListEditor-A0nqHeND.mjs";
import { t as U } from "./VarListPicker-CrG8EHn2.mjs";
import { t as D } from "./useSettings-Cq_-E7Ut.mjs";
import "./Vars-Cgan49KR.mjs";
import { t as H } from "./AiCodeGenerateModal-B1K3t9ws.mjs";
import { Divider as J, Select as K, Tooltip as Q } from "ant-design-vue/es";
import { createCommentVNode as W, createElementBlock as h, createElementVNode as n, createTextVNode as X, createVNode as t, defineComponent as Y, isRef as c, normalizeClass as Z, openBlock as b, ref as ee, resolveComponent as C, unref as e, withCtx as u } from "vue";
import { BasicModal as te, useModal as w } from "/@/components/Modal";
import { CodeEditor as x } from "/@/components/CodeEditor";
var ae = { class: "code-setting" }, oe = { class: "setting-item" }, re = { class: "setting-item" }, ne = { class: "code-header" }, le = { class: "code-type-select" }, se = {
  key: 0,
  style: {
    padding: "10px 20px 0",
    width: "100%",
    height: "100%"
  }
}, ie = { class: "setting-item" }, pe = /* @__PURE__ */ Y({
  __name: "CodeSetting",
  props: {
    type: {
      type: String,
      required: !0
    },
    node: {
      type: Object,
      required: !0
    },
    properties: {
      type: Object,
      required: !0
    },
    isSilentMode: {
      type: Boolean,
      required: !0
    },
    setProperties: {
      type: Function,
      required: !0
    }
  },
  setup(k) {
    const { inputParams: i, outputParams: p, prevVariables: j, createOptionRef: v, isReadOnly: o } = D(k), l = v("code"), d = v("codeType"), A = {
      javascript: `function main(params) {
  return {
    result: params.arg1 + '_拼接_' + params.arg2,
  }
}`,
      python: 'resp = {"result": u"{}_拼接_{}".format(params["arg1"], params["arg2"])}',
      groovy: `def main(params) {
    return [
        result: "\${params.arg1}_拼接_\${params.arg2}"
    ]
}`,
      kotlin: `fun main(params: Map<String, Any?>): Map<String, Any?> {
    return mapOf(
        "result" to "\${params["arg1"]}_拼接_\${params["arg2"]}"
    )
}`,
      aviator: `let res = params.arg1 + "_拼接_" + params.arg2;
let resp = seq.map("result", res);`
    }, M = [
      {
        label: "JavaScript",
        value: "javascript"
      },
      {
        label: "Python",
        value: "python"
      },
      {
        label: "Groovy",
        value: "groovy"
      },
      {
        label: "Aviator",
        value: "aviator"
      }
    ], _ = ee("https://www.runoob.com/js/js-tutorial.html"), S = {
      python: "https://www.runoob.com/python/python-tutorial.html",
      javascript: "https://www.runoob.com/js/js-tutorial.html",
      groovy: "https://www.w3cschool.cn/groovy/",
      kotlin: "https://www.runoob.com/kotlin/kotlin-tutorial.html",
      aviator: "https://www.yuque.com/boyan-avfmj/aviatorscript"
    };
    function g(r) {
      l.value = r;
    }
    const [V, { openModal: q, getOpen: O }] = w(), [P, { openModal: T }] = w();
    function R() {
      o.value || q();
    }
    function I() {
      o.value || T(!0, {
        codeType: d.value,
        code: l.value,
        inputParams: i.value,
        outputParams: p.value
      });
    }
    function B(r) {
      l.value = r;
    }
    function E(r) {
      l.value = A[r], _.value = S[r];
    }
    function F() {
      window.open(_.value, "_blank");
    }
    return (r, a) => {
      const N = K, m = C("Icon"), y = Q, $ = C("a-button"), f = J;
      return b(), h("div", ae, [
        n("div", oe, [a[3] || (a[3] = n("div", { class: "label" }, "输入变量", -1)), t(e(U), {
          vars: e(i),
          "onUpdate:vars": a[0] || (a[0] = (s) => c(i) ? i.value = s : null),
          prevVariables: e(j),
          readonly: e(o)
        }, null, 8, [
          "vars",
          "prevVariables",
          "readonly"
        ])]),
        n("div", re, [
          n("div", ne, [
            n("div", le, [t(N, {
              value: e(d),
              "onUpdate:value": a[1] || (a[1] = (s) => c(d) ? d.value = s : null),
              options: M,
              size: "small",
              style: { width: "100%" },
              disabled: e(o),
              onChange: E
            }, null, 8, ["value", "disabled"])]),
            t(y, { title: "帮助文档" }, {
              default: u(() => [t(m, {
                icon: "ant-design:question-circle",
                onClick: F
              })]),
              _: 1
            }),
            t(y, { title: "AI 帮写脚本" }, {
              default: u(() => [t($, {
                type: "link",
                size: "small",
                disabled: e(o),
                onClick: I
              }, {
                default: u(() => [t(m, { icon: "ant-design:robot-outlined" }), a[4] || (a[4] = X(" AI 帮写 ", -1))]),
                _: 1
              }, 8, ["disabled"])]),
              _: 1
            }),
            t(m, {
              icon: "ant-design:fullscreen",
              onClick: R,
              style: { "margin-left": "6px" },
              class: Z({ "icon-disabled": e(o) })
            }, null, 8, ["class"])
          ]),
          t(f, { style: { margin: "4px 0 8px 0" } }),
          t(e(x), {
            value: e(l),
            mode: "javascript",
            readonly: e(o),
            onChange: g
          }, null, 8, ["value", "readonly"]),
          t(e(te), {
            onRegister: e(V),
            canFullscreen: !1,
            destroyOnClose: !0,
            defaultFullscreen: !0,
            footer: null,
            header: null
          }, {
            default: u(() => [e(O) ? (b(), h("div", se, [t(e(x), {
              value: e(l),
              mode: "javascript",
              readonly: e(o),
              onChange: g
            }, null, 8, ["value", "readonly"])])) : W("", !0)]),
            _: 1
          }, 8, ["onRegister"])
        ]),
        t(f, { style: { margin: "4px 0 8px 0" } }),
        n("div", ie, [a[5] || (a[5] = n("div", { class: "label" }, "输出变量", -1)), t(e(L), {
          vars: e(p),
          "onUpdate:vars": a[2] || (a[2] = (s) => c(p) ? p.value = s : null),
          readonly: e(o)
        }, null, 8, ["vars", "readonly"])]),
        t(H, {
          onRegister: e(P),
          onApply: B
        }, null, 8, ["onRegister"])
      ]);
    };
  }
}), we = /* @__PURE__ */ z({ default: () => de }), de = /* @__PURE__ */ G(pe, [["__scopeId", "data-v-e180da0e"]]);
export {
  we as n,
  de as t
};
