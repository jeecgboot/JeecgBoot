import { a as e } from "./objectSpread2-B0BetFB8.mjs";
import { t as r } from "./NodeIcon-Dt_fCcq_.mjs";
import { createBlock as a, defineComponent as o, openBlock as t } from "vue";
var _ = /* @__PURE__ */ o({
  __name: "BraveSearchIcon",
  setup(n) {
    return (p, u) => (t(), a(r, {
      icon: "mdi:magnify",
      color: "#fb542b"
    }));
  }
}), s = /* @__PURE__ */ e({ default: () => c }), c = _;
export {
  s as n,
  c as t
};
