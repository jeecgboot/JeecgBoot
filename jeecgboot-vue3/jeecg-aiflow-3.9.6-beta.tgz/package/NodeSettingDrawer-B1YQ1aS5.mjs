import { a as R } from "./objectSpread2-B0BetFB8.mjs";
import { t as T } from "./_plugin-vue_export-helper-Dj7HTbfw.mjs";
import { t as U } from "./asyncToGenerator-BkhZtDh9.mjs";
import { t as q } from "./const-OjvoZKjM.mjs";
import { t as z } from "./NodeIcon-I60YeJ6p.mjs";
import { t as A } from "./NodeSetting-C3ePduoI.mjs";
import { t as F } from "./propStore-CR0aJ5bA.mjs";
import { t as G } from "./TitleEditor-DDuJD1TA.mjs";
import { Empty as j, Input as H, Space as J, Tooltip as K } from "ant-design-vue/es";
import { Fragment as S, computed as n, createBlock as h, createCommentVNode as k, createElementBlock as g, createElementVNode as u, createVNode as r, defineComponent as L, guardReactiveProps as O, normalizeProps as Q, openBlock as l, ref as W, resolveComponent as X, toDisplayString as Y, unref as i, withCtx as p } from "vue";
import { cloneDeep as Z } from "lodash-es";
import { BasicDrawer as ee, useDrawerInner as te } from "/@/components/Drawer";
var oe = { class: "airag-node-label" }, re = { key: 0 }, ae = ["href"], ne = { class: "remarks" }, le = { class: "content" }, ie = /* @__PURE__ */ L({
  __name: "NodeSettingDrawer",
  props: { isSilentMode: Boolean },
  emits: ["register", "update"],
  setup(v, { emit: M }) {
    const w = v, x = M, c = F(), o = W(), s = n({
      get: () => {
        var e;
        return c.getProps((e = o.value) === null || e === void 0 ? void 0 : e.id);
      },
      set: (e) => {
        var t;
        return c.updateProps((t = o.value) === null || t === void 0 ? void 0 : t.id, e);
      }
    }), [C, { getVisible: D, closeDrawer: N }] = te((function() {
      var e = U(function* (t) {
        o.value = t.node, s.value = Z(t.node.properties);
      });
      return function(t) {
        return e.apply(this, arguments);
      };
    })()), m = (e) => {
      var t;
      c.setProperties((t = o.value) === null || t === void 0 ? void 0 : t.id, e), x("update", o.value);
    }, _ = n({
      get: () => i(s).text,
      set: (e) => m({ text: e })
    }), y = n({
      get: () => i(s).remarks,
      set: (e) => m({ remarks: e })
    }), a = n(() => {
      var e;
      const t = (e = o.value) === null || e === void 0 ? void 0 : e.type;
      if (!t) return {};
      const d = q.get(t);
      return d || {};
    }), P = n(() => ({
      title: _.value,
      disabled: w.isSilentMode,
      "onUpdate:title": (e) => _.value = e,
      promptProps: {
        title: "修改节点名称",
        defaultValue: _.value,
        placeholder: "请输入节点名称",
        rules: [{
          required: !0,
          message: "请输入节点名称！"
        }, {
          max: 12,
          message: "节点名称不能超过12个字符！"
        }]
      }
    }));
    function b() {
      N();
    }
    return (e, t) => {
      const d = X("Icon"), I = K, B = J, E = H, V = j;
      return l(), h(i(ee), {
        onRegister: i(C),
        width: 600,
        mask: !1,
        getContainer: !1,
        onClose: b
      }, {
        title: p(() => [r(G, Q(O(P.value)), null, 16)]),
        default: p(() => {
          var f;
          return [i(D) ? (l(), g(S, { key: 0 }, [!((f = a.value) === null || f === void 0) && f.type ? (l(), g(S, { key: 0 }, [
            r(B, { style: { "margin-bottom": "8px" } }, {
              default: p(() => [
                r(z, { type: a.value.type }, null, 8, ["type"]),
                u("span", oe, Y(a.value.label), 1),
                a.value.docs ? (l(), g("span", re, [r(I, { title: "查看文档" }, {
                  default: p(() => [u("a", {
                    href: a.value.docs,
                    target: "_blank"
                  }, [r(d, {
                    icon: "material-symbols:menu-book-outline-rounded",
                    color: "#666"
                  })], 8, ae)]),
                  _: 1
                })])) : k("", !0)
              ]),
              _: 1
            }),
            u("div", ne, [r(E, {
              value: y.value,
              "onUpdate:value": t[0] || (t[0] = ($) => y.value = $),
              placeholder: "描述",
              readonly: v.isSilentMode,
              style: { width: "100%" }
            }, null, 8, ["value", "readonly"])]),
            u("div", le, [r(A, {
              type: a.value.type,
              node: o.value,
              properties: s.value,
              isSilentMode: v.isSilentMode,
              setProperties: m
            }, null, 8, [
              "type",
              "node",
              "properties",
              "isSilentMode"
            ])])
          ], 64)) : (l(), h(V, {
            key: 1,
            description: "未知节点类型"
          }))], 64)) : k("", !0)];
        }),
        _: 1
      }, 8, ["onRegister"]);
    };
  }
}), ke = /* @__PURE__ */ R({ default: () => se }), se = /* @__PURE__ */ T(ie, [["__scopeId", "data-v-8f08c56d"]]);
export {
  ke as n,
  se as t
};
