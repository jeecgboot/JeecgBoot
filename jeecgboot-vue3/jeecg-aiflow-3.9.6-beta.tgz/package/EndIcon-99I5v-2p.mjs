import { a as e } from "./objectSpread2-B0BetFB8.mjs";
import { t as o } from "./NodeIcon-Dt_fCcq_.mjs";
import { createBlock as t, defineComponent as r, openBlock as n } from "vue";
var _ = /* @__PURE__ */ r({
  __name: "EndIcon",
  setup(c) {
    return (p, u) => (n(), t(o, {
      icon: "ic:round-stop",
      color: "#ee4a4a"
    }));
  }
}), f = /* @__PURE__ */ e({ default: () => a }), a = _;
export {
  f as n,
  a as t
};
