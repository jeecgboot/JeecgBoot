import { a as Z, n as K, t as x } from "./objectSpread2-B0BetFB8.mjs";
import { t as Q } from "./_plugin-vue_export-helper-Dj7HTbfw.mjs";
import { t as V } from "./asyncToGenerator-BkhZtDh9.mjs";
import { t as Y } from "./rules-BcwBMgYM.mjs";
import { Divider as ee, Empty as te } from "ant-design-vue/es";
import { Fragment as A, computed as w, createBlock as ae, createCommentVNode as N, createElementBlock as c, createElementVNode as p, createVNode as y, defineComponent as le, nextTick as re, normalizeClass as ie, openBlock as o, reactive as ne, ref as T, renderList as oe, resolveComponent as se, toDisplayString as F, unref as h, withCtx as de, withModifiers as q } from "vue";
import { useMessage as ue } from "/@/hooks/web/useMessage";
import { BasicModal as ce, useModal as pe } from "/@/components/Modal";
import { omit as fe } from "lodash-es";
import { BasicForm as me, useForm as ve } from "/@/components/Form";
import { PlusOutlined as ye } from "@ant-design/icons-vue";
K();
var be = ["onClick"], _e = { class: "icon" }, xe = { class: "name" }, he = { style: { color: "#999999" } }, ge = { key: 0 }, Ve = { key: 1 }, we = {
  key: 0,
  class: "action"
}, Ne = { key: 0 }, Fe = ["onClick"], ke = {
  key: 1,
  class: "field-add",
  style: {
    width: "100%",
    "margin-bottom": "10px"
  }
}, Se = { style: { "margin-left": "6px" } }, Ee = { style: { padding: "20px" } }, Be = /* @__PURE__ */ le({
  __name: "VarListEditor",
  props: {
    vars: {
      type: Array,
      required: !0
    },
    readonly: {
      type: Boolean,
      default: !1
    },
    allowAdd: {
      type: Boolean,
      default: !0
    },
    fixedVars: {
      type: Object,
      default: () => ({})
    },
    type: {
      type: String,
      default: "other"
    },
    fieldBeforeText: {
      type: String,
      default: ""
    }
  },
  emits: ["update:vars"],
  setup(b, { emit: D }) {
    const { createConfirmSync: M } = ue(), r = b, C = D, v = w(() => r.readonly === !0), f = w(() => r.type === "start"), k = w(() => r.type === "subflow"), n = ne(f.value ? { varName: "字段" } : { varName: "变量" }), [R, { openModal: P, closeModal: I }] = pe(), g = T(!1), L = w(() => g.value ? `编辑${n.varName}` : `添加${n.varName}`), m = T([]), [O, s] = ve({
      showActionButtonGroup: !1,
      schemas: [
        {
          field: "idx",
          label: "",
          component: "InputNumber",
          show: !1
        },
        {
          field: "field",
          label: `${n.varName}名称`,
          component: "Input",
          componentProps: { addonBefore: r.fieldBeforeText },
          dynamicDisabled: () => m.value.includes("field") || k.value,
          rules: [{
            required: !0,
            message: `请输入${n.varName}名称`
          }, { validator: (e, a) => {
            const t = Y(a, { allowDot: !!r.fieldBeforeText });
            return t.passed ? Promise.resolve() : Promise.reject(`${n.varName}名称` + t.message);
          } }]
        },
        {
          field: "name",
          label: "显示名称",
          component: "Input",
          dynamicDisabled: () => m.value.includes("name"),
          required: !0
        },
        {
          field: "type",
          label: `${n.varName}类型`,
          component: f.value ? "RadioGroup" : "Select",
          dynamicDisabled: () => m.value.includes("type"),
          componentProps: {
            options: W(),
            getPopupContainer: () => document.body
          }
        },
        {
          field: "required",
          label: "是否必填",
          component: "Switch",
          dynamicDisabled: () => m.value.includes("required"),
          ifShow: () => f.value
        },
        {
          field: "accept",
          label: "允许格式",
          component: "Select",
          componentProps: {
            mode: "tags",
            placeholder: "选择或输入格式后按 Enter，留空则不限制",
            getPopupContainer: () => document.body,
            options: [
              {
                label: "PDF",
                value: "pdf"
              },
              {
                label: "Word (.docx)",
                value: "docx"
              },
              {
                label: "Word 旧版 (.doc)",
                value: "doc"
              },
              {
                label: "Excel (.xlsx)",
                value: "xlsx"
              },
              {
                label: "Excel 旧版 (.xls)",
                value: "xls"
              },
              {
                label: "PowerPoint (.pptx)",
                value: "pptx"
              },
              {
                label: "PowerPoint 旧版 (.ppt)",
                value: "ppt"
              },
              {
                label: "纯文本 (.txt)",
                value: "txt"
              },
              {
                label: "Markdown (.md)",
                value: "md"
              },
              {
                label: "CSV (.csv)",
                value: "csv"
              },
              {
                label: "JSON (.json)",
                value: "json"
              },
              {
                label: "XML (.xml)",
                value: "xml"
              },
              {
                label: "ZIP (.zip)",
                value: "zip"
              },
              {
                label: "RAR (.rar)",
                value: "rar"
              }
            ]
          },
          ifShow: ({ values: e }) => f.value && e.type === "file"
        }
      ]
    });
    function W() {
      const e = [{
        label: "文本",
        value: "string"
      }, {
        label: "数字",
        value: "number"
      }];
      return f.value ? e.push({
        label: "图片",
        value: "picture"
      }, {
        label: "文件",
        value: "file"
      }) : e.push({
        label: "对象",
        value: "object"
      }, {
        label: "文本数组",
        value: "string[]"
      }, {
        label: "数字数组",
        value: "number[]"
      }, {
        label: "对象数组",
        value: "object[]"
      }), e;
    }
    function z(e) {
      switch (e) {
        case "string":
          return "memory:format-text";
        case "number":
          return "ant-design:number";
        case "picture":
          return "ant-design:picture";
        case "file":
          return "ant-design:file-outlined";
        case "object":
          return "ic:baseline-data-object";
        case "string[]":
          return "carbon:array-strings";
        case "number[]":
          return "carbon:array-numbers";
        case "object[]":
          return "carbon:array-objects";
      }
      return "memory:format-text";
    }
    function _(e) {
      return !!r.fixedVars[e];
    }
    function j(e) {
      var a, t;
      return _(e) && ((a = (t = r.fixedVars[e]) === null || t === void 0 ? void 0 : t.allowEditName) !== null && a !== void 0 ? a : !1);
    }
    function G(e) {
      return S.apply(this, arguments);
    }
    function S() {
      return S = V(function* (e) {
        if (v.value || !(yield M({
          title: "删除",
          content: `确定要删除这个${n.varName}吗？`
        }))) return;
        const { vars: a } = r, t = [...a];
        t.splice(e, 1), C("update:vars", t);
      }), S.apply(this, arguments);
    }
    function H() {
      return E.apply(this, arguments);
    }
    function E() {
      return E = V(function* () {
        v.value || (g.value = !1, m.value = [], P(), yield s.resetFields(), yield s.setFieldsValue({
          type: "string",
          required: !0
        }), yield s.clearValidate());
      }), E.apply(this, arguments);
    }
    function J(e, a) {
      return B.apply(this, arguments);
    }
    function B() {
      return B = V(function* (e, a) {
        if (v.value) return;
        e = x({}, e);
        const { fieldBeforeText: t } = r;
        t && e.field.startsWith(t) && (e.field = e.field.slice(t.length));
        const i = _(e.field), d = i && j(e.field);
        if (i && !d) return;
        g.value = !0, P(), i ? m.value = ["field", "type"] : m.value = [], yield s.resetFields(), yield s.setFieldsValue({ type: e.type }), yield re();
        const l = Array.isArray(e.accept) ? e.accept : e.accept ? String(e.accept).split(",").map((u) => u.trim()).filter(Boolean) : [];
        yield s.setFieldsValue(x(x({}, e), {}, {
          accept: l,
          idx: a
        })), yield s.clearValidate();
      }), B.apply(this, arguments);
    }
    function U() {
      return $.apply(this, arguments);
    }
    function $() {
      return $ = V(function* () {
        try {
          const e = yield s.validate();
          if (!e) return;
          const a = x(x({}, fe(e, "idx", "required")), {}, { required: !!e.required }), { vars: t, fieldBeforeText: i } = r;
          i && Object.entries(a).forEach(([l, u]) => {
            l === "field" && u && !u.startsWith(i) && (a.field = i + u);
          });
          const d = [...t];
          d[e.idx] = e, g.value ? d[e.idx] = a : d.push(a), C("update:vars", d), I();
        } catch (e) {
        }
      }), $.apply(this, arguments);
    }
    return (e, a) => {
      const t = te, i = se("Icon"), d = ee;
      return o(), c(A, null, [
        f.value && b.vars.length === 0 ? (o(), ae(t, {
          key: 0,
          "image-style": { height: "64px" },
          description: `尚未配置${n.varName}`
        }, null, 8, ["description"])) : N("", !0),
        (o(!0), c(A, null, oe(b.vars, (l, u) => (o(), c("div", {
          class: ie(["field-item", {
            "field-item-fixed": _(l.field),
            "field-item-allow-edit-name": _(l.field) && j(l.field),
            "field-item-readonly": v.value
          }]),
          onClick: (X) => J(l, u)
        }, [
          p("div", _e, [y(i, { icon: z(l.type) }, null, 8, ["icon"])]),
          p("div", xe, [
            p("span", null, F(l.field), 1),
            y(d, { type: "vertical" }),
            p("span", he, [_(l.field) ? (o(), c("span", ge, F(b.fixedVars[l.field].tip || l.name), 1)) : (o(), c("span", Ve, F(l.name), 1))])
          ]),
          !k.value && !v.value ? (o(), c("div", we, [f.value && l.required ? (o(), c("span", Ne, "必填")) : N("", !0), p("span", { onClick: q((X) => G(u), ["stop"]) }, [y(i, { icon: "ant-design:delete" })], 8, Fe)])) : N("", !0)
        ], 10, be))), 256)),
        b.allowAdd && !k.value && !v.value ? (o(), c("div", ke, [p("a", {
          type: "text",
          style: { "border-radius": "15px" },
          onClick: q(H, ["stop"])
        }, [y(h(ye)), p("span", Se, "添加" + F(n.varName), 1)])])) : N("", !0),
        y(h(ce), {
          onRegister: h(R),
          title: L.value,
          minHeight: 320,
          okText: "保存",
          forceRender: "",
          onOk: U
        }, {
          default: de(() => [p("div", Ee, [y(h(me), { onRegister: h(O) }, null, 8, ["onRegister"])])]),
          _: 1
        }, 8, ["onRegister", "title"])
      ], 64);
    };
  }
}), Oe = /* @__PURE__ */ Z({ default: () => $e }), $e = /* @__PURE__ */ Q(Be, [["__scopeId", "data-v-7133744a"]]);
export {
  Oe as n,
  $e as t
};
