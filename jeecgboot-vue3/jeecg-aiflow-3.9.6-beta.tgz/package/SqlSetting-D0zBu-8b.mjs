import { a as R, n as T, t as q } from "./objectSpread2-B0BetFB8.mjs";
import { t as E } from "./_plugin-vue_export-helper-Dj7HTbfw.mjs";
import { t as L } from "./VarTextarea-BzeLBgKt.mjs";
import { t as P } from "./VarListPicker-CrG8EHn2.mjs";
import { t as A } from "./VarListShow-Dg1oan43.mjs";
import { t as D } from "./useSettings-Cq_-E7Ut.mjs";
import "./Vars-Cgan49KR.mjs";
import { t as Q } from "./SelectSourceModal-DKxmS4NM.mjs";
import { Space as U, Tooltip as $ } from "ant-design-vue/es";
import { Fragment as G, createBlock as b, createCommentVNode as f, createElementBlock as V, createElementVNode as o, createVNode as s, defineComponent as H, isRef as k, normalizeClass as O, openBlock as u, resolveComponent as J, toDisplayString as K, unref as e, withCtx as m, withModifiers as W } from "vue";
import { useModal as X } from "/@/components/Modal";
T();
var Y = { class: "sql-setting" }, Z = { class: "setting-item" }, ee = { class: "setting-item" }, te = { class: "label" }, oe = { class: "setting-item" }, ae = { class: "setting-item" }, le = /* @__PURE__ */ H({
  __name: "SqlSetting",
  props: {
    type: {
      type: String,
      required: !0
    },
    node: {
      type: Object,
      required: !0
    },
    properties: {
      type: Object,
      required: !0
    },
    isSilentMode: {
      type: Boolean,
      required: !0
    },
    setProperties: {
      type: Function,
      required: !0
    }
  },
  setup(w) {
    const { inputParams: d, outputParams: p, prevVariables: x, createOptionRef: i, inputVarsOptions: M, isReadOnly: l } = D(w);
    function _() {
      if (r.value) {
        const a = r.value.replace(/^[\s\u00A0\uFEFF]+|[\s\u00A0\uFEFF]+$/g, "");
        r.value !== a && (r.value = a);
      }
    }
    const r = i("sql.outputSql");
    r.value == null ? r.value = "" : _();
    const c = i("sql.dataSourceId"), n = i("sql.dataSourceName"), S = i("sql.dataSourceCode"), [F, { openModal: h }] = X();
    function g() {
      l.value || h(!0, { dataSourceId: c });
    }
    function B(a) {
      l.value || a && (c.value = a[0].id, n.value = a[0].name, S.value = a[0].code);
    }
    function j() {
      l.value || (c.value = "", n.value = "", S.value = "");
    }
    const z = { body: { allowType: [
      "string",
      "number",
      "object[]"
    ] } };
    function I({ newType: a }) {
      l.value || (p.value = [q(q({}, p.value[0]), {}, { type: a })]);
    }
    return (a, t) => {
      const C = J("Icon"), N = $, y = U;
      return u(), V(G, null, [o("div", Y, [
        o("div", Z, [t[2] || (t[2] = o("div", { class: "label" }, "输入变量", -1)), s(e(P), {
          vars: e(d),
          "onUpdate:vars": t[0] || (t[0] = (v) => k(d) ? d.value = v : null),
          prevVariables: e(x),
          readonly: e(l)
        }, null, 8, [
          "vars",
          "prevVariables",
          "readonly"
        ])]),
        o("div", ee, [o("div", te, [s(y, null, {
          default: m(() => [t[3] || (t[3] = o("span", null, "数据源", -1)), s(N, { title: "添加数据源" }, {
            default: m(() => [e(n) ? f("", !0) : (u(), b(C, {
              key: 0,
              class: O(["add-icon", { disabled: e(l) }]),
              icon: "ant-design:plus-circle-outlined",
              onClick: g
            }, null, 8, ["class"]))]),
            _: 1
          })]),
          _: 1
        })]), e(n) ? (u(), V("div", {
          key: 0,
          class: O(["source-card", { disabled: e(l) }]),
          onClick: g
        }, [s(y, null, {
          default: m(() => [t[4] || (t[4] = o("div", { class: "source-icon" }, [o("svg", {
            viewBox: "0 0 1024 1024",
            version: "1.1",
            xmlns: "http://www.w3.org/2000/svg",
            "p-id": "1785",
            width: "20",
            height: "20"
          }, [o("path", {
            d: "M213.333333 533.333333c0 13.354667 19.669333 36.608 65.28 59.434667C337.664 622.293333 421.418667 640 512 640c90.581333 0 174.336-17.706667 233.386667-47.232 45.610667-22.826667 65.28-46.08 65.28-59.434667v-92.629333C740.266667 484.224 632.618667 512 512 512s-228.266667-27.818667-298.666667-71.296V533.333333z m597.333334 120.704C740.266667 697.557333 632.618667 725.333333 512 725.333333s-228.266667-27.818667-298.666667-71.296V746.666667c0 13.354667 19.669333 36.608 65.28 59.434666C337.664 835.626667 421.418667 853.333333 512 853.333333c90.581333 0 174.336-17.706667 233.386667-47.232 45.610667-22.826667 65.28-46.08 65.28-59.434666v-92.629334zM128 746.666667v-426.666667C128 213.973333 299.946667 128 512 128s384 85.973333 384 192v426.666667c0 106.026667-171.946667 192-384 192s-384-85.973333-384-192z m384-320c90.581333 0 174.336-17.706667 233.386667-47.232C790.954667 356.608 810.666667 333.354667 810.666667 320c0-13.354667-19.669333-36.608-65.28-59.434667C686.293333 231.04 602.581333 213.333333 512 213.333333c-90.581333 0-174.336 17.706667-233.386667 47.232C233.002667 283.392 213.333333 306.645333 213.333333 320c0 13.354667 19.669333 36.608 65.28 59.434667C337.664 408.96 421.418667 426.666667 512 426.666667z",
            fill: "#ffffff",
            "p-id": "1786"
          })])], -1)), o("span", null, K(e(n)), 1)]),
          _: 1
        }), e(l) ? f("", !0) : (u(), b(C, {
          key: 0,
          class: "source-card-close",
          icon: "ant-design:close-outlined",
          onClick: W(j, ["prevent", "stop"])
        }))], 2)) : f("", !0)]),
        o("div", oe, [t[5] || (t[5] = o("div", { class: "label" }, "SQL", -1)), s(e(L), {
          value: e(r),
          "onUpdate:value": t[1] || (t[1] = (v) => k(r) ? r.value = v : null),
          readonly: e(l),
          varsOptions: e(M),
          placeholder: "请输入自定义SQL。按下 “/” 可以选择变量",
          onBlur: _
        }, null, 8, [
          "value",
          "readonly",
          "varsOptions"
        ])]),
        o("div", ae, [t[6] || (t[6] = o("div", { class: "label" }, "输出变量", -1)), s(e(A), {
          vars: e(p),
          varsConfig: z,
          onChangeType: I
        }, null, 8, ["vars"])])
      ]), s(Q, {
        onRegister: e(F),
        onOk: B
      }, null, 8, ["onRegister"])], 64);
    };
  }
}), Se = /* @__PURE__ */ R({ default: () => re }), re = /* @__PURE__ */ E(le, [["__scopeId", "data-v-55deaa82"]]);
export {
  Se as n,
  re as t
};
