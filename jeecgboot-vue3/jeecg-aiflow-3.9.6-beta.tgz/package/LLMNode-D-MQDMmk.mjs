import { a as i } from "./objectSpread2-B0BetFB8.mjs";
import "./base-node-CKuyN1x8.mjs";
import { t as d } from "./NodeContainer-zpIyuhKY.mjs";
import { t as v } from "./NodeKVS-CRVYjcYN.mjs";
import { t as s } from "./useNode-lPs0rKwe.mjs";
import { computed as m, createBlock as _, createVNode as c, defineComponent as f, guardReactiveProps as L, normalizeProps as N, openBlock as $, unref as r, withCtx as b } from "vue";
var g = /* @__PURE__ */ f({
  __name: "LLMNode",
  props: {
    node: {
      type: Object,
      required: !0
    },
    graph: {
      type: Object,
      required: !0
    }
  },
  setup(a) {
    const { $properties: l, getInputParamKVItem: u, getOutputParamKVItem: p } = s(a), n = m(() => {
      var e, o, t;
      return [
        u({
          label: "输入变量",
          emptyAction: "hidden"
        }),
        {
          label: "模型",
          value: (e = l.value) === null || e === void 0 || (e = e.options) === null || e === void 0 || (e = e.model) === null || e === void 0 || (e = e.params) === null || e === void 0 ? void 0 : e.model,
          emptyAction: "tip",
          emptyTip: "尚未选择"
        },
        {
          label: "系统提示",
          value: (o = l.value) === null || o === void 0 || (o = o.options) === null || o === void 0 || (o = o.messages) === null || o === void 0 || (o = o[0]) === null || o === void 0 ? void 0 : o.content
        },
        {
          label: "用户提示",
          value: (t = l.value) === null || t === void 0 || (t = t.options) === null || t === void 0 || (t = t.messages) === null || t === void 0 || (t = t[1]) === null || t === void 0 ? void 0 : t.content
        },
        p({ label: "输出变量" })
      ];
    });
    return (e, o) => ($(), _(r(d), N(L(e.$props)), {
      default: b(() => [c(r(v), { kvs: n.value }, null, 8, ["kvs"])]),
      _: 1
    }, 16));
  }
}), P = /* @__PURE__ */ i({ default: () => y }), y = g;
export {
  P as n,
  y as t
};
