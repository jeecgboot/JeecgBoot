import { a as pe } from "./objectSpread2-B0BetFB8.mjs";
import { t as ce } from "./_plugin-vue_export-helper-Dj7HTbfw.mjs";
import { t as ve } from "./asyncToGenerator-BkhZtDh9.mjs";
import { t as fe } from "./VarPicker-HOsUWkU-.mjs";
import { t as de } from "./useSettings-Cq_-E7Ut.mjs";
import { Alert as me, Col as _e, Collapse as ye, CollapsePanel as he, Input as Ce, Popconfirm as ge, Row as ke, Space as $e } from "ant-design-vue/es";
import { Fragment as T, computed as Ve, createBlock as G, createCommentVNode as g, createElementBlock as k, createElementVNode as d, createVNode as m, defineComponent as Ge, nextTick as j, normalizeClass as be, openBlock as i, ref as N, renderList as F, toDisplayString as L, unref as p, withCtx as $, withModifiers as U } from "vue";
import { useMessage as we } from "/@/hooks/web/useMessage";
import b from "/@/components/Icon";
import { cloneDeep as h } from "lodash-es";
function Pe(w) {
  return Array.isArray(w) ? w.filter((v) => !!(v != null && v.name) && !!(v != null && v.type)).map((v) => ({
    field: v.name,
    name: v.name,
    type: v.type || "any"
  })) : [];
}
function J() {
  return {
    nodeId: "",
    field: "",
    isCustom: !1
  };
}
function H(w) {
  return {
    name: `variable${w}`,
    type: "",
    vars: [J()]
  };
}
var Ne = { class: "var-merge-setting" }, Oe = ["onClick"], Se = { key: 0 }, Ae = { style: { color: "#999999" } }, Ee = { class: "vars-list" }, Me = ["data-pop"], Ke = { class: "var-left" }, Be = {
  key: 0,
  class: "var-handle"
}, qe = { class: "var-picker" }, De = { class: "var-actions delete-action" }, Re = ["onClick"], ze = { key: 0 }, Te = 20, je = 20, Fe = /* @__PURE__ */ Ge({
  __name: "VarMergeSetting",
  props: {
    type: {
      type: String,
      required: !0
    },
    node: {
      type: Object,
      required: !0
    },
    properties: {
      type: Object,
      required: !0
    },
    isSilentMode: {
      type: Boolean,
      required: !0
    },
    setProperties: {
      type: Function,
      required: !0
    }
  },
  setup(w) {
    const v = w, { createMessage: Q } = we(), O = N(-1);
    let A = -1;
    const { prevVariables: B, options: W, updateOptions: X, isReadOnly: s } = de(v), l = Ve({
      get: () => {
        const t = h(W.value.varGroups);
        return A === -1 && (A = 0, t.forEach((e) => {
          e.vars.forEach((n) => {
            delete n._key;
          });
        })), t;
      },
      set: (t) => {
        const e = h(t);
        X({ varGroups: e }), Y(e);
      }
    }), V = N(l.value.map((t) => t.name));
    function Y(t) {
      const e = Pe(t);
      v.setProperties({ outputParams: e });
    }
    function Z() {
      if (s.value) return;
      const t = h(l.value), e = H(l.value.length + 1);
      let n = l.value.length + 1;
      for (; t.some((a) => a.name === e.name); )
        n += 1, e.name = `variable${n}`;
      t.push(e), l.value = t, V.value.push(e.name), j(() => {
        D(e, t.length - 1);
      });
    }
    function x(t) {
      if (s.value || l.value.length <= 1) return;
      let e = h(l.value);
      const n = e[t];
      e = e.filter((a, o) => o !== t), e.length === 0 && e.push(H(1)), l.value = e, V.value = V.value.filter((a) => a !== n.name);
    }
    const P = N(""), q = N();
    function D(t, e) {
      return E.apply(this, arguments);
    }
    function E() {
      return E = ve(function* (t, e) {
        if (s.value) return;
        O.value = e, P.value = t.name, yield j();
        const n = q.value[0];
        n && n.focus();
      }), E.apply(this, arguments);
    }
    function I(t) {
      if (s.value) return;
      O.value = -1;
      const e = P.value;
      if (e) {
        if (l.value.some((a) => a.name === e && a !== t)) {
          Q.error("输出变量名称重复，已还原修改"), P.value = "";
          return;
        }
        const n = V.value.findIndex((a) => a === t.name);
        n >= 0 && (V.value[n] = e), t.name = e, l.value = h(l.value);
      }
      P.value = "";
    }
    function ee(t) {
      return t.nodeId && t.field ? (delete t._key, `${t.nodeId}::${t.field}`) : (t._key || (t._key = `${A++}`), t._key);
    }
    function te(t) {
      if (s.value) return;
      const e = h(l.value), n = e[t];
      if (!n) return;
      const a = n.vars || [], o = a.findIndex((C) => C.isCustom), r = o >= 0 ? o : a.length;
      a.splice(r, 0, J()), n.vars = a, e[t] = n, l.value = e;
    }
    function ne(t, e) {
      if (s.value) return;
      const n = h(l.value), a = n[t];
      a && (a.vars.length <= 1 || (a.vars = a.vars.filter((o, r) => r !== e), n[t] = a, l.value = n));
    }
    function ae(t, e) {
      return t.type ? B.value.filter((n) => {
        if (n.type !== t.type) return !1;
        const a = t.vars.find((o) => o.nodeId === n.nodeId && o.field === n.field);
        return e && e.nodeId === n.nodeId && e.field === n.field ? !0 : !a;
      }) : B.value;
    }
    function re(t, e, n) {
      if (s.value) return;
      const a = h(l.value), o = a[t];
      if (!o || !n) return;
      o.type || (o.type = n.type || "");
      const r = o.vars[e];
      r && (!n.nodeId || !n.field ? (r.nodeId = "", r.field = "", r.type = void 0) : (r.nodeId = n.nodeId, r.field = n.field, r.type = n.type, r.customValue = void 0, r.isCustom = !1, o.type || (o.type = n.type || "")), o.vars[e] = r, a[t] = o, l.value = a);
    }
    function oe(t, e, n) {
      if (s.value || e === 0) return;
      const a = h(l.value), o = a[t];
      if (!o) return;
      const r = o.vars[e];
      r && (o.type || (o.type = "string"), r.nodeId = "", r.field = "", r.customValue = n, r.isCustom = !0, r.type = o.type || r.type, o.vars[e] = r, a[t] = o, l.value = a);
    }
    function R(t, e, n) {
      var a;
      if (s.value) return;
      const o = h(l.value), r = o[t];
      if (!r) return;
      const C = e + n;
      if (C < 0 || C >= r.vars.length || !((a = r.vars[C]) === null || a === void 0) && a.isCustom) return;
      const M = r.vars[e];
      r.vars[e] = r.vars[C], r.vars[C] = M, o[t] = r, l.value = o;
    }
    function le(t) {
      V.value = t;
    }
    const S = N("");
    function z(t) {
      t ? setTimeout(() => S.value = t, 150) : S.value = "";
    }
    return (t, e) => {
      const n = me, a = Ce, o = _e, r = ge, C = ke, M = $e, se = he, ie = ye;
      return i(), k("div", Ne, [
        m(n, {
          type: "info",
          "show-icon": "",
          message: "按顺序取值：每个输出变量从上到下尝试候选变量，首个非空值即为输出值",
          style: { "margin-bottom": "10px" }
        }),
        m(ie, {
          class: "var-merge-setting-groups",
          activeKey: V.value,
          bordered: !1,
          ghost: "",
          expandIconPosition: "start",
          onChange: le
        }, {
          default: $(() => [(i(!0), k(T, null, F(l.value, (u, c) => (i(), G(se, { key: u.name }, {
            header: $(() => [m(C, {
              class: "group-header",
              type: "flex"
            }, {
              default: $(() => [m(o, { span: 22 }, {
                default: $(() => [d("div", {
                  class: be(["group-header-title", { editable: O.value === c }]),
                  onClick: e[1] || (e[1] = U(() => {
                  }, ["stop"]))
                }, [O.value !== c ? (i(), k("div", {
                  key: 0,
                  class: "title-span",
                  onClick: (_) => D(u, c)
                }, [
                  d("span", null, L(u.name), 1),
                  u.type ? (i(), k("span", Se, [e[3] || (e[3] = d("span", null, " ", -1)), d("span", Ae, "<" + L(u.type) + ">", 1)])) : g("", !0),
                  e[4] || (e[4] = d("span", null, " ", -1)),
                  m(p(b), {
                    class: "action-hover",
                    icon: "ant-design:edit-outlined"
                  })
                ], 8, Oe)) : (i(), G(a, {
                  key: 1,
                  ref_for: !0,
                  ref_key: "titleInputRef",
                  ref: q,
                  class: "title-input",
                  value: P.value,
                  "onUpdate:value": e[0] || (e[0] = (_) => P.value = _),
                  placeholder: "请输入输出变量名",
                  size: "small",
                  "show-count": "",
                  maxlength: je,
                  disabled: p(s),
                  onBlur: () => I(u)
                }, null, 8, [
                  "value",
                  "disabled",
                  "onBlur"
                ]))], 2)]),
                _: 2
              }, 1024), p(s) ? g("", !0) : (i(), G(o, {
                key: 0,
                span: 2,
                class: "actions action-hover delete-action",
                "data-pop": S.value === `${c}`,
                onClick: e[2] || (e[2] = U(() => {
                }, ["stop"]))
              }, {
                default: $(() => [l.value.length > 1 ? (i(), G(r, {
                  key: 0,
                  title: "确定要删除该输出变量吗？",
                  placement: "left",
                  onConfirm: () => x(c),
                  onOpenChange: (_) => z(_ ? `${c}` : "")
                }, {
                  default: $(() => [m(p(b), { icon: "ant-design:delete-outlined" })]),
                  _: 1
                }, 8, ["onConfirm", "onOpenChange"])) : g("", !0)]),
                _: 2
              }, 1032, ["data-pop"]))]),
              _: 2
            }, 1024)]),
            default: $(() => [d("div", Ee, [(i(!0), k(T, null, F(u.vars, (_, f) => (i(), k("div", {
              key: ee(_),
              class: "var-item",
              "data-pop": S.value === `${c}-${f}`
            }, [
              d("div", Ke, [_.isCustom ? g("", !0) : (i(), k("span", Be, [m(M, {
                direction: "vertical",
                size: 0
              }, {
                default: $(() => {
                  var y, K;
                  return [!p(s) && f > 0 && !(!((y = u.vars[f - 1]) === null || y === void 0) && y.isCustom) ? (i(), G(p(b), {
                    key: 0,
                    icon: "ant-design:up-outlined",
                    class: "move-icon",
                    onClick: (ue) => R(c, f, -1)
                  }, null, 8, ["onClick"])) : g("", !0), !p(s) && f < u.vars.length - 1 && !(!((K = u.vars[f + 1]) === null || K === void 0) && K.isCustom) ? (i(), G(p(b), {
                    key: 1,
                    icon: "ant-design:down-outlined",
                    class: "move-icon",
                    onClick: (ue) => R(c, f, 1)
                  }, null, 8, ["onClick"])) : g("", !0)];
                }),
                _: 2
              }, 1024)]))]),
              d("div", qe, [m(fe, {
                item: _,
                vars: ae(u, _),
                allowEditValue: f > 0 && f === u.vars.length - 1 && (!u.type || ["string", "number"].includes(u.type)),
                readonly: p(s),
                onChange: (y) => re(c, f, y),
                onChangeCustom: (y) => oe(c, f, y)
              }, null, 8, [
                "item",
                "vars",
                "allowEditValue",
                "readonly",
                "onChange",
                "onChangeCustom"
              ])]),
              d("div", De, [!p(s) && u.vars.length > 1 ? (i(), G(r, {
                key: 0,
                title: "确定要删除该变量吗？",
                placement: "left",
                onConfirm: (y) => ne(c, f),
                onOpenChange: (y) => z(y ? `${c}-${f}` : "")
              }, {
                default: $(() => [m(p(b), { icon: "ant-design:delete-outlined" })]),
                _: 1
              }, 8, ["onConfirm", "onOpenChange"])) : g("", !0)])
            ], 8, Me))), 128)), d("div", null, [p(s) ? g("", !0) : (i(), k("a", {
              key: 0,
              onClick: (_) => te(c)
            }, [m(p(b), { icon: "ic:round-add" }), e[5] || (e[5] = d("span", null, "添加候选变量", -1))], 8, Re))])])]),
            _: 2
          }, 1024))), 128))]),
          _: 1
        }, 8, ["activeKey"]),
        l.value.length < Te && !p(s) ? (i(), k("div", ze, [d("a", { onClick: Z }, [m(p(b), { icon: "ic:round-add" }), e[6] || (e[6] = d("span", null, "添加输出变量", -1))])])) : g("", !0)
      ]);
    };
  }
}), tt = /* @__PURE__ */ pe({ default: () => Le }), Le = /* @__PURE__ */ ce(Fe, [["__scopeId", "data-v-9f907cfc"]]);
export {
  H as i,
  tt as n,
  Pe as r,
  Le as t
};
