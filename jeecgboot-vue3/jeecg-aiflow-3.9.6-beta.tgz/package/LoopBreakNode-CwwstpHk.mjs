import { a as o } from "./objectSpread2-B0BetFB8.mjs";
import "./base-node-CKuyN1x8.mjs";
import { t as r } from "./NodeContainer-zpIyuhKY.mjs";
import { createBlock as p, defineComponent as a, guardReactiveProps as t, normalizeProps as _, openBlock as n, unref as u } from "vue";
var s = /* @__PURE__ */ a({
  __name: "LoopBreakNode",
  props: {
    node: {},
    graph: {}
  },
  setup(l) {
    return (e, m) => (n(), p(u(r), _(t(e.$props)), null, 16));
  }
}), v = /* @__PURE__ */ o({ default: () => d }), d = s;
export {
  v as n,
  d as t
};
