import { a as o } from "./objectSpread2-B0BetFB8.mjs";
import "./base-node-CKuyN1x8.mjs";
import { t as r } from "./NodeContainer-zpIyuhKY.mjs";
import { createBlock as t, defineComponent as p, guardReactiveProps as a, normalizeProps as _, openBlock as n, unref as u } from "vue";
var s = /* @__PURE__ */ p({
  __name: "SetLoopVarNode",
  props: {
    node: {},
    graph: {}
  },
  setup(l) {
    return (e, m) => (n(), t(u(r), _(a(e.$props)), null, 16));
  }
}), N = /* @__PURE__ */ o({ default: () => d }), d = s;
export {
  N as n,
  d as t
};
