import { a as k, n as x, t as d } from "./objectSpread2-B0BetFB8.mjs";
import { t as T } from "./_plugin-vue_export-helper-Dj7HTbfw.mjs";
import { Dropdown as A, Menu as V, MenuItem as S } from "ant-design-vue/es";
import { Fragment as y, computed as L, createBlock as f, createElementBlock as u, createElementVNode as n, createTextVNode as b, createVNode as $, defineComponent as j, openBlock as o, renderList as m, toDisplayString as s, withCtx as _ } from "vue";
x();
var B = { style: { color: "#666666" } }, N = { class: "allow-change-type" }, q = { key: 1 }, D = /* @__PURE__ */ j({
  __name: "VarListShow",
  props: {
    vars: {
      type: Array,
      required: !0
    },
    varsConfig: {
      type: Object,
      required: !1,
      default: () => ({})
    }
  },
  emits: ["changeType"],
  setup(g, { emit: v }) {
    const c = g, h = v, w = L(() => {
      const { varsConfig: p } = c;
      return [...c.vars].map((t) => {
        var r, l;
        const a = (r = (l = p[t.field]) === null || l === void 0 ? void 0 : l.allowType) !== null && r !== void 0 ? r : [], e = Array.isArray(a) && a.length > 0;
        return d(d({}, t), {}, {
          allowedTypes: a,
          isAllowChangeType: e,
          class: e ? "allow-change-type" : ""
        });
      });
    });
    function C(p, t) {
      h("changeType", {
        varItem: p,
        newType: t
      });
    }
    return (p, t) => {
      const r = S, l = V, a = A;
      return o(!0), u(y, null, m(w.value, (e) => (o(), u("p", B, [
        n("span", null, s(e.field), 1),
        n("span", null, [
          t[0] || (t[0] = n("span", null, " <", -1)),
          e.isAllowChangeType ? (o(), f(a, {
            key: 0,
            trigger: "click",
            placement: "bottomCenter"
          }, {
            overlay: _(() => [$(l, {
              selectedKeys: [e.type],
              onClick: (i) => C(e, i.key)
            }, {
              default: _(() => [(o(!0), u(y, null, m(e.allowedTypes, (i) => (o(), f(r, { key: i }, {
                default: _(() => [b(s(i), 1)]),
                _: 2
              }, 1024))), 128))]),
              _: 2
            }, 1032, ["selectedKeys", "onClick"])]),
            default: _(() => [n("span", N, s(e.type), 1)]),
            _: 2
          }, 1024)) : (o(), u("span", q, s(e.type), 1)),
          t[1] || (t[1] = n("span", null, "> ", -1))
        ]),
        n("span", null, s(e.name), 1)
      ]))), 256);
    };
  }
}), G = /* @__PURE__ */ k({ default: () => E }), E = /* @__PURE__ */ T(D, [["__scopeId", "data-v-016f0761"]]);
export {
  G as n,
  E as t
};
