import { a as He, n as ze, t as U } from "./objectSpread2-B0BetFB8.mjs";
import { t as h } from "./asyncToGenerator-BkhZtDh9.mjs";
import { t as _e } from "./TitleEditor-DDuJD1TA.mjs";
import { r as Ae, t as Ye } from "./WorkflowView-BngXHwMm.mjs";
import { r as w, t as Xe } from "./ProcessAddBeforeModal-3dmdqRsr.mjs";
import { t as Ze } from "./CheckListPop-bUZj5td5.mjs";
import { DropdownButton as qe, Menu as Ve, MenuItem as $e, Skeleton as el, Space as ll, Spin as nl } from "ant-design-vue/es";
import { Fragment as ol, computed as C, createBlock as R, createElementBlock as re, createElementVNode as S, createTextVNode as pe, createVNode as a, defineComponent as tl, guardReactiveProps as il, mergeProps as Ie, nextTick as ue, normalizeProps as rl, normalizeStyle as ul, openBlock as E, provide as al, ref as A, resolveComponent as ae, toDisplayString as sl, unref as L, withCtx as s } from "vue";
import { useMessage as dl } from "/@/hooks/web/useMessage";
import { getFileAccessHttpUrl as vl } from "/@/utils/common/compUtils";
import { sleep as ye } from "/@/utils";
import { BasicModal as cl, useModal as gl, useModalInner as fl } from "/@/components/Modal";
import { useAttrs as ml } from "/@/hooks/core/useAttrs";
ze();
var Al = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMgAAADICAYAAACtWK6eAAAAAXNSR0IArs4c6QAACt9JREFUeF7tnU1WHDkQhCW8hTO5OQM+iXleA2s/fBI4A+0zwdZoXpVppjHdlerUf9bnjRdTWZJCERmZqvbIO/4kIfDt5/PGnblN8P7r/KLgNkkvzBHs3daH8Nu9uu3Dj4ttjleu9R1+rQtPXfckjPDF33QhCGEx3oW7h+uL29Q1rzEegSh2/dv9821w/kYR2iwEkeigRyAn4nb16+VpBNc4uCzvto/fzy9PXPKqH0cgJ2z/iM7xaXmI5IQddw6BRMJlQhxva6Xcitx0h0Cikbq6fwnRDw/woH8Nl5xwyRuFg8gYOUvu8b5cSq2IncdBokCy5h67ReMi8vbjIAJGJt1j14tQZokKQSArFoijzEIgIgIIhO8iCxzAQQSBDP1hUMoOOIiEEN9BJIQQiISQ7f+Og+AglFiUWPosh4PosbMQiYPgIDgIDqLPZTiIHjsLkTgIDoKD4CD6XIaD6LGzEImD4CA4CA6iz2U4iB47C5E4CA6Cg+Ag+lyGg+ixsxCJg+AgOAgOos9lOIgeOwuROAgOgoPgIPpchoPosbMQiYPgIDgIDqLPZTiIHjsLkTgIDoKD4CD6XIaD6LGzEImD4CA4CA6iz2U4iB47C5E4CA6Cg+Ag+lyGg+ixsxCJg+AgOAgOos9lOIgeOwuROAgOgoPgIPpchoPosbMQiYPgIDgIDqLPZTiIHjsLkTgIDoKD4CD6XIaD6LGzEImD4CA4CA6iz2WW7yjkCjaZFziIgNG3n8+bcOafZCjHe8K7cPdwfXE73szrzRiBrFkg3HIrKg2BiBA5Z7VRf7w+Z/+F/QegCIFYLLMoryI23jku8YyDyZiLcLtt7LYjkGiknB2RUFrF7zolVjxWzkKp5WnMT9hxSqyTwNo9PGTT7t3W/wl3Dz8utqpFrzQIB1Fu/EgfEGnIlZtMk64Hbhc5C8X7ry64TfrbMr5hcowQfrtXt8U19LjiIHrsDkZOfYr4yjO3Cc7fiM/tPTC5wET2mBgEEYNS3DMIJA6nrE9pmn2a66xbEP0yBBINVb4HEUg+LEu/CYGURvjA+xFIA9CVQyIQJXApYQgkBb26sQikLt7zaAikAejKIRGIEriUMASSgl7dWARSF28cpAHeKUMikBT0lLE4iBK4BmEIpAHoCKQB6MohEYgSuJQwBJKCXt1YBFIXb3qQBninDIlAUtBTxuIgSuAahCGQBqAjkAagK4dEIErgUsIQSAp6dWMRSF286UEa4J0yJAJJQU8Zi4MogWsQhkAagI5AGoCuHBKBKIFLCUMgKejVjUUgdfGmB2mAd8qQCCQFPWUsDqIErkEYAmkAOgJpALpySASiBC4lDIGkoFc3FoHUxZsepAHeKUMikBT0lLE4iBK4BmEIpAHoCKQB6MohEYgSuJQwBJKCXt1YBFIXb3qQBninDIlAUtBTxuIgSuAahCGQBqAjkAagK4dEIErgUsIQSAp6dWMRSF286UEa4J0yJAJJQU8Zi4MogWsQhkAagI5AGoCuHBKBKIFLCUMgKejVjUUgdfGmB2mAd8qQCCQFPWUsDqIErkFY9wKJuhSzAXBJQxa+xDNpbpWDe79wtCuBzJn1y9vtr71dq1yZOKsbrtNrq7sQSLd3ja+Opf0seLr2+uH64rb1jJoK5N0xcIvWPOh2/NZCaSaQq18vTw5hdEvMnibWUiTVBYJr9ES9gebi3fbx+/ll7RlXF8jV/UuovUjGM4JAA5FUFQhllRGitlxGZZFUE8h8UuXejnBbAszYwyNQsyepIhDEMTwnu1uAfw2XNT4yVhEIfUd3/Bp/QpVKreICwT3G52KvK6jhIsUFgnv0Si8D86rgIkUFovnV6odtm36f8yfcGdjKj0vgx4p/8Thzm+mvlMObx+vzohwu+nJ1eVUhM7QUnSZx1CgnmmKiPOUsjUtRgWi+e9Q8wmtFCARyGHkNX1zhZFpWIIqv5qUts5Uo9sdFIId3QYPLqgSyBveYqKEhQulSoofEMc1B4yIlk2oxB4EExykHNnmxWY1ASi60lwyJgyzvRG/JoysHQSDHybOWEguBLCQQBIJAEAgCoUlf4AACQSAIBIHojjIpsSixcBAcBAfBQXCQpcPM3rIkR+ALzl0KHA0JKLEosTS8KXkEzneQUhlioDKiAQRHh0Qg9CD0IAMlDxykQfrsLUs2gAAH0ZCAHoQeRMMbepCeUlyGufRGggxLyvaK3rChxMq2tfEv6o0E8TMv/2Rv2CCQ8nv+aYTeSNAAAnoQDQnoQehBNLyhB+kpxWWYS28kyLCkbK/oDRtKrGxbG/+i3kgQP/PyT/aGDQIpv+f0ICdgjED4ks6XdL6k82vepaTZW5Y8IcEXf7Q3bCixim/55wF6I0EDCDjm1ZCAY16OeTW84Zi3pxSXYS69kSDDkrK9ojdsKLGybW38i3ojQfzMyz/ZGzYIpPyec8x7AsYIhGNejnk55uWYl2PeE2xj71EcBAfBQXAQHAQHWaGDTPYXvWzNRZWv4VJ6f43L46U5HPvv0fhosHHhzr26bczcesUoCp/C2Ez4nYLP4inWXA9+8TfzpoS/N5L28me6jWpe7PXFbcs5vWPUGT7T1WQ+hN/gc4QdkfgcFEi3m350reGuNhHUN/g2UHOLq+2s4PNJIJpThAZ7/mnIWiQYLXnsA1XyJxn742juGeyVQx8EMpLqDwJa+ErgUZNHTZGMKo4dRv8m2neBWNj8eZEFRXKluNa6h8z47xxKOcno4ngXyWu43DXy7wKxsvl/NZK/JxneXT/YiNs+fj8XTwxPEbcpfJxzu1+WzwKxtrhZJHtZ4JSNPvQs+MgIWkqw+0l2Foi1xeUutSwKJGcpahKfNxfxVhc3iSTXP8AymUAyuqxlfEwLJEeZZTmBgI9QOk4fE62cPBxaao5m3bJAcpRZ1vHxVu0x12mW5QSCQGIcxMjZfikHQSDLJDLtIFOfhoMsEwCBrBgfBBJxvv/r5am3XzLLs458IsOvDkwnEAQiE8k0ARCISABKLAEiBEKJFUQZDfpAjmNeBIJAEMgCBxAIAkEgCERdI5hOIDTpMi9ME4AmXSQATTpNetK/CzGdQHAQMYE40wTAQUQC4CA4CA6ywAEEgkAQCAIRnfToA5RYHPNyzMsxrzqDmE4gNOkyL0wTgCZdJAA9CD0IPQg9iJgo6EGUEJl2WEosmRWmCUCJJRKAEosSixKLEktMFJRYSohMOywllswK0wSgxBIJQIlFiUWJRYklJgpKLCVEph2WEktmhWkCUGKJBKDEosSixKLEEhMFJZYSItMOS4kls8I0ASixRAJQYlFiUWJRYomJghJLCZFph6XEkllhmgCUWCIBKLEosSixKLHEREGJpYTI9P0gXMEms8IyAXL8v4st4zPdwGX6jsIct9x++/m8CWf+SZbSeE9kEYhxfLxlAuQQyER7q7dwgc9yUptuAfYzAQzeopQjO+7gA59lIlkts6YEMgvEoovkyo5W8cmZQCy67A6fWSDWXCT35s8iuX++Dc7fjNdpfJ4x+Ai7uPd96F0gVrJAic03lUQyfBw8Ri8rSWS/+vggkNFLrZLiMCGSguLY4TO6SKbG/OHHxXa3ng8CGZkENcQxNAkqiMMiPgcFMlTNPX3M+RPu9lVfo0+YMuU0Tvd9CfgIZ7nL/DkqkP1sMBPB+68uuE0N8i2O4d1sf5Mopr9rC+PfuU1lqTtzm27wmcH5HyPwOcCmE/D5D03e6Azd7SodAAAAAElFTkSuQmCC", pl = { class: "process-header-container" }, Il = { class: "header-icon-container" }, yl = ["src"], hl = {
  key: 0,
  style: {
    "margin-left": "8px",
    "line-height": "22px"
  }
}, Cl = 55, K = 50, El = /* @__PURE__ */ tl({
  __name: "ProcessDesignModal",
  emits: ["register", "close"],
  setup(Ql, { expose: he, emit: Ce }) {
    const Ee = Ce, ke = ml(), { createMessage: x, createConfirmSync: T } = dl(), r = A(), t = A(), se = A({
      nodes: [],
      edges: []
    }), p = A(!1), k = A(!0), P = A(!1), Qe = C(() => {
      var e;
      return (e = t.value) === null || e === void 0 ? void 0 : e.id;
    });
    al("$flowId", Qe);
    const Q = C({
      get: () => {
        var e;
        return (e = t.value) === null || e === void 0 ? void 0 : e.name;
      },
      set: (e) => t.value.name = e
    }), M = C(() => {
      var e;
      return ((e = t.value) === null || e === void 0 ? void 0 : e.status) === "release";
    }), Se = C(() => {
      var e;
      return Ge((e = t.value) === null || e === void 0 ? void 0 : e.icon);
    }), [xe, { closeModal: Me }] = fl(Ue), Be = C(() => {
      let e = {
        title: Q.value,
        width: 800,
        zIndex: 999,
        bodyStyle: { padding: "0" },
        wrapClassName: "ai-rag-process-design-modal",
        confirmLoading: p.value,
        footer: null,
        draggable: !1,
        maskClosable: !1,
        canFullscreen: !1,
        destroyOnClose: !0,
        defaultFullscreen: !0,
        closeFunc: Te,
        modalHeaderHeight: 29
      };
      return U(U(U({ keyboard: !0 }, e), L(ke)), {}, {
        onCancel: me,
        "onUpdate:open": Ne,
        onRegister: xe
      });
    }), de = A(), B = C(() => ({
      data: se.value,
      width: window.innerWidth,
      height: window.innerHeight - Cl,
      openCheckListPop: () => {
        var e, l;
        return (e = de.value) === null || e === void 0 || (l = e.openPop) === null || l === void 0 ? void 0 : l.call(e);
      }
    })), ve = A(), De = C(() => ({
      title: Q.value,
      "onUpdate:title": (e) => Q.value = e,
      handleCustomEdit() {
        We();
      },
      promptProps: {
        title: "修改流程名称",
        defaultValue: Q.value,
        placeholder: "请输入流程名称",
        rules: [
          {
            required: !0,
            message: "请输入流程名称！"
          },
          {
            pattern: /^(?!未命名$).+$/,
            message: "请输入流程名称！"
          },
          {
            max: 12,
            message: "流程名称不能超过12个字符！"
          }
        ]
      }
    }));
    let O = "";
    function Ue(e) {
      return N.apply(this, arguments);
    }
    function N() {
      return N = h(function* (e) {
        var l, i;
        if (k.value = !0, t.value = e == null ? void 0 : e.record, P.value = !!L(e == null ? void 0 : e.isUpdate), P.value) {
          var o;
          if (!((o = e.record) === null || o === void 0) && o.id) try {
            const n = yield w.queryById(e.record.id);
            n && (t.value = n);
          } catch (n) {
            x.error("查询流程详情失败"), k.value = !1;
            return;
          }
        } else {
          const n = Math.round(B.value.height / 2);
          t.value = {
            name: e.record.name ? e.record.name : "未命名",
            descr: e.record.descr ? e.record.descr : "",
            icon: e.record.icon ? e.record.icon : "",
            design: JSON.stringify({
              nodes: [Ae({
                x: 300,
                y: n
              })],
              edges: []
            }),
            chain: ""
          };
        }
        if (!(!((l = t.value) === null || l === void 0) && l.design)) {
          const n = Math.round(B.value.height / 2);
          t.value.design = JSON.stringify({
            nodes: [Ae({
              x: 300,
              y: n
            })],
            edges: []
          });
        }
        se.value = JSON.parse(t.value.design), yield ue(), yield ye(300), k.value = !1, yield ue(), yield ye(300), O = JSON.stringify((i = r.value) === null || i === void 0 ? void 0 : i.getGraphData());
      }), N.apply(this, arguments);
    }
    function Pe() {
      ue(() => Je());
    }
    function Je() {
      if (!r.value) return;
      const e = M.value;
      r.value.setSilentMode(e);
    }
    function we() {
      r.value && r.value.doDebugRun();
    }
    function J(e) {
      return F.apply(this, arguments);
    }
    function F() {
      return F = h(function* (e) {
        if (M.value) {
          var l;
          x.warning("流程已发布，不允许保存"), e == null || (l = e.onError) === null || l === void 0 || l.call(e);
          return;
        }
        if (r.value)
          try {
            var i;
            const n = r.value.validateData();
            if ((!((i = e == null ? void 0 : e.needName) !== null && i !== void 0) || i) && Q.value === "未命名") {
              ve.value.showPrompt(() => ge(n, e), () => {
                var u;
                return e == null || (u = e.onError) === null || u === void 0 ? void 0 : u.call(e);
              });
              return;
            }
            yield ge(n, e);
          } catch (n) {
            var o;
            x.error((n == null ? void 0 : n.message) || n), e == null || (o = e.onError) === null || o === void 0 || o.call(e, n);
          }
      }), F.apply(this, arguments);
    }
    function Re() {
      return b.apply(this, arguments);
    }
    function b() {
      return b = h(function* () {
        r.value && r.value.checkProblemCount("发布") && (yield T({
          title: "发布流程",
          content: "确定要发布流程吗？发布后将不允许修改流程。",
          okText: "确定",
          cancelText: "取消"
        })) && ce(!0);
      }), b.apply(this, arguments);
    }
    function Le() {
      return W.apply(this, arguments);
    }
    function W() {
      return W = h(function* () {
        r.value && (yield T({
          title: "取消发布流程",
          content: "确定要取消发布流程吗？取消后将允许修改流程。",
          okText: "确定",
          cancelText: "取消"
        })) && ce(!1);
      }), W.apply(this, arguments);
    }
    function ce(e) {
      return j.apply(this, arguments);
    }
    function j() {
      return j = h(function* (e) {
        try {
          p.value = !0;
          let n;
          if (e ? (yield J({ silent: !0 }), n = yield w.releaseProcess(t.value.id)) : n = yield w.unreleaseProcess(t.value.id), n)
            if (e) {
              var l, i;
              t.value.status = "release", (l = r.value) === null || l === void 0 || l.setSilentMode(!0), (i = r.value) === null || i === void 0 || i.closeSettingDrawer();
            } else {
              var o;
              t.value.status = "enable", (o = r.value) === null || o === void 0 || o.setSilentMode(!1);
            }
        } finally {
          p.value = !1;
        }
      }), j.apply(this, arguments);
    }
    function ge(e, l) {
      return G.apply(this, arguments);
    }
    function G() {
      return G = h(function* (e, l) {
        if (M.value) {
          var i;
          x.warning("流程已发布，不允许保存"), l == null || (i = l.onError) === null || i === void 0 || i.call(l);
          return;
        }
        p.value = !0;
        try {
          var o;
          t.value.design = JSON.stringify(e);
          try {
            t.value.chain = r.value.getLiteFlowData();
          } catch (d) {
            x.error((d == null ? void 0 : d.message) || d);
            return;
          }
          const n = l == null ? void 0 : l.silent, u = (o = l == null ? void 0 : l.saveFn) !== null && o !== void 0 ? o : w.saveOrUpdate, m = l == null ? void 0 : l.savedFb, g = yield u(t.value, P.value, { silent: n });
          g && (t.value = g, P.value = !0, O = t.value.design, m && m({ result: g }));
        } finally {
          p.value = !1;
        }
      }), G.apply(this, arguments);
    }
    function fe(e) {
      var l;
      if (!e) return null;
      const i = JSON.parse(JSON.stringify(e));
      return (l = i.edges) === null || l === void 0 || l.forEach((o) => {
        delete o.startPoint, delete o.endPoint, delete o.pointsList, o.properties && delete o.properties.runStatus;
      }), i;
    }
    function Ke(e, l) {
      var i, o, n, u, m, g, d, D;
      const v = fe(e), c = fe(l);
      if (!v || !c) return v !== c;
      if (((i = v.nodes) === null || i === void 0 ? void 0 : i.length) !== ((o = c.nodes) === null || o === void 0 ? void 0 : o.length) || ((n = v.edges) === null || n === void 0 ? void 0 : n.length) !== ((u = c.edges) === null || u === void 0 ? void 0 : u.length)) return !0;
      for (let f = 0; f < ((m = (g = v.nodes) === null || g === void 0 ? void 0 : g.length) !== null && m !== void 0 ? m : 0); f++) {
        var z, _, Y, X, Z, q, V, $, ee, le, ne, oe;
        const I = v.nodes[f], y = c.nodes[f];
        if (I.id !== y.id || I.type !== y.type || Math.abs(((z = I.x) !== null && z !== void 0 ? z : 0) - ((_ = y.x) !== null && _ !== void 0 ? _ : 0)) > K || Math.abs(((Y = I.y) !== null && Y !== void 0 ? Y : 0) - ((X = y.y) !== null && X !== void 0 ? X : 0)) > K || Math.abs(((Z = (q = I.properties) === null || q === void 0 ? void 0 : q.width) !== null && Z !== void 0 ? Z : 0) - ((V = ($ = y.properties) === null || $ === void 0 ? void 0 : $.width) !== null && V !== void 0 ? V : 0)) > K || Math.abs(((ee = (le = I.properties) === null || le === void 0 ? void 0 : le.height) !== null && ee !== void 0 ? ee : 0) - ((ne = (oe = y.properties) === null || oe === void 0 ? void 0 : oe.height) !== null && ne !== void 0 ? ne : 0)) > K) return !0;
        const te = U({}, I.properties), ie = U({}, y.properties);
        if (delete te.width, delete te.height, delete ie.width, delete ie.height, JSON.stringify(te) !== JSON.stringify(ie)) return !0;
      }
      for (let f = 0; f < ((d = (D = v.edges) === null || D === void 0 ? void 0 : D.length) !== null && d !== void 0 ? d : 0); f++) if (JSON.stringify(v.edges[f]) !== JSON.stringify(c.edges[f])) return !0;
      return !1;
    }
    function Te() {
      return H.apply(this, arguments);
    }
    function H() {
      return H = h(function* () {
        var e;
        return Ke((e = r.value) === null || e === void 0 ? void 0 : e.getGraphData(), JSON.parse(O || "{}")) ? yield T({
          title: "尚未保存",
          content: "流程已修改，并且尚未保存，确定要关闭吗？",
          okText: "确定",
          cancelText: "取消"
        }) : !0;
      }), H.apply(this, arguments);
    }
    function me() {
      Me();
    }
    function Oe() {
      k.value = !0, Ee("close");
    }
    function Ne(e) {
      e || Oe();
    }
    he({ onSubmit: J });
    const [Fe, be] = gl();
    function We() {
      var e, l, i, o, n;
      const u = !!(!((e = t.value) === null || e === void 0) && e.id);
      be.openModal(!0, {
        isUpdate: u,
        record: {
          id: (l = t.value) === null || l === void 0 ? void 0 : l.id,
          name: (i = t.value) === null || i === void 0 ? void 0 : i.name,
          icon: (o = t.value) === null || o === void 0 ? void 0 : o.icon,
          descr: (n = t.value) === null || n === void 0 ? void 0 : n.descr
        }
      });
    }
    function je(e) {
      t.value || (t.value = {}), t.value.name = e.name, t.value.descr = e.descr, t.value.icon = e.icon;
    }
    function Ge(e) {
      return e ? vl(e) : Al;
    }
    return (e, l) => {
      const i = ae("a-button"), o = ae("a-icon"), n = ll, u = ae("Icon"), m = $e, g = Ve, d = qe, D = el, v = nl;
      return E(), re(ol, null, [a(L(cl), rl(il(Be.value)), {
        title: s(() => [S("div", pl, [
          S("div", Il, [S("img", { src: Se.value }, null, 8, yl)]),
          l[8] || (l[8] = S("div", { class: "header-icon-placeholder" }, null, -1)),
          M.value ? (E(), re("span", hl, sl(Q.value), 1)) : (E(), R(_e, Ie({
            key: 1,
            ref_key: "titleEditorRef",
            ref: ve
          }, De.value), null, 16)),
          a(n, { class: "action-container" }, {
            default: s(() => {
              var c;
              return [
                a(Ze, {
                  ref_key: "checkPopRef",
                  ref: de,
                  nodeChecklist: (c = r.value) === null || c === void 0 ? void 0 : c.nodeChecklist
                }, null, 8, ["nodeChecklist"]),
                a(i, {
                  preIcon: "codicon:debug-start",
                  onClick: we
                }, {
                  default: s(() => [...l[4] || (l[4] = [pe("调试", -1)])]),
                  _: 1
                }),
                M.value ? (E(), R(i, {
                  key: 0,
                  preIcon: "tabler:rocket-off",
                  onClick: Le
                }, {
                  default: s(() => [...l[5] || (l[5] = [pe("取消发布", -1)])]),
                  _: 1
                })) : (E(), R(d, {
                  key: 1,
                  type: "primary",
                  loading: p.value,
                  onClick: l[0] || (l[0] = () => J())
                }, {
                  overlay: s(() => [a(g, null, {
                    default: s(() => [a(m, { onClick: Re }, {
                      default: s(() => [a(n, null, {
                        default: s(() => [a(u, { icon: "lineicons:rocket-5" }), l[7] || (l[7] = S("span", null, "发布", -1))]),
                        _: 1
                      })]),
                      _: 1
                    })]),
                    _: 1
                  })]),
                  default: s(() => [a(n, null, {
                    default: s(() => [a(o, { type: "save" }), l[6] || (l[6] = S("span", null, "保存", -1))]),
                    _: 1
                  })]),
                  _: 1
                }, 8, ["loading"]))
              ];
            }),
            _: 1
          })
        ])]),
        default: s(() => [a(v, { spinning: p.value && !k.value }, {
          default: s(() => [k.value ? (E(), R(D, {
            key: 0,
            active: !0
          })) : (E(), re("div", {
            key: 1,
            class: "ai-rag-lf-container",
            style: ul({
              width: B.value.width + "px",
              height: B.value.height + "px"
            })
          }, [a(Ye, Ie({
            ref_key: "flowRef",
            ref: r
          }, B.value, {
            onInit: l[1] || (l[1] = () => Pe()),
            onSave: l[2] || (l[2] = () => J()),
            onClose: l[3] || (l[3] = () => me())
          }), null, 16)], 4))]),
          _: 1
        }, 8, ["spinning"])]),
        _: 1
      }, 16), a(Xe, {
        onRegister: L(Fe),
        onOk: je
      }, null, 8, ["onRegister"])], 64);
    };
  }
}), Ol = /* @__PURE__ */ He({ default: () => kl }), kl = El;
export {
  Ol as n,
  kl as t
};
