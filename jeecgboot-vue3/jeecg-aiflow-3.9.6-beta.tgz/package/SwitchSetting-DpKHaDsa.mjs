import { a as G, n as H, t as M } from "./objectSpread2-B0BetFB8.mjs";
import { t as K } from "./_plugin-vue_export-helper-Dj7HTbfw.mjs";
import { t as W } from "./VarPicker-HOsUWkU-.mjs";
import { t as X } from "./VarListShow-Dg1oan43.mjs";
import { t as Z } from "./useSettings-Cq_-E7Ut.mjs";
import "./Vars-Cgan49KR.mjs";
import { Divider as ee, Input as te, RadioButton as oe, RadioGroup as le, Select as ae, SelectOption as ne, Tooltip as ie } from "ant-design-vue/es";
import { Fragment as O, computed as re, createBlock as se, createCommentVNode as $, createElementBlock as m, createElementVNode as a, createTextVNode as U, createVNode as p, defineComponent as de, normalizeClass as ue, openBlock as f, ref as pe, renderList as B, resolveComponent as ce, toDisplayString as R, unref as s, watch as D, withCtx as h } from "vue";
import { useMessage as ve } from "/@/hooks/web/useMessage";
import V from "/@/components/Icon";
import { PlusOutlined as fe } from "@ant-design/icons-vue";
H();
var xe = /* @__PURE__ */ G({
  getAnchorId: () => k,
  getAnchorIdByChooseIndex: () => ge,
  getCaseList: () => _e
});
function _e(_) {
  var v, c;
  const E = [], I = (v = (c = _.properties) === null || c === void 0 ? void 0 : c.options) !== null && v !== void 0 ? v : {};
  return Array.isArray(I.if) && E.push(...I.if.map((C, n) => ({
    type: n === 0 ? "IF" : "ELIF",
    label: `CASE ${n + 1}`,
    remarks: C.remarks || "",
    value: C
  }))), I.else && E.push({
    type: "ELSE",
    label: "ELSE",
    value: I.else
  }), E;
}
function k(_, v, c) {
  return `${_}_${v === "IF" ? "source_if" : v === "ELSE" ? "source_else" : `case_${c}`}`;
}
function ge(_, v) {
  return k(_, v === -1 ? "ELSE" : v === 0 ? "IF" : "ELIF", v + 1);
}
var me = [
  {
    label: "等于",
    value: "EQUALS"
  },
  {
    label: "不等于",
    value: "NOT_EQUALS"
  },
  {
    label: "包含",
    value: "CONTAINS"
  },
  {
    label: "不包含",
    value: "NOT_CONTAINS"
  },
  {
    label: "小于",
    value: "LT"
  },
  {
    label: "小于等于",
    value: "LTE"
  },
  {
    label: "大于",
    value: "GT"
  },
  {
    label: "大于等于",
    value: "GTE"
  },
  {
    label: "长度等于",
    value: "LEN_EQ"
  },
  {
    label: "长度小于",
    value: "LEN_LT"
  },
  {
    label: "长度小于等于",
    value: "LEN_LTE"
  },
  {
    label: "长度大于",
    value: "LEN_GT"
  },
  {
    label: "长度大于等于",
    value: "LEN_GTE"
  },
  {
    label: "为空",
    value: "EMPTY"
  },
  {
    label: "不为空",
    value: "NOT_EMPTY"
  }
], he = { class: "switch-setting" }, be = { class: "setting-item" }, ye = { class: "label case-label" }, Ee = { class: "c-type" }, Ie = { class: "c-label" }, Se = { class: "condition-item" }, Ae = { class: "condition-item-logic" }, Le = ["onClick"], ke = { class: "field" }, Ce = { class: "operator" }, Ne = {
  key: 0,
  class: "value"
}, Te = ["onClick"], Oe = {
  class: "condition-action",
  style: {
    width: "100%",
    "margin-bottom": "10px"
  }
}, we = ["onClick"], $e = { class: "setting-item" }, Ue = /* @__PURE__ */ de({
  __name: "SwitchSetting",
  props: {
    type: {
      type: String,
      required: !0
    },
    node: {
      type: Object,
      required: !0
    },
    properties: {
      type: Object,
      required: !0
    },
    isSilentMode: {
      type: Boolean,
      required: !0
    },
    setProperties: {
      type: Function,
      required: !0
    }
  },
  setup(_) {
    const { createMessage: v } = ve(), c = _, { lfRef: E, prevVariables: I, outputParams: C, isReadOnly: n } = Z(c), S = re(() => {
      var t;
      const { properties: e } = c;
      return Array.isArray(e == null || (t = e.options) === null || t === void 0 ? void 0 : t.if) ? e.options.if : [];
    });
    D(S, () => {
      const { properties: t, setProperties: e } = c;
      e({ options: M(M({}, t.options), {}, { if: S.value }) });
    }, { deep: !0 });
    function q() {
      var t;
      if (n.value) return;
      const { properties: e } = c;
      Array.isArray(e == null || (t = e.options) === null || t === void 0 ? void 0 : t.if) || (e.options.if = []), e.options.if.push({
        logic: "AND",
        conditions: [],
        next: ""
      }), P(e.options.if.length - 1);
    }
    function P(t) {
      n.value || c.properties.options.if[t].conditions.push({
        nodeId: "",
        field: "",
        operator: "EQUALS",
        value: ""
      });
    }
    function j(t, e) {
      if (n.value) return;
      const { properties: l } = c, d = l.options.if[t];
      if (d.conditions.length === 1) {
        v.warning("请至少保留一个条件");
        return;
      }
      d.conditions.splice(e, 1);
    }
    const N = pe([]);
    function Q() {
      const t = S.value || [], e = [];
      for (let r = 0; r < t.length; r++) {
        const g = t[r] && t[r].remarks;
        if (typeof g == "string") e.push(g);
        else {
          var l, d;
          const A = ((l = c.node) === null || l === void 0 ? void 0 : l.$caseList) || [];
          e.push(((d = A[r]) === null || d === void 0 ? void 0 : d.remarks) || "");
        }
      }
      N.value = e;
    }
    D(S, () => Q(), {
      deep: !0,
      immediate: !0
    });
    function Y(t, e) {
      if (n.value) return;
      const { properties: l, setProperties: d } = c, r = l.options.if[e];
      r && (r.remarks = t, d({ options: l.options }));
    }
    function F(t) {
      return t === "EMPTY" || t === "NOT_EMPTY";
    }
    function x(t, e) {
      F(e) && (t.value = "");
    }
    function z(t, e, l) {
      n.value || (l != null && l.nodeId ? (t.nodeId = l.nodeId, t.field = l.field) : (t.nodeId = "", t.field = ""));
    }
    function J(t) {
      var e;
      if (n.value) return;
      const { properties: l, node: d } = c;
      if (l.options.if.length === 1) {
        v.warning("请至少保留一个 IF 分支");
        return;
      }
      if (!E.value) return;
      const r = E.value.graphModel, { $caseList: g } = d, { type: A } = g[t], w = k(d.id, A, t + 1), b = r.getAnchorOutgoingEdge(w);
      !(b == null || (e = b[0]) === null || e === void 0) && e.id && r.deleteEdgeById(b[0].id);
      const L = [];
      for (let o = t + 1; o < g.length; o++) {
        var y;
        const { type: i } = g[o];
        if (i === "ELSE") continue;
        const T = k(d.id, i, o + 1), u = r.getAnchorOutgoingEdge(T);
        !(u == null || (y = u[0]) === null || y === void 0) && y.id && L.push({
          edge: u[0],
          newSourceAnchorId: k(d.id, o === 1 ? "IF" : "", o)
        });
      }
      l.options.if.splice(t, 1), L.length && setTimeout(() => {
        for (const o of L) {
          const i = {
            id: o.edge.id,
            type: o.edge.type,
            sourceNodeId: o.edge.sourceNodeId,
            targetNodeId: o.edge.targetNodeId,
            sourceAnchorId: o.newSourceAnchorId,
            targetAnchorId: o.edge.targetAnchorId
          };
          r.deleteEdgeById(o.edge.id), r.addEdge(i);
        }
        r.$J.repaintGraph();
      }, 10);
    }
    return (t, e) => {
      const l = te, d = oe, r = le, g = ie, A = ne, w = ae, b = ee, L = ce("a-button");
      return f(), m("div", he, [
        (f(!0), m(O, null, B(S.value, (y, o) => (f(), m(O, { key: o }, [a("div", be, [
          a("div", ye, [a("div", Ee, R(_.node.$caseList[o].type), 1), a("div", Ie, [p(l, {
            value: N.value[o],
            "onUpdate:value": (i) => N.value[o] = i,
            size: "small",
            bordered: !1,
            placeholder: _.node.$caseList[o].label,
            disabled: s(n),
            onBlur: () => Y(N.value[o] || "", o)
          }, null, 8, [
            "value",
            "onUpdate:value",
            "placeholder",
            "disabled",
            "onBlur"
          ])])]),
          a("div", Se, [a("div", Ae, [p(r, {
            value: y.logic,
            "onUpdate:value": (i) => y.logic = i,
            "button-style": "solid",
            size: "small",
            disabled: s(n)
          }, {
            default: h(() => [p(d, { value: "AND" }, {
              default: h(() => [...e[0] || (e[0] = [U("AND", -1)])]),
              _: 1
            }), p(d, { value: "OR" }, {
              default: h(() => [...e[1] || (e[1] = [U("OR", -1)])]),
              _: 1
            })]),
            _: 1
          }, 8, [
            "value",
            "onUpdate:value",
            "disabled"
          ]), p(g, {
            title: "移除分支",
            placement: "left"
          }, {
            default: h(() => [s(n) ? $("", !0) : (f(), m("div", {
              key: 0,
              class: "remove-case",
              onClick: (i) => J(o)
            }, [p(s(V), { icon: "ant-design:delete" })], 8, Le))]),
            _: 2
          }, 1024)]), (f(!0), m(O, null, B(y.conditions, (i, T) => (f(), m("div", {
            key: T,
            class: "condition-item-component"
          }, [
            a("div", ke, [p(s(W), {
              item: i,
              vars: s(I),
              readonly: s(n),
              onChange: (u) => z(i, o, u)
            }, null, 8, [
              "item",
              "vars",
              "readonly",
              "onChange"
            ])]),
            a("div", Ce, [p(w, {
              value: i.operator,
              "onUpdate:value": (u) => i.operator = u,
              style: { width: "100%" },
              disabled: s(n),
              onChange: (u) => x(i, u)
            }, {
              default: h(() => [(f(!0), m(O, null, B(s(me), (u) => (f(), se(A, {
                key: u.value,
                value: u.value
              }, {
                default: h(() => [U(R(u.label), 1)]),
                _: 2
              }, 1032, ["value"]))), 128))]),
              _: 1
            }, 8, [
              "value",
              "onUpdate:value",
              "disabled",
              "onChange"
            ])]),
            F(i.operator) ? $("", !0) : (f(), m("div", Ne, [p(l, {
              value: i.value,
              "onUpdate:value": (u) => i.value = u,
              placeholder: "请输入值",
              disabled: s(n)
            }, null, 8, [
              "value",
              "onUpdate:value",
              "disabled"
            ])])),
            p(g, {
              title: "移除条件",
              placement: "left"
            }, {
              default: h(() => [s(n) ? $("", !0) : (f(), m("div", {
                key: 0,
                class: "action",
                onClick: () => j(o, T)
              }, [p(s(V), { icon: "ant-design:delete" })], 8, Te))]),
              _: 2
            }, 1024)
          ]))), 128))]),
          a("div", Oe, [a("a", {
            type: "text",
            onClick: () => P(o),
            class: ue({ disabled: s(n) })
          }, [p(s(fe)), e[2] || (e[2] = a("span", { style: { "margin-left": "6px" } }, "添加条件", -1))], 10, we)])
        ]), p(b, { style: { margin: "4px 0 8px 0" } })], 64))), 128)),
        a("div", null, [p(L, {
          block: "",
          preIcon: "ant-design:plus",
          onClick: q,
          disabled: s(n)
        }, {
          default: h(() => [...e[3] || (e[3] = [a("span", null, "添加分支", -1)])]),
          _: 1
        }, 8, ["disabled"])]),
        p(b, { style: { margin: "8px 0 8px 0" } }),
        e[5] || (e[5] = a("div", { class: "setting-item" }, [a("div", { class: "label case-label" }, [a("div", { class: "c-type" }, "ELSE")]), a("div", { style: { color: "#aaaaaa" } }, [a("span", null, "当以上条件都不满足时，执行此分支")])], -1)),
        a("div", $e, [e[4] || (e[4] = a("div", { class: "label" }, "输出变量", -1)), p(s(X), { vars: s(C) }, null, 8, ["vars"])])
      ]);
    };
  }
}), ze = /* @__PURE__ */ G({ default: () => Be }), Be = /* @__PURE__ */ K(Ue, [["__scopeId", "data-v-4406c148"]]);
export {
  xe as a,
  _e as i,
  ze as n,
  k as r,
  Be as t
};
