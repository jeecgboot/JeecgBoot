import { a as w } from "./objectSpread2-B0BetFB8.mjs";
import { t as P } from "./_plugin-vue_export-helper-Dj7HTbfw.mjs";
import { t as L } from "./NodeIcon-I60YeJ6p.mjs";
import { Badge as N, Empty as A, Popover as B, Space as V } from "ant-design-vue/es";
import { Fragment as u, computed as E, createBlock as v, createCommentVNode as I, createElementBlock as s, createElementVNode as o, createTextVNode as j, createVNode as a, defineComponent as S, openBlock as n, ref as T, renderList as m, resolveComponent as D, toDisplayString as f, withCtx as r } from "vue";
var F = { class: "j-ai-flow-check-list-pop" }, M = ["onClick"], R = { class: "check-header" }, U = { class: "node-name airag-node-label" }, q = { class: "problem-container" }, z = { class: "problem-item" }, G = { class: "problem-text" }, H = /* @__PURE__ */ S({
  __name: "CheckListPop",
  props: { nodeChecklist: { type: Array } },
  setup(p, { expose: k }) {
    const c = p, l = T(!1), i = E(() => Array.isArray(c.nodeChecklist) ? c.nodeChecklist.flatMap(({ problems: d }) => d).length : 0);
    function h() {
      l.value = !0;
    }
    return k({ openPop: h }), (d, t) => {
      const _ = V, C = A, g = D("a-button"), y = N, b = B;
      return n(), v(b, {
        open: l.value,
        "onUpdate:open": t[0] || (t[0] = (e) => l.value = e),
        title: "问题清单",
        placement: "bottomRight",
        arrow: !1,
        trigger: "click"
      }, {
        content: r(() => [o("div", F, [(n(!0), s(u, null, m(p.nodeChecklist, (e) => (n(), s("div", {
          key: e.node.id,
          class: "j-ai-flow-check-list-pop-node",
          onClick: () => {
            e.onClick(), l.value = !1;
          }
        }, [o("div", R, [a(_, { class: "node-icon-wrapper" }, {
          default: r(() => [a(L, { type: e.node.type }, null, 8, ["type"]), o("div", U, f(e.nodeText), 1)]),
          _: 2
        }, 1024)]), o("div", q, [(n(!0), s(u, null, m(e.problems, (x) => (n(), s("div", z, [a(_, null, {
          default: r(() => [t[1] || (t[1] = o("div", { class: "warning-icon" }, "⚠", -1)), o("div", G, f(x), 1)]),
          _: 2
        }, 1024)]))), 256))])], 8, M))), 128)), i.value == 0 ? (n(), v(C, {
          key: 0,
          description: "暂未发现问题"
        })) : I("", !0)])]),
        default: r(() => [a(y, {
          count: i.value,
          offset: [-4, 4],
          overflowCount: 9
        }, {
          default: r(() => [a(g, { preIcon: "mingcute:list-check-3-line" }, {
            default: r(() => [...t[2] || (t[2] = [j("问题", -1)])]),
            _: 1
          })]),
          _: 1
        }, 8, ["count"])]),
        _: 1
      }, 8, ["open"]);
    };
  }
}), Y = /* @__PURE__ */ w({ default: () => J }), J = /* @__PURE__ */ P(H, [["__scopeId", "data-v-a4b70695"]]);
export {
  Y as n,
  J as t
};
