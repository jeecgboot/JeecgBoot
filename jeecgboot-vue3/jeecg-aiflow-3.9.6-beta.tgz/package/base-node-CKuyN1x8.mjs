import { a as Ou, n as wu, o as Su, r as Ks, s as Zs, t as ca } from "./objectSpread2-B0BetFB8.mjs";
import { t as Au } from "./const-OjvoZKjM.mjs";
import { n as Mu } from "./propStore-CR0aJ5bA.mjs";
import { i as Bo } from "./NodeContainer-zpIyuhKY.mjs";
import "./NodeKV-DCNHOs9C.mjs";
import "./NodeKVS-CRVYjcYN.mjs";
import * as Pu from "vue";
import { assign as U, clamp as Tu, cloneDeep as R, debounce as qs, find as Ue, forEach as pt, get as He, has as da, indexOf as Nu, isArray as Ii, isBoolean as $n, isEmpty as qr, isEqual as fa, isFunction as ki, isNil as yt, isNumber as Js, isObject as Du, isUndefined as cr, last as Cu, map as ce, mapKeys as Lu, merge as Bi, noop as Sn, pick as rr, random as ju, reduce as Ru, round as pa, set as Iu, throttle as Qs, toPairs as Ne } from "lodash-es";
import * as Tv from "vue";
var yn, H, tl, ku, Re, ha, el, rl, ol, Xi, Un, Vn, Bu, Jr = {}, nl = [], Xu = /acit|ex(?:s|g|n|p|$)|rph|grid|ows|mnc|ntw|ine[ch]|zoo|^ord|itera/i, lo = Array.isArray;
function he(r, t) {
  for (var e in t) r[e] = t[e];
  return r;
}
function Yi(r) {
  r && r.parentNode && r.parentNode.removeChild(r);
}
function Ot(r, t, e) {
  var o, n, i, a = {};
  for (i in t) i == "key" ? o = t[i] : i == "ref" ? n = t[i] : a[i] = t[i];
  if (arguments.length > 2 && (a.children = arguments.length > 3 ? yn.call(arguments, 2) : e), typeof r == "function" && r.defaultProps != null) for (i in r.defaultProps) a[i] === void 0 && (a[i] = r.defaultProps[i]);
  return Xo(r, a, o, n, null);
}
function Xo(r, t, e, o, n) {
  var i = {
    type: r,
    props: t,
    key: e,
    ref: o,
    __k: null,
    __: null,
    __b: 0,
    __e: null,
    __c: null,
    constructor: void 0,
    __v: n == null ? ++tl : n,
    __i: -1,
    __u: 0
  };
  return n == null && H.vnode != null && H.vnode(i), i;
}
function Hi() {
  return { current: null };
}
function dr(r) {
  return r.children;
}
function V(r, t) {
  this.props = r, this.context = t;
}
function fr(r, t) {
  if (t == null) return r.__ ? fr(r.__, r.__i + 1) : null;
  for (var e; t < r.__k.length; t++) if ((e = r.__k[t]) != null && e.__e != null) return e.__e;
  return typeof r.type == "function" ? fr(r) : null;
}
function il(r) {
  var t, e;
  if ((r = r.__) != null && r.__c != null) {
    for (r.__e = r.__c.base = null, t = 0; t < r.__k.length; t++) if ((e = r.__k[t]) != null && e.__e != null) {
      r.__e = r.__c.base = e.__e;
      break;
    }
    return il(r);
  }
}
function va(r) {
  (!r.__d && (r.__d = !0) && Re.push(r) && !$o.__r++ || ha != H.debounceRendering) && ((ha = H.debounceRendering) || el)($o);
}
function $o() {
  for (var r, t, e, o, n, i, a, s = 1; Re.length; ) Re.length > s && Re.sort(rl), r = Re.shift(), s = Re.length, r.__d && (e = void 0, o = void 0, n = (o = (t = r).__v).__e, i = [], a = [], t.__P && ((e = he({}, o)).__v = o.__v + 1, H.vnode && H.vnode(e), Gi(t.__P, e, o, t.__n, t.__P.namespaceURI, 32 & o.__u ? [n] : null, i, n == null ? fr(o) : n, !!(32 & o.__u), a), e.__v = o.__v, e.__.__k[e.__i] = e, ll(i, e, a), o.__e = o.__ = null, e.__e != n && il(e)));
  $o.__r = 0;
}
function al(r, t, e, o, n, i, a, s, l, u, c) {
  var d, f, p, v, h, g, y, _ = o && o.__k || nl, E = t.length;
  for (l = Yu(e, t, _, l, E), d = 0; d < E; d++) (p = e.__k[d]) != null && (f = p.__i == -1 ? Jr : _[p.__i] || Jr, p.__i = d, g = Gi(r, p, f, n, i, a, s, l, u, c), v = p.__e, p.ref && f.ref != p.ref && (f.ref && zi(f.ref, null, p), c.push(p.ref, p.__c || v, p)), h == null && v != null && (h = v), (y = !!(4 & p.__u)) || f.__k === p.__k ? l = sl(p, l, r, y) : typeof p.type == "function" && g !== void 0 ? l = g : v && (l = v.nextSibling), p.__u &= -7);
  return e.__e = h, l;
}
function Yu(r, t, e, o, n) {
  var i, a, s, l, u, c = e.length, d = c, f = 0;
  for (r.__k = new Array(n), i = 0; i < n; i++) (a = t[i]) != null && typeof a != "boolean" && typeof a != "function" ? (typeof a == "string" || typeof a == "number" || typeof a == "bigint" || a.constructor == String ? a = r.__k[i] = Xo(null, a, null, null, null) : lo(a) ? a = r.__k[i] = Xo(dr, { children: a }, null, null, null) : a.constructor === void 0 && a.__b > 0 ? a = r.__k[i] = Xo(a.type, a.props, a.key, a.ref ? a.ref : null, a.__v) : r.__k[i] = a, l = i + f, a.__ = r, a.__b = r.__b + 1, s = null, (u = a.__i = Hu(a, e, l, d)) != -1 && (d--, (s = e[u]) && (s.__u |= 2)), s == null || s.__v == null ? (u == -1 && (n > c ? f-- : n < c && f++), typeof a.type != "function" && (a.__u |= 4)) : u != l && (u == l - 1 ? f-- : u == l + 1 ? f++ : (u > l ? f-- : f++, a.__u |= 4))) : r.__k[i] = null;
  if (d) for (i = 0; i < c; i++) (s = e[i]) != null && (2 & s.__u) == 0 && (s.__e == o && (o = fr(s)), cl(s, s));
  return o;
}
function sl(r, t, e, o) {
  var n, i;
  if (typeof r.type == "function") {
    for (n = r.__k, i = 0; n && i < n.length; i++) n[i] && (n[i].__ = r, t = sl(n[i], t, e, o));
    return t;
  }
  r.__e != t && (o && (t && r.type && !t.parentNode && (t = fr(r)), e.insertBefore(r.__e, t || null)), t = r.__e);
  do
    t = t && t.nextSibling;
  while (t != null && t.nodeType == 8);
  return t;
}
function Uo(r, t) {
  return t = t || [], r == null || typeof r == "boolean" || (lo(r) ? r.some(function(e) {
    Uo(e, t);
  }) : t.push(r)), t;
}
function Hu(r, t, e, o) {
  var n, i, a, s = r.key, l = r.type, u = t[e], c = u != null && (2 & u.__u) == 0;
  if (u === null && s == null || c && s == u.key && l == u.type) return e;
  if (o > (c ? 1 : 0)) {
    for (n = e - 1, i = e + 1; n >= 0 || i < t.length; ) if ((u = t[a = n >= 0 ? n-- : i++]) != null && (2 & u.__u) == 0 && s == u.key && l == u.type) return a;
  }
  return -1;
}
function ya(r, t, e) {
  t[0] == "-" ? r.setProperty(t, e == null ? "" : e) : r[t] = e == null ? "" : typeof e != "number" || Xu.test(t) ? e : e + "px";
}
function yo(r, t, e, o, n) {
  var i, a;
  t: if (t == "style") if (typeof e == "string") r.style.cssText = e;
  else {
    if (typeof o == "string" && (r.style.cssText = o = ""), o) for (t in o) e && t in e || ya(r.style, t, "");
    if (e) for (t in e) o && e[t] == o[t] || ya(r.style, t, e[t]);
  }
  else if (t[0] == "o" && t[1] == "n") i = t != (t = t.replace(ol, "$1")), a = t.toLowerCase(), t = a in r || t == "onFocusOut" || t == "onFocusIn" ? a.slice(2) : t.slice(2), r.l || (r.l = {}), r.l[t + i] = e, e ? o ? e.u = o.u : (e.u = Xi, r.addEventListener(t, i ? Vn : Un, i)) : r.removeEventListener(t, i ? Vn : Un, i);
  else {
    if (n == "http://www.w3.org/2000/svg") t = t.replace(/xlink(H|:h)/, "h").replace(/sName$/, "s");
    else if (t != "width" && t != "height" && t != "href" && t != "list" && t != "form" && t != "tabIndex" && t != "download" && t != "rowSpan" && t != "colSpan" && t != "role" && t != "popover" && t in r) try {
      r[t] = e == null ? "" : e;
      break t;
    } catch (s) {
    }
    typeof e == "function" || (e == null || e === !1 && t[4] != "-" ? r.removeAttribute(t) : r.setAttribute(t, t == "popover" && e == 1 ? "" : e));
  }
}
function ga(r) {
  return function(t) {
    if (this.l) {
      var e = this.l[t.type + r];
      if (t.t == null) t.t = Xi++;
      else if (t.t < e.u) return;
      return e(H.event ? H.event(t) : t);
    }
  };
}
function Gi(r, t, e, o, n, i, a, s, l, u) {
  var c, d, f, p, v, h, g, y, _, E, x, O, M, P, m, w, T, D = t.type;
  if (t.constructor !== void 0) return null;
  128 & e.__u && (l = !!(32 & e.__u), i = [s = t.__e = e.__e]), (c = H.__b) && c(t);
  t: if (typeof D == "function") try {
    if (y = t.props, _ = "prototype" in D && D.prototype.render, E = (c = D.contextType) && o[c.__c], x = c ? E ? E.props.value : c.__ : o, e.__c ? g = (d = t.__c = e.__c).__ = d.__E : (_ ? t.__c = d = new D(y, x) : (t.__c = d = new V(y, x), d.constructor = D, d.render = zu), E && E.sub(d), d.state || (d.state = {}), d.__n = o, f = d.__d = !0, d.__h = [], d._sb = []), _ && d.__s == null && (d.__s = d.state), _ && D.getDerivedStateFromProps != null && (d.__s == d.state && (d.__s = he({}, d.__s)), he(d.__s, D.getDerivedStateFromProps(y, d.__s))), p = d.props, v = d.state, d.__v = t, f) _ && D.getDerivedStateFromProps == null && d.componentWillMount != null && d.componentWillMount(), _ && d.componentDidMount != null && d.__h.push(d.componentDidMount);
    else {
      if (_ && D.getDerivedStateFromProps == null && y !== p && d.componentWillReceiveProps != null && d.componentWillReceiveProps(y, x), t.__v == e.__v || !d.__e && d.shouldComponentUpdate != null && d.shouldComponentUpdate(y, d.__s, x) === !1) {
        for (t.__v != e.__v && (d.props = y, d.state = d.__s, d.__d = !1), t.__e = e.__e, t.__k = e.__k, t.__k.some(function(B) {
          B && (B.__ = t);
        }), O = 0; O < d._sb.length; O++) d.__h.push(d._sb[O]);
        d._sb = [], d.__h.length && a.push(d);
        break t;
      }
      d.componentWillUpdate != null && d.componentWillUpdate(y, d.__s, x), _ && d.componentDidUpdate != null && d.__h.push(function() {
        d.componentDidUpdate(p, v, h);
      });
    }
    if (d.context = x, d.props = y, d.__P = r, d.__e = !1, M = H.__r, P = 0, _) {
      for (d.state = d.__s, d.__d = !1, M && M(t), c = d.render(d.props, d.state, d.context), m = 0; m < d._sb.length; m++) d.__h.push(d._sb[m]);
      d._sb = [];
    } else do
      d.__d = !1, M && M(t), c = d.render(d.props, d.state, d.context), d.state = d.__s;
    while (d.__d && ++P < 25);
    d.state = d.__s, d.getChildContext != null && (o = he(he({}, o), d.getChildContext())), _ && !f && d.getSnapshotBeforeUpdate != null && (h = d.getSnapshotBeforeUpdate(p, v)), w = c, c != null && c.type === dr && c.key == null && (w = ul(c.props.children)), s = al(r, lo(w) ? w : [w], t, e, o, n, i, a, s, l, u), d.base = t.__e, t.__u &= -161, d.__h.length && a.push(d), g && (d.__E = d.__ = null);
  } catch (B) {
    if (t.__v = null, l || i != null) if (B.then) {
      for (t.__u |= l ? 160 : 128; s && s.nodeType == 8 && s.nextSibling; ) s = s.nextSibling;
      i[i.indexOf(s)] = null, t.__e = s;
    } else {
      for (T = i.length; T--; ) Yi(i[T]);
      Fn(t);
    }
    else t.__e = e.__e, t.__k = e.__k, B.then || Fn(t);
    H.__e(B, t, e);
  }
  else i == null && t.__v == e.__v ? (t.__k = e.__k, t.__e = e.__e) : s = t.__e = Gu(e.__e, t, e, o, n, i, a, l, u);
  return (c = H.diffed) && c(t), 128 & t.__u ? void 0 : s;
}
function Fn(r) {
  r && r.__c && (r.__c.__e = !0), r && r.__k && r.__k.forEach(Fn);
}
function ll(r, t, e) {
  for (var o = 0; o < e.length; o++) zi(e[o], e[++o], e[++o]);
  H.__c && H.__c(t, r), r.some(function(n) {
    try {
      r = n.__h, n.__h = [], r.some(function(i) {
        i.call(n);
      });
    } catch (i) {
      H.__e(i, n.__v);
    }
  });
}
function ul(r) {
  return typeof r != "object" || r == null || r.__b && r.__b > 0 ? r : lo(r) ? r.map(ul) : he({}, r);
}
function Gu(r, t, e, o, n, i, a, s, l) {
  var u, c, d, f, p, v, h, g = e.props || Jr, y = t.props, _ = t.type;
  if (_ == "svg" ? n = "http://www.w3.org/2000/svg" : _ == "math" ? n = "http://www.w3.org/1998/Math/MathML" : n || (n = "http://www.w3.org/1999/xhtml"), i != null) {
    for (u = 0; u < i.length; u++) if ((p = i[u]) && "setAttribute" in p == !!_ && (_ ? p.localName == _ : p.nodeType == 3)) {
      r = p, i[u] = null;
      break;
    }
  }
  if (r == null) {
    if (_ == null) return document.createTextNode(y);
    r = document.createElementNS(n, _, y.is && y), s && (H.__m && H.__m(t, i), s = !1), i = null;
  }
  if (_ == null) g === y || s && r.data == y || (r.data = y);
  else {
    if (i = i && yn.call(r.childNodes), !s && i != null) for (g = {}, u = 0; u < r.attributes.length; u++) g[(p = r.attributes[u]).name] = p.value;
    for (u in g) if (p = g[u], u != "children") {
      if (u == "dangerouslySetInnerHTML") d = p;
      else if (!(u in y)) {
        if (u == "value" && "defaultValue" in y || u == "checked" && "defaultChecked" in y) continue;
        yo(r, u, null, p, n);
      }
    }
    for (u in y) p = y[u], u == "children" ? f = p : u == "dangerouslySetInnerHTML" ? c = p : u == "value" ? v = p : u == "checked" ? h = p : s && typeof p != "function" || g[u] === p || yo(r, u, p, g[u], n);
    if (c) s || d && (c.__html == d.__html || c.__html == r.innerHTML) || (r.innerHTML = c.__html), t.__k = [];
    else if (d && (r.innerHTML = ""), al(t.type == "template" ? r.content : r, lo(f) ? f : [f], t, e, o, _ == "foreignObject" ? "http://www.w3.org/1999/xhtml" : n, i, a, i ? i[0] : e.__k && fr(e, 0), s, l), i != null) for (u = i.length; u--; ) Yi(i[u]);
    s || (u = "value", _ == "progress" && v == null ? r.removeAttribute("value") : v != null && (v !== r[u] || _ == "progress" && !v || _ == "option" && v != g[u]) && yo(r, u, v, g[u], n), u = "checked", h != null && h != r[u] && yo(r, u, h, g[u], n));
  }
  return r;
}
function zi(r, t, e) {
  try {
    if (typeof r == "function") {
      var o = typeof r.__u == "function";
      o && r.__u(), o && t == null || (r.__u = r(t));
    } else r.current = t;
  } catch (n) {
    H.__e(n, e);
  }
}
function cl(r, t, e) {
  var o, n;
  if (H.unmount && H.unmount(r), (o = r.ref) && (o.current && o.current != r.__e || zi(o, null, t)), (o = r.__c) != null) {
    if (o.componentWillUnmount) try {
      o.componentWillUnmount();
    } catch (i) {
      H.__e(i, t);
    }
    o.base = o.__P = null;
  }
  if (o = r.__k) for (n = 0; n < o.length; n++) o[n] && cl(o[n], t, e || typeof r.type != "function");
  e || Yi(r.__e), r.__c = r.__ = r.__e = void 0;
}
function zu(r, t, e) {
  return this.constructor(r, e);
}
function $u(r, t, e) {
  var o, n, i, a;
  t == document && (t = document.documentElement), H.__ && H.__(r, t), n = (o = typeof e == "function") ? null : e && e.__k || t.__k, i = [], a = [], Gi(t, r = (!o && e || t).__k = Ot(dr, null, [r]), n || Jr, Jr, t.namespaceURI, !o && e ? [e] : n ? null : t.firstChild ? yn.call(t.childNodes) : null, i, !o && e ? e : n ? n.__e : t.firstChild, o, a), ll(i, r, a);
}
yn = nl.slice, H = { __e: function(r, t, e, o) {
  for (var n, i, a; t = t.__; ) if ((n = t.__c) && !n.__) try {
    if ((i = n.constructor) && i.getDerivedStateFromError != null && (n.setState(i.getDerivedStateFromError(r)), a = n.__d), n.componentDidCatch != null && (n.componentDidCatch(r, o || {}), a = n.__d), a) return n.__E = n;
  } catch (s) {
    r = s;
  }
  throw r;
} }, tl = 0, ku = function(r) {
  return r != null && r.constructor === void 0;
}, V.prototype.setState = function(r, t) {
  var e = this.__s != null && this.__s != this.state ? this.__s : this.__s = he({}, this.state);
  typeof r == "function" && (r = r(he({}, e), this.props)), r && he(e, r), r != null && this.__v && (t && this._sb.push(t), va(this));
}, V.prototype.forceUpdate = function(r) {
  this.__v && (this.__e = !0, r && this.__h.push(r), va(this));
}, V.prototype.render = dr, Re = [], el = typeof Promise == "function" ? Promise.prototype.then.bind(Promise.resolve()) : setTimeout, rl = function(r, t) {
  return r.__v.__b - t.__v.__b;
}, $o.__r = 0, ol = /(PointerCapture)$|Capture$/i, Xi = 0, Un = ga(!1), Vn = ga(!0), Bu = 0;
var Uu = "An invariant failed, however the error is obfuscated because this is a production build.", Vo = [];
Object.freeze(Vo);
var $i = {};
Object.freeze($i);
function Nt() {
  return ++N.mobxGuid;
}
function X(r) {
  throw st(!1, r), "X";
}
function st(r, t) {
  if (!r) throw new Error("[mobx] " + (t || Uu));
}
var _a = [];
function dl(r, t) {
  return process.env.NODE_ENV === "production" ? !1 : t ? dl("'" + r + "', use '" + t + "' instead.") : _a.indexOf(r) !== -1 ? !1 : (_a.push(r), !0);
}
function Ui(r) {
  var t = !1;
  return function() {
    if (!t)
      return t = !0, r.apply(this, arguments);
  };
}
var go = function() {
};
function Vu(r) {
  var t = [];
  return r.forEach(function(e) {
    t.indexOf(e) === -1 && t.push(e);
  }), t;
}
function Vi(r) {
  return r !== null && typeof r == "object";
}
function We(r) {
  if (r === null || typeof r != "object") return !1;
  var t = Object.getPrototypeOf(r);
  return t === Object.prototype || t === null;
}
function Fu(r) {
  if (Sr(r) || Pt(r)) return r;
  if (Array.isArray(r)) return new Map(r);
  if (We(r)) {
    var t = /* @__PURE__ */ new Map();
    for (var e in r) t.set(e, r[e]);
    return t;
  } else return X("Cannot convert to map from '" + r + "'");
}
function wr(r, t, e) {
  Object.defineProperty(r, t, {
    enumerable: !1,
    writable: !0,
    configurable: !0,
    value: e
  });
}
function Wu(r, t, e) {
  Object.defineProperty(r, t, {
    enumerable: !1,
    writable: !1,
    configurable: !0,
    value: e
  });
}
function fl(r, t) {
  var e = Object.getOwnPropertyDescriptor(r, t);
  return !e || e.configurable !== !1 && e.writable !== !1;
}
function Ku(r, t) {
  process.env.NODE_ENV !== "production" && !fl(r, t) && X("Cannot make property '" + t.toString() + "' observable, it is not configurable and writable in the target object");
}
function De(r, t) {
  var e = "isMobX" + r;
  return t.prototype[e] = !0, function(o) {
    return Vi(o) && o[e] === !0;
  };
}
function Sr(r) {
  return r instanceof Map;
}
function uo(r) {
  return r instanceof Set;
}
function Fi(r) {
  var t = /* @__PURE__ */ new Set();
  for (var e in r) t.add(e);
  return Object.getOwnPropertySymbols(r).forEach(function(o) {
    Object.getOwnPropertyDescriptor(r, o).enumerable && t.add(o);
  }), Array.from(t);
}
function kt(r) {
  return r && r.toString ? r.toString() : new String(r).toString();
}
function pl(r) {
  return r === null ? null : typeof r == "object" ? "" + r : r;
}
var Zu = typeof Reflect != "undefined" && Reflect.ownKeys ? Reflect.ownKeys : Object.getOwnPropertySymbols ? function(r) {
  return Object.getOwnPropertyNames(r).concat(Object.getOwnPropertySymbols(r));
} : (
  /* istanbul ignore next */
  Object.getOwnPropertyNames
), k = /* @__PURE__ */ Symbol("mobx administration"), Ar = (function() {
  function r(t) {
    t === void 0 && (t = "Atom@" + Nt()), this.name = t, this.isPendingUnobservation = !1, this.isBeingObserved = !1, this.observers = /* @__PURE__ */ new Set(), this.diffValue = 0, this.lastAccessedBy = 0, this.lowestObserverState = Q.NOT_TRACKING;
  }
  return r.prototype.onBecomeObserved = function() {
    this.onBecomeObservedListeners && this.onBecomeObservedListeners.forEach(function(t) {
      return t();
    });
  }, r.prototype.onBecomeUnobserved = function() {
    this.onBecomeUnobservedListeners && this.onBecomeUnobservedListeners.forEach(function(t) {
      return t();
    });
  }, r.prototype.reportObserved = function() {
    return wl(this);
  }, r.prototype.reportChanged = function() {
    qt(), Oc(this), Jt();
  }, r.prototype.toString = function() {
    return this.name;
  }, r;
})(), Wi = De("Atom", Ar);
function Ki(r, t, e) {
  t === void 0 && (t = go), e === void 0 && (e = go);
  var o = new Ar(r);
  return t !== go && Xc(o, t), e !== go && Nl(o, e), o;
}
function qu(r, t) {
  return r === t;
}
function Ju(r, t) {
  return ra(r, t);
}
function Qu(r, t) {
  return ra(r, t, 1);
}
function tc(r, t) {
  return Object.is(r, t);
}
var pr = {
  identity: qu,
  structural: Ju,
  default: tc,
  shallow: Qu
}, Wn = function(r, t) {
  return Wn = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(e, o) {
    e.__proto__ = o;
  } || function(e, o) {
    for (var n in o) o.hasOwnProperty(n) && (e[n] = o[n]);
  }, Wn(r, t);
};
function ec(r, t) {
  Wn(r, t);
  function e() {
    this.constructor = r;
  }
  r.prototype = t === null ? Object.create(t) : (e.prototype = t.prototype, new e());
}
var it = function() {
  return it = Object.assign || function(t) {
    for (var e, o = 1, n = arguments.length; o < n; o++) {
      e = arguments[o];
      for (var i in e) Object.prototype.hasOwnProperty.call(e, i) && (t[i] = e[i]);
    }
    return t;
  }, it.apply(this, arguments);
};
function Ft(r) {
  var t = typeof Symbol == "function" && r[Symbol.iterator], e = 0;
  return t ? t.call(r) : { next: function() {
    return r && e >= r.length && (r = void 0), {
      value: r && r[e++],
      done: !r
    };
  } };
}
function or(r, t) {
  var e = typeof Symbol == "function" && r[Symbol.iterator];
  if (!e) return r;
  var o = e.call(r), n, i = [], a;
  try {
    for (; (t === void 0 || t-- > 0) && !(n = o.next()).done; ) i.push(n.value);
  } catch (s) {
    a = { error: s };
  } finally {
    try {
      n && !n.done && (e = o.return) && e.call(o);
    } finally {
      if (a) throw a.error;
    }
  }
  return i;
}
function Zi() {
  for (var r = [], t = 0; t < arguments.length; t++) r = r.concat(or(arguments[t]));
  return r;
}
var Fo = /* @__PURE__ */ Symbol("mobx did run lazy initializers"), jr = /* @__PURE__ */ Symbol("mobx pending decorators"), rc = {}, oc = {};
function nc(r, t) {
  var e = t ? rc : oc;
  return e[r] || (e[r] = {
    configurable: !0,
    enumerable: t,
    get: function() {
      return Ve(this), this[r];
    },
    set: function(o) {
      Ve(this), this[r] = o;
    }
  });
}
function Ve(r) {
  var t, e;
  if (r[Fo] !== !0) {
    var o = r[jr];
    if (o) {
      wr(r, Fo, !0);
      var n = Zi(Object.getOwnPropertySymbols(o), Object.keys(o));
      try {
        for (var i = Ft(n), a = i.next(); !a.done; a = i.next()) {
          var s = o[a.value];
          s.propertyCreator(r, s.prop, s.descriptor, s.decoratorTarget, s.decoratorArguments);
        }
      } catch (l) {
        t = { error: l };
      } finally {
        try {
          a && !a.done && (e = i.return) && e.call(i);
        } finally {
          if (t) throw t.error;
        }
      }
    }
  }
}
function hl(r, t) {
  return function() {
    var o, n = function(a, s, l, u) {
      if (u === !0)
        return t(a, s, l, a, o), null;
      if (process.env.NODE_ENV !== "production" && !ma(arguments) && X("This function is a decorator, but it wasn't invoked like a decorator"), !Object.prototype.hasOwnProperty.call(a, jr)) {
        var c = a[jr];
        wr(a, jr, it({}, c));
      }
      return a[jr][s] = {
        prop: s,
        propertyCreator: t,
        descriptor: l,
        decoratorTarget: a,
        decoratorArguments: o
      }, nc(s, r);
    };
    return ma(arguments) ? (o = Vo, n.apply(null, arguments)) : (o = Array.prototype.slice.call(arguments), n);
  };
}
function ma(r) {
  return (r.length === 2 || r.length === 3) && (typeof r[1] == "string" || typeof r[1] == "symbol") || r.length === 4 && r[3] === !0;
}
function co(r, t, e) {
  return Pe(r) ? r : Array.isArray(r) ? A.array(r, { name: e }) : We(r) ? A.object(r, void 0, { name: e }) : Sr(r) ? A.map(r, { name: e }) : uo(r) ? A.set(r, { name: e }) : r;
}
function ic(r, t, e) {
  return r == null || Ht(r) || ee(r) || Pt(r) || Yt(r) ? r : Array.isArray(r) ? A.array(r, {
    name: e,
    deep: !1
  }) : We(r) ? A.object(r, void 0, {
    name: e,
    deep: !1
  }) : Sr(r) ? A.map(r, {
    name: e,
    deep: !1
  }) : uo(r) ? A.set(r, {
    name: e,
    deep: !1
  }) : X(process.env.NODE_ENV !== "production" && "The shallow modifier / decorator can only used in combination with arrays, objects, maps and sets");
}
function gn(r) {
  return r;
}
function ac(r, t, e) {
  if (process.env.NODE_ENV !== "production" && Pe(r)) throw "observable.struct should not be used with observable values";
  return ra(r, t) ? t : r;
}
function _n(r) {
  st(r);
  var t = hl(!0, function(o, n, i, a, s) {
    process.env.NODE_ENV !== "production" && st(!i || !i.get, '@observable cannot be used on getter (property "' + kt(n) + '"), use @computed instead.');
    var l = i ? i.initializer ? i.initializer.call(o) : i.value : void 0;
    ea(o).addObservableProp(n, l, r);
  }), e = typeof process != "undefined" && process.env && process.env.NODE_ENV !== "production" ? function() {
    return arguments.length < 2 ? X("Incorrect decorator invocation. @observable decorator doesn't expect any arguments") : t.apply(null, arguments);
  } : t;
  return e.enhancer = r, e;
}
var vl = {
  deep: !0,
  name: void 0,
  defaultDecorator: void 0,
  proxy: !0
};
Object.freeze(vl);
function sc(r) {
  /^(deep|name|equals|defaultDecorator|proxy)$/.test(r) || X("invalid option for (extend)observable: " + r);
}
function er(r) {
  if (r == null) return vl;
  if (typeof r == "string") return {
    name: r,
    deep: !0,
    proxy: !0
  };
  if (process.env.NODE_ENV !== "production") {
    if (typeof r != "object") return X("expected options object");
    Object.keys(r).forEach(sc);
  }
  return r;
}
var qi = _n(co), lc = _n(ic), yl = _n(gn), uc = _n(ac);
function _o(r) {
  return r.defaultDecorator ? r.defaultDecorator.enhancer : r.deep === !1 ? gn : co;
}
function cc(r, t, e) {
  if (typeof arguments[1] == "string" || typeof arguments[1] == "symbol") return qi.apply(null, arguments);
  if (Pe(r)) return r;
  var o = We(r) ? A.object(r, t, e) : Array.isArray(r) ? A.array(r, t) : Sr(r) ? A.map(r, t) : uo(r) ? A.set(r, t) : r;
  if (o !== r) return o;
  X(process.env.NODE_ENV !== "production" && "The provided value could not be converted into an observable. If you want just create an observable reference to the object use 'observable.box(value)'");
}
var xa = {
  box: function(r, t) {
    arguments.length > 2 && Tr("box");
    var e = er(t);
    return new ze(r, _o(e), e.name, !0, e.equals);
  },
  array: function(r, t) {
    arguments.length > 2 && Tr("array");
    var e = er(t);
    return ed(r, _o(e), e.name);
  },
  map: function(r, t) {
    arguments.length > 2 && Tr("map");
    var e = er(t);
    return new ta(r, _o(e), e.name);
  },
  set: function(r, t) {
    arguments.length > 2 && Tr("set");
    var e = er(t);
    return new Xl(r, _o(e), e.name);
  },
  object: function(r, t, e) {
    typeof arguments[1] == "string" && Tr("object");
    var o = er(e);
    if (o.proxy === !1) return Qn({}, r, t, o);
    var n = Cl(o), i = Jc(Qn({}, void 0, void 0, o));
    return Ll(i, r, t, n), i;
  },
  ref: yl,
  shallow: lc,
  deep: qi,
  struct: uc
}, A = cc;
Object.keys(xa).forEach(function(r) {
  return A[r] = xa[r];
});
function Tr(r) {
  X("Expected one or two arguments to observable." + r + ". Did you accidentally try to use observable." + r + " as decorator?");
}
var Wo = hl(!1, function(r, t, e, o, n) {
  process.env.NODE_ENV !== "production" && st(e && e.get, "Trying to declare a computed value for unspecified getter '" + kt(t) + "'");
  var i = e.get, a = e.set, s = n[0] || {};
  ea(r).addComputedProp(r, t, it({
    get: i,
    set: a,
    context: r
  }, s));
}), dc = Wo({ equals: pr.structural }), ot = function(t, e, o) {
  if (typeof e == "string" || t !== null && typeof t == "object" && arguments.length === 1) return Wo.apply(null, arguments);
  process.env.NODE_ENV !== "production" && (st(typeof t == "function", "First argument to `computed` should be an expression."), st(arguments.length < 3, "Computed takes one or two arguments if used as function"));
  var n = typeof e == "object" ? e : {};
  return n.get = t, n.set = typeof e == "function" ? e : n.set, n.name = n.name || t.name || "", new vr(n);
};
ot.struct = dc;
var Q;
(function(r) {
  r[r.NOT_TRACKING = -1] = "NOT_TRACKING", r[r.UP_TO_DATE = 0] = "UP_TO_DATE", r[r.POSSIBLY_STALE = 1] = "POSSIBLY_STALE", r[r.STALE = 2] = "STALE";
})(Q || (Q = {}));
var Zt;
(function(r) {
  r[r.NONE = 0] = "NONE", r[r.LOG = 1] = "LOG", r[r.BREAK = 2] = "BREAK";
})(Zt || (Zt = {}));
var Ko = /* @__PURE__ */ (function() {
  function r(t) {
    this.cause = t;
  }
  return r;
})();
function Rr(r) {
  return r instanceof Ko;
}
function Kn(r) {
  switch (r.dependenciesState) {
    case Q.UP_TO_DATE:
      return !1;
    case Q.NOT_TRACKING:
    case Q.STALE:
      return !0;
    case Q.POSSIBLY_STALE:
      for (var t = Ji(!0), e = Mr(), o = r.observing, n = o.length, i = 0; i < n; i++) {
        var a = o[i];
        if (yr(a)) {
          if (N.disableErrorBoundaries) a.get();
          else try {
            a.get();
          } catch (s) {
            return Ae(e), Xr(t), !0;
          }
          if (r.dependenciesState === Q.STALE)
            return Ae(e), Xr(t), !0;
        }
      }
      return ml(r), Ae(e), Xr(t), !1;
  }
}
function hr(r) {
  var t = r.observers.size > 0;
  N.computationDepth > 0 && t && X(process.env.NODE_ENV !== "production" && "Computed values are not allowed to cause side effects by changing observables that are already being observed. Tried to modify: " + r.name), !N.allowStateChanges && (t || N.enforceActions === "strict") && X(process.env.NODE_ENV !== "production" && (N.enforceActions ? "Since strict-mode is enabled, changing observed observable values outside actions is not allowed. Please wrap the code in an `action` if this change is intended. Tried to modify: " : "Side effects like changing state are not allowed at this point. Are you trying to modify state from, for example, the render function of a React component? Tried to modify: ") + r.name);
}
function fc(r) {
  process.env.NODE_ENV !== "production" && !N.allowStateReads && N.observableRequiresReaction;
}
function gl(r, t, e) {
  var o = Ji(!0);
  ml(r), r.newObserving = new Array(r.observing.length + 100), r.unboundDepsCount = 0, r.runId = ++N.runId;
  var n = N.trackingDerivation;
  N.trackingDerivation = r;
  var i;
  if (N.disableErrorBoundaries === !0) i = t.call(e);
  else try {
    i = t.call(e);
  } catch (a) {
    i = new Ko(a);
  }
  return N.trackingDerivation = n, hc(r), pc(r), Xr(o), i;
}
function pc(r) {
  process.env.NODE_ENV !== "production" && r.observing.length === 0 && (N.reactionRequiresObservable || r.requiresObservable);
}
function hc(r) {
  for (var t = r.observing, e = r.observing = r.newObserving, o = Q.UP_TO_DATE, n = 0, i = r.unboundDepsCount, a = 0; a < i; a++) {
    var s = e[a];
    s.diffValue === 0 && (s.diffValue = 1, n !== a && (e[n] = s), n++), s.dependenciesState > o && (o = s.dependenciesState);
  }
  for (e.length = n, r.newObserving = null, i = t.length; i--; ) {
    var s = t[i];
    s.diffValue === 0 && bl(s, r), s.diffValue = 0;
  }
  for (; n--; ) {
    var s = e[n];
    s.diffValue === 1 && (s.diffValue = 0, bc(s, r));
  }
  o !== Q.UP_TO_DATE && (r.dependenciesState = o, r.onBecomeStale());
}
function Zn(r) {
  var t = r.observing;
  r.observing = [];
  for (var e = t.length; e--; ) bl(t[e], r);
  r.dependenciesState = Q.NOT_TRACKING;
}
function _l(r) {
  var t = Mr();
  try {
    return r();
  } finally {
    Ae(t);
  }
}
function Mr() {
  var r = N.trackingDerivation;
  return N.trackingDerivation = null, r;
}
function Ae(r) {
  N.trackingDerivation = r;
}
function Ji(r) {
  var t = N.allowStateReads;
  return N.allowStateReads = r, t;
}
function Xr(r) {
  N.allowStateReads = r;
}
function ml(r) {
  if (r.dependenciesState !== Q.UP_TO_DATE) {
    r.dependenciesState = Q.UP_TO_DATE;
    for (var t = r.observing, e = t.length; e--; ) t[e].lowestObserverState = Q.UP_TO_DATE;
  }
}
var Zo = 0, vc = 1, Ea = Object.getOwnPropertyDescriptor(function() {
}, "name"), yc = Ea && Ea.configurable;
function Ge(r, t, e) {
  process.env.NODE_ENV !== "production" && (st(typeof t == "function", "`action` can only be invoked on functions"), (typeof r != "string" || !r) && X("actions should have valid names, got: '" + r + "'"));
  var o = function() {
    return xl(r, t, e || this, arguments);
  };
  return o.isMobxAction = !0, process.env.NODE_ENV !== "production" && yc && Object.defineProperty(o, "name", { value: r }), o;
}
function xl(r, t, e, o) {
  var n = gc(r, e, o);
  try {
    return t.apply(e, o);
  } catch (i) {
    throw n.error = i, i;
  } finally {
    _c(n);
  }
}
function gc(r, t, e) {
  var o = wt() && !!r, n = 0;
  if (o && process.env.NODE_ENV !== "production") {
    n = Date.now();
    var i = e && e.length || 0, a = new Array(i);
    if (i > 0) for (var s = 0; s < i; s++) a[s] = e[s];
    Lt({
      type: "action",
      name: r,
      object: t,
      arguments: a
    });
  }
  var l = Mr();
  qt();
  var u = {
    prevDerivation: l,
    prevAllowStateChanges: mn(!0),
    prevAllowStateReads: Ji(!0),
    notifySpy: o,
    startTime: n,
    actionId: vc++,
    parentActionId: Zo
  };
  return Zo = u.actionId, u;
}
function _c(r) {
  Zo !== r.actionId && X("invalid action stack. did you forget to finish an action?"), Zo = r.parentActionId, r.error !== void 0 && (N.suppressReactionErrors = !0), xn(r.prevAllowStateChanges), Xr(r.prevAllowStateReads), Jt(), Ae(r.prevDerivation), r.notifySpy && process.env.NODE_ENV !== "production" && jt({ time: Date.now() - r.startTime }), N.suppressReactionErrors = !1;
}
function mn(r) {
  var t = N.allowStateChanges;
  return N.allowStateChanges = r, t;
}
function xn(r) {
  N.allowStateChanges = r;
}
var ze = (function(r) {
  ec(t, r);
  function t(e, o, n, i, a) {
    n === void 0 && (n = "ObservableValue@" + Nt()), i === void 0 && (i = !0), a === void 0 && (a = pr.default);
    var s = r.call(this, n) || this;
    return s.enhancer = o, s.name = n, s.equals = a, s.hasUnreportedChange = !1, s.value = o(e, void 0, n), i && wt() && process.env.NODE_ENV !== "production" && Fe({
      type: "create",
      name: s.name,
      newValue: "" + s.value
    }), s;
  }
  return t.prototype.dehanceValue = function(e) {
    return this.dehancer !== void 0 ? this.dehancer(e) : e;
  }, t.prototype.set = function(e) {
    var o = this.value;
    if (e = this.prepareNewValue(e), e !== N.UNCHANGED) {
      var n = wt();
      n && process.env.NODE_ENV !== "production" && Lt({
        type: "update",
        name: this.name,
        newValue: e,
        oldValue: o
      }), this.setNewValue(e), n && process.env.NODE_ENV !== "production" && jt();
    }
  }, t.prototype.prepareNewValue = function(e) {
    if (hr(this), le(this)) {
      var o = ue(this, {
        object: this,
        type: "update",
        newValue: e
      });
      if (!o) return N.UNCHANGED;
      e = o.newValue;
    }
    return e = this.enhancer(e, this.value, this.name), this.equals(this.value, e) ? N.UNCHANGED : e;
  }, t.prototype.setNewValue = function(e) {
    var o = this.value;
    this.value = e, this.reportChanged(), Qt(this) && te(this, {
      type: "update",
      object: this,
      newValue: e,
      oldValue: o
    });
  }, t.prototype.get = function() {
    return this.reportObserved(), this.dehanceValue(this.value);
  }, t.prototype.intercept = function(e) {
    return fo(this, e);
  }, t.prototype.observe = function(e, o) {
    return o && e({
      object: this,
      type: "update",
      newValue: this.value,
      oldValue: void 0
    }), po(this, e);
  }, t.prototype.toJSON = function() {
    return this.get();
  }, t.prototype.toString = function() {
    return this.name + "[" + this.value + "]";
  }, t.prototype.valueOf = function() {
    return pl(this.get());
  }, t.prototype[Symbol.toPrimitive] = function() {
    return this.valueOf();
  }, t;
})(Ar), mc = De("ObservableValue", ze), vr = (function() {
  function r(t) {
    this.dependenciesState = Q.NOT_TRACKING, this.observing = [], this.newObserving = null, this.isBeingObserved = !1, this.isPendingUnobservation = !1, this.observers = /* @__PURE__ */ new Set(), this.diffValue = 0, this.runId = 0, this.lastAccessedBy = 0, this.lowestObserverState = Q.UP_TO_DATE, this.unboundDepsCount = 0, this.__mapid = "#" + Nt(), this.value = new Ko(null), this.isComputing = !1, this.isRunningSetter = !1, this.isTracing = Zt.NONE, st(t.get, "missing option for computed: get"), this.derivation = t.get, this.name = t.name || "ComputedValue@" + Nt(), t.set && (this.setter = Ge(this.name + "-setter", t.set)), this.equals = t.equals || (t.compareStructural || t.struct ? pr.structural : pr.default), this.scope = t.context, this.requiresReaction = !!t.requiresReaction, this.keepAlive = !!t.keepAlive;
  }
  return r.prototype.onBecomeStale = function() {
    Sc(this);
  }, r.prototype.onBecomeObserved = function() {
    this.onBecomeObservedListeners && this.onBecomeObservedListeners.forEach(function(t) {
      return t();
    });
  }, r.prototype.onBecomeUnobserved = function() {
    this.onBecomeUnobservedListeners && this.onBecomeUnobservedListeners.forEach(function(t) {
      return t();
    });
  }, r.prototype.get = function() {
    this.isComputing && X("Cycle detected in computation " + this.name + ": " + this.derivation), N.inBatch === 0 && this.observers.size === 0 && !this.keepAlive ? Kn(this) && (this.warnAboutUntrackedRead(), qt(), this.value = this.computeValue(!1), Jt()) : (wl(this), Kn(this) && this.trackAndCompute() && wc(this));
    var t = this.value;
    if (Rr(t)) throw t.cause;
    return t;
  }, r.prototype.peek = function() {
    var t = this.computeValue(!1);
    if (Rr(t)) throw t.cause;
    return t;
  }, r.prototype.set = function(t) {
    if (this.setter) {
      st(!this.isRunningSetter, "The setter of computed value '" + this.name + "' is trying to update itself. Did you intend to update an _observable_ value, instead of the computed property?"), this.isRunningSetter = !0;
      try {
        this.setter.call(this.scope, t);
      } finally {
        this.isRunningSetter = !1;
      }
    } else st(!1, process.env.NODE_ENV !== "production" && "[ComputedValue '" + this.name + "'] It is not possible to assign a new value to a computed value.");
  }, r.prototype.trackAndCompute = function() {
    wt() && process.env.NODE_ENV !== "production" && Fe({
      object: this.scope,
      type: "compute",
      name: this.name
    });
    var t = this.value, e = this.dependenciesState === Q.NOT_TRACKING, o = this.computeValue(!0), n = e || Rr(t) || Rr(o) || !this.equals(t, o);
    return n && (this.value = o), n;
  }, r.prototype.computeValue = function(t) {
    this.isComputing = !0, N.computationDepth++;
    var e;
    if (t) e = gl(this, this.derivation, this.scope);
    else if (N.disableErrorBoundaries === !0) e = this.derivation.call(this.scope);
    else try {
      e = this.derivation.call(this.scope);
    } catch (o) {
      e = new Ko(o);
    }
    return N.computationDepth--, this.isComputing = !1, e;
  }, r.prototype.suspend = function() {
    this.keepAlive || (Zn(this), this.value = void 0);
  }, r.prototype.observe = function(t, e) {
    var o = this, n = !0, i = void 0;
    return Ic(function() {
      var a = o.get();
      if (!n || e) {
        var s = Mr();
        t({
          type: "update",
          object: o,
          newValue: a,
          oldValue: i
        }), Ae(s);
      }
      n = !1, i = a;
    });
  }, r.prototype.warnAboutUntrackedRead = function() {
    process.env.NODE_ENV !== "production" && (this.requiresReaction === !0 && X("[mobx] Computed value " + this.name + " is read outside a reactive context"), this.isTracing, Zt.NONE, N.computedRequiresReaction);
  }, r.prototype.toJSON = function() {
    return this.get();
  }, r.prototype.toString = function() {
    return this.name + "[" + this.derivation.toString() + "]";
  }, r.prototype.valueOf = function() {
    return pl(this.get());
  }, r.prototype[Symbol.toPrimitive] = function() {
    return this.valueOf();
  }, r;
})(), yr = De("ComputedValue", vr), Yo = /* @__PURE__ */ (function() {
  function r() {
    this.version = 5, this.UNCHANGED = {}, this.trackingDerivation = null, this.computationDepth = 0, this.runId = 0, this.mobxGuid = 0, this.inBatch = 0, this.pendingUnobservations = [], this.pendingReactions = [], this.isRunningReactions = !1, this.allowStateChanges = !0, this.allowStateReads = !0, this.enforceActions = !1, this.spyListeners = [], this.globalReactionErrorHandlers = [], this.computedRequiresReaction = !1, this.reactionRequiresObservable = !1, this.observableRequiresReaction = !1, this.computedConfigurable = !1, this.disableErrorBoundaries = !1, this.suppressReactionErrors = !1;
  }
  return r;
})(), xc = {};
function qo() {
  return typeof window != "undefined" ? window : typeof global != "undefined" ? global : typeof self != "undefined" ? self : xc;
}
var Ho = !0, El = !1, N = (function() {
  var r = qo();
  return r.__mobxInstanceCount > 0 && !r.__mobxGlobals && (Ho = !1), r.__mobxGlobals && r.__mobxGlobals.version !== new Yo().version && (Ho = !1), Ho ? r.__mobxGlobals ? (r.__mobxInstanceCount += 1, r.__mobxGlobals.UNCHANGED || (r.__mobxGlobals.UNCHANGED = {}), r.__mobxGlobals) : (r.__mobxInstanceCount = 1, r.__mobxGlobals = new Yo()) : (setTimeout(function() {
    El || X("There are multiple, different versions of MobX active. Make sure MobX is loaded only once or use `configure({ isolateGlobalState: true })`");
  }, 1), new Yo());
})();
function Ec() {
  (N.pendingReactions.length || N.inBatch || N.isRunningReactions) && X("isolateGlobalState should be called before MobX is running any reactions"), El = !0, Ho && (--qo().__mobxInstanceCount === 0 && (qo().__mobxGlobals = void 0), N = new Yo());
}
function qn() {
  return N;
}
function bc(r, t) {
  r.observers.add(t), r.lowestObserverState > t.dependenciesState && (r.lowestObserverState = t.dependenciesState);
}
function bl(r, t) {
  r.observers.delete(t), r.observers.size === 0 && Ol(r);
}
function Ol(r) {
  r.isPendingUnobservation === !1 && (r.isPendingUnobservation = !0, N.pendingUnobservations.push(r));
}
function qt() {
  N.inBatch++;
}
function Jt() {
  if (--N.inBatch === 0) {
    Ml();
    for (var r = N.pendingUnobservations, t = 0; t < r.length; t++) {
      var e = r[t];
      e.isPendingUnobservation = !1, e.observers.size === 0 && (e.isBeingObserved && (e.isBeingObserved = !1, e.onBecomeUnobserved()), e instanceof vr && e.suspend());
    }
    N.pendingUnobservations = [];
  }
}
function wl(r) {
  fc(r);
  var t = N.trackingDerivation;
  return t !== null ? (t.runId !== r.lastAccessedBy && (r.lastAccessedBy = t.runId, t.newObserving[t.unboundDepsCount++] = r, r.isBeingObserved || (r.isBeingObserved = !0, r.onBecomeObserved())), !0) : (r.observers.size === 0 && N.inBatch > 0 && Ol(r), !1);
}
function Oc(r) {
  r.lowestObserverState !== Q.STALE && (r.lowestObserverState = Q.STALE, r.observers.forEach(function(t) {
    t.dependenciesState === Q.UP_TO_DATE && (t.isTracing !== Zt.NONE && Sl(t, r), t.onBecomeStale()), t.dependenciesState = Q.STALE;
  }));
}
function wc(r) {
  r.lowestObserverState !== Q.STALE && (r.lowestObserverState = Q.STALE, r.observers.forEach(function(t) {
    t.dependenciesState === Q.POSSIBLY_STALE ? t.dependenciesState = Q.STALE : t.dependenciesState === Q.UP_TO_DATE && (r.lowestObserverState = Q.UP_TO_DATE);
  }));
}
function Sc(r) {
  r.lowestObserverState === Q.UP_TO_DATE && (r.lowestObserverState = Q.POSSIBLY_STALE, r.observers.forEach(function(t) {
    t.dependenciesState === Q.UP_TO_DATE && (t.dependenciesState = Q.POSSIBLY_STALE, t.isTracing !== Zt.NONE && Sl(t, r), t.onBecomeStale());
  }));
}
function Sl(r, t) {
  if (r.isTracing === Zt.BREAK) {
    var e = [];
    Al(Hc(r), e, 1), new Function(`debugger;
/*
Tracing '` + r.name + `'

You are entering this break point because derivation '` + r.name + "' is being traced and '" + t.name + `' is now forcing it to update.
Just follow the stacktrace you should now see in the devtools to see precisely what piece of your code is causing this update
The stackframe you are looking for is at least ~6-8 stack-frames up.

` + (r instanceof vr ? r.derivation.toString().replace(/[*]\//g, "/") : "") + `

The dependencies for this derivation are:

` + e.join(`
`) + `
*/
    `)();
  }
}
function Al(r, t, e) {
  if (t.length >= 1e3) {
    t.push("(and many more)");
    return;
  }
  t.push("" + new Array(e).join("	") + r.name), r.dependencies && r.dependencies.forEach(function(o) {
    return Al(o, t, e + 1);
  });
}
var Qr = (function() {
  function r(t, e, o, n) {
    t === void 0 && (t = "Reaction@" + Nt()), n === void 0 && (n = !1), this.name = t, this.onInvalidate = e, this.errorHandler = o, this.requiresObservable = n, this.observing = [], this.newObserving = [], this.dependenciesState = Q.NOT_TRACKING, this.diffValue = 0, this.runId = 0, this.unboundDepsCount = 0, this.__mapid = "#" + Nt(), this.isDisposed = !1, this._isScheduled = !1, this._isTrackPending = !1, this._isRunning = !1, this.isTracing = Zt.NONE;
  }
  return r.prototype.onBecomeStale = function() {
    this.schedule();
  }, r.prototype.schedule = function() {
    this._isScheduled || (this._isScheduled = !0, N.pendingReactions.push(this), Ml());
  }, r.prototype.isScheduled = function() {
    return this._isScheduled;
  }, r.prototype.runReaction = function() {
    if (!this.isDisposed) {
      if (qt(), this._isScheduled = !1, Kn(this)) {
        this._isTrackPending = !0;
        try {
          this.onInvalidate(), this._isTrackPending && wt() && process.env.NODE_ENV !== "production" && Fe({
            name: this.name,
            type: "scheduled-reaction"
          });
        } catch (t) {
          this.reportExceptionInDerivation(t);
        }
      }
      Jt();
    }
  }, r.prototype.track = function(t) {
    if (!this.isDisposed) {
      qt();
      var e = wt(), o;
      e && process.env.NODE_ENV !== "production" && (o = Date.now(), Lt({
        name: this.name,
        type: "reaction"
      })), this._isRunning = !0;
      var n = gl(this, t, void 0);
      this._isRunning = !1, this._isTrackPending = !1, this.isDisposed && Zn(this), Rr(n) && this.reportExceptionInDerivation(n.cause), e && process.env.NODE_ENV !== "production" && jt({ time: Date.now() - o }), Jt();
    }
  }, r.prototype.reportExceptionInDerivation = function(t) {
    var e = this;
    if (this.errorHandler) {
      this.errorHandler(t, this);
      return;
    }
    if (N.disableErrorBoundaries) throw t;
    var o = "[mobx] Encountered an uncaught exception that was thrown by a reaction or observer component, in: '" + this + "'";
    N.suppressReactionErrors, wt() && Fe({
      type: "error",
      name: this.name,
      message: o,
      error: "" + t
    }), N.globalReactionErrorHandlers.forEach(function(n) {
      return n(t, e);
    });
  }, r.prototype.dispose = function() {
    this.isDisposed || (this.isDisposed = !0, this._isRunning || (qt(), Zn(this), Jt()));
  }, r.prototype.getDisposer = function() {
    var t = this.dispose.bind(this);
    return t[k] = this, t;
  }, r.prototype.toString = function() {
    return "Reaction[" + this.name + "]";
  }, r.prototype.trace = function(t) {
    t === void 0 && (t = !1), Kc(this, t);
  }, r;
})(), Ac = 100, Jn = function(r) {
  return r();
};
function Ml() {
  N.inBatch > 0 || N.isRunningReactions || Jn(Mc);
}
function Mc() {
  N.isRunningReactions = !0;
  for (var r = N.pendingReactions, t = 0; r.length > 0; ) {
    ++t === Ac && r.splice(0);
    for (var e = r.splice(0), o = 0, n = e.length; o < n; o++) e[o].runReaction();
  }
  N.isRunningReactions = !1;
}
var Jo = De("Reaction", Qr);
function Pc(r) {
  var t = Jn;
  Jn = function(e) {
    return r(function() {
      return t(e);
    });
  };
}
function wt() {
  return process.env.NODE_ENV !== "production" && !!N.spyListeners.length;
}
function Fe(r) {
  if (process.env.NODE_ENV !== "production" && N.spyListeners.length)
    for (var t = N.spyListeners, e = 0, o = t.length; e < o; e++) t[e](r);
}
function Lt(r) {
  process.env.NODE_ENV !== "production" && Fe(it(it({}, r), { spyReportStart: !0 }));
}
var Tc = { spyReportEnd: !0 };
function jt(r) {
  process.env.NODE_ENV !== "production" && Fe(r ? it(it({}, r), { spyReportEnd: !0 }) : Tc);
}
function Nc(r) {
  return process.env.NODE_ENV === "production" ? function() {
  } : (N.spyListeners.push(r), Ui(function() {
    N.spyListeners = N.spyListeners.filter(function(t) {
      return t !== r;
    });
  }));
}
function Dc() {
  X(process.env.NODE_ENV !== "production" && "@action fields are not reassignable");
}
function ba(r) {
  return function(t, e, o) {
    if (o) {
      if (process.env.NODE_ENV !== "production" && o.get !== void 0) return X("@action cannot be used with getters");
      if (o.value) return {
        value: Ge(r, o.value),
        enumerable: !1,
        configurable: !0,
        writable: !0
      };
      var n = o.initializer;
      return {
        enumerable: !1,
        configurable: !0,
        writable: !0,
        initializer: function() {
          return Ge(r, n.call(this));
        }
      };
    }
    return Cc(r).apply(this, arguments);
  };
}
function Cc(r) {
  return function(t, e, o) {
    Object.defineProperty(t, e, {
      configurable: !0,
      enumerable: !1,
      get: function() {
      },
      set: function(n) {
        wr(this, e, b(r, n));
      }
    });
  };
}
function Lc(r, t, e, o) {
  return o === !0 ? (An(r, t, e.value), null) : e ? {
    configurable: !0,
    enumerable: !1,
    get: function() {
      return An(this, t, e.value || e.initializer.call(this)), this[t];
    },
    set: Dc
  } : {
    enumerable: !1,
    configurable: !0,
    set: function(n) {
      An(this, t, n);
    },
    get: function() {
    }
  };
}
var b = function(t, e, o, n) {
  if (arguments.length === 1 && typeof t == "function") return Ge(t.name || "<unnamed action>", t);
  if (arguments.length === 2 && typeof e == "function") return Ge(t, e);
  if (arguments.length === 1 && typeof t == "string") return ba(t);
  if (n === !0) wr(t, e, Ge(t.name || e, o.value, this));
  else return ba(e).apply(null, arguments);
};
b.bound = Lc;
function jc(r, t) {
  var e = typeof r == "string" ? r : r.name || "<unnamed action>", o = typeof r == "function" ? r : t;
  return process.env.NODE_ENV !== "production" && (st(typeof o == "function" && o.length === 0, "`runInAction` expects a function without arguments"), (typeof e != "string" || !e) && X("actions should have valid names, got: '" + e + "'")), xl(e, o, this, void 0);
}
function Rc(r) {
  return typeof r == "function" && r.isMobxAction === !0;
}
function An(r, t, e) {
  wr(r, t, Ge(t, e.bind(r)));
}
function Ic(r, t) {
  t === void 0 && (t = $i), process.env.NODE_ENV !== "production" && (st(typeof r == "function", "Autorun expects a function as first argument"), st(Rc(r) === !1, "Autorun does not accept actions since actions are untrackable"));
  var e = t && t.name || r.name || "Autorun@" + Nt(), o = !t.scheduler && !t.delay, n;
  if (o) n = new Qr(e, function() {
    this.track(s);
  }, t.onError, t.requiresObservable);
  else {
    var i = Pl(t), a = !1;
    n = new Qr(e, function() {
      a || (a = !0, i(function() {
        a = !1, n.isDisposed || n.track(s);
      }));
    }, t.onError, t.requiresObservable);
  }
  function s() {
    r(n);
  }
  return n.schedule(), n.getDisposer();
}
var kc = function(r) {
  return r();
};
function Pl(r) {
  return r.scheduler ? r.scheduler : r.delay ? function(t) {
    return setTimeout(t, r.delay);
  } : kc;
}
function Tl(r, t, e) {
  e === void 0 && (e = $i), process.env.NODE_ENV !== "production" && (st(typeof r == "function", "First argument to reaction should be a function"), st(typeof e == "object", "Third argument of reactions should be an object"));
  var o = e.name || "Reaction@" + Nt(), n = b(o, e.onError ? Bc(e.onError, t) : t), i = !e.scheduler && !e.delay, a = Pl(e), s = !0, l = !1, u, c = e.compareStructural ? pr.structural : e.equals || pr.default, d = new Qr(o, function() {
    s || i ? f() : l || (l = !0, a(f));
  }, e.onError, e.requiresObservable);
  function f() {
    if (l = !1, !d.isDisposed) {
      var p = !1;
      d.track(function() {
        var v = r(d);
        p = s || !c(u, v), u = v;
      }), s && e.fireImmediately && n(u, d), !s && p === !0 && n(u, d), s && (s = !1);
    }
  }
  return d.schedule(), d.getDisposer();
}
function Bc(r, t) {
  return function() {
    try {
      return t.apply(this, arguments);
    } catch (e) {
      r.call(this, e);
    }
  };
}
function Xc(r, t, e) {
  return Dl("onBecomeObserved", r, t, e);
}
function Nl(r, t, e) {
  return Dl("onBecomeUnobserved", r, t, e);
}
function Dl(r, t, e, o) {
  var n = typeof o == "function" ? ye(t, e) : ye(t), i = typeof o == "function" ? o : e, a = r + "Listeners";
  return n[a] ? n[a].add(i) : n[a] = /* @__PURE__ */ new Set([i]), typeof n[r] != "function" ? X(process.env.NODE_ENV !== "production" && "Not an atom that can be (un)observed") : function() {
    var s = n[a];
    s && (s.delete(i), s.size === 0 && delete n[a]);
  };
}
function Yc(r) {
  var t = r.enforceActions, e = r.computedRequiresReaction, o = r.computedConfigurable, n = r.disableErrorBoundaries, i = r.reactionScheduler, a = r.reactionRequiresObservable, s = r.observableRequiresReaction;
  if (r.isolateGlobalState === !0 && Ec(), t !== void 0) {
    (typeof t == "boolean" || t === "strict") && dl(`Deprecated value for 'enforceActions', use 'false' => '"never"', 'true' => '"observed"', '"strict"' => "'always'" instead`);
    var l = void 0;
    switch (t) {
      case !0:
      case "observed":
        l = !0;
        break;
      case !1:
      case "never":
        l = !1;
        break;
      case "strict":
      case "always":
        l = "strict";
        break;
      default:
        X("Invalid value for 'enforceActions': '" + t + "', expected 'never', 'always' or 'observed'");
    }
    N.enforceActions = l, N.allowStateChanges = !(l === !0 || l === "strict");
  }
  e !== void 0 && (N.computedRequiresReaction = !!e), a !== void 0 && (N.reactionRequiresObservable = !!a), s !== void 0 && (N.observableRequiresReaction = !!s, N.allowStateReads = !N.observableRequiresReaction), o !== void 0 && (N.computedConfigurable = !!o), n !== void 0 && (N.disableErrorBoundaries = !!n), i && Pc(i);
}
function Qn(r, t, e, o) {
  process.env.NODE_ENV !== "production" && (st(arguments.length >= 2 && arguments.length <= 4, "'extendObservable' expected 2-4 arguments"), st(typeof r == "object", "'extendObservable' expects an object as first argument"), st(!Pt(r), "'extendObservable' should not be used on maps, use map.merge instead")), o = er(o);
  var n = Cl(o);
  return Ve(r), ea(r, o.name, n.enhancer), t && Ll(r, t, e, n), r;
}
function Cl(r) {
  return r.defaultDecorator || (r.deep === !1 ? yl : qi);
}
function Ll(r, t, e, o) {
  var n, i, a, s;
  if (process.env.NODE_ENV !== "production" && (st(!Pe(t), "Extending an object with another observable (object) is not supported. Please construct an explicit propertymap, using `toJS` if need. See issue #540"), e)) {
    var l = Fi(e);
    try {
      for (var u = Ft(l), c = u.next(); !c.done; c = u.next()) {
        var d = c.value;
        d in t || X("Trying to declare a decorator for unspecified property '" + kt(d) + "'");
      }
    } catch (y) {
      n = { error: y };
    } finally {
      try {
        c && !c.done && (i = u.return) && i.call(u);
      } finally {
        if (n) throw n.error;
      }
    }
  }
  qt();
  try {
    var l = Zu(t);
    try {
      for (var f = Ft(l), p = f.next(); !p.done; p = f.next()) {
        var d = p.value, v = Object.getOwnPropertyDescriptor(t, d);
        process.env.NODE_ENV !== "production" && (We(t) || X("'extendObservable' only accepts plain objects as second argument"), Il(v.value) && X("Passing a 'computed' as initial property value is no longer supported by extendObservable. Use a getter or decorator instead"));
        var h = e && d in e ? e[d] : v.get ? Wo : o;
        process.env.NODE_ENV !== "production" && typeof h != "function" && X("Not a valid decorator for '" + kt(d) + "', got: " + h);
        var g = h(r, d, v, !0);
        g && Object.defineProperty(r, d, g);
      }
    } catch (_) {
      a = { error: _ };
    } finally {
      try {
        p && !p.done && (s = f.return) && s.call(f);
      } finally {
        if (a) throw a.error;
      }
    }
  } finally {
    Jt();
  }
}
function Hc(r, t) {
  return jl(ye(r, t));
}
function jl(r) {
  var t = { name: r.name };
  return r.observing && r.observing.length > 0 && (t.dependencies = Vu(r.observing).map(jl)), t;
}
function Gc() {
  this.message = "FLOW_CANCELLED";
}
Gc.prototype = Object.create(Error.prototype);
function Rl(r, t) {
  return r == null ? !1 : t !== void 0 ? Ht(r) === !1 || !r[k].values.has(t) ? !1 : yr(ye(r, t)) : yr(r);
}
function Il(r) {
  return arguments.length > 1 ? X(process.env.NODE_ENV !== "production" && "isComputed expects only 1 argument. Use isObservableProp to inspect the observability of a property") : Rl(r);
}
function Oa(r, t) {
  return typeof t != "string" ? X(process.env.NODE_ENV !== "production" && "isComputed expected a property name as second argument") : Rl(r, t);
}
function zc(r, t) {
  return r == null ? !1 : t !== void 0 ? process.env.NODE_ENV !== "production" && (Pt(r) || ee(r)) ? X("isObservable(object, propertyName) is not supported for arrays and maps. Use map.has or array.length instead.") : Ht(r) ? r[k].values.has(t) : !1 : Ht(r) || !!r[k] || Wi(r) || Jo(r) || yr(r);
}
function Pe(r) {
  return arguments.length !== 1 && X(process.env.NODE_ENV !== "production" && "isObservable expects only 1 argument. Use isObservableProp to inspect the observability of a property"), zc(r);
}
function gr(r) {
  return Ht(r) ? r[k].getKeys() : Pt(r) || Yt(r) ? Array.from(r.keys()) : ee(r) ? r.map(function(t, e) {
    return e;
  }) : X(process.env.NODE_ENV !== "production" && "'keys()' can only be used on observable objects, arrays, sets and maps");
}
function $c(r) {
  return Ht(r) ? gr(r).map(function(t) {
    return r[t];
  }) : Pt(r) ? gr(r).map(function(t) {
    return r.get(t);
  }) : Yt(r) ? Array.from(r.values()) : ee(r) ? r.slice() : X(process.env.NODE_ENV !== "production" && "'values()' can only be used on observable objects, arrays, sets and maps");
}
function Uc(r) {
  return Ht(r) ? gr(r).map(function(t) {
    return [t, r[t]];
  }) : Pt(r) ? gr(r).map(function(t) {
    return [t, r.get(t)];
  }) : Yt(r) ? Array.from(r.entries()) : ee(r) ? r.map(function(t, e) {
    return [e, t];
  }) : X(process.env.NODE_ENV !== "production" && "'entries()' can only be used on observable objects, arrays and maps");
}
function Qi(r, t, e) {
  if (arguments.length === 2 && !Yt(r)) {
    qt();
    var o = t;
    try {
      for (var n in o) Qi(r, n, o[n]);
    } finally {
      Jt();
    }
    return;
  }
  if (Ht(r)) {
    var i = r[k];
    i.values.get(t) ? i.write(t, e) : i.addObservableProp(t, e, i.defaultEnhancer);
  } else if (Pt(r)) r.set(t, e);
  else if (Yt(r)) r.add(t);
  else if (ee(r))
    typeof t != "number" && (t = parseInt(t, 10)), st(t >= 0, "Not a valid index: '" + t + "'"), qt(), t >= r.length && (r.length = t + 1), r[t] = e, Jt();
  else return X(process.env.NODE_ENV !== "production" && "'set()' can only be used on observable objects, arrays and maps");
}
function kl(r, t, e, o) {
  return typeof e == "function" ? Fc(r, t, e, o) : Vc(r, t, e);
}
function Vc(r, t, e) {
  return ho(r).observe(t, e);
}
function Fc(r, t, e, o) {
  return ho(r, t).observe(e, o);
}
var Wc = {
  detectCycles: !0,
  exportMapsAsObjects: !0,
  recurseEverything: !1
};
function Ke(r, t, e, o) {
  return o.detectCycles && r.set(t, e), e;
}
function Ee(r, t, e) {
  if (!t.recurseEverything && !Pe(r) || typeof r != "object") return r;
  if (r === null) return null;
  if (r instanceof Date) return r;
  if (mc(r)) return Ee(r.get(), t, e);
  if (Pe(r) && gr(r), t.detectCycles === !0 && r !== null && e.has(r)) return e.get(r);
  if (ee(r) || Array.isArray(r)) {
    var o = Ke(e, r, [], t), n = r.map(function(f) {
      return Ee(f, t, e);
    });
    o.length = n.length;
    for (var i = 0, a = n.length; i < a; i++) o[i] = n[i];
    return o;
  }
  if (Yt(r) || Object.getPrototypeOf(r) === Set.prototype)
    if (t.exportMapsAsObjects === !1) {
      var s = Ke(e, r, /* @__PURE__ */ new Set(), t);
      return r.forEach(function(f) {
        s.add(Ee(f, t, e));
      }), s;
    } else {
      var l = Ke(e, r, [], t);
      return r.forEach(function(f) {
        l.push(Ee(f, t, e));
      }), l;
    }
  if (Pt(r) || Object.getPrototypeOf(r) === Map.prototype)
    if (t.exportMapsAsObjects === !1) {
      var u = Ke(e, r, /* @__PURE__ */ new Map(), t);
      return r.forEach(function(f, p) {
        u.set(p, Ee(f, t, e));
      }), u;
    } else {
      var c = Ke(e, r, {}, t);
      return r.forEach(function(f, p) {
        c[p] = Ee(f, t, e);
      }), c;
    }
  var d = Ke(e, r, {}, t);
  return Fi(r).forEach(function(f) {
    d[f] = Ee(r[f], t, e);
  }), d;
}
function ie(r, t) {
  typeof t == "boolean" && (t = { detectCycles: t }), t || (t = Wc), t.detectCycles = t.detectCycles === void 0 ? t.recurseEverything === !0 : t.detectCycles === !0;
  var e;
  return t.detectCycles && (e = /* @__PURE__ */ new Map()), Ee(r, t, e);
}
function Kc() {
  for (var r = [], t = 0; t < arguments.length; t++) r[t] = arguments[t];
  var e = !1;
  typeof r[r.length - 1] == "boolean" && (e = r.pop());
  var o = Zc(r);
  if (!o) return X(process.env.NODE_ENV !== "production" && "'trace(break?)' can only be used inside a tracked computed value or a Reaction. Consider passing in the computed value or reaction explicitly");
  o.isTracing, Zt.NONE, o.isTracing = e ? Zt.BREAK : Zt.LOG;
}
function Zc(r) {
  switch (r.length) {
    case 0:
      return N.trackingDerivation;
    case 1:
      return ye(r[0]);
    case 2:
      return ye(r[0], r[1]);
  }
}
function Wt(r, t) {
  t === void 0 && (t = void 0), qt();
  try {
    return r.apply(t);
  } finally {
    Jt();
  }
}
function mo(r) {
  return r[k];
}
function xo(r) {
  return typeof r == "string" || typeof r == "number" || typeof r == "symbol";
}
var qc = {
  has: function(r, t) {
    if (t === k || t === "constructor" || t === Fo) return !0;
    var e = mo(r);
    return xo(t) ? e.has(t) : t in r;
  },
  get: function(r, t) {
    if (t === k || t === "constructor" || t === Fo) return r[t];
    var e = mo(r), o = e.values.get(t);
    if (o instanceof Ar) {
      var n = o.get();
      return n === void 0 && e.has(t), n;
    }
    return xo(t) && e.has(t), r[t];
  },
  set: function(r, t, e) {
    return xo(t) ? (Qi(r, t, e), !0) : !1;
  },
  deleteProperty: function(r, t) {
    return xo(t) ? (mo(r).remove(t), !0) : !1;
  },
  ownKeys: function(r) {
    return mo(r).keysAtom.reportObserved(), Reflect.ownKeys(r);
  },
  preventExtensions: function(r) {
    return X("Dynamic observable objects cannot be frozen"), !1;
  }
};
function Jc(r) {
  var t = new Proxy(r, qc);
  return r[k].proxy = t, t;
}
function le(r) {
  return r.interceptors !== void 0 && r.interceptors.length > 0;
}
function fo(r, t) {
  var e = r.interceptors || (r.interceptors = []);
  return e.push(t), Ui(function() {
    var o = e.indexOf(t);
    o !== -1 && e.splice(o, 1);
  });
}
function ue(r, t) {
  var e = Mr();
  try {
    for (var o = Zi(r.interceptors || []), n = 0, i = o.length; n < i && (t = o[n](t), st(!t || t.type, "Intercept handlers should return nothing or a change object"), !!t); n++)
      ;
    return t;
  } finally {
    Ae(e);
  }
}
function Qt(r) {
  return r.changeListeners !== void 0 && r.changeListeners.length > 0;
}
function po(r, t) {
  var e = r.changeListeners || (r.changeListeners = []);
  return e.push(t), Ui(function() {
    var o = e.indexOf(t);
    o !== -1 && e.splice(o, 1);
  });
}
function te(r, t) {
  var e = Mr(), o = r.changeListeners;
  if (o) {
    o = o.slice();
    for (var n = 0, i = o.length; n < i; n++) o[n](t);
    Ae(e);
  }
}
var Qc = 1e4, td = {
  get: function(r, t) {
    return t === k ? r[k] : t === "length" ? r[k].getArrayLength() : typeof t == "number" ? pe.get.call(r, t) : typeof t == "string" && !isNaN(t) ? pe.get.call(r, parseInt(t)) : pe.hasOwnProperty(t) ? pe[t] : r[t];
  },
  set: function(r, t, e) {
    return t === "length" && r[k].setArrayLength(e), typeof t == "number" && pe.set.call(r, t, e), typeof t == "symbol" || isNaN(t) ? r[t] = e : pe.set.call(r, parseInt(t), e), !0;
  },
  preventExtensions: function(r) {
    return X("Observable arrays cannot be frozen"), !1;
  }
};
function ed(r, t, e, o) {
  e === void 0 && (e = "ObservableArray@" + Nt()), o === void 0 && (o = !1);
  var n = new Bl(e, t, o);
  Wu(n.values, k, n);
  var i = new Proxy(n.values, td);
  if (n.proxy = i, r && r.length) {
    var a = mn(!0);
    n.spliceWithArray(0, 0, r), xn(a);
  }
  return i;
}
var Bl = (function() {
  function r(t, e, o) {
    this.owned = o, this.values = [], this.proxy = void 0, this.lastKnownLength = 0, this.atom = new Ar(t || "ObservableArray@" + Nt()), this.enhancer = function(n, i) {
      return e(n, i, t + "[..]");
    };
  }
  return r.prototype.dehanceValue = function(t) {
    return this.dehancer !== void 0 ? this.dehancer(t) : t;
  }, r.prototype.dehanceValues = function(t) {
    return this.dehancer !== void 0 && t.length > 0 ? t.map(this.dehancer) : t;
  }, r.prototype.intercept = function(t) {
    return fo(this, t);
  }, r.prototype.observe = function(t, e) {
    return e === void 0 && (e = !1), e && t({
      object: this.proxy,
      type: "splice",
      index: 0,
      added: this.values.slice(),
      addedCount: this.values.length,
      removed: [],
      removedCount: 0
    }), po(this, t);
  }, r.prototype.getArrayLength = function() {
    return this.atom.reportObserved(), this.values.length;
  }, r.prototype.setArrayLength = function(t) {
    if (typeof t != "number" || t < 0) throw new Error("[mobx.array] Out of range: " + t);
    var e = this.values.length;
    if (t !== e)
      if (t > e) {
        for (var o = new Array(t - e), n = 0; n < t - e; n++) o[n] = void 0;
        this.spliceWithArray(e, 0, o);
      } else this.spliceWithArray(t, e - t);
  }, r.prototype.updateArrayLength = function(t, e) {
    if (t !== this.lastKnownLength) throw new Error("[mobx] Modification exception: the internal structure of an observable array was changed.");
    this.lastKnownLength += e;
  }, r.prototype.spliceWithArray = function(t, e, o) {
    var n = this;
    hr(this.atom);
    var i = this.values.length;
    if (t === void 0 ? t = 0 : t > i ? t = i : t < 0 && (t = Math.max(0, i + t)), arguments.length === 1 ? e = i - t : e == null ? e = 0 : e = Math.max(0, Math.min(e, i - t)), o === void 0 && (o = Vo), le(this)) {
      var a = ue(this, {
        object: this.proxy,
        type: "splice",
        index: t,
        removedCount: e,
        added: o
      });
      if (!a) return Vo;
      e = a.removedCount, o = a.added;
    }
    if (o = o.length === 0 ? o : o.map(function(u) {
      return n.enhancer(u, void 0);
    }), process.env.NODE_ENV !== "production") {
      var s = o.length - e;
      this.updateArrayLength(i, s);
    }
    var l = this.spliceItemsIntoValues(t, e, o);
    return (e !== 0 || o.length !== 0) && this.notifyArraySplice(t, o, l), this.dehanceValues(l);
  }, r.prototype.spliceItemsIntoValues = function(t, e, o) {
    var n;
    if (o.length < Qc) return (n = this.values).splice.apply(n, Zi([t, e], o));
    var i = this.values.slice(t, t + e);
    return this.values = this.values.slice(0, t).concat(o, this.values.slice(t + e)), i;
  }, r.prototype.notifyArrayChildUpdate = function(t, e, o) {
    var n = !this.owned && wt(), i = Qt(this), a = i || n ? {
      object: this.proxy,
      type: "update",
      index: t,
      newValue: e,
      oldValue: o
    } : null;
    n && process.env.NODE_ENV !== "production" && Lt(it(it({}, a), { name: this.atom.name })), this.atom.reportChanged(), i && te(this, a), n && process.env.NODE_ENV !== "production" && jt();
  }, r.prototype.notifyArraySplice = function(t, e, o) {
    var n = !this.owned && wt(), i = Qt(this), a = i || n ? {
      object: this.proxy,
      type: "splice",
      index: t,
      removed: o,
      added: e,
      removedCount: o.length,
      addedCount: e.length
    } : null;
    n && process.env.NODE_ENV !== "production" && Lt(it(it({}, a), { name: this.atom.name })), this.atom.reportChanged(), i && te(this, a), n && process.env.NODE_ENV !== "production" && jt();
  }, r;
})(), pe = {
  intercept: function(r) {
    return this[k].intercept(r);
  },
  observe: function(r, t) {
    return t === void 0 && (t = !1), this[k].observe(r, t);
  },
  clear: function() {
    return this.splice(0);
  },
  replace: function(r) {
    var t = this[k];
    return t.spliceWithArray(0, t.values.length, r);
  },
  toJS: function() {
    return this.slice();
  },
  toJSON: function() {
    return this.toJS();
  },
  splice: function(r, t) {
    for (var e = [], o = 2; o < arguments.length; o++) e[o - 2] = arguments[o];
    var n = this[k];
    switch (arguments.length) {
      case 0:
        return [];
      case 1:
        return n.spliceWithArray(r);
      case 2:
        return n.spliceWithArray(r, t);
    }
    return n.spliceWithArray(r, t, e);
  },
  spliceWithArray: function(r, t, e) {
    return this[k].spliceWithArray(r, t, e);
  },
  push: function() {
    for (var r = [], t = 0; t < arguments.length; t++) r[t] = arguments[t];
    var e = this[k];
    return e.spliceWithArray(e.values.length, 0, r), e.values.length;
  },
  pop: function() {
    return this.splice(Math.max(this[k].values.length - 1, 0), 1)[0];
  },
  shift: function() {
    return this.splice(0, 1)[0];
  },
  unshift: function() {
    for (var r = [], t = 0; t < arguments.length; t++) r[t] = arguments[t];
    var e = this[k];
    return e.spliceWithArray(0, 0, r), e.values.length;
  },
  reverse: function() {
    process.env.NODE_ENV;
    var r = this.slice();
    return r.reverse.apply(r, arguments);
  },
  sort: function(r) {
    process.env.NODE_ENV;
    var t = this.slice();
    return t.sort.apply(t, arguments);
  },
  remove: function(r) {
    var t = this[k], e = t.dehanceValues(t.values).indexOf(r);
    return e > -1 ? (this.splice(e, 1), !0) : !1;
  },
  get: function(r) {
    var t = this[k];
    if (t && r < t.values.length)
      return t.atom.reportObserved(), t.dehanceValue(t.values[r]);
  },
  set: function(r, t) {
    var e = this[k], o = e.values;
    if (r < o.length) {
      hr(e.atom);
      var n = o[r];
      if (le(e)) {
        var i = ue(e, {
          type: "update",
          object: e.proxy,
          index: r,
          newValue: t
        });
        if (!i) return;
        t = i.newValue;
      }
      t = e.enhancer(t, n), t !== n && (o[r] = t, e.notifyArrayChildUpdate(r, t, n));
    } else if (r === o.length) e.spliceWithArray(r, 0, [t]);
    else throw new Error("[mobx.array] Index out of bounds, " + r + " is larger than " + o.length);
  }
};
[
  "concat",
  "flat",
  "includes",
  "indexOf",
  "join",
  "lastIndexOf",
  "slice",
  "toString",
  "toLocaleString"
].forEach(function(r) {
  typeof Array.prototype[r] == "function" && (pe[r] = function() {
    var t = this[k];
    t.atom.reportObserved();
    var e = t.dehanceValues(t.values);
    return e[r].apply(e, arguments);
  });
});
[
  "every",
  "filter",
  "find",
  "findIndex",
  "flatMap",
  "forEach",
  "map",
  "some"
].forEach(function(r) {
  typeof Array.prototype[r] == "function" && (pe[r] = function(t, e) {
    var o = this, n = this[k];
    return n.atom.reportObserved(), n.dehanceValues(n.values)[r](function(i, a) {
      return t.call(e, i, a, o);
    }, e);
  });
});
["reduce", "reduceRight"].forEach(function(r) {
  pe[r] = function() {
    var t = this, e = this[k];
    e.atom.reportObserved();
    var o = arguments[0];
    return arguments[0] = function(n, i, a) {
      return i = e.dehanceValue(i), o(n, i, a, t);
    }, e.values[r].apply(e.values, arguments);
  };
});
var rd = De("ObservableArrayAdministration", Bl);
function ee(r) {
  return Vi(r) && rd(r[k]);
}
var wa, od = {}, ta = (function() {
  function r(t, e, o) {
    if (e === void 0 && (e = co), o === void 0 && (o = "ObservableMap@" + Nt()), this.enhancer = e, this.name = o, this[wa] = od, this._keysAtom = Ki(this.name + ".keys()"), this[Symbol.toStringTag] = "Map", typeof Map != "function") throw new Error("mobx.map requires Map polyfill for the current browser. Check babel-polyfill or core-js/es6/map.js");
    this._data = /* @__PURE__ */ new Map(), this._hasMap = /* @__PURE__ */ new Map(), this.merge(t);
  }
  return r.prototype._has = function(t) {
    return this._data.has(t);
  }, r.prototype.has = function(t) {
    var e = this;
    if (!N.trackingDerivation) return this._has(t);
    var o = this._hasMap.get(t);
    if (!o) {
      var n = o = new ze(this._has(t), gn, this.name + "." + kt(t) + "?", !1);
      this._hasMap.set(t, n), Nl(n, function() {
        return e._hasMap.delete(t);
      });
    }
    return o.get();
  }, r.prototype.set = function(t, e) {
    var o = this._has(t);
    if (le(this)) {
      var n = ue(this, {
        type: o ? "update" : "add",
        object: this,
        newValue: e,
        name: t
      });
      if (!n) return this;
      e = n.newValue;
    }
    return o ? this._updateValue(t, e) : this._addValue(t, e), this;
  }, r.prototype.delete = function(t) {
    var e = this;
    if (hr(this._keysAtom), le(this)) {
      var o = ue(this, {
        type: "delete",
        object: this,
        name: t
      });
      if (!o) return !1;
    }
    if (this._has(t)) {
      var n = wt(), i = Qt(this), o = i || n ? {
        type: "delete",
        object: this,
        oldValue: this._data.get(t).value,
        name: t
      } : null;
      return n && process.env.NODE_ENV !== "production" && Lt(it(it({}, o), {
        name: this.name,
        key: t
      })), Wt(function() {
        e._keysAtom.reportChanged(), e._updateHasMapEntry(t, !1), e._data.get(t).setNewValue(void 0), e._data.delete(t);
      }), i && te(this, o), n && process.env.NODE_ENV !== "production" && jt(), !0;
    }
    return !1;
  }, r.prototype._updateHasMapEntry = function(t, e) {
    var o = this._hasMap.get(t);
    o && o.setNewValue(e);
  }, r.prototype._updateValue = function(t, e) {
    var o = this._data.get(t);
    if (e = o.prepareNewValue(e), e !== N.UNCHANGED) {
      var n = wt(), i = Qt(this), a = i || n ? {
        type: "update",
        object: this,
        oldValue: o.value,
        name: t,
        newValue: e
      } : null;
      n && process.env.NODE_ENV !== "production" && Lt(it(it({}, a), {
        name: this.name,
        key: t
      })), o.setNewValue(e), i && te(this, a), n && process.env.NODE_ENV !== "production" && jt();
    }
  }, r.prototype._addValue = function(t, e) {
    var o = this;
    hr(this._keysAtom), Wt(function() {
      var s = new ze(e, o.enhancer, o.name + "." + kt(t), !1);
      o._data.set(t, s), e = s.value, o._updateHasMapEntry(t, !0), o._keysAtom.reportChanged();
    });
    var n = wt(), i = Qt(this), a = i || n ? {
      type: "add",
      object: this,
      name: t,
      newValue: e
    } : null;
    n && process.env.NODE_ENV !== "production" && Lt(it(it({}, a), {
      name: this.name,
      key: t
    })), i && te(this, a), n && process.env.NODE_ENV !== "production" && jt();
  }, r.prototype.get = function(t) {
    return this.has(t) ? this.dehanceValue(this._data.get(t).get()) : this.dehanceValue(void 0);
  }, r.prototype.dehanceValue = function(t) {
    return this.dehancer !== void 0 ? this.dehancer(t) : t;
  }, r.prototype.keys = function() {
    return this._keysAtom.reportObserved(), this._data.keys();
  }, r.prototype.values = function() {
    var t = this, e = this.keys();
    return Qo({ next: function() {
      var o = e.next(), n = o.done, i = o.value;
      return {
        done: n,
        value: n ? void 0 : t.get(i)
      };
    } });
  }, r.prototype.entries = function() {
    var t = this, e = this.keys();
    return Qo({ next: function() {
      var o = e.next(), n = o.done, i = o.value;
      return {
        done: n,
        value: n ? void 0 : [i, t.get(i)]
      };
    } });
  }, r.prototype[wa = k, Symbol.iterator] = function() {
    return this.entries();
  }, r.prototype.forEach = function(t, e) {
    var o, n;
    try {
      for (var i = Ft(this), a = i.next(); !a.done; a = i.next()) {
        var s = or(a.value, 2), l = s[0], u = s[1];
        t.call(e, u, l, this);
      }
    } catch (c) {
      o = { error: c };
    } finally {
      try {
        a && !a.done && (n = i.return) && n.call(i);
      } finally {
        if (o) throw o.error;
      }
    }
  }, r.prototype.merge = function(t) {
    var e = this;
    return Pt(t) && (t = t.toJS()), Wt(function() {
      var o = mn(!0);
      try {
        We(t) ? Fi(t).forEach(function(n) {
          return e.set(n, t[n]);
        }) : Array.isArray(t) ? t.forEach(function(n) {
          var i = or(n, 2), a = i[0], s = i[1];
          return e.set(a, s);
        }) : Sr(t) ? (t.constructor !== Map && X("Cannot initialize from classes that inherit from Map: " + t.constructor.name), t.forEach(function(n, i) {
          return e.set(i, n);
        })) : t != null && X("Cannot initialize map from " + t);
      } finally {
        xn(o);
      }
    }), this;
  }, r.prototype.clear = function() {
    var t = this;
    Wt(function() {
      _l(function() {
        var e, o;
        try {
          for (var n = Ft(t.keys()), i = n.next(); !i.done; i = n.next()) {
            var a = i.value;
            t.delete(a);
          }
        } catch (s) {
          e = { error: s };
        } finally {
          try {
            i && !i.done && (o = n.return) && o.call(n);
          } finally {
            if (e) throw e.error;
          }
        }
      });
    });
  }, r.prototype.replace = function(t) {
    var e = this;
    return Wt(function() {
      var o, n, i, a, s = Fu(t), l = /* @__PURE__ */ new Map(), u = !1;
      try {
        for (var c = Ft(e._data.keys()), d = c.next(); !d.done; d = c.next()) {
          var f = d.value;
          if (!s.has(f))
            if (e.delete(f)) u = !0;
            else {
              var p = e._data.get(f);
              l.set(f, p);
            }
        }
      } catch (P) {
        o = { error: P };
      } finally {
        try {
          d && !d.done && (n = c.return) && n.call(c);
        } finally {
          if (o) throw o.error;
        }
      }
      try {
        for (var v = Ft(s.entries()), h = v.next(); !h.done; h = v.next()) {
          var g = or(h.value, 2), f = g[0], p = g[1], y = e._data.has(f);
          if (e.set(f, p), e._data.has(f)) {
            var _ = e._data.get(f);
            l.set(f, _), y || (u = !0);
          }
        }
      } catch (P) {
        i = { error: P };
      } finally {
        try {
          h && !h.done && (a = v.return) && a.call(v);
        } finally {
          if (i) throw i.error;
        }
      }
      if (!u)
        if (e._data.size !== l.size) e._keysAtom.reportChanged();
        else
          for (var E = e._data.keys(), x = l.keys(), O = E.next(), M = x.next(); !O.done; ) {
            if (O.value !== M.value) {
              e._keysAtom.reportChanged();
              break;
            }
            O = E.next(), M = x.next();
          }
      e._data = l;
    }), this;
  }, Object.defineProperty(r.prototype, "size", {
    get: function() {
      return this._keysAtom.reportObserved(), this._data.size;
    },
    enumerable: !0,
    configurable: !0
  }), r.prototype.toPOJO = function() {
    var t, e, o = {};
    try {
      for (var n = Ft(this), i = n.next(); !i.done; i = n.next()) {
        var a = or(i.value, 2), s = a[0], l = a[1];
        o[typeof s == "symbol" ? s : kt(s)] = l;
      }
    } catch (u) {
      t = { error: u };
    } finally {
      try {
        i && !i.done && (e = n.return) && e.call(n);
      } finally {
        if (t) throw t.error;
      }
    }
    return o;
  }, r.prototype.toJS = function() {
    return new Map(this);
  }, r.prototype.toJSON = function() {
    return this.toPOJO();
  }, r.prototype.toString = function() {
    var t = this;
    return this.name + "[{ " + Array.from(this.keys()).map(function(e) {
      return kt(e) + ": " + ("" + t.get(e));
    }).join(", ") + " }]";
  }, r.prototype.observe = function(t, e) {
    return process.env.NODE_ENV !== "production" && st(e !== !0, "`observe` doesn't support fireImmediately=true in combination with maps."), po(this, t);
  }, r.prototype.intercept = function(t) {
    return fo(this, t);
  }, r;
})(), Pt = De("ObservableMap", ta), Sa, nd = {}, Xl = (function() {
  function r(t, e, o) {
    if (e === void 0 && (e = co), o === void 0 && (o = "ObservableSet@" + Nt()), this.name = o, this[Sa] = nd, this._data = /* @__PURE__ */ new Set(), this._atom = Ki(this.name), this[Symbol.toStringTag] = "Set", typeof Set != "function") throw new Error("mobx.set requires Set polyfill for the current browser. Check babel-polyfill or core-js/es6/set.js");
    this.enhancer = function(n, i) {
      return e(n, i, o);
    }, t && this.replace(t);
  }
  return r.prototype.dehanceValue = function(t) {
    return this.dehancer !== void 0 ? this.dehancer(t) : t;
  }, r.prototype.clear = function() {
    var t = this;
    Wt(function() {
      _l(function() {
        var e, o;
        try {
          for (var n = Ft(t._data.values()), i = n.next(); !i.done; i = n.next()) {
            var a = i.value;
            t.delete(a);
          }
        } catch (s) {
          e = { error: s };
        } finally {
          try {
            i && !i.done && (o = n.return) && o.call(n);
          } finally {
            if (e) throw e.error;
          }
        }
      });
    });
  }, r.prototype.forEach = function(t, e) {
    var o, n;
    try {
      for (var i = Ft(this), a = i.next(); !a.done; a = i.next()) {
        var s = a.value;
        t.call(e, s, s, this);
      }
    } catch (l) {
      o = { error: l };
    } finally {
      try {
        a && !a.done && (n = i.return) && n.call(i);
      } finally {
        if (o) throw o.error;
      }
    }
  }, Object.defineProperty(r.prototype, "size", {
    get: function() {
      return this._atom.reportObserved(), this._data.size;
    },
    enumerable: !0,
    configurable: !0
  }), r.prototype.add = function(t) {
    var e = this;
    if (hr(this._atom), le(this)) {
      var o = ue(this, {
        type: "add",
        object: this,
        newValue: t
      });
      if (!o) return this;
    }
    if (!this.has(t)) {
      Wt(function() {
        e._data.add(e.enhancer(t, void 0)), e._atom.reportChanged();
      });
      var n = wt(), i = Qt(this), o = i || n ? {
        type: "add",
        object: this,
        newValue: t
      } : null;
      n && process.env.NODE_ENV !== "production" && Lt(o), i && te(this, o), n && process.env.NODE_ENV !== "production" && jt();
    }
    return this;
  }, r.prototype.delete = function(t) {
    var e = this;
    if (le(this)) {
      var o = ue(this, {
        type: "delete",
        object: this,
        oldValue: t
      });
      if (!o) return !1;
    }
    if (this.has(t)) {
      var n = wt(), i = Qt(this), o = i || n ? {
        type: "delete",
        object: this,
        oldValue: t
      } : null;
      return n && process.env.NODE_ENV !== "production" && Lt(it(it({}, o), { name: this.name })), Wt(function() {
        e._atom.reportChanged(), e._data.delete(t);
      }), i && te(this, o), n && process.env.NODE_ENV !== "production" && jt(), !0;
    }
    return !1;
  }, r.prototype.has = function(t) {
    return this._atom.reportObserved(), this._data.has(this.dehanceValue(t));
  }, r.prototype.entries = function() {
    var t = 0, e = Array.from(this.keys()), o = Array.from(this.values());
    return Qo({ next: function() {
      var n = t;
      return t += 1, n < o.length ? {
        value: [e[n], o[n]],
        done: !1
      } : { done: !0 };
    } });
  }, r.prototype.keys = function() {
    return this.values();
  }, r.prototype.values = function() {
    this._atom.reportObserved();
    var t = this, e = 0, o = Array.from(this._data.values());
    return Qo({ next: function() {
      return e < o.length ? {
        value: t.dehanceValue(o[e++]),
        done: !1
      } : { done: !0 };
    } });
  }, r.prototype.replace = function(t) {
    var e = this;
    return Yt(t) && (t = t.toJS()), Wt(function() {
      var o = mn(!0);
      try {
        Array.isArray(t) ? (e.clear(), t.forEach(function(n) {
          return e.add(n);
        })) : uo(t) ? (e.clear(), t.forEach(function(n) {
          return e.add(n);
        })) : t != null && X("Cannot initialize set from " + t);
      } finally {
        xn(o);
      }
    }), this;
  }, r.prototype.observe = function(t, e) {
    return process.env.NODE_ENV !== "production" && st(e !== !0, "`observe` doesn't support fireImmediately=true in combination with sets."), po(this, t);
  }, r.prototype.intercept = function(t) {
    return fo(this, t);
  }, r.prototype.toJS = function() {
    return new Set(this);
  }, r.prototype.toString = function() {
    return this.name + "[ " + Array.from(this).join(", ") + " ]";
  }, r.prototype[Sa = k, Symbol.iterator] = function() {
    return this.values();
  }, r;
})(), Yt = De("ObservableSet", Xl), Yl = (function() {
  function r(t, e, o, n) {
    e === void 0 && (e = /* @__PURE__ */ new Map()), this.target = t, this.values = e, this.name = o, this.defaultEnhancer = n, this.keysAtom = new Ar(o + ".keys");
  }
  return r.prototype.read = function(t) {
    return this.values.get(t).get();
  }, r.prototype.write = function(t, e) {
    var o = this.target, n = this.values.get(t);
    if (n instanceof vr) {
      n.set(e);
      return;
    }
    if (le(this)) {
      var i = ue(this, {
        type: "update",
        object: this.proxy || o,
        name: t,
        newValue: e
      });
      if (!i) return;
      e = i.newValue;
    }
    if (e = n.prepareNewValue(e), e !== N.UNCHANGED) {
      var a = Qt(this), s = wt(), i = a || s ? {
        type: "update",
        object: this.proxy || o,
        oldValue: n.value,
        name: t,
        newValue: e
      } : null;
      s && process.env.NODE_ENV !== "production" && Lt(it(it({}, i), {
        name: this.name,
        key: t
      })), n.setNewValue(e), a && te(this, i), s && process.env.NODE_ENV !== "production" && jt();
    }
  }, r.prototype.has = function(t) {
    var e = this.pendingKeys || (this.pendingKeys = /* @__PURE__ */ new Map()), o = e.get(t);
    return o || (o = new ze(!!this.values.get(t), gn, this.name + "." + kt(t) + "?", !1), e.set(t, o)), o.get();
  }, r.prototype.addObservableProp = function(t, e, o) {
    o === void 0 && (o = this.defaultEnhancer);
    var n = this.target;
    if (Ku(n, t), le(this)) {
      var i = ue(this, {
        object: this.proxy || n,
        name: t,
        type: "add",
        newValue: e
      });
      if (!i) return;
      e = i.newValue;
    }
    var a = new ze(e, o, this.name + "." + kt(t), !1);
    this.values.set(t, a), e = a.value, Object.defineProperty(n, t, id(t)), this.notifyPropertyAddition(t, e);
  }, r.prototype.addComputedProp = function(t, e, o) {
    var n = this.target;
    o.name = o.name || this.name + "." + kt(e), this.values.set(e, new vr(o)), (t === n || fl(t, e)) && Object.defineProperty(t, e, ad(e));
  }, r.prototype.remove = function(t) {
    if (this.values.has(t)) {
      var e = this.target;
      if (le(this)) {
        var o = ue(this, {
          object: this.proxy || e,
          name: t,
          type: "remove"
        });
        if (!o) return;
      }
      try {
        qt();
        var n = Qt(this), i = wt(), a = this.values.get(t), s = a && a.get();
        if (a && a.set(void 0), this.keysAtom.reportChanged(), this.values.delete(t), this.pendingKeys) {
          var l = this.pendingKeys.get(t);
          l && l.set(!1);
        }
        delete this.target[t];
        var o = n || i ? {
          type: "remove",
          object: this.proxy || e,
          oldValue: s,
          name: t
        } : null;
        i && process.env.NODE_ENV !== "production" && Lt(it(it({}, o), {
          name: this.name,
          key: t
        })), n && te(this, o), i && process.env.NODE_ENV !== "production" && jt();
      } finally {
        Jt();
      }
    }
  }, r.prototype.illegalAccess = function(t, e) {
  }, r.prototype.observe = function(t, e) {
    return process.env.NODE_ENV !== "production" && st(e !== !0, "`observe` doesn't support the fire immediately property for observable objects."), po(this, t);
  }, r.prototype.intercept = function(t) {
    return fo(this, t);
  }, r.prototype.notifyPropertyAddition = function(t, e) {
    var o = Qt(this), n = wt(), i = o || n ? {
      type: "add",
      object: this.proxy || this.target,
      name: t,
      newValue: e
    } : null;
    if (n && process.env.NODE_ENV !== "production" && Lt(it(it({}, i), {
      name: this.name,
      key: t
    })), o && te(this, i), n && process.env.NODE_ENV !== "production" && jt(), this.pendingKeys) {
      var a = this.pendingKeys.get(t);
      a && a.set(!0);
    }
    this.keysAtom.reportChanged();
  }, r.prototype.getKeys = function() {
    var t, e;
    this.keysAtom.reportObserved();
    var o = [];
    try {
      for (var n = Ft(this.values), i = n.next(); !i.done; i = n.next()) {
        var a = or(i.value, 2), s = a[0];
        a[1] instanceof ze && o.push(s);
      }
    } catch (l) {
      t = { error: l };
    } finally {
      try {
        i && !i.done && (e = n.return) && e.call(n);
      } finally {
        if (t) throw t.error;
      }
    }
    return o;
  }, r;
})();
function ea(r, t, e) {
  if (t === void 0 && (t = ""), e === void 0 && (e = co), Object.prototype.hasOwnProperty.call(r, k)) return r[k];
  process.env.NODE_ENV !== "production" && st(Object.isExtensible(r), "Cannot make the designated object observable; it is not extensible"), We(r) || (t = (r.constructor.name || "ObservableObject") + "@" + Nt()), t || (t = "ObservableObject@" + Nt());
  var o = new Yl(r, /* @__PURE__ */ new Map(), kt(t), e);
  return wr(r, k, o), o;
}
var Aa = /* @__PURE__ */ Object.create(null), Ma = /* @__PURE__ */ Object.create(null);
function id(r) {
  return Aa[r] || (Aa[r] = {
    configurable: !0,
    enumerable: !0,
    get: function() {
      return this[k].read(r);
    },
    set: function(t) {
      this[k].write(r, t);
    }
  });
}
function Pa(r) {
  var t = r[k];
  return t || (Ve(r), r[k]);
}
function ad(r) {
  return Ma[r] || (Ma[r] = {
    configurable: N.computedConfigurable,
    enumerable: !1,
    get: function() {
      return Pa(this).read(r);
    },
    set: function(t) {
      Pa(this).write(r, t);
    }
  });
}
var sd = De("ObservableObjectAdministration", Yl);
function Ht(r) {
  return Vi(r) ? (Ve(r), sd(r[k])) : !1;
}
function ye(r, t) {
  if (typeof r == "object" && r !== null) {
    if (ee(r))
      return t !== void 0 && X(process.env.NODE_ENV !== "production" && "It is not possible to get index atoms from arrays"), r[k].atom;
    if (Yt(r)) return r[k];
    if (Pt(r)) {
      var e = r;
      if (t === void 0) return e._keysAtom;
      var o = e._data.get(t) || e._hasMap.get(t);
      return o || X(process.env.NODE_ENV !== "production" && "the entry '" + t + "' does not exist in the observable map '" + ti(r) + "'"), o;
    }
    if (Ve(r), t && !r[k] && r[t], Ht(r)) {
      if (!t) return X(process.env.NODE_ENV !== "production" && "please specify a property");
      var o = r[k].values.get(t);
      return o || X(process.env.NODE_ENV !== "production" && "no observable property '" + t + "' found on the observable object '" + ti(r) + "'"), o;
    }
    if (Wi(r) || yr(r) || Jo(r)) return r;
  } else if (typeof r == "function" && Jo(r[k]))
    return r[k];
  return X(process.env.NODE_ENV !== "production" && "Cannot obtain atom from " + r);
}
function ho(r, t) {
  if (r || X("Expecting some object"), t !== void 0) return ho(ye(r, t));
  if (Wi(r) || yr(r) || Jo(r) || Pt(r) || Yt(r)) return r;
  if (Ve(r), r[k]) return r[k];
  X(process.env.NODE_ENV !== "production" && "Cannot obtain administration from " + r);
}
function ti(r, t) {
  var e;
  return t !== void 0 ? e = ye(r, t) : Ht(r) || Pt(r) || Yt(r) ? e = ho(r) : e = ye(r), e.name;
}
var Ta = Object.prototype.toString;
function ra(r, t, e) {
  return e === void 0 && (e = -1), ei(r, t, e);
}
function ei(r, t, e, o, n) {
  if (r === t) return r !== 0 || 1 / r === 1 / t;
  if (r == null || t == null) return !1;
  if (r !== r) return t !== t;
  var i = typeof r;
  if (i !== "function" && i !== "object" && typeof t != "object") return !1;
  var a = Ta.call(r);
  if (a !== Ta.call(t)) return !1;
  switch (a) {
    case "[object RegExp]":
    case "[object String]":
      return "" + r == "" + t;
    case "[object Number]":
      return +r != +r ? +t != +t : +r == 0 ? 1 / +r === 1 / t : +r == +t;
    case "[object Date]":
    case "[object Boolean]":
      return +r == +t;
    case "[object Symbol]":
      return typeof Symbol != "undefined" && Symbol.valueOf.call(r) === Symbol.valueOf.call(t);
    case "[object Map]":
    case "[object Set]":
      e >= 0 && e++;
  }
  r = Na(r), t = Na(t);
  var s = a === "[object Array]";
  if (!s) {
    if (typeof r != "object" || typeof t != "object") return !1;
    var l = r.constructor, u = t.constructor;
    if (l !== u && !(typeof l == "function" && l instanceof l && typeof u == "function" && u instanceof u) && "constructor" in r && "constructor" in t) return !1;
  }
  if (e === 0) return !1;
  e < 0 && (e = -1), o = o || [], n = n || [];
  for (var c = o.length; c--; ) if (o[c] === r) return n[c] === t;
  if (o.push(r), n.push(t), s) {
    if (c = r.length, c !== t.length) return !1;
    for (; c--; ) if (!ei(r[c], t[c], e - 1, o, n)) return !1;
  } else {
    var d = Object.keys(r), f = void 0;
    if (c = d.length, Object.keys(t).length !== c) return !1;
    for (; c--; )
      if (f = d[c], !(ld(t, f) && ei(r[f], t[f], e - 1, o, n))) return !1;
  }
  return o.pop(), n.pop(), !0;
}
function Na(r) {
  return ee(r) ? r.slice() : Sr(r) || Pt(r) || uo(r) || Yt(r) ? Array.from(r.entries()) : r;
}
function ld(r, t) {
  return Object.prototype.hasOwnProperty.call(r, t);
}
function Qo(r) {
  return r[Symbol.iterator] = ud, r;
}
function ud() {
  return this;
}
if (typeof Proxy == "undefined" || typeof Symbol == "undefined") throw new Error("[mobx] MobX 5+ requires Proxy and Symbol objects. If your environment doesn't support Symbol or Proxy objects, please downgrade to MobX 4. For React Native Android, consider upgrading JSCore.");
try {
  process.env.NODE_ENV;
} catch (r) {
  var Da = qo();
  typeof process == "undefined" && (Da.process = {}), Da.process.env = {};
}
(function() {
  function r() {
  }
  if (r.name !== "testCodeMinification" && process.env.NODE_ENV !== "production" && typeof process != "undefined" && process.env.IGNORE_MOBX_MINIFY_WARNING !== "true")
    var t = [
      "process",
      "env",
      "NODE_ENV"
    ].join(".");
})();
typeof __MOBX_DEVTOOLS_GLOBAL_HOOK__ == "object" && __MOBX_DEVTOOLS_GLOBAL_HOOK__.injectMobx({
  spy: Nc,
  extras: { getDebugName: ti },
  $mobx: k
});
function cd(r) {
  return !(r.prototype && r.prototype.render) && !V.isPrototypeOf(r);
}
function Hl(r) {
  var t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {}, e = t.prefix, o = e === void 0 ? "" : e, n = t.suffix, i = n === void 0 ? "" : n;
  return o + (r.displayName || r.name || r.constructor && r.constructor.name || "<component>") + i;
}
var Ca = typeof Symbol == "function" && typeof Symbol.iterator == "symbol" ? function(r) {
  return typeof r;
} : function(r) {
  return r && typeof Symbol == "function" && r.constructor === Symbol && r !== Symbol.prototype ? "symbol" : typeof r;
}, Gl = function(r, t) {
  if (!(r instanceof t)) throw new TypeError("Cannot call a class as a function");
}, zl = /* @__PURE__ */ (function() {
  function r(t, e) {
    for (var o = 0; o < e.length; o++) {
      var n = e[o];
      n.enumerable = n.enumerable || !1, n.configurable = !0, "value" in n && (n.writable = !0), Object.defineProperty(t, n.key, n);
    }
  }
  return function(t, e, o) {
    return e && r(t.prototype, e), o && r(t, o), t;
  };
})(), $l = function(r, t) {
  if (typeof t != "function" && t !== null) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
  r.prototype = Object.create(t && t.prototype, { constructor: {
    value: r,
    enumerable: !1,
    writable: !0,
    configurable: !0
  } }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(r, t) : r.__proto__ = t);
}, Ul = function(r, t) {
  if (!r) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  return t && (typeof t == "object" || typeof t == "function") ? t : r;
}, Mn = !1, ri = console;
function dd(r) {
  var t = qn().allowStateChanges;
  return qn().allowStateChanges = r, t;
}
function fd(r) {
  qn().allowStateChanges = r;
}
function pd(r, t, e, o, n) {
  var i = dd(r), a = void 0;
  try {
    a = t(e, o, n);
  } finally {
    fd(i);
  }
  return a;
}
function La(r, t) {
  var e = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : !1, o = r[t], n = Vl[t];
  r[t] = o ? e === !0 ? function() {
    n.apply(this, arguments), o.apply(this, arguments);
  } : function() {
    o.apply(this, arguments), n.apply(this, arguments);
  } : n;
}
function ja(r, t) {
  if (r == null || t == null || (typeof r == "undefined" ? "undefined" : Ca(r)) !== "object" || (typeof t == "undefined" ? "undefined" : Ca(t)) !== "object") return r !== t;
  var e = Object.keys(r);
  if (e.length !== Object.keys(t).length) return !0;
  for (var o = void 0, n = e.length - 1; o = e[n]; n--) if (t[o] !== r[o]) return !0;
  return !1;
}
var Vl = {
  componentWillMount: function() {
    var t = this;
    if (Mn === !0) return;
    var e = Hl(this), o = !1, n = !1;
    function i(d) {
      var f = this[d], p = Ki("reactive " + d);
      Object.defineProperty(this, d, {
        configurable: !0,
        enumerable: !0,
        get: function() {
          return p.reportObserved(), f;
        },
        set: function(h) {
          !n && ja(f, h) ? (f = h, o = !0, p.reportChanged(), o = !1) : f = h;
        }
      });
    }
    i.call(this, "props"), i.call(this, "state");
    var a = this.render.bind(this), s = null, l = !1, u = function() {
      return s = new Qr(e + ".render()", function() {
        if (!l && (l = !0, typeof t.componentWillReact == "function" && t.componentWillReact(), t.__$mobxIsUnmounted !== !0)) {
          var f = !0;
          try {
            n = !0, o || V.prototype.forceUpdate.call(t), f = !1;
          } finally {
            n = !1, f && s.dispose();
          }
        }
      }), s.reactComponent = t, c.$mobx = s, t.render = c, c(t.props, t.state, t.context);
    }, c = function(f, p, v) {
      l = !1;
      var h = void 0, g = void 0;
      if (s.track(function() {
        try {
          g = pd(!1, a, f, p, v);
        } catch (y) {
          h = y;
        }
      }), h) throw h;
      return g;
    };
    this.render = u;
  },
  componentWillUnmount: function() {
    Mn !== !0 && (this.render.$mobx && this.render.$mobx.dispose(), this.__$mobxIsUnmounted = !0);
  },
  componentDidMount: function() {
  },
  componentDidUpdate: function() {
  },
  shouldComponentUpdate: function(t, e) {
    return Mn && ri.warn("[mobx-preact] It seems that a re-rendering of a React component is triggered while in static (server-side) mode. Please make sure components are rendered only once server-side."), this.state !== e ? !0 : ja(this.props, t);
  }
};
function oa(r) {
  if (arguments.length > 1 && ri.warn('Mobx observer: Using observer to inject stores is not supported. Use `@connect(["store1", "store2"]) ComponentClass instead or preferably, use `@inject("store1", "store2") @observer ComponentClass` or `inject("store1", "store2")(observer(componentClass))``'), r.isMobxInjector === !0 && ri.warn("Mobx observer: You are trying to use 'observer' on a component that already has 'inject'. Please apply 'observer' before applying 'inject'"), cd(r)) {
    var t, e;
    return oa((e = t = (function(o) {
      $l(n, o);
      function n() {
        return Gl(this, n), Ul(this, (n.__proto__ || Object.getPrototypeOf(n)).apply(this, arguments));
      }
      return zl(n, [{
        key: "render",
        value: function() {
          return r.call(this, this.props, this.context);
        }
      }]), n;
    })(V), t.displayName = Hl(r), e));
  }
  if (!r) throw new Error("Please pass a valid component to 'observer'");
  return hd(r.prototype || r), r.isMobXReactObserver = !0, r;
}
function hd(r) {
  La(r, "componentWillMount", !0), La(r, "componentDidMount"), r.shouldComponentUpdate || (r.shouldComponentUpdate = Vl.shouldComponentUpdate);
}
var vd = oa(function(r) {
  return r.children[0]();
});
vd.displayName = "Observer";
var yd = typeof window != "undefined" ? window : typeof global != "undefined" ? global : typeof self != "undefined" ? self : {};
function gd(r, t) {
  return t = { exports: {} }, r(t, t.exports), t.exports;
}
var ay = gd(function(r, t) {
  (function(e, o) {
    r.exports = o();
  })(yd, (function() {
    var e = {
      childContextTypes: !0,
      contextTypes: !0,
      defaultProps: !0,
      displayName: !0,
      getDefaultProps: !0,
      getDerivedStateFromProps: !0,
      mixins: !0,
      propTypes: !0,
      type: !0
    }, o = {
      name: !0,
      length: !0,
      prototype: !0,
      caller: !0,
      callee: !0,
      arguments: !0,
      arity: !0
    }, n = Object.defineProperty, i = Object.getOwnPropertyNames, a = Object.getOwnPropertySymbols, s = Object.getOwnPropertyDescriptor, l = Object.getPrototypeOf, u = l && l(Object);
    return function c(d, f, p) {
      if (typeof f != "string") {
        if (u) {
          var v = l(f);
          v && v !== u && c(d, v, p);
        }
        var h = i(f);
        a && (h = h.concat(a(f)));
        for (var g = 0; g < h.length; ++g) {
          var y = h[g];
          if (!e[y] && !o[y] && (!p || !p[y])) {
            var _ = s(f, y);
            try {
              n(d, y, _);
            } catch (E) {
            }
          }
        }
        return d;
      }
      return d;
    };
  }));
}), Ra = {
  children: !0,
  key: !0,
  ref: !0
}, Ia = console, sy = (function(r) {
  $l(t, r);
  function t() {
    return Gl(this, t), Ul(this, (t.__proto__ || Object.getPrototypeOf(t)).apply(this, arguments));
  }
  return zl(t, [
    {
      key: "render",
      value: function(o) {
        var n = o.children;
        return n.length > 1 ? Ot("div", null, " ", n, " ") : n[0];
      }
    },
    {
      key: "getChildContext",
      value: function() {
        var o = {}, n = this.context.mobxStores;
        if (n) for (var i in n) o[i] = n[i];
        for (var a in this.props) !Ra[a] && a !== "suppressChangedStoreWarning" && (o[a] = this.props[a]);
        return { mobxStores: o };
      }
    },
    {
      key: "componentWillReceiveProps",
      value: function(o) {
        if (Object.keys(o).length !== Object.keys(this.props).length && Ia.warn("MobX Provider: The set of provided stores has changed. Please avoid changing stores as the change might not propagate to all children"), !o.suppressChangedStoreWarning)
          for (var n in o) !Ra[n] && this.props[n] !== o[n] && Ia.warn("MobX Provider: Provided store '" + n + "' has changed. Please avoid replacing stores as the change might not propagate to all children");
      }
    }
  ]), t;
})(V);
if (!V) throw new Error("mobx-preact requires Preact to be available");
var ka, ae, Pn, Ba, Fl = [], bt = H, Xa = bt.__b, Ya = bt.__r, Ha = bt.diffed, Ga = bt.__c, za = bt.unmount, $a = bt.__;
function _d() {
  for (var r; r = Fl.shift(); ) if (r.__P && r.__H) try {
    r.__H.__h.forEach(Go), r.__H.__h.forEach(oi), r.__H.__h = [];
  } catch (t) {
    r.__H.__h = [], bt.__e(t, r.__v);
  }
}
bt.__b = function(r) {
  ae = null, Xa && Xa(r);
}, bt.__ = function(r, t) {
  r && t.__k && t.__k.__m && (r.__m = t.__k.__m), $a && $a(r, t);
}, bt.__r = function(r) {
  Ya && Ya(r), ka = 0;
  var t = (ae = r.__c).__H;
  t && (Pn === ae ? (t.__h = [], ae.__h = [], t.__.forEach(function(e) {
    e.__N && (e.__ = e.__N), e.u = e.__N = void 0;
  })) : (t.__h.forEach(Go), t.__h.forEach(oi), t.__h = [], ka = 0)), Pn = ae;
}, bt.diffed = function(r) {
  Ha && Ha(r);
  var t = r.__c;
  t && t.__H && (t.__H.__h.length && (Fl.push(t) !== 1 && Ba === bt.requestAnimationFrame || ((Ba = bt.requestAnimationFrame) || md)(_d)), t.__H.__.forEach(function(e) {
    e.u && (e.__H = e.u), e.u = void 0;
  })), Pn = ae = null;
}, bt.__c = function(r, t) {
  t.some(function(e) {
    try {
      e.__h.forEach(Go), e.__h = e.__h.filter(function(o) {
        return !o.__ || oi(o);
      });
    } catch (o) {
      t.some(function(n) {
        n.__h && (n.__h = []);
      }), t = [], bt.__e(o, e.__v);
    }
  }), Ga && Ga(r, t);
}, bt.unmount = function(r) {
  za && za(r);
  var t, e = r.__c;
  e && e.__H && (e.__H.__.forEach(function(o) {
    try {
      Go(o);
    } catch (n) {
      t = n;
    }
  }), e.__H = void 0, t && bt.__e(t, e.__v));
};
var Ua = typeof requestAnimationFrame == "function";
function md(r) {
  var t, e = function() {
    clearTimeout(o), Ua && cancelAnimationFrame(t), setTimeout(r);
  }, o = setTimeout(e, 35);
  Ua && (t = requestAnimationFrame(e));
}
function Go(r) {
  var t = ae, e = r.__c;
  typeof e == "function" && (r.__c = void 0, e()), ae = t;
}
function oi(r) {
  var t = ae;
  r.__c = r.__(), ae = t;
}
function xd(r, t) {
  for (var e in t) r[e] = t[e];
  return r;
}
function Va(r, t) {
  for (var e in r) if (e !== "__source" && !(e in t)) return !0;
  for (var o in t) if (o !== "__source" && r[o] !== t[o]) return !0;
  return !1;
}
function Fa(r, t) {
  this.props = r, this.context = t;
}
(Fa.prototype = new V()).isPureReactComponent = !0, Fa.prototype.shouldComponentUpdate = function(r, t) {
  return Va(this.props, r) || Va(this.state, t);
};
var Wa = H.__b;
H.__b = function(r) {
  r.type && r.type.__f && r.ref && (r.props.ref = r.ref, r.ref = null), Wa && Wa(r);
};
var ly = typeof Symbol != "undefined" && Symbol.for && /* @__PURE__ */ Symbol.for("react.forward_ref") || 3911, Ed = H.__e;
H.__e = function(r, t, e, o) {
  if (r.then) {
    for (var n, i = t; i = i.__; ) if ((n = i.__c) && n.__c) return t.__e == null && (t.__e = e.__e, t.__k = e.__k), n.__c(r, t);
  }
  Ed(r, t, e, o);
};
var Ka = H.unmount;
function Wl(r, t, e) {
  return r && (r.__c && r.__c.__H && (r.__c.__H.__.forEach(function(o) {
    typeof o.__c == "function" && o.__c();
  }), r.__c.__H = null), (r = xd({}, r)).__c != null && (r.__c.__P === e && (r.__c.__P = t), r.__c.__e = !0, r.__c = null), r.__k = r.__k && r.__k.map(function(o) {
    return Wl(o, t, e);
  })), r;
}
function Kl(r, t, e) {
  return r && e && (r.__v = null, r.__k = r.__k && r.__k.map(function(o) {
    return Kl(o, t, e);
  }), r.__c && r.__c.__P === t && (r.__e && e.appendChild(r.__e), r.__c.__e = !0, r.__c.__P = e)), r;
}
function Tn() {
  this.__u = 0, this.o = null, this.__b = null;
}
function Zl(r) {
  var t = r.__.__c;
  return t && t.__a && t.__a(r);
}
function Eo() {
  this.i = null, this.l = null;
}
H.unmount = function(r) {
  var t = r.__c;
  t && t.__R && t.__R(), t && 32 & r.__u && (r.type = null), Ka && Ka(r);
}, (Tn.prototype = new V()).__c = function(r, t) {
  var e = t.__c, o = this;
  o.o == null && (o.o = []), o.o.push(e);
  var n = Zl(o.__v), i = !1, a = function() {
    i || (i = !0, e.__R = null, n ? n(s) : s());
  };
  e.__R = a;
  var s = function() {
    if (!--o.__u) {
      if (o.state.__a) {
        var l = o.state.__a;
        o.__v.__k[0] = Kl(l, l.__c.__P, l.__c.__O);
      }
      var u;
      for (o.setState({ __a: o.__b = null }); u = o.o.pop(); ) u.forceUpdate();
    }
  };
  o.__u++ || 32 & t.__u || o.setState({ __a: o.__b = o.__v.__k[0] }), r.then(a, a);
}, Tn.prototype.componentWillUnmount = function() {
  this.o = [];
}, Tn.prototype.render = function(r, t) {
  if (this.__b) {
    if (this.__v.__k) {
      var e = document.createElement("div"), o = this.__v.__k[0].__c;
      this.__v.__k[0] = Wl(this.__b, e, o.__O = o.__P);
    }
    this.__b = null;
  }
  var n = t.__a && Ot(dr, null, r.fallback);
  return n && (n.__u &= -33), [Ot(dr, null, t.__a ? null : r.children), n];
};
var Za = function(r, t, e) {
  if (++e[1] === e[0] && r.l.delete(t), r.props.revealOrder && (r.props.revealOrder[0] !== "t" || !r.l.size)) for (e = r.i; e; ) {
    for (; e.length > 3; ) e.pop()();
    if (e[1] < e[0]) break;
    r.i = e = e[2];
  }
};
(Eo.prototype = new V()).__a = function(r) {
  var t = this, e = Zl(t.__v), o = t.l.get(r);
  return o[0]++, function(n) {
    var i = function() {
      t.props.revealOrder ? (o.push(n), Za(t, r, o)) : n();
    };
    e ? e(i) : i();
  };
}, Eo.prototype.render = function(r) {
  this.i = null, this.l = /* @__PURE__ */ new Map();
  var t = Uo(r.children);
  r.revealOrder && r.revealOrder[0] === "b" && t.reverse();
  for (var e = t.length; e--; ) this.l.set(t[e], this.i = [
    1,
    0,
    this.i
  ]);
  return r.children;
}, Eo.prototype.componentDidUpdate = Eo.prototype.componentDidMount = function() {
  var r = this;
  this.l.forEach(function(t, e) {
    Za(r, e, t);
  });
};
var bd = typeof Symbol != "undefined" && Symbol.for && /* @__PURE__ */ Symbol.for("react.element") || 60103, Od = /^(?:accent|alignment|arabic|baseline|cap|clip(?!PathU)|color|dominant|fill|flood|font|glyph(?!R)|horiz|image(!S)|letter|lighting|marker(?!H|W|U)|overline|paint|pointer|shape|stop|strikethrough|stroke|text(?!L)|transform|underline|unicode|units|v|vector|vert|word|writing|x(?!C))[A-Z]/, wd = /^on(Ani|Tra|Tou|BeforeInp|Compo)/, Sd = /[A-Z0-9]/g, Ad = typeof document != "undefined", Md = function(r) {
  return (typeof Symbol != "undefined" && typeof /* @__PURE__ */ Symbol() == "symbol" ? /fil|che|rad/ : /fil|che|ra/).test(r);
};
function qa(r, t, e) {
  return t.__k == null && (t.textContent = ""), $u(r, t), typeof e == "function" && e(), r ? r.__c : null;
}
V.prototype.isReactComponent = {}, [
  "componentWillMount",
  "componentWillReceiveProps",
  "componentWillUpdate"
].forEach(function(r) {
  Object.defineProperty(V.prototype, r, {
    configurable: !0,
    get: function() {
      return this["UNSAFE_" + r];
    },
    set: function(t) {
      Object.defineProperty(this, r, {
        configurable: !0,
        writable: !0,
        value: t
      });
    }
  });
});
var Ja = H.event;
function Pd() {
}
function Td() {
  return this.cancelBubble;
}
function Nd() {
  return this.defaultPrevented;
}
H.event = function(r) {
  return Ja && (r = Ja(r)), r.persist = Pd, r.isPropagationStopped = Td, r.isDefaultPrevented = Nd, r.nativeEvent = r;
};
var ql, Dd = {
  enumerable: !1,
  configurable: !0,
  get: function() {
    return this.class;
  }
}, Qa = H.vnode;
H.vnode = function(r) {
  typeof r.type == "string" && (function(t) {
    var e = t.props, o = t.type, n = {}, i = o.indexOf("-") === -1;
    for (var a in e) {
      var s = e[a];
      if (!(a === "value" && "defaultValue" in e && s == null || Ad && a === "children" && o === "noscript" || a === "class" || a === "className")) {
        var l = a.toLowerCase();
        a === "defaultValue" && "value" in e && e.value == null ? a = "value" : a === "download" && s === !0 ? s = "" : l === "translate" && s === "no" ? s = !1 : l[0] === "o" && l[1] === "n" ? l === "ondoubleclick" ? a = "ondblclick" : l !== "onchange" || o !== "input" && o !== "textarea" || Md(e.type) ? l === "onfocus" ? a = "onfocusin" : l === "onblur" ? a = "onfocusout" : wd.test(a) && (a = l) : l = a = "oninput" : i && Od.test(a) ? a = a.replace(Sd, "-$&").toLowerCase() : s === null && (s = void 0), l === "oninput" && n[a = l] && (a = "oninputCapture"), n[a] = s;
      }
    }
    o == "select" && n.multiple && Array.isArray(n.value) && (n.value = Uo(e.children).forEach(function(u) {
      u.props.selected = n.value.indexOf(u.props.value) != -1;
    })), o == "select" && n.defaultValue != null && (n.value = Uo(e.children).forEach(function(u) {
      u.props.selected = n.multiple ? n.defaultValue.indexOf(u.props.value) != -1 : n.defaultValue == u.props.value;
    })), e.class && !e.className ? (n.class = e.class, Object.defineProperty(n, "className", Dd)) : (e.className && !e.class || e.class && e.className) && (n.class = n.className = e.className), t.props = n;
  })(r), r.$$typeof = bd, Qa && Qa(r);
};
var ts = H.__r;
H.__r = function(r) {
  ts && ts(r), ql = r.__c;
};
var es = H.diffed;
H.diffed = function(r) {
  es && es(r);
  var t = r.props, e = r.__e;
  e != null && r.type === "textarea" && "value" in t && t.value !== e.value && (e.value = t.value == null ? "" : t.value), ql = null;
};
var Cd = 0;
function S(r, t, e, o, n, i) {
  t || (t = {});
  var a, s, l = t;
  if ("ref" in l) for (s in l = {}, t) s == "ref" ? a = t[s] : l[s] = t[s];
  var u = {
    type: r,
    props: l,
    key: e,
    ref: a,
    __k: null,
    __: null,
    __b: 0,
    __e: null,
    __c: null,
    constructor: void 0,
    __v: --Cd,
    __i: -1,
    __u: 0,
    __source: n,
    __self: i
  };
  if (typeof r == "function" && (a = r.defaultProps)) for (s in a) l[s] === void 0 && (l[s] = a[s]);
  return H.vnode && H.vnode(u), u;
}
var Ld = function(r, t) {
  var e = {};
  for (var o in r) Object.prototype.hasOwnProperty.call(r, o) && t.indexOf(o) < 0 && (e[o] = r[o]);
  if (r != null && typeof Object.getOwnPropertySymbols == "function")
    for (var n = 0, o = Object.getOwnPropertySymbols(r); n < o.length; n++) t.indexOf(o[n]) < 0 && Object.prototype.propertyIsEnumerable.call(r, o[n]) && (e[o[n]] = r[o[n]]);
  return e;
}, to;
(function(r) {
  function t(e) {
    var o = Ld(e, []);
    if (!e.container) throw new Error("Ensure the container of LogicFlow is specified and valid.");
    return U({}, r.defaults, o);
  }
  r.get = t;
})(to || (to = {}));
(function(r) {
  r.defaults = {
    background: !1,
    grid: !1,
    textEdit: !0,
    snapline: !0,
    outline: !1,
    disabledTools: []
  };
})(to || (to = {}));
var rs = {
  node: !1,
  edge: !1
}, jd = {
  node: !0,
  edge: !0
}, Rd = function(r) {
  return !r || typeof r == "boolean" ? r === !0 ? R(jd) : R(rs) : Bi(R(rs), r);
}, Id = function() {
  return He(window, "navigator.userAgent", "").match(/MSIE|Trident/) !== null;
};
function Mt(r) {
  try {
    return JSON.parse(JSON.stringify(r));
  } catch (t) {
    return r;
  }
}
var kd = {
  baseNode: {
    fill: "#fff",
    stroke: "#474747",
    strokeWidth: 2,
    radius: 12
  },
  baseEdge: {
    stroke: "#474747",
    strokeWidth: 2,
    radius: 12
  },
  rect: { shadow: {
    dx: 0,
    dy: 0,
    stdDeviation: 4,
    floodColor: "#9CA1AA55"
  } },
  circle: {},
  diamond: {},
  ellipse: {},
  polygon: {},
  html: {
    fill: "transparent",
    stroke: "transparent",
    shadow: {
      dx: 0,
      dy: 0,
      stdDeviation: 4,
      floodColor: "#9CA1AA55"
    }
  },
  text: {
    color: "#474747",
    stroke: "none",
    fontSize: 12,
    background: { fill: "transparent" }
  },
  nodeText: {
    color: "#474747",
    overflowMode: "default",
    fontSize: 12,
    lineHeight: 1.2
  },
  anchor: {
    stroke: "#474747",
    fill: "#fff",
    r: 4,
    hover: {
      r: 8,
      fill: "#707070",
      fillOpacity: 0.15,
      stroke: "transparent"
    }
  },
  anchorLine: {
    stroke: "#474747",
    strokeWidth: 2,
    strokeDasharray: "3,2"
  },
  line: {},
  polyline: {},
  bezier: {
    fill: "none",
    adjustLine: { stroke: "#949494" },
    adjustAnchor: {
      r: 4,
      fill: "#949494",
      fillOpacity: 1,
      stroke: "#949494"
    }
  },
  edgeText: {
    textWidth: 100,
    overflowMode: "default",
    fontSize: 12,
    background: { fill: "#fff" }
  },
  arrow: {
    strokeLinecap: "round",
    strokeLinejoin: "round",
    offset: 10,
    verticalLength: 5
  },
  snapline: {
    strokeLinecap: "round",
    strokeLinejoin: "round",
    stroke: "#AAAAAA",
    strokeWidth: 1,
    strokeDasharray: "3,3"
  },
  edgeAdjust: {
    r: 4,
    fill: "#fff",
    stroke: "#474747",
    strokeWidth: 1
  },
  outline: {
    fill: "none",
    stroke: "transparent",
    strokeWidth: 0
  },
  edgeOutline: {
    fill: "transparent",
    stroke: "#757575",
    strokeWidth: 1.5,
    strokeDasharray: "4,4",
    radius: 8,
    hover: { stroke: "#4271DF" }
  },
  edgeAnimation: {
    stroke: "#4271DF",
    strokeDasharray: "12,4,6,4",
    strokeDashoffset: "100%",
    animationName: "lf_animate_dash",
    animationDuration: "20s",
    animationIterationCount: "infinite",
    animationTimingFunction: "linear",
    animationDirection: "normal"
  },
  rotateControl: {
    stroke: "#474747",
    fill: "#fff",
    strokeWidth: 1,
    hover: {
      fill: "#707070",
      fillOpacity: 0.15,
      stroke: "transparent"
    }
  },
  resizeControl: {
    width: 8,
    height: 8,
    radius: 2,
    fill: "#fff",
    stroke: "#474747",
    hover: {
      width: 12,
      height: 12,
      fill: "#707070",
      fillOpacity: 0.15,
      stroke: "transparent"
    }
  },
  resizeOutline: {
    fill: "transparent",
    stroke: "#757575",
    strokeWidth: 1.5,
    strokeDasharray: "4,4",
    radius: 8,
    hover: { stroke: "#4271DF" }
  }
}, Bd = {
  baseNode: {
    fill: "#fff",
    stroke: "#000",
    strokeWidth: 2
  },
  baseEdge: {
    stroke: "#000",
    strokeWidth: 2
  },
  rect: {},
  circle: {},
  diamond: {},
  ellipse: {},
  polygon: {},
  html: {
    fill: "transparent",
    stroke: "transparent"
  },
  text: {
    color: "#000",
    stroke: "none",
    fontSize: 12,
    background: { fill: "transparent" }
  },
  anchor: {
    stroke: "#000",
    fill: "#fff",
    r: 4,
    hover: {
      r: 10,
      fill: "#949494",
      fillOpacity: 0.5,
      stroke: "#949494"
    }
  },
  anchorLine: {
    stroke: "#000",
    strokeWidth: 2,
    strokeDasharray: "3,2"
  },
  nodeText: {
    color: "#000",
    overflowMode: "default",
    fontSize: 12,
    lineHeight: 1.2
  },
  edgeText: {
    textWidth: 100,
    overflowMode: "default",
    fontSize: 12,
    background: { fill: "#fff" }
  },
  line: {},
  polyline: {},
  bezier: {
    fill: "none",
    adjustLine: { stroke: "#949494" },
    adjustAnchor: {
      r: 4,
      fill: "#949494",
      fillOpacity: 1,
      stroke: "#949494"
    }
  },
  arrow: {
    offset: 10,
    verticalLength: 5
  },
  snapline: {
    stroke: "#949494",
    strokeWidth: 1
  },
  edgeAdjust: {
    r: 4,
    fill: "#fff",
    stroke: "#949494",
    strokeWidth: 2
  },
  outline: {
    fill: "transparent",
    stroke: "#949494",
    strokeDasharray: "3,3",
    hover: { stroke: "#949494" }
  },
  edgeOutline: {
    fill: "transparent",
    stroke: "#949494",
    strokeDasharray: "3,3",
    hover: { stroke: "#949494" }
  },
  edgeAnimation: {
    stroke: "red",
    strokeDasharray: "10,10",
    strokeDashoffset: "100%",
    animationName: "lf_animate_dash",
    animationDuration: "20s",
    animationIterationCount: "infinite",
    animationTimingFunction: "linear",
    animationDirection: "normal"
  },
  rotateControl: {
    stroke: "#000",
    fill: "#fff",
    strokeWidth: 1.5
  },
  resizeControl: {
    width: 7,
    height: 7,
    fill: "#fff",
    stroke: "#000"
  },
  resizeOutline: {
    fill: "none",
    stroke: "transparent",
    strokeWidth: 1,
    strokeDasharray: "3,3"
  }
}, Xd = {
  baseNode: {
    fill: "#33353A",
    stroke: "#EAEAEA",
    strokeWidth: 2,
    radius: 12
  },
  baseEdge: {
    stroke: "#EAEAEA",
    strokeWidth: 2,
    radius: 12
  },
  rect: {},
  circle: {},
  diamond: {},
  ellipse: {},
  polygon: {},
  html: {
    fill: "#33353A",
    stroke: "transparent",
    shadow: {
      dx: 0,
      dy: 0,
      stdDeviation: 4,
      floodColor: "#9CA1AA55"
    }
  },
  text: {
    color: "#EAEAEA",
    stroke: "none",
    fontSize: 12,
    background: { fill: "transparent" }
  },
  nodeText: {
    color: "#EAEAEA",
    overflowMode: "default",
    fontSize: 12,
    lineHeight: 1.2
  },
  anchor: {
    stroke: "#EAEAEA",
    fill: "#33353A",
    r: 4,
    hover: {
      r: 8,
      fill: "#707070",
      fillOpacity: 0.15,
      stroke: "transparent"
    }
  },
  anchorLine: {
    stroke: "#EAEAEA",
    strokeWidth: 2,
    strokeDasharray: "3,2"
  },
  line: {},
  polyline: {},
  bezier: {
    fill: "none",
    adjustLine: { stroke: "#EAEAEA" },
    adjustAnchor: {
      r: 4,
      fill: "#33353A",
      fillOpacity: 1,
      stroke: "#EAEAEA"
    }
  },
  edgeText: {
    textWidth: 100,
    overflowMode: "default",
    fontSize: 12,
    background: { fill: "#EAEAEA" }
  },
  arrow: {
    strokeLinecap: "round",
    strokeLinejoin: "round",
    offset: 10,
    verticalLength: 5
  },
  snapline: {
    strokeLinecap: "round",
    strokeLinejoin: "round",
    stroke: "#949494",
    strokeWidth: 1
  },
  edgeAdjust: {
    r: 4,
    fill: "#33353A",
    stroke: "#EAEAEA",
    strokeWidth: 1
  },
  outline: {
    fill: "none",
    stroke: "transparent",
    strokeWidth: 0
  },
  edgeOutline: {
    fill: "transparent",
    stroke: "#EAEAEA",
    strokeWidth: 1.5,
    strokeDasharray: "4,4",
    radius: 8,
    hover: { stroke: "#4271DF" }
  },
  edgeAnimation: {
    stroke: "#4271DF",
    strokeDasharray: "12,4,6,4",
    strokeDashoffset: "100%",
    animationName: "lf_animate_dash",
    animationDuration: "20s",
    animationIterationCount: "infinite",
    animationTimingFunction: "linear",
    animationDirection: "normal"
  },
  rotateControl: {
    stroke: "#EAEAEA",
    fill: "#33353A",
    strokeWidth: 1,
    hover: {
      fill: "#707070",
      fillOpacity: 0.15,
      stroke: "transparent"
    }
  },
  resizeControl: {
    width: 8,
    height: 8,
    radius: 2,
    fill: "#33353A",
    stroke: "#EAEAEA",
    hover: {
      width: 12,
      height: 12,
      fill: "#707070",
      fillOpacity: 0.15,
      stroke: "transparent"
    }
  },
  resizeOutline: {
    fill: "transparent",
    stroke: "#EAEAEA",
    strokeWidth: 1.5,
    strokeDasharray: "4,4",
    radius: 8,
    hover: { stroke: "#4271DF" }
  }
}, Yd = {
  baseNode: {
    fill: "#fff",
    stroke: "#474747",
    strokeWidth: 2,
    radius: 12
  },
  baseEdge: {
    stroke: "#474747",
    strokeWidth: 2,
    radius: 12
  },
  rect: {
    fill: "#72CBFF",
    stroke: "#3ABDF9",
    radius: 8
  },
  circle: {
    fill: "#FFE075",
    stroke: "#F9CE3A",
    radius: 8
  },
  ellipse: {
    fill: "#FFA8A8",
    stroke: "#FF6B66",
    radius: 8
  },
  text: {
    fill: "#72CBFF",
    radius: 8,
    fontSize: 12
  },
  diamond: {
    fill: "#96F7AF",
    stroke: "#40EF7E",
    radius: 8
  },
  polygon: {
    fill: "#E0A8FF",
    stroke: "#C271FF",
    radius: 8
  },
  nodeText: {
    color: "#474747",
    overflowMode: "default",
    fontSize: 12,
    lineHeight: 1.2
  },
  edgeText: {
    textWidth: 100,
    overflowMode: "default",
    fontSize: 12,
    background: { fill: "#fff" }
  },
  html: {
    fill: "#fff",
    stroke: "transparent",
    strokeWidth: 0
  },
  anchor: {
    stroke: "#474747",
    fill: "#fff",
    r: 4,
    hover: {
      r: 8,
      fill: "#707070",
      fillOpacity: 0.15,
      stroke: "transparent"
    }
  },
  anchorLine: {
    stroke: "#474747",
    strokeWidth: 2,
    strokeDasharray: "3,2"
  },
  line: {},
  polyline: { radius: 8 },
  bezier: {
    fill: "none",
    adjustLine: { stroke: "#3ABDF9" },
    adjustAnchor: {
      r: 4,
      fill: "#3ABDF9",
      fillOpacity: 1,
      stroke: "#3ABDF9"
    }
  },
  edgeAdjust: {
    r: 4,
    fill: "#fff",
    stroke: "#474747",
    strokeWidth: 1
  },
  arrow: {
    strokeLinecap: "round",
    strokeLinejoin: "round",
    offset: 10,
    verticalLength: 5
  },
  snapline: {
    strokeLinecap: "round",
    strokeLinejoin: "round",
    stroke: "#949494",
    strokeWidth: 1
  },
  outline: {
    radius: 8,
    fill: "transparent",
    stroke: "#949494",
    strokeDasharray: "3,3",
    hover: { stroke: "#949494" }
  },
  edgeOutline: {
    fill: "transparent",
    stroke: "#757575",
    strokeWidth: 1.5,
    strokeDasharray: "4,4",
    radius: 8,
    hover: { stroke: "#4271DF" }
  },
  edgeAnimation: {
    stroke: "#4271DF",
    strokeDasharray: "12,4,6,4",
    strokeDashoffset: "100%",
    animationName: "lf_animate_dash",
    animationDuration: "20s",
    animationIterationCount: "infinite",
    animationTimingFunction: "linear",
    animationDirection: "normal"
  },
  rotateControl: {
    stroke: "#474747",
    fill: "#fff",
    strokeWidth: 1,
    hover: {
      fill: "#707070",
      fillOpacity: 0.15,
      stroke: "transparent"
    }
  },
  resizeControl: {
    width: 8,
    height: 8,
    radius: 2,
    fill: "#fff",
    stroke: "#474747",
    hover: {
      width: 12,
      height: 12,
      fill: "#707070",
      fillOpacity: 0.15,
      stroke: "transparent"
    }
  },
  resizeOutline: {
    fill: "transparent",
    stroke: "#757575",
    strokeWidth: 1.5,
    strokeDasharray: "4,4",
    radius: 8,
    hover: { stroke: "#4271DF" }
  }
}, _r = {
  default: kd,
  colorful: Yd,
  dark: Xd,
  retro: Bd
}, Hd = { background: "#33353A" }, Gd = { background: "#fefeff" }, Jl = { background: "#FBFCFE" }, zd = { background: "#ffffff" }, Xe = {
  colorful: Gd,
  dark: Hd,
  default: Jl,
  retro: zd
}, $d = {
  size: 10,
  visible: !0,
  type: "mesh",
  config: {
    color: "#83838377",
    thickness: 2
  },
  majorBold: !0
}, Ud = {
  size: 10,
  visible: !0,
  type: "dot",
  config: {
    color: "#b7c2d9",
    thickness: 2
  },
  majorBold: !1
}, na = {
  size: 10,
  visible: !0,
  type: "mesh",
  config: {
    color: "#D7DEEB",
    thickness: 1
  },
  majorBold: {
    opacity: 0.6,
    boldIndices: [5],
    dashArrayConfig: { pattern: [] },
    customBoldWidth: 2
  }
}, Vd = {
  size: 10,
  visible: !0,
  type: "dot",
  config: {
    color: "#ababab",
    thickness: 1
  },
  majorBold: !1
}, Ye = {
  colorful: Ud,
  dark: $d,
  retro: Vd,
  default: na
}, Fd = 9999, J;
(function(r) {
  r[r.DEFAULT = 1] = "DEFAULT", r[r.TEXT_EDIT = 2] = "TEXT_EDIT", r[r.SHOW_MENU = 3] = "SHOW_MENU", r[r.ALLOW_CONNECT = 4] = "ALLOW_CONNECT", r[r.NOT_ALLOW_CONNECT = 5] = "NOT_ALLOW_CONNECT";
})(J || (J = {}));
var dt;
(function(r) {
  r.NODE = "node", r.EDGE = "edge", r.GRAPH = "graph";
})(dt || (dt = {}));
var G;
(function(r) {
  r.NODE = "node", r.CIRCLE_NODE = "circle-node", r.POLYGON_NODE = "polygon-node", r.RECT_NODE = "rect-node", r.TEXT_NODE = "text-node", r.ELLIPSE_NODE = "ellipse-node", r.DIAMOND_NODE = "diamond-node", r.HTML_NODE = "html-node", r.CUSTOM_HTML_NODE = "custom-html-node", r.EDGE = "edge", r.LINE_EDGE = "line-edge", r.POLYLINE_EDGE = "polyline-edge", r.BEZIER_EDGE = "bezier-edge", r.GRAPH = "graph";
})(G || (G = {}));
var L;
(function(r) {
  r.ELEMENT_CLICK = "element:click", r.NODE_ADD = "node:add", r.NODE_DELETE = "node:delete", r.NODE_CLICK = "node:click", r.NODE_DBCLICK = "node:dbclick", r.NODE_GROUP_COPY = "node:group-copy-add", r.NODE_DND_ADD = "node:dnd-add", r.NODE_DND_DRAG = "node:dnd-drag", r.NODE_MOUSEDOWN = "node:mousedown", r.NODE_DRAGSTART = "node:dragstart", r.NODE_DRAG = "node:drag", r.NODE_DROP = "node:drop", r.NODE_MOUSEUP = "node:mouseup", r.NODE_MOUSEMOVE = "node:mousemove", r.NODE_MOUSEENTER = "node:mouseenter", r.NODE_MOUSELEAVE = "node:mouseleave", r.NODE_CONTEXTMENU = "node:contextmenu", r.NODE_ROTATE = "node:rotate", r.NODE_RESIZE = "node:resize", r.NODE_FOCUS = "node:focus", r.NODE_BLUR = "node:blur", r.NODE_PROPERTIES_CHANGE = "node:properties-change", r.NODE_PROPERTIES_DELETE = "node:properties-delete", r.EDGE_ADD = "edge:add", r.EDGE_DELETE = "edge:delete", r.EDGE_CLICK = "edge:click", r.EDGE_DBCLICK = "edge:dbclick", r.EDGE_FOCUS = "edge:focus", r.EDGE_BLUR = "edge:blur", r.EDGE_MOUSEENTER = "edge:mouseenter", r.EDGE_MOUSELEAVE = "edge:mouseleave", r.EDGE_CONTEXTMENU = "edge:contextmenu", r.EDGE_ADJUST = "edge:adjust", r.EDGE_EXCHANGE_NODE = "edge:exchange-node", r.ANCHOR_CLICK = "anchor:click", r.ANCHOR_MOUSEDOWN = "anchor:mousedown", r.ANCHOR_DRAGSTART = "anchor:dragstart", r.ANCHOR_DRAG = "anchor:drag", r.ANCHOR_DROP = "anchor:drop", r.ANCHOR_DRAGEND = "anchor:dragend", r.ADJUST_POINT_MOUSEDOWN = "adjustPoint:mousedown", r.ADJUST_POINT_MOUSEUP = "adjustPoint:mouseup", r.ADJUST_POINT_MOUSEMOVE = "adjustPoint:mousemove", r.ADJUST_POINT_DRAGSTART = "adjustPoint:dragstart", r.ADJUST_POINT_DRAG = "adjustPoint:drag", r.ADJUST_POINT_DROP = "adjustPoint:drop", r.ADJUST_POINT_DRAGEND = "adjustPoint:dragend", r.BLANK_MOUSEDOWN = "blank:mousedown", r.BLANK_DRAGSTART = "blank:dragstart", r.BLANK_DRAG = "blank:drag", r.BLANK_DROP = "blank:drop", r.BLANK_MOUSEMOVE = "blank:mousemove", r.BLANK_CANVAS_MOUSEMOVE = "blank:canvas-mousemove", r.BLANK_MOUSEUP = "blank:mouseup", r.BLANK_CLICK = "blank:click", r.BLANK_CONTEXTMENU = "blank:contextmenu", r.SELECTION_MOUSEDOWN = "selection:mousedown", r.SELECTION_DRAGSTART = "selection:dragstart", r.SELECTION_DRAG = "selection:drag", r.SELECTION_DROP = "selection:drop", r.SELECTION_MOUSEMOVE = "selection:mousemove", r.SELECTION_MOUSEUP = "selection:mouseup", r.SELECTION_CONTEXTMENU = "selection:contextmenu", r.CONNECTION_NOT_ALLOWED = "connection:not-allowed", r.TEXT_MOUSEDOWN = "text:mousedown", r.TEXT_DRAGSTART = "text:dragstart", r.TEXT_DRAG = "text:drag", r.TEXT_DROP = "text:drop", r.TEXT_CLICK = "text:click", r.TEXT_DBCLICK = "text:dbclick", r.TEXT_BLUR = "text:blur", r.TEXT_MOUSEMOVE = "text:mousemove", r.TEXT_MOUSEUP = "text:mouseup", r.TEXT_FOCUS = "text:focus", r.TEXT_ADD = "text:add", r.TEXT_UPDATE = "text:update", r.TEXT_CLEAR = "text:clear", r.LABEL_MOUSEDOWN = "label:mousedown", r.LABEL_DRAGSTART = "label:dragstart", r.LABEL_DRAG = "label:drag", r.LABEL_DROP = "label:drop", r.LABEL_CLICK = "label:click", r.LABEL_DBCLICK = "label:dbclick", r.LABEL_BLUR = "label:blur", r.LABEL_MOUSEMOVE = "label:mousemove", r.LABEL_MOUSEUP = "label:mouseup", r.LABEL_FOCUS = "label:focus", r.LABEL_ADD = "label:add", r.LABEL_UPDATE = "label:update", r.LABEL_CLEAR = "label:clear", r.LABEL_DELETE = "label:delete", r.LABEL_SHOULD_ADD = "label:should-add", r.LABEL_BATCH_ADD = "label:batch-add", r.LABEL_SHOULD_UPDATE = "label:should-update", r.LABEL_SHOULD_DELETE = "label:should-delete", r.LABEL_BATCH_DELETE = "label:batch-delete", r.LABEL_NOT_ALLOWED_ADD = "label:not-allowed-add", r.HISTORY_CHANGE = "history:change", r.GRAPH_TRANSFORM = "graph:transform", r.GRAPH_RENDERED = "graph:rendered", r.GRAPH_UPDATED = "graph:updated", r.EDIT_CONFIG_CHANGED = "editConfig:changed";
})(L || (L = {}));
var mt;
(function(r) {
  r[r.STATIC = -1] = "STATIC", r[r.DEFAULT = 0] = "DEFAULT", r[r.INCREASE = 1] = "INCREASE", r[r.EDGE_TOP = 2] = "EDGE_TOP";
})(mt || (mt = {}));
var $;
(function(r) {
  r.HORIZONTAL = "horizontal", r.VERTICAL = "vertical";
})($ || ($ = {}));
var Xt;
(function(r) {
  r.TEXT = "text", r.LABEL = "label";
})(Xt || (Xt = {}));
var Wd = 0, de = (function() {
  function r(t) {
    var e = t.onDragStart, o = e === void 0 ? Sn : e, n = t.onDragging, i = n === void 0 ? Sn : n, a = t.onDragEnd, s = a === void 0 ? Sn : a, l = t.eventType, u = l === void 0 ? "" : l, c = t.eventCenter, d = t.step, f = d === void 0 ? 1 : d, p = t.isStopPropagation, v = p === void 0 ? !0 : p, h = t.model, g = t.data, y = this;
    this.isDragging = !1, this.isStartDragging = !1, this.startX = 0, this.startY = 0, this.sumDeltaX = 0, this.sumDeltaY = 0, this.handleMouseDown = function(_) {
      var E, x, O = window == null ? void 0 : window.document;
      if (_.button === Wd) {
        y.isStopPropagation && _.stopPropagation(), y.isStartDragging = !0, y.startX = _.clientX, y.startY = _.clientY, O.addEventListener("pointermove", y.handleMouseMove, !1), O.addEventListener("pointerup", y.handleMouseUp, !1);
        var M = (E = y.model) === null || E === void 0 ? void 0 : E.getData();
        (x = y.eventCenter) === null || x === void 0 || x.emit(L["".concat(y.eventType, "_MOUSEDOWN")], {
          e: _,
          data: y.data || M
        }), y.startTime = (/* @__PURE__ */ new Date()).getTime();
      }
    }, this.handleMouseMove = function(_) {
      var E, x;
      if (y.isStopPropagation && _.stopPropagation(), _.preventDefault(), !!y.isStartDragging && (y.sumDeltaX += _.clientX - y.startX, y.sumDeltaY += _.clientY - y.startY, y.startX = _.clientX, y.startY = _.clientY, y.step <= 1 || Math.abs(y.sumDeltaX) > y.step || Math.abs(y.sumDeltaY) > y.step)) {
        var O = y.sumDeltaX % y.step, M = y.sumDeltaY % y.step, P = y.sumDeltaX - O, m = y.sumDeltaY - M;
        y.sumDeltaX = O, y.sumDeltaY = M;
        var w = (E = y.model) === null || E === void 0 ? void 0 : E.getData();
        y.isDragging || ((x = y.eventCenter) === null || x === void 0 || x.emit(L["".concat(y.eventType, "_DRAGSTART")], {
          e: _,
          data: y.data || w
        }), y.onDragStart({ event: _ })), y.isDragging = !0, Promise.resolve().then(function() {
          var T, D;
          y.onDragging({
            deltaX: P,
            deltaY: m,
            event: _
          }), (T = y.eventCenter) === null || T === void 0 || T.emit(L["".concat(y.eventType, "_MOUSEMOVE")], {
            deltaX: P,
            deltaY: m,
            e: _,
            data: y.data || w
          }), (D = y.eventCenter) === null || D === void 0 || D.emit(L["".concat(y.eventType, "_DRAG")], {
            e: _,
            data: y.data || w
          });
        });
      }
    }, this.handleMouseUp = function(_) {
      var E = window.document;
      y.isStartDragging = !1, y.isStopPropagation && _.stopPropagation();
      var x = _.target;
      x && typeof x.releasePointerCapture == "function" && x.releasePointerCapture(_.pointerId), Promise.resolve().then(function() {
        var O, M, P;
        E.removeEventListener("pointermove", y.handleMouseMove, !1), E.removeEventListener("pointerup", y.handleMouseUp, !1);
        var m = (O = y.model) === null || O === void 0 ? void 0 : O.getData();
        (M = y.eventCenter) === null || M === void 0 || M.emit(L["".concat(y.eventType, "_MOUSEUP")], {
          e: _,
          data: y.data || m
        }), y.isDragging && (y.isDragging = !1, y.onDragEnd({ event: _ }), (P = y.eventCenter) === null || P === void 0 || P.emit(L["".concat(y.eventType, "_DROP")], {
          e: _,
          data: y.data || m
        }));
      });
    }, this.cancelDrag = function() {
      var _ = window == null ? void 0 : window.document;
      _.removeEventListener("pointermove", y.handleMouseMove, !1), _.removeEventListener("pointerup", y.handleMouseUp, !1), y.onDragEnd({ event: void 0 }), y.isDragging = !1;
    }, this.destroy = function() {
      y.isStartDragging && y.cancelDrag();
    }, this.onDragStart = o, this.onDragging = i, this.onDragEnd = s, this.step = f, this.isStopPropagation = v, this.eventType = u, this.eventCenter = c, this.model = h, this.data = g;
  }
  return r.prototype.setStep = function(t) {
    this.step = t;
  }, r.prototype.setModel = function(t) {
    this.model = t;
  }, r;
})(), Kd = function(r) {
  var t = r.x, e = r.y, o = r.width, n = r.height;
  return {
    x: t - o / 2,
    y: e - n / 2,
    x1: t + o / 2,
    y1: e + n / 2
  };
}, Zd = function(r) {
  var t = r.startPoint, e = r.endPoint, o = (t.x + e.x) / 2, n = (t.y + e.y) / 2, i = Math.abs(t.x - e.x) + 10, a = Math.abs(t.y - e.y) + 10;
  return {
    x: o - i / 2,
    y: n - a / 2,
    x1: o + i / 2,
    y1: n + a / 2
  };
}, qd = function(r) {
  var t = r.points, e = Me(t), o = En(e, 8), n = o.x, i = o.y, a = o.width, s = o.height;
  return {
    x: n - a / 2,
    y: i - s / 2,
    x1: n + a / 2,
    y1: i + s / 2
  };
}, Jd = function(r) {
  var t = r.path, e = ia(t), o = En(e, 8), n = o.x, i = o.y, a = o.width, s = o.height;
  return {
    x: n - a / 2,
    y: i - s / 2,
    x1: n + a / 2,
    y1: i + s / 2
  };
}, Qd = function(r) {
  if (r.modelType === G.LINE_EDGE) return Zd(r);
  if (r.modelType === G.POLYLINE_EDGE) return qd(r);
  if (r.modelType === G.BEZIER_EDGE) return Jd(r);
}, tf = function(r, t, e, o) {
  var n = (t.y - r.y) * (o.x - e.x) - (r.x - t.x) * (e.y - o.y);
  if (n === 0) return !1;
  var i = ((t.x - r.x) * (o.x - e.x) * (e.y - r.y) + (t.y - r.y) * (o.x - e.x) * r.x - (o.y - e.y) * (t.x - r.x) * e.x) / n, a = -((t.y - r.y) * (o.y - e.y) * (e.x - r.x) + (t.x - r.x) * (o.y - e.y) * r.y - (o.x - e.x) * (t.y - r.y) * e.y) / n;
  return (i - r.x) * (i - t.x) <= 0 && (a - r.y) * (a - t.y) <= 0 && (i - e.x) * (i - o.x) <= 0 && (a - e.y) * (a - o.y) <= 0 ? {
    x: i,
    y: a
  } : !1;
}, eo = function(r, t, e) {
  var o = r.x, n = r.y, i = t.x, a = t.y, s = e.x, l = e.y, u = (l - a) / (s - i), c = a - u * i;
  return (o >= i && o <= s || o <= i && o >= s) && (n >= a && n <= l || n <= a && n >= l) && Math.abs(n - u * o - c) < Number.EPSILON;
}, ro = function(r) {
  var t = r.start, e = r.end, o = r.offset, n = r.verticalLength, i = r.type, a = {
    leftX: 0,
    leftY: 0,
    rightX: 0,
    rightY: 0
  }, s = Math.atan((e.y - t.y) / (e.x - t.x)), l = Math.atan(o / n), u = Math.sqrt(n * n + o * o);
  return i === "start" ? e.x >= t.x ? (a.leftX = t.x + u * Math.sin(s + l), a.leftY = t.y - u * Math.cos(s + l), a.rightX = t.x - u * Math.sin(s - l), a.rightY = t.y + u * Math.cos(s - l)) : (a.leftX = t.x - u * Math.sin(s + l), a.leftY = t.y + u * Math.cos(s + l), a.rightX = t.x + u * Math.sin(s - l), a.rightY = t.y - u * Math.cos(s - l)) : i === "end" && (e.x >= t.x ? (a.leftX = e.x + u * Math.sin(s - l), a.leftY = e.y - u * Math.cos(s - l), a.rightX = e.x - u * Math.sin(s + l), a.rightY = e.y + u * Math.cos(s + l)) : (a.leftX = e.x - u * Math.sin(s - l), a.leftY = e.y + u * Math.cos(s - l), a.rightX = e.x + u * Math.sin(s + l), a.rightY = e.y - u * Math.cos(s + l))), a;
}, nr = function() {
  return nr = Object.assign || function(r) {
    for (var t, e = 1, o = arguments.length; e < o; e++) {
      t = arguments[e];
      for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && (r[n] = t[n]);
    }
    return r;
  }, nr.apply(this, arguments);
}, Bt = function(r, t) {
  var e = typeof Symbol == "function" && r[Symbol.iterator];
  if (!e) return r;
  var o = e.call(r), n, i = [], a;
  try {
    for (; (t === void 0 || t-- > 0) && !(n = o.next()).done; ) i.push(n.value);
  } catch (s) {
    a = { error: s };
  } finally {
    try {
      n && !n.done && (e = o.return) && e.call(o);
    } finally {
      if (a) throw a.error;
    }
  }
  return i;
}, we = function(r, t, e) {
  if (e || arguments.length === 2)
    for (var o = 0, n = t.length, i; o < n; o++) (i || !(o in t)) && (i || (i = Array.prototype.slice.call(t, 0, o)), i[o] = t[o]);
  return r.concat(i || Array.prototype.slice.call(t));
}, ef = function(r, t) {
  return Math.abs(r.centerX - t.centerX) * 2 < r.width + t.width && Math.abs(r.centerY - t.centerY) * 2 < r.height + t.height;
}, ni = function(r) {
  var t = [], e = {};
  return r.forEach(function(o) {
    var n = "".concat(o.x, "-").concat(o.y);
    o.id = n, e[n] = o;
  }), Object.keys(e).forEach(function(o) {
    t.push(e[o]);
  }), t;
}, tn = function(r, t) {
  return r.width === 0 && r.height === 0 ? r : {
    x: r.x,
    y: r.y,
    centerX: r.centerX,
    centerY: r.centerY,
    minX: r.minX - t,
    minY: r.minY - t,
    maxX: r.maxX + t,
    maxY: r.maxY + t,
    height: r.height + 2 * t,
    width: r.width + 2 * t
  };
}, rf = function(r, t) {
  var e = Math.abs(r.x - t.centerX), o = Math.abs(r.y - t.centerY);
  return e / t.width > o / t.height ? $.HORIZONTAL : $.VERTICAL;
}, en = function(r, t, e) {
  return rf(e, t) === $.HORIZONTAL ? {
    x: e.x > r.centerX ? r.maxX : r.minX,
    y: e.y
  } : {
    x: e.x,
    y: e.y > r.centerY ? r.maxY : r.minY
  };
}, os = function(r, t) {
  var e = Math.min(r.minX, t.minX), o = Math.min(r.minY, t.minY), n = Math.max(r.maxX, t.maxX), i = Math.max(r.maxY, t.maxY);
  return {
    x: (e + n) / 2,
    y: (o + i) / 2,
    centerX: (e + n) / 2,
    centerY: (o + i) / 2,
    minX: e,
    minY: o,
    maxX: n,
    maxY: i,
    height: i - o,
    width: n - e
  };
}, En = function(r, t, e) {
  r === void 0 && (r = []);
  var o = [], n = [];
  r.forEach(function(d) {
    o.push(d.x), n.push(d.y);
  });
  var i = Math.min.apply(Math, we([], Bt(o), !1)), a = Math.max.apply(Math, we([], Bt(o), !1)), s = Math.min.apply(Math, we([], Bt(n), !1)), l = Math.max.apply(Math, we([], Bt(n), !1)), u = a - i, c = l - s;
  return t && (u += t, c += e || t), {
    centerX: (i + a) / 2,
    centerY: (s + l) / 2,
    maxX: a,
    maxY: l,
    minX: i,
    minY: s,
    x: (i + a) / 2,
    y: (s + l) / 2,
    height: c,
    width: u
  };
}, rn = function(r) {
  var t = r.minX, e = r.minY, o = r.maxX, n = r.maxY;
  return [
    {
      x: t,
      y: e
    },
    {
      x: o,
      y: e
    },
    {
      x: o,
      y: n
    },
    {
      x: t,
      y: n
    }
  ];
}, bo = function(r, t) {
  var e = r.x, o = r.y;
  return e < t.minX || e > t.maxX || o < t.minY || o > t.maxY;
}, of = function(r, t) {
  return t < r.minX || t > r.maxX ? [] : [{
    x: t,
    y: r.minY
  }, {
    x: t,
    y: r.maxY
  }];
}, nf = function(r, t) {
  return t < r.minY || t > r.maxY ? [] : [{
    x: r.minX,
    y: t
  }, {
    x: r.maxX,
    y: t
  }];
}, af = function(r, t) {
  return we(we([], Bt(of(r, t.x)), !1), Bt(nf(r, t.y)), !1);
}, ii = function(r, t) {
  return Math.abs(r.x - t.x) + Math.abs(r.y - t.y);
}, sf = function(r, t) {
  var e = -2, o = 0;
  return t.forEach(function(n) {
    n && (r.x === n.x && (o += e), r.y === n.y && (o += e));
  }), o;
}, ns = function(r, t, e, o, n) {
  return ii(r, t) + ii(r, e) + sf(r, [
    t,
    e,
    o,
    n
  ]);
}, Ql = function(r, t, e, o, n) {
  n || (n = 0), r.unshift(t[o]), e[o] && e[o] !== o && n <= 100 && Ql(r, t, e, e[o], n + 1);
}, lf = function(r, t) {
  var e = r.indexOf(t);
  e > -1 && r.splice(e, 1);
}, Ir = function(r, t, e, o) {
  var n = t.x - r.x, i = t.y - r.y, a = o.x - e.x, s = o.y - e.y, l = (-i * (r.x - e.x) + n * (r.y - e.y)) / (-a * i + n * s), u = (a * (r.y - e.y) - s * (r.x - e.x)) / (-a * i + n * s);
  return l >= 0 && l <= 1 && u >= 0 && u <= 1;
}, is = function(r, t, e) {
  if (e.width === 0 && e.height === 0) return !1;
  var o = Bt(rn(e), 4), n = o[0], i = o[1], a = o[2], s = o[3];
  return Ir(r, t, n, i) || Ir(r, t, n, s) || Ir(r, t, i, a) || Ir(r, t, a, s);
}, uf = function(r, t, e, o) {
  var n = [];
  return r.forEach(function(i) {
    i !== t && (i.x === t.x || i.y === t.y) && !is(i, t, e) && !is(i, t, o) && n.push(i);
  }), ni(n);
}, cf = function(r, t, e, o, n, i, a) {
  var s = [], l = [t], u = {}, c = {}, d = {};
  t.id && (c[t.id] = 0, d[t.id] = ns(t, e, t));
  var f = {};
  r.forEach(function(h) {
    h.id && (f[h.id] = h);
  });
  for (var p = function() {
    var h, g = 1 / 0;
    if (l.forEach(function(_) {
      _.id && d[_.id] < g && (g = d[_.id], h = _);
    }), h === e && e.id) {
      var y = [];
      return Ql(y, f, u, e.id), { value: y };
    }
    if (!h) return { value: [t, e] };
    lf(l, h), s.push(h), uf(r, h, o, n).forEach(function(_) {
      var E;
      if (s.indexOf(_) === -1 && (l.indexOf(_) === -1 && l.push(_), h != null && h.id && (_ != null && _.id))) {
        var x = ((E = c[h.id]) !== null && E !== void 0 ? E : 0) + ii(h, _);
        if (c[_.id] && x >= c[_.id]) return;
        u[_.id] = h.id, c[_.id] = x, d[_.id] = c[_.id] + ns(_, e, t, i, a);
      }
    });
  }; l.length; ) {
    var v = p();
    if (typeof v == "object") return v.value;
  }
  return [t, e];
}, as = function(r) {
  return Ct(r);
}, tu = function(r) {
  for (var t = 1; t < r.length - 1; ) {
    var e = r[t - 1], o = r[t], n = r[t + 1];
    e.x === o.x && o.x === n.x || e.y === o.y && o.y === n.y ? r.splice(t, 1) : t++;
  }
  return r;
}, ss = function(r, t, e, o, n) {
  var i = as(e), a = as(o), s = tn(i, n), l = tn(a, n), u = en(s, i, r), c = en(l, a, t);
  if (ef(s, l)) {
    var d = ff(r, t, u, c);
    return we(we([r, u], Bt(d), !1), [c, t], !1);
  }
  var f = En([u, c]), p = os(s, f), v = os(l, f), h = [];
  h = h.concat(rn(p)), h = h.concat(rn(v));
  var g = {
    x: (r.x + t.x) / 2,
    y: (r.y + t.y) / 2
  };
  [
    f,
    p,
    v
  ].forEach(function(_) {
    h = h.concat(af(_, g).filter(function(E) {
      return bo(E, s) && bo(E, l);
    }));
  }), [{
    x: u.x,
    y: c.y
  }, {
    x: c.x,
    y: u.y
  }].forEach(function(_) {
    bo(_, s) && bo(_, l) && h.push(_);
  }), h.unshift(u), h.push(c), h = ni(h);
  var y = cf(h, u, c, i, a, r, t);
  return y.unshift(r), y.push(t), y.length > 2 && (y = tu(y)), ni(y);
}, df = function(r) {
  if (r.length === 1) {
    var t = Bt(r, 1)[0];
    return [t, t];
  } else {
    for (var e = r[0], o = r[1], n = Kt(e.x, e.y, o.x, o.y), i = 1; i < r.length - 1; i++) {
      var a = r[i], s = r[i + 1], l = Kt(a.x, a.y, s.x, s.y);
      l > n && (n = l, e = a, o = s);
    }
    return [e, o];
  }
}, ls = function(r, t, e) {
  var o = ve(r, e), n = ve(t, e);
  return o && n;
}, us = function(r, t, e) {
  var o = ve(r, e), n = ve(t, e);
  return !(o && n) && (o || n);
}, cs = function(r, t, e) {
  for (var o = void 0, n = rn(Ct(e)), i = 0; i < n.length; i++) Ir(r, t, n[i], n[(i + 1) % n.length]) && (o = [n[i], n[(i + 1) % n.length]]);
  if (o) return tf(r, t, o[0], o[1]);
}, on = function(r, t) {
  var e = void 0;
  return r.x === t.x ? e = $.VERTICAL : r.y === t.y && (e = $.HORIZONTAL), e;
}, Me = function(r) {
  var t = r.split(" "), e = [];
  return t && t.forEach(function(o) {
    var n = Bt(o.split(","), 2), i = n[0], a = n[1];
    e.push({
      x: Number(i),
      y: Number(a)
    });
  }), e;
}, ff = function(r, t, e, o) {
  var n = [];
  if (on(r, e) === on(t, o))
    r.y === e.y ? (n.push({
      x: e.x,
      y: (e.y + o.y) / 2
    }), n.push({
      x: o.x,
      y: (e.y + o.y) / 2
    })) : (n.push({
      x: (e.x + o.x) / 2,
      y: e.y
    }), n.push({
      x: (e.x + o.x) / 2,
      y: o.y
    }));
  else {
    var i = {
      x: e.x,
      y: o.y
    }, a = eo(i, r, e), s = eo(i, t, o);
    if (a || s) i = {
      x: o.x,
      y: e.y
    };
    else {
      var l = ds(i, r, e), u = ds(i, t, o);
      l && u && (i = {
        x: o.x,
        y: e.y
      });
    }
    n.push(i);
  }
  return n;
}, ds = function(r, t, e) {
  return r.x === t.x && r.x === e.x || r.y === t.y && r.y === e.y;
}, eu = function(r) {
  if (!r) return 0;
  for (var t = 0, e = 0; e < r.length; e++) {
    var o = r.charCodeAt(e);
    r.match(/[A-Z]/) ? t += 1.5 : o >= 1 && o <= 126 || o >= 65376 && o <= 65439 ? t += 1 : t += 2;
  }
  return t;
}, pf = function(r) {
  var t = r.start, e = r.end, o;
  if (t.x === e.x && t.y === e.y) o = "";
  else {
    var n = {
      start: t,
      end: e,
      offset: 10,
      verticalLength: 5
    }, i = ro(nr(nr({}, n), { type: "start" })), a = ro(nr(nr({}, n), { type: "end" }));
    o = "M".concat(i.leftX, " ").concat(i.leftY, `
    L`).concat(i.rightX, " ").concat(i.rightY, `
    L`).concat(a.rightX, " ").concat(a.rightY, `
    L`).concat(a.leftX, " ").concat(a.leftY, " z");
  }
  return {
    d: o,
    fill: "transparent",
    stroke: "transparent",
    strokeWidth: 1,
    strokeDasharray: "4, 4"
  };
}, fs = function(r) {
  var t = r.start, e = r.end, o = r.sourceNode, n = r.targetNode, i = r.offset, a = Ct(o), s = Ct(n), l = tn(a, i), u = tn(s, i);
  return {
    sNext: en(l, a, t),
    ePre: en(u, s, e)
  };
}, ia = function(r) {
  var t = r.replace(/M/g, "").replace(/C/g, ",").split(",");
  return [
    Oo(t[0]),
    Oo(t[1]),
    Oo(t[2]),
    Oo(t[3])
  ];
}, Oo = function(r) {
  var t = Bt(r.replace(/(^\s*)/g, "").split(" "), 2), e = t[0], o = t[1];
  return {
    x: +e,
    y: +o
  };
}, ps = function(r, t) {
  var e = Bt(r, 4), o = e[0], n = e[1], i = e[2], a = e[3];
  return [op(o, n, i, a, t), r[3]];
}, ru = function(r, t) {
  for (var e = r.x, o = r.y, n = Me(t), i = Number.MAX_SAFE_INTEGER, a, s = [], l = 0; l < n.length; l++) s.push({
    start: n[l],
    end: n[(l + 1) % n.length]
  });
  if (s.forEach(function(f) {
    var p = f.start, v = f.end;
    if (p.x === v.x) {
      var h = {
        x: p.x,
        y: o
      }, g = eo(h, p, v);
      if (g) {
        var y = Math.abs(p.x - e);
        y < i && (i = y, a = h);
      }
    } else if (p.y === v.y) {
      var h = {
        x: e,
        y: p.y
      }, g = eo(h, p, v);
      if (g) {
        var y = Math.abs(p.y - o);
        y < i && (i = y, a = h);
      }
    }
  }), !a) {
    var u = s[0], c = u.start, d = u.end;
    a = {
      x: c.x + (d.x - c.x) / 2,
      y: c.y + (d.y - c.y) / 2
    };
  }
  return a;
}, hf = function(r) {
  return rr(r, [
    "id",
    "type",
    "sourceNodeId",
    "sourceAnchorId",
    "targetNodeId",
    "targetAnchorId",
    "pointsList",
    "startPoint",
    "endPoint",
    "properties"
  ]);
}, hs = function(r, t) {
  return Math.sqrt(Math.pow(r.x - t.x, 2) + Math.pow(r.y - t.y, 2));
};
function vf(r, t) {
  return typeof t != "function" ? function(e, o, n) {
    return Object.assign({ type: r.edgeType }, n);
  } : function(e, o, n) {
    var i = t(e, o, n);
    return i ? typeof i == "string" ? Object.assign({}, n, { type: i }) : Object.assign({ type: i }, n) : { type: r.edgeType };
  };
}
var yf = function(r) {
  var t = r.rows, e = r.rowsLength, o = r.fontSize, n = 0;
  return pt(t, function(i) {
    var a = eu(i);
    n = a > n ? a : n;
  }), {
    width: Math.ceil(n / 2) * o + o / 4,
    height: e * (o + 2) + o / 4
  };
}, Ze = function(r, t) {
  var e = typeof Symbol == "function" && r[Symbol.iterator];
  if (!e) return r;
  var o = e.call(r), n, i = [], a;
  try {
    for (; (t === void 0 || t-- > 0) && !(n = o.next()).done; ) i.push(n.value);
  } catch (s) {
    a = { error: s };
  } finally {
    try {
      n && !n.done && (e = o.return) && e.call(o);
    } finally {
      if (a) throw a.error;
    }
  }
  return i;
}, wo = function(r, t, e) {
  if (e || arguments.length === 2)
    for (var o = 0, n = t.length, i; o < n; o++) (i || !(o in t)) && (i || (i = Array.prototype.slice.call(t, 0, o)), i[o] = t[o]);
  return r.concat(i || Array.prototype.slice.call(t));
};
function mr(r, t, e) {
  return e && t * Math.round(r / t) || r;
}
function gf(r, t, e) {
  if (!r) return [];
  var o = Math.min.apply(Math, wo([], Ze(r.map(function(h) {
    return h[0];
  })), !1)), n = Math.max.apply(Math, wo([], Ze(r.map(function(h) {
    return h[0];
  })), !1)), i = Math.min.apply(Math, wo([], Ze(r.map(function(h) {
    return h[1];
  })), !1)), a = Math.max.apply(Math, wo([], Ze(r.map(function(h) {
    return h[1];
  })), !1)), s = -o, l = -i, u = r.map(function(h) {
    var g = Ze(h, 2), y = g[0], _ = g[1];
    return [y + s, _ + l];
  }), c = n - o, d = a - i, f = t ? t / c : 1, p = e ? e / d : 1, v = Math.min(f, p);
  return u.map(function(h) {
    var g = Ze(h, 2), y = g[0], _ = g[1];
    return [y * v, _ * v];
  });
}
var ou = function(r, t, e) {
  var o = r.length;
  if (o < 2 || t <= 0) return r.slice();
  for (var n = function(E, x) {
    return {
      x: x.x - E.x,
      y: x.y - E.y
    };
  }, i = function(E) {
    return Math.hypot(E.x, E.y);
  }, a = function(E) {
    var x = i(E) || 1;
    return {
      x: E.x / x,
      y: E.y / x
    };
  }, s = [], l = function(E, x, O) {
    var M = n(x, E), P = n(x, O), m = i(M), w = i(P);
    if (m < 1e-6 || w < 1e-6) return [x];
    for (var T = a(M), D = a(P), B = Math.min(t, m * 0.45, w * 0.45), Z = {
      x: x.x + T.x * B,
      y: x.y + T.y * B
    }, et = {
      x: x.x + D.x * B,
      y: x.y + D.y * B
    }, ht = 10, vt = [Z], ut = 1; ut < ht; ut++) {
      var rt = ut / ht, gt = 1 - rt;
      vt.push({
        x: gt * gt * Z.x + 2 * gt * rt * x.x + rt * rt * et.x,
        y: gt * gt * Z.y + 2 * gt * rt * x.y + rt * rt * et.y
      });
    }
    return vt.push(et), vt;
  }, u = 0; u < o; u++) {
    var c = u === 0 ? e ? o - 1 : 0 : u - 1, d = u === o - 1 ? e ? 0 : o - 1 : u + 1, f = r[c], p = r[u], v = r[d];
    !e && (u === 0 || u === o - 1) ? s.push(p) : l(f, p, v).forEach(function(E) {
      return s.push(E);
    });
  }
  for (var h = [], u = 0; u < s.length; u++) {
    var g = s[u];
    (h.length === 0 || Math.hypot(g.x - h[h.length - 1].x, g.y - h[h.length - 1].y) > 1e-6) && h.push(g);
  }
  if (e && h.length > 1) {
    var y = h[0], _ = h[h.length - 1];
    Math.hypot(y.x - _.x, y.y - _.y) < 1e-6 && h.pop();
  }
  return h;
}, Nn = function(r, t) {
  var e = typeof Symbol == "function" && r[Symbol.iterator];
  if (!e) return r;
  var o = e.call(r), n, i = [], a;
  try {
    for (; (t === void 0 || t-- > 0) && !(n = o.next()).done; ) i.push(n.value);
  } catch (s) {
    a = { error: s };
  } finally {
    try {
      n && !n.done && (e = o.return) && e.call(o);
    } finally {
      if (a) throw a.error;
    }
  }
  return i;
}, Dn = function(r, t, e) {
  var o = Nn(r, 2), n = o[0], i = o[1], a = Nn(t, 2), s = a[0], l = a[1], u = Nn(e, 2), c = u[0], d = u[1];
  return n > s && n < c && i > l && i < d;
}, nu = function(r, t) {
  var e = t.multipleSelectKey, o = !1;
  switch (e) {
    case "meta":
      o = r.metaKey;
      break;
    case "alt":
      o = r.altKey;
      break;
    case "shift":
      o = r.shiftKey;
      break;
    case "ctrl":
      o = r.ctrlKey;
      break;
    default:
      o = !1;
  }
  return o;
}, aa = /* @__PURE__ */ (function() {
  var r = function(t, e) {
    return r = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(o, n) {
      o.__proto__ = n;
    } || function(o, n) {
      for (var i in n) Object.prototype.hasOwnProperty.call(n, i) && (o[i] = n[i]);
    }, r(t, e);
  };
  return function(t, e) {
    if (typeof e != "function" && e !== null) throw new TypeError("Class extends value " + String(e) + " is not a constructor or null");
    r(t, e);
    function o() {
      this.constructor = t;
    }
    t.prototype = e === null ? Object.create(e) : (o.prototype = e.prototype, new o());
  };
})();
function vs(r, t) {
  return r instanceof St && t instanceof St;
}
var iu = (function(r) {
  aa(t, r);
  function t(e, o, n) {
    var i = r.call(this, 3) || this;
    return i[0] = e, i[1] = o, i[2] = n, i.x = e, i.y = o, i.z = n, Object.setPrototypeOf(i, t.prototype), i;
  }
  return t.prototype.add = function(e) {
    if (vs(this, e)) return new St(this.x + e.x, this.y + e.y);
    var o = this.z + e.z;
    return new ai((this.x + e.x) / o, (this.y + e.y) / o);
  }, t.prototype.subtract = function(e) {
    if (vs(this, e)) return new St(this.x - e.x, this.y - e.y);
    var o = this.z - e.z;
    return o === 0 ? new St(this.x - e.x, this.y - e.y) : new ai((this.x - e.x) / o, (this.y - e.y) / o);
  }, t;
})(Array), St = (function(r) {
  aa(t, r);
  function t(e, o, n) {
    var i = r.call(this, e, o, n != null ? n : 0) || this;
    return Object.setPrototypeOf(i, t.prototype), i;
  }
  return t.prototype.toString = function() {
    return "Vector";
  }, t.prototype.dot = function(e) {
    var o = this;
    return e.reduce(function(n, i, a) {
      return n + i * o[a];
    });
  }, t.prototype.cross = function(e) {
    return new t(this.y * e.z - this.z * e.y, this.z * e.x - this.x * e.z, this.x * e.y - this.y * e.x);
  }, t.prototype.getLength = function() {
    return Math.hypot(this.x, this.y);
  }, t.prototype.normalize = function() {
    var e = this.getLength();
    return new t(this.x / e, this.y / e);
  }, t.prototype.crossZ = function(e) {
    return this.x * e.y - this.y * e.x;
  }, t.prototype.angle = function(e) {
    var o = this.crossZ(e), n = Math.acos(this.normalize().dot(e.normalize()));
    return o >= 0 ? n : -n;
  }, t;
})(iu), ai = (function(r) {
  aa(t, r);
  function t(e, o) {
    var n = r.call(this, e, o, 1) || this;
    return Object.setPrototypeOf(n, t.prototype), n;
  }
  return t.prototype.toString = function() {
    return "Point";
  }, t;
})(iu), bn = /* @__PURE__ */ (function() {
  var r = function(t, e) {
    return r = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(o, n) {
      o.__proto__ = n;
    } || function(o, n) {
      for (var i in n) Object.prototype.hasOwnProperty.call(n, i) && (o[i] = n[i]);
    }, r(t, e);
  };
  return function(t, e) {
    if (typeof e != "function" && e !== null) throw new TypeError("Class extends value " + String(e) + " is not a constructor or null");
    r(t, e);
    function o() {
      this.constructor = t;
    }
    t.prototype = e === null ? Object.create(e) : (o.prototype = e.prototype, new o());
  };
})(), qe = function(r, t) {
  var e = typeof Symbol == "function" && r[Symbol.iterator];
  if (!e) return r;
  var o = e.call(r), n, i = [], a;
  try {
    for (; (t === void 0 || t-- > 0) && !(n = o.next()).done; ) i.push(n.value);
  } catch (s) {
    a = { error: s };
  } finally {
    try {
      n && !n.done && (e = o.return) && e.call(o);
    } finally {
      if (a) throw a.error;
    }
  }
  return i;
}, Cn = function(r, t, e) {
  if (e || arguments.length === 2)
    for (var o = 0, n = t.length, i; o < n; o++) (i || !(o in t)) && (i || (i = Array.prototype.slice.call(t, 0, o)), i[o] = t[o]);
  return r.concat(i || Array.prototype.slice.call(t));
}, vo = (function(r) {
  bn(t, r);
  function t() {
    for (var e = [], o = 0; o < arguments.length; o++) e[o] = arguments[o];
    var n = r.call(this, e.length) || this;
    return n.fill(new Array(3)), e.forEach(function(i, a) {
      n[a] = i;
    }), n.columns = e[0].length, n.rows = e.length, Object.setPrototypeOf(n, t.prototype), n;
  }
  return t.prototype.getRow = function(e) {
    return this[e];
  }, t.prototype.getColumn = function(e) {
    return Cn([], qe(this.map(function(o) {
      return o[e];
    })), !1);
  }, t.prototype.transpose = function() {
    for (var e = [], o = 0; o < this.columns; o++) e.push(this.getColumn(o));
    return new (t.bind.apply(t, Cn([void 0], qe(e), !1)))();
  }, t.prototype.cross = function(e) {
    var o = new Array(this.rows).fill("").map(function() {
      return [];
    });
    if (this.columns === e.rows) for (var n = 0; n < this.rows; n++)
      for (var i = this.getRow(n), a = function(l) {
        var u = e.getColumn(l);
        o[n][l] = i.reduce(function(c, d, f) {
          return c + d * u[f];
        }, 0);
      }, s = 0; s < e.columns; s++) a(s);
    return new (t.bind.apply(t, Cn([void 0], qe(o), !1)))();
  }, t.prototype.to2D = function() {
    return this.map(function(e) {
      return [e[0], e[1]];
    });
  }, t.prototype.toPoints = function() {
    return this.map(function(e) {
      return new ai(e[0], e[1]);
    });
  }, t.prototype.toString = function() {
    var e = qe(this[0], 2), o = e[0], n = e[1], i = qe(this[1], 2), a = i[0], s = i[1], l = qe(this[2], 2), u = l[0], c = l[1];
    return "matrix(".concat(o, " ").concat(n, " ").concat(a, " ").concat(s, " ").concat(u, " ").concat(c, ")");
  }, t.prototype.translate = function(e, o) {
    return this.cross(new nn(e, o));
  }, t.prototype.rotate = function(e) {
    return this.cross(new _f(e));
  }, t.prototype.scale = function(e, o) {
    return this.cross(new mf(e, o));
  }, t;
})(Array), _f = (function(r) {
  bn(t, r);
  function t(e) {
    var o = r.call(this, new St(+Math.cos(e).toFixed(2), +Math.sin(e).toFixed(2), 0), new St(-Math.sin(e).toFixed(2), +Math.cos(e).toFixed(2), 0), new St(0, 0, 1)) || this;
    return Object.setPrototypeOf(o, t.prototype), o;
  }
  return t.prototype.inverse = function() {
    return this.transpose();
  }, t;
})(vo), mf = (function(r) {
  bn(t, r);
  function t(e, o) {
    var n = r.call(this, new St(e, 0, 0), new St(0, o, 0), new St(0, 0, 1)) || this;
    return n.sx = e, n.sy = o, Object.setPrototypeOf(n, t.prototype), n;
  }
  return t.prototype.inverse = function() {
    return new t(1 / this.sx, 1 / this.sy);
  }, t;
})(vo), nn = (function(r) {
  bn(t, r);
  function t(e, o) {
    var n = r.call(this, new St(1, 0, 0), new St(0, 1, 0), new St(e, o, 1)) || this;
    return n.tx = e, n.ty = o, Object.setPrototypeOf(n, t.prototype), n;
  }
  return t.prototype.inverse = function() {
    return new t(-this.tx, -this.ty);
  }, t;
})(vo);
Yc({ isolateGlobalState: !0 });
var an = function() {
  return an = Object.assign || function(r) {
    for (var t, e = 1, o = arguments.length; e < o; e++) {
      t = arguments[e];
      for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && (r[n] = t[n]);
    }
    return r;
  }, an.apply(this, arguments);
}, xf = function(r, t) {
  var e = typeof Symbol == "function" && r[Symbol.iterator];
  if (!e) return r;
  var o = e.call(r), n, i = [], a;
  try {
    for (; (t === void 0 || t-- > 0) && !(n = o.next()).done; ) i.push(n.value);
  } catch (s) {
    a = { error: s };
  } finally {
    try {
      n && !n.done && (e = o.return) && e.call(o);
    } finally {
      if (a) throw a.error;
    }
  }
  return i;
}, si = function(r) {
  return r.anchors;
}, sn = function(r, t) {
  for (var e = t.nodes, o, n = e.length - 1; n >= 0; n--) {
    var i = e[n];
    if (Of(r, i)) {
      var a = i.getTargetAnchor(r);
      if (a) {
        var s = {
          node: i,
          anchorIndex: a.index,
          anchor: a.anchor
        };
        (!o || Ef(i, o.node, t)) && (o = s);
      }
    }
  }
  return o;
}, Ef = function(r, t, e) {
  return r.zIndex > t.zIndex ? !0 : e.nodesMap[r.id].index > e.nodesMap[t.id].index;
}, bf = function(r, t) {
  for (var e = si(t), o, n = Number.MAX_SAFE_INTEGER, i = 0; i < e.length; i++) {
    var a = Kt(r.x, r.y, e[i].x, e[i].y);
    a < n && (n = a, o = {
      index: i,
      anchor: an(an({}, e[i]), {
        x: e[i].x,
        y: e[i].y,
        id: e[i].id
      })
    });
  }
  return o;
}, Kt = function(r, t, e, o) {
  return Math.hypot(r - e, t - o);
}, ve = function(r, t, e) {
  e === void 0 && (e = 0);
  var o = !1, n = Ct(t), i = xf(new vo([
    r.x,
    r.y,
    1
  ]).translate(-t.x, -t.y).rotate(-t.rotate).translate(t.x, t.y)[0], 2), a = {
    x: i[0],
    y: i[1]
  };
  return a.x >= n.minX - e && a.x <= n.maxX + e && a.y >= n.minY - e && a.y <= n.maxY + e && (o = !0), o;
}, Of = function(r, t) {
  return ve(r, t, 5);
}, Ct = function(r) {
  var t = r.x, e = r.y, o = r.width, n = r.height;
  return {
    minX: t - o / 2,
    minY: e - n / 2,
    maxX: t + o / 2,
    maxY: e + n / 2,
    x: t,
    y: e,
    width: o,
    height: n,
    centerX: t,
    centerY: e
  };
}, wf = function(r) {
  var t = r, e = t.x, o = t.y, n = t.width, i = t.height, a = t.radius;
  return [
    {
      x: e - n / 2 + a,
      y: o - i / 2 + a,
      r: a
    },
    {
      x: e + n / 2 - a,
      y: o - i / 2 + a,
      r: a
    },
    {
      x: e - n / 2 + a,
      y: o + i / 2 - a,
      r: a
    },
    {
      x: e + n / 2 - a,
      y: o + i / 2 - a,
      r: a
    }
  ];
}, ys = function(r, t, e) {
  var o = wf(e), n, i = Number.MAX_SAFE_INTEGER;
  if (o.forEach(function(c) {
    if (t === $.HORIZONTAL ? Math.abs(r.y - c.y) <= c.r : t === $.VERTICAL && Math.abs(r.x - c.x) <= c.r) {
      var d = Kt(r.x, r.y, c.x, c.y);
      d < i && (i = d, n = c);
    }
  }), n) return li(r, t, n);
  var a = e.x, s = e.y, l = e.width, u = e.height;
  return t === $.HORIZONTAL ? {
    x: r.x <= a ? a - l / 2 : a + l / 2,
    y: r.y
  } : t === $.VERTICAL ? {
    x: r.x,
    y: r.y <= s ? s - u / 2 : s + u / 2
  } : r;
}, li = function(r, t, e) {
  var o, n = e.x, i = e.y, a = e.r;
  if (t === $.HORIZONTAL) {
    var s = n - Math.sqrt(a * a - (r.y - i) * (r.y - i)), l = n + Math.sqrt(a * a - (r.y - i) * (r.y - i));
    o = {
      x: Math.abs(s - r.x) < Math.abs(l - r.x) ? s : l,
      y: r.y
    };
  } else if (t === $.VERTICAL) {
    var u = i - Math.sqrt(a * a - (r.x - n) * (r.x - n)), c = i + Math.sqrt(a * a - (r.x - n) * (r.x - n)), d = Math.abs(u - r.y) < Math.abs(c - r.y) ? u : c;
    o = {
      x: r.x,
      y: d
    };
  }
  return o;
}, gs = function(r, t) {
  var e = t, o = !1, n = e.x, i = e.y, a = e.width, s = e.height, l = e.radius, u = {
    minX: n - a / 2 + l,
    maxX: n + a / 2 - l,
    minY: i - s / 2 + l,
    maxY: i + s / 2 - l
  };
  return r.y === i + s / 2 || r.y === i - s / 2 ? o = r.x > u.minX && r.x < u.maxX : (r.x === n + a / 2 || r.x === n - a / 2) && (o = r.y > u.minY && r.y < u.maxY), o;
}, _s = function(r, t, e) {
  var o, n = e, i = n.x, a = n.y, s = n.rx, l = n.ry;
  if (t === $.HORIZONTAL) {
    var u = i - Math.sqrt(s * s - (r.y - a) * (r.y - a) * s * s / (l * l)), c = i + Math.sqrt(s * s - (r.y - a) * (r.y - a) * s * s / (l * l));
    o = {
      x: Math.abs(u - r.x) < Math.abs(c - r.x) ? u : c,
      y: r.y
    };
  } else if (t === $.VERTICAL) {
    var d = a - Math.sqrt(l * l - (r.x - i) * (r.x - i) * l * l / (s * s)), f = a + Math.sqrt(l * l - (r.x - i) * (r.x - i) * l * l / (s * s)), p = Math.abs(d - r.y) < Math.abs(f - r.y) ? d : f;
    o = {
      x: r.x,
      y: p
    };
  }
  return o;
}, So = function(r, t, e) {
  for (var o = e.pointsPosition, n = Number.MAX_SAFE_INTEGER, i, a = [], s = 0; s < o.length; s++) a.push({
    start: o[s],
    end: o[(s + 1) % o.length]
  });
  return a.forEach(function(l) {
    var u = l.start, c = l.end, d = u, f = c;
    u.x > c.x && (d = c, f = u);
    var p = {
      x: r.x,
      y: r.y
    };
    if (d.x === f.x && t === $.HORIZONTAL && (p = {
      x: d.x,
      y: r.y
    }), d.y === f.y && t === $.VERTICAL && (p = {
      x: r.x,
      y: d.y
    }), d.x !== f.x && d.y !== f.y) {
      var v = (f.y - d.y) / (f.x - d.x), h = (d.x * f.y - f.x * d.y) / (d.x - f.x);
      t === $.HORIZONTAL ? p = {
        x: (r.y - h) / v,
        y: r.y
      } : t === $.VERTICAL && (p = {
        x: r.x,
        y: v * r.x + h
      });
    }
    if (eo(p, u, c)) {
      var g = Kt(p.x, p.y, r.x, r.y);
      g < n && (n = g, i = p);
    }
  }), i;
}, Sf = function(r) {
  return rr(r, [
    "id",
    "type",
    "x",
    "y",
    "text",
    "label",
    "properties",
    "virtual",
    "rotate",
    "resizable",
    "rotatable"
  ]);
}, ms = function(r, t, e, o) {
  var n = r.x, i = r.y;
  return t.x > r.x ? n = r.x + e / 2 : t.x < r.x && (n = r.x - e / 2), t.y > r.y ? i = r.y + o / 2 : t.y < r.y && (i = r.y - o / 2), {
    x: n,
    y: i
  };
}, au = function(r) {
  var t = r.rows, e = r.style, o = r.rowsLength, n = r.className, i = document.createElement("div");
  i.className = n, i.style.fontSize = "".concat(e.fontSize), i.style.width = "".concat(e.width), i.style.lineHeight = "".concat(e.lineHeight), i.style.padding = "".concat(e.padding), e.fontFamily && (i.style.fontFamily = "".concat(e.fontFamily)), o > 1 ? t.forEach(function(s) {
    var l = document.createElement("div");
    l.textContent = s, i.appendChild(l);
  }) : i.textContent = t[0], document.body.appendChild(i);
  var a = i.clientHeight;
  return document.body.removeChild(i), a;
}, xs = function(r) {
  var t = r.rows, e = r.rowsLength, o = r.fontSize, n = 0;
  return t && t.forEach(function(i) {
    var a = eu(i);
    n = a > n ? a : n;
  }), {
    width: Math.ceil(n / 2) * o + o / 4,
    height: e * (o + 2) + o / 4
  };
}, ln = function(r) {
  return typeof r != "object" ? {
    isAllPass: !!r,
    msg: r ? "" : "不允许连接"
  } : r;
}, Ao, Af = /* @__PURE__ */ new Uint8Array(16);
function Mf() {
  if (!Ao && (Ao = typeof crypto != "undefined" && crypto.getRandomValues && crypto.getRandomValues.bind(crypto), !Ao))
    throw new Error("crypto.getRandomValues() not supported. See https://github.com/uuidjs/uuid#getrandomvalues-not-supported");
  return Ao(Af);
}
var Et = [];
for (let r = 0; r < 256; ++r) Et.push((r + 256).toString(16).slice(1));
function Pf(r, t = 0) {
  return Et[r[t + 0]] + Et[r[t + 1]] + Et[r[t + 2]] + Et[r[t + 3]] + "-" + Et[r[t + 4]] + Et[r[t + 5]] + "-" + Et[r[t + 6]] + Et[r[t + 7]] + "-" + Et[r[t + 8]] + Et[r[t + 9]] + "-" + Et[r[t + 10]] + Et[r[t + 11]] + Et[r[t + 12]] + Et[r[t + 13]] + Et[r[t + 14]] + Et[r[t + 15]];
}
var Tf = typeof crypto != "undefined" && crypto.randomUUID && crypto.randomUUID.bind(crypto), Es = { randomUUID: Tf };
function Nf(r, t, e) {
  if (Es.randomUUID && !t && !r) return Es.randomUUID();
  r = r || {};
  const o = r.random || (r.rng || Mf)();
  if (o[6] = o[6] & 15 | 64, o[8] = o[8] & 63 | 128, t) {
    e = e || 0;
    for (let n = 0; n < 16; ++n) t[e + n] = o[n];
    return t;
  }
  return Pf(o);
}
var $e = function() {
  return Nf();
}, Yr = /* @__PURE__ */ new Map(), su = function(r) {
  var t = $e();
  function e() {
    if (r(), Yr.get(t)) {
      var n = window.requestAnimationFrame(e);
      Yr.set(t, n);
    }
  }
  var o = window.requestAnimationFrame(e);
  return Yr.set(t, o), t;
}, un = function(r) {
  var t = Yr.get(r);
  t && (window.cancelAnimationFrame(t), Yr.delete(r));
}, oo = function() {
  return oo = Object.assign || function(r) {
    for (var t, e = 1, o = arguments.length; e < o; e++) {
      t = arguments[e];
      for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && (r[n] = t[n]);
    }
    return r;
  }, oo.apply(this, arguments);
}, Df = function(r, t) {
  var e = typeof Symbol == "function" && r[Symbol.iterator];
  if (!e) return r;
  var o = e.call(r), n, i = [], a;
  try {
    for (; (t === void 0 || t-- > 0) && !(n = o.next()).done; ) i.push(n.value);
  } catch (s) {
    a = { error: s };
  } finally {
    try {
      n && !n.done && (e = o.return) && e.call(o);
    } finally {
      if (a) throw a.error;
    }
  }
  return i;
};
function lu(r) {
  var t = r.x, e = t === void 0 ? 0 : t, o = r.y, n = o === void 0 ? 0 : o, i = r.value, a = r.fontSize, s = a === void 0 ? 12 : a, l = r.fill, u = l === void 0 ? "currentColor" : l, c = r.overflowMode, d = c === void 0 ? "default" : c, f = r.textWidth, p = f === void 0 ? void 0 : f, v = r.model, h = {
    x: e,
    y: n,
    fill: u,
    fontSize: s,
    textAnchor: "middle",
    dominantBaseline: "central"
  };
  if (pt(Ne(r), function(O) {
    var M = Df(O, 2), P = M[0], m = M[1];
    typeof m != "object" && (h[P] = m);
  }), i) {
    var g = String(i).split(/[\r\n]/g), y = g.length;
    if (d !== "default") {
      var _ = v.BaseType, E = v.modelType;
      if (_ === dt.NODE && E !== G.TEXT_NODE || _ === dt.EDGE && p) return Cf(r);
    }
    if (y > 1) {
      var x = g.map(function(O, M) {
        var P = s + 2, m = (M - (y - 1) / 2) * P;
        return S("tspan", {
          className: "lf-text-tspan",
          x: e,
          y: n + m,
          children: O
        });
      });
      return S("text", oo({}, h, { children: x }));
    }
    return S("text", oo({}, h, { children: i }));
  }
  return null;
}
function Cf(r) {
  var t = r.x, e = r.y, o = r.value, n = r.model, i = r.textWidth, a = r.fontSize, s = a === void 0 ? 12 : a, l = r.lineHeight, u = r.fontFamily, c = u === void 0 ? "" : u, d = r.wrapPadding, f = d === void 0 ? "0, 0" : d, p = r.overflowMode, v = n.width, h = n.height, g = n.textHeight, y = i || v, _ = String(o).split(/[\r\n]/g), E = _.length, x = au({
    rows: _,
    style: {
      fontSize: "".concat(s, "px"),
      width: "".concat(y, "px"),
      fontFamily: c,
      lineHeight: l,
      padding: f
    },
    rowsLength: E,
    className: "lf-get-text-height"
  }), O = h > x ? h : x;
  g && (O = g);
  var M = p === "ellipsis";
  return M && (O = s + 2), S("g", { children: S("foreignObject", {
    width: y,
    height: O,
    x: t - y / 2,
    y: e - O / 2,
    style: {
      overflow: "visible",
      textAlign: "left"
    },
    children: S("div", {
      className: "lf-node-text-auto-wrap",
      style: {
        minHeight: O,
        width: y,
        padding: f
      },
      children: S("div", {
        className: M ? "lf-node-text-ellipsis-content" : "lf-node-text-auto-wrap-content",
        title: M ? _.join("") : "",
        style: oo({}, r),
        children: _.map(function(P) {
          return S("div", {
            className: "lf-node-text--auto-wrap-inner",
            children: P
          });
        })
      })
    })
  }) });
}
var ui = function() {
  return ui = Object.assign || function(r) {
    for (var t, e = 1, o = arguments.length; e < o; e++) {
      t = arguments[e];
      for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && (r[n] = t[n]);
    }
    return r;
  }, ui.apply(this, arguments);
}, Lf = function(r, t) {
  var e = typeof Symbol == "function" && r[Symbol.iterator];
  if (!e) return r;
  var o = e.call(r), n, i = [], a;
  try {
    for (; (t === void 0 || t-- > 0) && !(n = o.next()).done; ) i.push(n.value);
  } catch (s) {
    a = { error: s };
  } finally {
    try {
      n && !n.done && (e = o.return) && e.call(o);
    } finally {
      if (a) throw a.error;
    }
  }
  return i;
};
function xr(r) {
  var t = {
    x1: 10,
    y1: 10,
    x2: 20,
    y2: 20,
    stroke: "black"
  };
  return pt(Ne(r), function(e) {
    var o = Lf(e, 2), n = o[0], i = o[1];
    (n === "style" || typeof i != "object") && (t[n] = i);
  }), S("line", ui({}, t));
}
var ci = function() {
  return ci = Object.assign || function(r) {
    for (var t, e = 1, o = arguments.length; e < o; e++) {
      t = arguments[e];
      for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && (r[n] = t[n]);
    }
    return r;
  }, ci.apply(this, arguments);
}, jf = function(r, t) {
  var e = typeof Symbol == "function" && r[Symbol.iterator];
  if (!e) return r;
  var o = e.call(r), n, i = [], a;
  try {
    for (; (t === void 0 || t-- > 0) && !(n = o.next()).done; ) i.push(n.value);
  } catch (s) {
    a = { error: s };
  } finally {
    try {
      n && !n.done && (e = o.return) && e.call(o);
    } finally {
      if (a) throw a.error;
    }
  }
  return i;
};
function Te(r) {
  var t = r.x, e = r.y, o = r.width, n = r.height, i = r.className, a = r.strokeWidth, s = r.radius, l = s === void 0 ? 0 : s, u = t - o / 2, c = e - n / 2, d = {};
  return d["stroke-width"] = a, pt(Ne(r), function(f) {
    var p = jf(f, 2), v = p[0], h = p[1];
    typeof h != "object" && (d[v] = h);
  }), i ? d.className = "lf-basic-shape ".concat(i) : d.className = "lf-basic-shape", l && (d.rx = l, d.ry = l), d.x = u, d.y = c, S("rect", ci({}, d));
}
var di = function() {
  return di = Object.assign || function(r) {
    for (var t, e = 1, o = arguments.length; e < o; e++) {
      t = arguments[e];
      for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && (r[n] = t[n]);
    }
    return r;
  }, di.apply(this, arguments);
}, Rf = function(r, t) {
  var e = typeof Symbol == "function" && r[Symbol.iterator];
  if (!e) return r;
  var o = e.call(r), n, i = [], a;
  try {
    for (; (t === void 0 || t-- > 0) && !(n = o.next()).done; ) i.push(n.value);
  } catch (s) {
    a = { error: s };
  } finally {
    try {
      n && !n.done && (e = o.return) && e.call(o);
    } finally {
      if (a) throw a.error;
    }
  }
  return i;
};
function no(r) {
  var t = { d: "" };
  return pt(Ne(r), function(e) {
    var o = Rf(e, 2), n = o[0], i = o[1];
    (n === "style" || typeof i != "object") && (t[n] = i);
  }), S("path", di({}, t));
}
var fi = function() {
  return fi = Object.assign || function(r) {
    for (var t, e = 1, o = arguments.length; e < o; e++) {
      t = arguments[e];
      for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && (r[n] = t[n]);
    }
    return r;
  }, fi.apply(this, arguments);
}, If = function(r, t) {
  var e = typeof Symbol == "function" && r[Symbol.iterator];
  if (!e) return r;
  var o = e.call(r), n, i = [], a;
  try {
    for (; (t === void 0 || t-- > 0) && !(n = o.next()).done; ) i.push(n.value);
  } catch (s) {
    a = { error: s };
  } finally {
    try {
      n && !n.done && (e = o.return) && e.call(o);
    } finally {
      if (a) throw a.error;
    }
  }
  return i;
};
function Er(r) {
  var t = r.x, e = t === void 0 ? 0 : t, o = r.y, n = o === void 0 ? 0 : o, i = r.r, a = i === void 0 ? 4 : i, s = r.className, l = {
    cx: e,
    cy: n,
    r: a,
    fill: "transparent",
    fillOpacity: 1,
    strokeWidth: 1,
    stroke: "#000",
    strokeOpacity: 1
  };
  return pt(Ne(r), function(u) {
    var c = If(u, 2), d = c[0], f = c[1];
    typeof f != "object" && (l[d] = f);
  }), s ? l.className = "lf-basic-shape ".concat(s) : l.className = "lf-basic-shape", S("circle", fi({}, l));
}
var pi = function() {
  return pi = Object.assign || function(r) {
    for (var t, e = 1, o = arguments.length; e < o; e++) {
      t = arguments[e];
      for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && (r[n] = t[n]);
    }
    return r;
  }, pi.apply(this, arguments);
}, kf = function(r, t) {
  var e = typeof Symbol == "function" && r[Symbol.iterator];
  if (!e) return r;
  var o = e.call(r), n, i = [], a;
  try {
    for (; (t === void 0 || t-- > 0) && !(n = o.next()).done; ) i.push(n.value);
  } catch (s) {
    a = { error: s };
  } finally {
    try {
      n && !n.done && (e = o.return) && e.call(o);
    } finally {
      if (a) throw a.error;
    }
  }
  return i;
};
function Bf(r) {
  var t = r.x, e = t === void 0 ? 0 : t, o = r.y, n = o === void 0 ? 0 : o, i = r.rx, a = i === void 0 ? 4 : i, s = r.ry, l = s === void 0 ? 4 : s, u = r.className, c = {
    cx: e,
    cy: n,
    rx: a,
    ry: l,
    fill: "transparent",
    fillOpacity: 1,
    strokeWidth: 1,
    stroke: "#000",
    strokeOpacity: 1
  };
  return pt(Ne(r), function(d) {
    var f = kf(d, 2), p = f[0], v = f[1];
    typeof v != "object" && (c[p] = v);
  }), u ? c.className = "lf-basic-shape ".concat(u) : c.className = "lf-basic-shape", S("ellipse", pi({}, c));
}
var cn = function() {
  return cn = Object.assign || function(r) {
    for (var t, e = 1, o = arguments.length; e < o; e++) {
      t = arguments[e];
      for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && (r[n] = t[n]);
    }
    return r;
  }, cn.apply(this, arguments);
}, Xf = function(r, t) {
  var e = typeof Symbol == "function" && r[Symbol.iterator];
  if (!e) return r;
  var o = e.call(r), n, i = [], a;
  try {
    for (; (t === void 0 || t-- > 0) && !(n = o.next()).done; ) i.push(n.value);
  } catch (s) {
    a = { error: s };
  } finally {
    try {
      n && !n.done && (e = o.return) && e.call(o);
    } finally {
      if (a) throw a.error;
    }
  }
  return i;
};
function uu(r) {
  var t = r.points, e = t === void 0 ? [] : t, o = r.className, n = r.radius, i = {
    fill: "transparent",
    fillOpacity: 1,
    strokeWidth: 1,
    stroke: "#000",
    strokeOpacity: 1,
    points: ""
  };
  if (pt(Ne(r), function(l) {
    var u = Xf(l, 2), c = u[0], d = u[1];
    typeof d != "object" && (i[c] = d);
  }), o ? i.className = "lf-basic-shape ".concat(o) : i.className = "lf-basic-shape", n) {
    var a = e.map(function(l) {
      return {
        x: l[0],
        y: l[1]
      };
    }), s = ou(a, n, !0);
    return i.d = s.length ? "M ".concat(s[0].x, " ").concat(s[0].y, " ").concat(s.slice(1).map(function(l) {
      return "L ".concat(l.x, " ").concat(l.y);
    }).join(" "), " Z") : "", delete i.points, S("path", cn({}, i));
  } else
    return i.points = e.map(function(l) {
      return l.join(",");
    }).join(" "), S("polygon", cn({}, i));
}
var hi = function() {
  return hi = Object.assign || function(r) {
    for (var t, e = 1, o = arguments.length; e < o; e++) {
      t = arguments[e];
      for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && (r[n] = t[n]);
    }
    return r;
  }, hi.apply(this, arguments);
}, Yf = function(r, t) {
  var e = typeof Symbol == "function" && r[Symbol.iterator];
  if (!e) return r;
  var o = e.call(r), n, i = [], a;
  try {
    for (; (t === void 0 || t-- > 0) && !(n = o.next()).done; ) i.push(n.value);
  } catch (s) {
    a = { error: s };
  } finally {
    try {
      n && !n.done && (e = o.return) && e.call(o);
    } finally {
      if (a) throw a.error;
    }
  }
  return i;
};
function Hf(r) {
  var t = r.className, e = {
    points: "",
    fill: "none"
  };
  return pt(Ne(r), function(o) {
    var n = Yf(o, 2), i = n[0], a = n[1];
    (i === "style" || typeof a != "object") && (e[i] = a);
  }), t && (e.className = "".concat(t)), S("polyline", hi({}, e));
}
var cu = /* @__PURE__ */ (function() {
  var r = function(t, e) {
    return r = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(o, n) {
      o.__proto__ = n;
    } || function(o, n) {
      for (var i in n) Object.prototype.hasOwnProperty.call(n, i) && (o[i] = n[i]);
    }, r(t, e);
  };
  return function(t, e) {
    if (typeof e != "function" && e !== null) throw new TypeError("Class extends value " + String(e) + " is not a constructor or null");
    r(t, e);
    function o() {
      this.constructor = t;
    }
    t.prototype = e === null ? Object.create(e) : (o.prototype = e.prototype, new o());
  };
})(), io = function() {
  return io = Object.assign || function(r) {
    for (var t, e = 1, o = arguments.length; e < o; e++) {
      t = arguments[e];
      for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && (r[n] = t[n]);
    }
    return r;
  }, io.apply(this, arguments);
}, Gf = function(r, t) {
  var e = {};
  for (var o in r) Object.prototype.hasOwnProperty.call(r, o) && t.indexOf(o) < 0 && (e[o] = r[o]);
  if (r != null && typeof Object.getOwnPropertySymbols == "function")
    for (var n = 0, o = Object.getOwnPropertySymbols(r); n < o.length; n++) t.indexOf(o[n]) < 0 && Object.prototype.propertyIsEnumerable.call(r, o[n]) && (e[o[n]] = r[o[n]]);
  return e;
}, zf = function(r, t) {
  var e = typeof Symbol == "function" && r[Symbol.iterator];
  if (!e) return r;
  var o = e.call(r), n, i = [], a;
  try {
    for (; (t === void 0 || t-- > 0) && !(n = o.next()).done; ) i.push(n.value);
  } catch (s) {
    a = { error: s };
  } finally {
    try {
      n && !n.done && (e = o.return) && e.call(o);
    } finally {
      if (a) throw a.error;
    }
  }
  return i;
}, K;
(function(r) {
  r[r.LEFT_TOP = 0] = "LEFT_TOP", r[r.RIGHT_TOP = 1] = "RIGHT_TOP", r[r.RIGHT_BOTTOM = 2] = "RIGHT_BOTTOM", r[r.LEFT_BOTTOM = 3] = "LEFT_BOTTOM";
})(K || (K = {}));
var $f = (function(r) {
  cu(t, r);
  function t(e) {
    var o = r.call(this) || this;
    o.isShiftPressed = !1, o.bindKeyboardEvents = function() {
      document.addEventListener("keydown", o.handleKeyDown), document.addEventListener("keyup", o.handleKeyUp);
    }, o.handleKeyDown = function(s) {
      s.key === "Shift" && (o.isShiftPressed = !0);
    }, o.handleKeyUp = function(s) {
      s.key === "Shift" && (o.isShiftPressed = !1);
    }, o.updateEdgePointByAnchors = function() {
      var s = o.nodeModel, l = s.id, u = s.anchors, c = o.graphModel.getNodeEdges(l);
      pt(c, function(d) {
        if (d.sourceNodeId === l) {
          var f = Ue(u, function(p) {
            return p.id === d.sourceAnchorId;
          });
          f && d.updateStartPoint({
            x: f.x,
            y: f.y
          });
        } else if (d.targetNodeId === l) {
          var f = Ue(u, function(v) {
            return v.id === d.targetAnchorId;
          });
          f && d.updateEndPoint({
            x: f.x,
            y: f.y
          });
        }
      });
    }, o.triggerResizeEvent = function(s, l, u, c, d, f) {
      o.graphModel.eventCenter.emit(L.NODE_RESIZE, {
        preData: s,
        data: l,
        deltaX: u,
        deltaY: c,
        index: d,
        model: f
      });
    }, o.recalcResizeInfo = function(s, l, u, c, d) {
      u === void 0 && (u = 1), c === void 0 && (c = !1), d === void 0 && (d = !1);
      var f = R(l), p = f.deltaX, v = f.deltaY, h = f.width, g = f.height, y = f.PCTResizeInfo;
      if (y) {
        var _ = 4, E = 0, x = 0;
        switch (s) {
          case K.LEFT_TOP:
            x = (p * -1 - v) / _;
            break;
          case K.RIGHT_TOP:
            x = (p - v) / _;
            break;
          case K.RIGHT_BOTTOM:
            x = (p + v) / _;
            break;
          case K.LEFT_BOTTOM:
            x = (p * -1 + v) / _;
        }
        x !== 0 && (E = Math.round(x / y.ResizeBasis.basisHeight * 1e5) / 1e3), y.ResizePCT.widthPCT = Math.max(Math.min(y.ResizePCT.widthPCT + E, y.ScaleLimit.maxScaleLimit), y.ScaleLimit.minScaleLimit), y.ResizePCT.heightPCT = Math.max(Math.min(y.ResizePCT.heightPCT + E, y.ScaleLimit.maxScaleLimit), y.ScaleLimit.minScaleLimit);
        var O = Math.round(y.ResizePCT.widthPCT * y.ResizeBasis.basisWidth / 100), M = Math.round(y.ResizePCT.heightPCT * y.ResizeBasis.basisHeight / 100);
        switch (s) {
          case K.LEFT_TOP:
            p = h - O, v = g - M;
            break;
          case K.RIGHT_TOP:
            p = O - h, v = g - M;
            break;
          case K.RIGHT_BOTTOM:
            p = O - h, v = M - g;
            break;
          case K.LEFT_BOTTOM:
            p = h - O, v = M - g;
        }
        return f;
      }
      switch (s) {
        case K.LEFT_TOP:
          f.width = c ? h : h - p * u, f.height = d ? g : g - v * u;
          break;
        case K.RIGHT_TOP:
          f.width = c ? h : h + p * u, f.height = d ? g : g - v * u;
          break;
        case K.RIGHT_BOTTOM:
          f.width = c ? h : h + p * u, f.height = d ? g : g + v * u;
          break;
        case K.LEFT_BOTTOM:
          f.width = c ? h : h - p * u, f.height = d ? g : g + v * u;
      }
      return f;
    }, o.resizeNode = function(s) {
      var l = s.deltaX, u = s.deltaY, c = o.index, d = o.props, f = d.model, p = d.graphModel, v = d.x, h = d.y;
      tp({
        x: v,
        y: h,
        deltaX: l,
        deltaY: u,
        index: c,
        nodeModel: f,
        graphModel: p,
        forceProportional: o.isShiftPressed,
        cancelCallback: function() {
          o.dragHandler.cancelDrag();
        }
      });
    }, o.onDragStart = function() {
      o.graphModel.selectNodeById(o.nodeModel.id);
    }, o.onDragging = function(s) {
      var l = s.deltaX, u = s.deltaY, c = o.graphModel.transformModel, d = zf(c.fixDeltaXY(l, u), 2), f = d[0], p = d[1];
      o.resizeNode({
        deltaX: f,
        deltaY: p
      });
    }, o.onDragEnd = function() {
      var s = o.nodeModel.x, l = o.nodeModel.y;
      o.nodeModel.moveTo(s, l), o.updateEdgePointByAnchors();
    }, o.onPointerDown = function(s) {
      s.stopPropagation(), o.dragHandler.handleMouseDown(s);
    };
    var n = e.index, i = e.model, a = e.graphModel;
    return o.index = n, o.nodeModel = i, o.graphModel = a, o.dragHandler = new de({
      onDragStart: o.onDragStart,
      onDragging: o.onDragging,
      onDragEnd: o.onDragEnd,
      step: a.gridSize
    }), o.bindKeyboardEvents(), o;
  }
  return t.prototype.componentWillUnmount = function() {
    this.dragHandler.destroy(), document.removeEventListener("keydown", this.handleKeyDown), document.removeEventListener("keyup", this.handleKeyUp);
  }, t.prototype.getViewPosition = function(e, o, n) {
    var i = this.props.model.getResizeControlStyle(), a = i.width, s = a === void 0 ? 8 : a, l = i.height, u = l === void 0 ? 8 : l;
    switch (e) {
      case "nw":
        return {
          x: o - s / 2,
          y: n - u / 2
        };
      case "ne":
        return {
          x: o + s / 2,
          y: n - u / 2
        };
      case "se":
        return {
          x: o + s / 2,
          y: n + u / 2
        };
      case "sw":
        return {
          x: o - s / 2,
          y: n + u / 2
        };
      default:
        return {
          x: o,
          y: n
        };
    }
  }, t.prototype.render = function() {
    var e = this.props, o = e.x, n = e.y, i = e.direction, a = e.model.getResizeControlStyle(), s = a.width, l = a.height, u = Gf(a, ["width", "height"]), c = this.getViewPosition(i, o, n), d = c.x, f = c.y;
    return S("g", {
      className: "lf-resize-control lf-resize-control-".concat(i),
      children: [S(Te, io({
        className: "lf-resize-control-content",
        x: d,
        y: f,
        width: s != null ? s : 7,
        height: l != null ? l : 7
      }, u)), S(Te, {
        className: "lf-resize-control-content",
        x: d,
        y: f,
        width: s ? s + 5 : 25,
        height: s ? s + 5 : 25,
        fill: "transparent",
        stroke: "transparent",
        onPointerDown: this.onPointerDown
      })]
    });
  }, t;
})(V), Uf = (function(r) {
  cu(t, r);
  function t() {
    return r.call(this) || this;
  }
  return t.prototype.getResizeControl = function() {
    var e = this.props, o = e.model, n = e.graphModel, i = Ct(o), a = i.minX, s = i.minY, l = i.maxX, u = i.maxY, c = [
      {
        index: K.LEFT_TOP,
        direction: "nw",
        x: a,
        y: s
      },
      {
        index: K.RIGHT_TOP,
        direction: "ne",
        x: l,
        y: s
      },
      {
        index: K.RIGHT_BOTTOM,
        direction: "se",
        x: l,
        y: u
      },
      {
        index: K.LEFT_BOTTOM,
        direction: "sw",
        x: a,
        y: u
      }
    ];
    return ce(c, function(d) {
      return S($f, io({}, d, {
        model: o,
        graphModel: n
      }));
    });
  }, t.prototype.getResizeOutline = function() {
    var e = this.props.model, o = e.x, n = e.y, i = e.width, a = e.height, s = e.getResizeOutlineStyle();
    return S(Te, io({}, s, {
      "pointer-events": "none",
      x: o,
      y: n,
      width: i + 10,
      height: a + 10
    }));
  }, t.prototype.render = function() {
    return S("g", {
      className: "lf-resize-control-group",
      children: [this.getResizeOutline(), this.getResizeControl()]
    });
  }, t;
})(V);
function Vf(r, t) {
  var e = r.x, o = r.y, n = t.x, i = t.y;
  return {
    x: e + (n - e) / 2,
    y: o + (i - o) / 2
  };
}
function kr(r, t, e) {
  var o = Ff(e), n = r.x - t.x, i = r.y - t.y;
  return {
    x: n * Math.cos(o) - i * Math.sin(o) + t.x,
    y: n * Math.sin(o) + i * Math.cos(o) + t.y
  };
}
function Ff(r) {
  return r * Math.PI / 180;
}
function Wf(r) {
  return r / Math.PI * 180;
}
function Kf(r, t, e, o, n, i, a, s) {
  n === void 0 && (n = !1), i === void 0 && (i = !1);
  var l = {
    x: e.x - (r.x - e.x),
    y: e.y - (r.y - e.y)
  }, u = Vf(l, t), c = kr(t, u, -o), d = kr(l, u, -o);
  if (n) {
    var f = Math.abs(c.x - d.x) - a;
    u.x > c.x ? u.x = u.x + f / 2 : u.x = u.x - f / 2;
  }
  if (i) {
    var p = Math.abs(c.y - d.y) - s;
    u.y > c.y ? u.y = u.y + p / 2 : u.y = u.y - p / 2;
  }
  if (n || i) {
    var v = kr(d, u, o), h = v.x - l.x, g = v.y - l.y;
    u.x = u.x - h, u.y = u.y - g, d = kr(l, u, -o), c = {
      x: u.x - (d.x - u.x),
      y: u.y - (d.y - u.y)
    };
  }
  var y = Math.abs(c.x - d.x), _ = Math.abs(c.y - d.y);
  return n && (y = a), i && (_ = s), {
    width: y,
    height: _,
    center: u
  };
}
function Zf(r, t, e, o, n, i, a, s, l) {
  s === void 0 && (s = !1), l === void 0 && (l = !1);
  var u = t.deltaX, c = t.deltaY, d = t.width, f = t.height, p = Wf(e), v = {
    x: o,
    y: n
  }, h = {
    x: i,
    y: a
  }, g = kr(v, h, p), y = Kf(g, {
    x: g.x + u,
    y: g.y + c
  }, h, p, s, l, d, f), _ = y.width, E = y.height, x = y.center;
  return t.width = _ * r, t.height = E * r, t.deltaX = (x.x - h.x) * 2, t.deltaY = (x.y - h.y) * 2, t;
}
var qf = function(r, t, e, o, n, i, a, s, l, u, c) {
  e === void 0 && (e = 1), o === void 0 && (o = !1), n === void 0 && (n = !1), i === void 0 && (i = 0), c === void 0 && (c = !1);
  var d = R(t), f = d.deltaX, p = d.deltaY, v = d.width, h = d.height, g = d.PCTResizeInfo;
  if (g) {
    var y = 4, _ = 0, E = 0;
    switch (r) {
      case K.LEFT_TOP:
        E = (f * -1 - p) / y;
        break;
      case K.RIGHT_TOP:
        E = (f - p) / y;
        break;
      case K.RIGHT_BOTTOM:
        E = (f + p) / y;
        break;
      case K.LEFT_BOTTOM:
        E = (f * -1 + p) / y;
    }
    E !== 0 && (_ = Math.round(E / g.ResizeBasis.basisHeight * 1e5) / 1e3), g.ResizePCT.widthPCT = Math.max(Math.min(g.ResizePCT.widthPCT + _, g.ScaleLimit.maxScaleLimit), g.ScaleLimit.minScaleLimit), g.ResizePCT.heightPCT = Math.max(Math.min(g.ResizePCT.heightPCT + _, g.ScaleLimit.maxScaleLimit), g.ScaleLimit.minScaleLimit);
    var x = Math.round(g.ResizePCT.widthPCT * g.ResizeBasis.basisWidth / 100), O = Math.round(g.ResizePCT.heightPCT * g.ResizeBasis.basisHeight / 100);
    switch (r) {
      case K.LEFT_TOP:
        f = v - x, p = h - O;
        break;
      case K.RIGHT_TOP:
        f = x - v, p = h - O;
        break;
      case K.RIGHT_BOTTOM:
        f = x - v, p = O - h;
        break;
      case K.LEFT_BOTTOM:
        f = v - x, p = O - h;
    }
    return d;
  }
  if (i % (2 * Math.PI) !== 0 && a !== void 0 && s !== void 0) return Zf(e, d, i, a, s, l, u, o, n);
  if (c) {
    var M = v / h, P = 0, m = v, w = h;
    switch (r) {
      case K.LEFT_TOP:
        P = Math.abs(f) > Math.abs(p) ? -f : -p, M >= 1 ? (m = v + P, w = m / M) : (w = h + P, m = w * M), d.width = m, d.height = w, d.deltaX = v - m, d.deltaY = h - w;
        break;
      case K.RIGHT_TOP:
        P = Math.abs(f) > Math.abs(p) ? f : -p, M >= 1 ? (m = v + P, w = m / M) : (w = h - P, m = w * M), d.width = m, d.height = w, d.deltaX = m - v, d.deltaY = h - w;
        break;
      case K.RIGHT_BOTTOM:
        P = Math.abs(f) > Math.abs(p) ? f : p, M >= 1 ? (m = v + P, w = m / M) : (w = h + P, m = w * M), d.width = m, d.height = w, d.deltaX = m - v, d.deltaY = w - h;
        break;
      case K.LEFT_BOTTOM:
        P = Math.abs(f) > Math.abs(p) ? -f : p, M >= 1 ? (m = v - P, w = m / M) : (w = h + P, m = w * M), d.width = m, d.height = w, d.deltaX = v - m, d.deltaY = w - h;
    }
    return d;
  }
  switch (r) {
    case K.LEFT_TOP:
      d.width = o ? v : v - f * e, d.height = n ? h : h - p * e;
      break;
    case K.RIGHT_TOP:
      d.width = o ? v : v + f * e, d.height = n ? h : h - p * e;
      break;
    case K.RIGHT_BOTTOM:
      d.width = o ? v : v + f * e, d.height = n ? h : h + p * e;
      break;
    case K.LEFT_BOTTOM:
      d.width = o ? v : v - f * e, d.height = n ? h : h + p * e;
  }
  return d;
}, Jf = function(r, t) {
  var e = r.id, o = r.anchors, n = t.getNodeEdges(e);
  pt(n, function(i) {
    if (i.sourceNodeId === e) {
      var a = Ue(o, function(s) {
        return s.id === i.sourceAnchorId;
      });
      a && i.updateStartPoint({
        x: a.x,
        y: a.y
      });
    } else if (i.targetNodeId === e) {
      var a = Ue(o, function(l) {
        return l.id === i.targetAnchorId;
      });
      a && i.updateEndPoint({
        x: a.x,
        y: a.y
      });
    }
  });
}, Qf = function(r, t, e, o, n, i, a) {
  a.eventCenter.emit(L.NODE_RESIZE, {
    preData: r,
    data: t,
    deltaX: e,
    deltaY: o,
    index: n,
    model: i
  });
}, tp = function(r) {
  var t = r.x, e = r.y, o = r.deltaX, n = r.deltaY, i = r.index, a = r.nodeModel, s = r.graphModel, l = r.cancelCallback, u = r.forceProportional, c = u === void 0 ? !1 : u, d = a.r, f = a.rx, p = a.ry, v = a.width, h = a.height, g = a.PCTResizeInfo, y = a.minWidth, _ = a.minHeight, E = a.maxWidth, x = a.maxHeight, O = a.rotate, M = a.x, P = a.y, m = y === E, w = _ === x, T = {
    width: d || f || v,
    height: d || p || h,
    deltaX: o,
    deltaY: n,
    PCTResizeInfo: g
  }, D = d || f && p ? 1 / 2 : 1, B = t, Z = e, et = qf(i, T, D, m, w, O, B, Z, M, P, c);
  if (et.width < y || et.width > E || et.height < _ || et.height > x) {
    l == null || l();
    return;
  }
  (O % (2 * Math.PI) == 0 || g || B === void 0 || Z === void 0) && (et.deltaX = m ? 0 : et.deltaX, et.deltaY = w ? 0 : et.deltaY);
  var ht = a.getData(), vt = a.resize(et);
  ht.x === vt.x && ht.y === vt.y || (Jf(a, s), Qf(ht, vt, o, n, i, a, s));
}, ep = 100, rp = {
  x: 1,
  y: 0,
  z: 0
};
function op(r, t, e, o, n) {
  for (var i = function(p) {
    if (p < 0 || p > 1) throw new RangeError('The value range of parameter "t" is [0,1]');
    return {
      x: r.x * Math.pow(1 - p, 3) + 3 * t.x * p * Math.pow(1 - p, 2) + 3 * e.x * Math.pow(p, 2) * (1 - p) + o.x * Math.pow(p, 3),
      y: r.y * Math.pow(1 - p, 3) + 3 * t.y * p * Math.pow(1 - p, 2) + 3 * e.y * Math.pow(p, 2) * (1 - p) + o.y * Math.pow(p, 3)
    };
  }, a = 0, s = 2, l = o.x, u = o.y, c = o; a < n && s < 50; ) {
    c = i(1 - s / ep);
    var d = c.x, f = c.y;
    a = Kt(l, u, d, f), s++;
  }
  return c;
}
function np(r, t) {
  return r.x * t.y - r.y * t.x;
}
function ip(r, t) {
  var e = [
    r.x,
    r.y,
    r.z
  ];
  return [
    t.x,
    t.y,
    t.z
  ].reduce(function(o, n, i) {
    return o + n * e[i];
  });
}
function ap(r, t) {
  var e = np(r, t), o = Math.acos(ip(bs(r), bs(t)));
  return e >= 0 ? o : -o;
}
function bs(r) {
  var t = Math.hypot(r.x, r.y);
  return {
    x: r.x / t,
    y: r.y / t,
    z: 0
  };
}
function sp(r) {
  return ap(rp, r);
}
function lp(r) {
  return r * (180 / Math.PI);
}
var du = function(r, t) {
  var e = R(_r[t || "default"]) || R(_r.default);
  return r && (e = Bi(e, r)), e;
}, up = function(r, t) {
  _r[r] || (_r[r] = t, Xe[r] = t.background || Jl, Ye[r] = t.grid || na);
}, cp = function(r) {
  delete _r[r], delete Xe[r], delete Ye[r];
}, dp = function() {
  var r = {
    colorful: {},
    dark: {},
    retro: {},
    default: {}
  };
  U(_r, r), U(Xe, r), U(Ye, r);
}, fp = du, pp = 1e3, hp = 999, ao = function() {
  return ++pp;
}, vp = function() {
  return --hp;
}, lt = function() {
  return lt = Object.assign || function(r) {
    for (var t, e = 1, o = arguments.length; e < o; e++) {
      t = arguments[e];
      for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && (r[n] = t[n]);
    }
    return r;
  }, lt.apply(this, arguments);
}, j = function(r, t, e, o) {
  var n = arguments.length, i = n < 3 ? t : o === null ? o = Object.getOwnPropertyDescriptor(t, e) : o, a;
  if (typeof Reflect == "object" && typeof Reflect.decorate == "function") i = Reflect.decorate(r, t, e, o);
  else for (var s = r.length - 1; s >= 0; s--) (a = r[s]) && (i = (n < 3 ? a(i) : n > 3 ? a(t, e, i) : a(t, e)) || i);
  return n > 3 && i && Object.defineProperty(t, e, i), i;
}, On = (function() {
  function r(t, e) {
    var o;
    this.BaseType = dt.EDGE, this.id = "", this.type = "", this.sourceNodeId = "", this.targetNodeId = "", this.textMode = Xt.TEXT, this.text = {
      value: "",
      x: 0,
      y: 0,
      draggable: !1,
      editable: !0
    }, this.points = "", this.pointsList = [], this.virtual = !1, this.isSelected = !1, this.isHovered = !1, this.isHitable = !0, this.isHittable = !0, this.draggable = !0, this.visible = !0, this.isAnimation = !1, this.isShowAdjustPoint = !1, this.zIndex = 0, this.state = J.DEFAULT, this.modelType = G.EDGE, this.customTextPosition = !1, this.style = {}, this.arrowConfig = {
      markerEnd: "url(#marker-end-".concat(this.id, ")"),
      markerStart: "url(#marker-start-".concat(this.id, ")")
    }, this.graphModel = e, this.properties = (o = t.properties) !== null && o !== void 0 ? o : {}, this.initEdgeData(t), this.setAttributes();
  }
  return r.prototype.initEdgeData = function(t) {
    var e = this;
    if (t.properties || (t.properties = {}), !t.id) {
      var o = this.graphModel.idGenerator, n = o && o(t.type);
      t.id = this.createId() || n || $e();
    }
    this.arrowConfig.markerEnd = "url(#marker-end-".concat(t.id, ")"), this.arrowConfig.markerStart = "url(#marker-start-".concat(t.id, ")");
    var i = this.graphModel.editConfigModel.adjustEdgeStartAndEnd;
    this.isShowAdjustPoint = i, U(this, hf(t));
    var a = this.graphModel, s = a.overlapMode, l = a.eventCenter;
    this.updateZIndexByOverlap(s, t.zIndex || ao()), this.setAnchors(), this.initPoints(), this.formatText(t), l.on("overlap:change", function(u) {
      var c = u.overlapMode;
      e.updateZIndexByOverlap(c, e.zIndex || ao());
    });
  }, r.prototype.setAttributes = function() {
  }, r.prototype.createId = function() {
    return null;
  }, r.prototype.getEdgeStyle = function() {
    return lt(lt({}, this.graphModel.theme.baseEdge), this.style);
  }, r.prototype.getAdjustPointStyle = function() {
    return lt({}, this.graphModel.theme.edgeAdjust);
  }, r.prototype.getTextStyle = function() {
    var t = this.graphModel.theme.edgeText;
    return R(t);
  }, r.prototype.getEdgeAnimationStyle = function() {
    var t = this.graphModel.theme.edgeAnimation;
    return R(t);
  }, r.prototype.getArrowStyle = function() {
    var t = this.getEdgeStyle(), e = this.getEdgeAnimationStyle(), o = this.graphModel.theme.arrow, n = this.isAnimation ? e.stroke : t.stroke;
    return lt(lt(lt({}, t), {
      fill: n,
      stroke: n
    }), o);
  }, r.prototype.getOutlineStyle = function() {
    var t = this.graphModel.theme.edgeOutline, e = lt({}, t);
    if (this.isHovered) {
      var o = t.hover || {};
      e = lt(lt({}, e), o);
    }
    return R(e);
  }, r.prototype.getTextPosition = function() {
    return {
      x: 0,
      y: 0
    };
  }, Object.defineProperty(r.prototype, "sourceNode", {
    get: function() {
      var t, e;
      return (e = (t = this.graphModel) === null || t === void 0 ? void 0 : t.nodesMap[this.sourceNodeId]) === null || e === void 0 ? void 0 : e.model;
    },
    enumerable: !1,
    configurable: !0
  }), Object.defineProperty(r.prototype, "targetNode", {
    get: function() {
      var t, e;
      return (e = (t = this.graphModel) === null || t === void 0 ? void 0 : t.nodesMap[this.targetNodeId]) === null || e === void 0 ? void 0 : e.model;
    },
    enumerable: !1,
    configurable: !0
  }), Object.defineProperty(r.prototype, "textPosition", {
    get: function() {
      return this.getTextPosition();
    },
    enumerable: !1,
    configurable: !0
  }), r.prototype.getBeginAnchor = function(t, e, o) {
    var n, i, a = si(t);
    return o && (n = Ue(a, function(s) {
      return s.id === o;
    }), n) || a.forEach(function(s) {
      var l = hs(s, e);
      (i === void 0 || l < i) && (i = l, n = s);
    }), n;
  }, r.prototype.getEndAnchor = function(t, e) {
    var o = this, n, i, a = si(t);
    return e && (n = Ue(a, function(s) {
      return s.id === e;
    }), n) || a.forEach(function(s) {
      if (o.startPoint) {
        var l = hs(s, o.startPoint);
        (i === void 0 || l < i) && (i = l, n = s);
      }
    }), n;
  }, r.prototype.getProperties = function() {
    return ie(this.properties);
  }, r.prototype.getData = function() {
    var t = this.properties;
    Pe(t) && (t = ie(t));
    var e = {
      id: this.id,
      type: this.type,
      properties: t,
      sourceNodeId: this.sourceNodeId,
      targetNodeId: this.targetNodeId,
      sourceAnchorId: this.sourceAnchorId,
      targetAnchorId: this.targetAnchorId,
      startPoint: U({}, this.startPoint),
      endPoint: U({}, this.endPoint)
    };
    [mt.INCREASE, mt.STATIC].includes(this.graphModel.overlapMode) && (e.zIndex = this.zIndex);
    var o = this.text, n = o.x, i = o.y, a = o.value;
    return a && (e.text = {
      x: n,
      y: i,
      value: a
    }), e;
  }, r.prototype.getHistoryData = function() {
    return this.getData();
  }, r.prototype.setProperty = function(t, e) {
    Qi(this.properties, t, Mt(e)), this.setAttributes();
  }, r.prototype.deleteProperty = function(t) {
    delete this.properties[t], this.setAttributes();
  }, r.prototype.setProperties = function(t) {
    this.properties = lt(lt({}, ie(this.properties)), Mt(t)), this.setAttributes();
  }, r.prototype.changeEdgeId = function(t) {
    var e = this.arrowConfig, o = e.markerEnd, n = e.markerStart;
    n && n === "url(#marker-start-".concat(this.id, ")") && (this.arrowConfig.markerStart = "url(#marker-start-".concat(t, ")")), o && o === "url(#marker-end-".concat(this.id, ")") && (this.arrowConfig.markerEnd = "url(#marker-end-".concat(t, ")")), this.id = t;
  }, r.prototype.setStyle = function(t, e) {
    var o;
    this.style = lt(lt({}, this.style), (o = {}, o[t] = Mt(e), o));
  }, r.prototype.setStyles = function(t) {
    this.style = lt(lt({}, this.style), Mt(t));
  }, r.prototype.updateStyles = function(t) {
    this.style = lt({}, Mt(t));
  }, r.prototype.setTextMode = function(t) {
    this.textMode = t;
  }, r.prototype.formatText = function(t) {
    var e, o, n, i = this.graphModel.editConfigModel, a = i.edgeTextDraggable, s = i.edgeTextEdit, l = this.textPosition, u = l.x, c = l.y, d = t.text, f = {
      value: "",
      x: u,
      y: c,
      draggable: a,
      editable: s
    };
    d && (typeof d == "string" ? f = lt(lt({}, f), { value: d }) : (f = lt(lt({}, f), {
      x: (e = d.x) !== null && e !== void 0 ? e : u,
      y: (o = d.y) !== null && o !== void 0 ? o : c,
      value: (n = d.value) !== null && n !== void 0 ? n : ""
    }), cr(d.draggable) || (f.draggable = d.draggable), cr(d.editable) || (f.editable = d.editable))), this.text = f;
  }, r.prototype.resetTextPosition = function() {
    var t = this.textPosition, e = t.x, o = t.y;
    this.text.x = e, this.text.y = o;
  }, r.prototype.moveText = function(t, e) {
    var o = this.text, n = o.x, i = o.y, a = o.value, s = o.draggable, l = o.editable;
    this.text = {
      value: a,
      editable: l,
      draggable: s,
      x: n + t,
      y: i + e
    };
  }, r.prototype.setText = function(t) {
    t && U(this.text, t);
  }, r.prototype.updateText = function(t) {
    this.text = lt(lt({}, ie(this.text)), { value: t });
  }, r.prototype.setAnchors = function() {
    if (!this.sourceAnchorId || !this.startPoint) {
      var t = this.getBeginAnchor(this.sourceNode, this.targetNode, this.sourceAnchorId);
      if (!t) throw new Error("无法获取beginAnchor，请检查anchors相关逻辑，anchors不能为空");
      this.startPoint || (this.startPoint = {
        x: t.x,
        y: t.y
      }), this.sourceAnchorId || (this.sourceAnchorId = t.id);
    }
    if (!this.targetAnchorId || !this.endPoint) {
      var t = this.getEndAnchor(this.targetNode, this.targetAnchorId);
      if (!t) throw new Error("无法获取endAnchor，请检查anchors相关逻辑，anchors不能为空");
      this.endPoint || (this.endPoint = {
        x: t.x,
        y: t.y
      }), this.targetAnchorId || (this.targetAnchorId = t.id);
    }
  }, r.prototype.setSelected = function(t) {
    t === void 0 && (t = !0), this.isSelected = t;
  }, r.prototype.setHovered = function(t) {
    t === void 0 && (t = !0), this.isHovered = t;
  }, r.prototype.setHitable = function(t) {
    t === void 0 && (t = !0), this.isHitable = t;
  }, r.prototype.setHittable = function(t) {
    t === void 0 && (t = !0), this.isHittable = t;
  }, r.prototype.openEdgeAnimation = function() {
    this.isAnimation = !0;
  }, r.prototype.closeEdgeAnimation = function() {
    this.isAnimation = !1;
  }, r.prototype.setElementState = function(t, e) {
    this.state = t, this.additionStateData = e;
  }, r.prototype.updateStartPoint = function(t) {
    this.startPoint = t;
  }, r.prototype.moveStartPoint = function(t, e) {
    this.startPoint && (this.startPoint.x += t, this.startPoint.y += e);
  }, r.prototype.updateEndPoint = function(t) {
    this.endPoint = t;
  }, r.prototype.moveEndPoint = function(t, e) {
    this.endPoint && (this.endPoint.x += t, this.endPoint.y += e);
  }, r.prototype.setZIndex = function(t) {
    t === void 0 && (t = 0), this.zIndex = t;
  }, r.prototype.initPoints = function() {
  }, r.prototype.updateAttributes = function(t) {
    U(this, t);
  }, r.prototype.getAdjustStart = function() {
    return this.startPoint;
  }, r.prototype.getAdjustEnd = function() {
    return this.endPoint;
  }, r.prototype.updateAfterAdjustStartAndEnd = function(t) {
    var e = t.startPoint, o = t.endPoint;
    this.updateStartPoint({
      x: e.x,
      y: e.y
    }), this.updateEndPoint({
      x: o.x,
      y: o.y
    });
  }, r.prototype.updateZIndexByOverlap = function(t, e) {
    switch (t) {
      case mt.DEFAULT:
        this.zIndex = 0;
        break;
      case mt.EDGE_TOP:
        this.zIndex = 1;
        break;
      case mt.INCREASE:
        this.zIndex = e;
    }
  }, r.BaseType = dt.EDGE, j([A], r.prototype, "type", void 0), j([A], r.prototype, "sourceNodeId", void 0), j([A], r.prototype, "targetNodeId", void 0), j([A], r.prototype, "startPoint", void 0), j([A], r.prototype, "endPoint", void 0), j([A], r.prototype, "textMode", void 0), j([A], r.prototype, "text", void 0), j([A], r.prototype, "properties", void 0), j([A], r.prototype, "points", void 0), j([A], r.prototype, "pointsList", void 0), j([A], r.prototype, "isSelected", void 0), j([A], r.prototype, "isHovered", void 0), j([A], r.prototype, "isHitable", void 0), j([A], r.prototype, "isHittable", void 0), j([A], r.prototype, "draggable", void 0), j([A], r.prototype, "visible", void 0), j([A], r.prototype, "isAnimation", void 0), j([A], r.prototype, "isShowAdjustPoint", void 0), j([A], r.prototype, "zIndex", void 0), j([A], r.prototype, "state", void 0), j([A], r.prototype, "style", void 0), j([A], r.prototype, "arrowConfig", void 0), j([ot], r.prototype, "sourceNode", null), j([ot], r.prototype, "targetNode", null), j([ot], r.prototype, "textPosition", null), j([b], r.prototype, "setProperty", null), j([b], r.prototype, "deleteProperty", null), j([b], r.prototype, "setProperties", null), j([b], r.prototype, "changeEdgeId", null), j([b], r.prototype, "setStyle", null), j([b], r.prototype, "setStyles", null), j([b], r.prototype, "updateStyles", null), j([b], r.prototype, "setTextMode", null), j([b], r.prototype, "formatText", null), j([b], r.prototype, "resetTextPosition", null), j([b], r.prototype, "moveText", null), j([b], r.prototype, "setText", null), j([b], r.prototype, "updateText", null), j([b], r.prototype, "setAnchors", null), j([b], r.prototype, "setSelected", null), j([b], r.prototype, "setHovered", null), j([b], r.prototype, "setHitable", null), j([b], r.prototype, "setHittable", null), j([b], r.prototype, "openEdgeAnimation", null), j([b], r.prototype, "closeEdgeAnimation", null), j([b], r.prototype, "setElementState", null), j([b], r.prototype, "updateStartPoint", null), j([b], r.prototype, "moveStartPoint", null), j([b], r.prototype, "updateEndPoint", null), j([b], r.prototype, "moveEndPoint", null), j([b], r.prototype, "setZIndex", null), j([b], r.prototype, "initPoints", null), j([b], r.prototype, "updateAttributes", null), j([b], r.prototype, "getAdjustStart", null), j([b], r.prototype, "getAdjustEnd", null), j([b], r.prototype, "updateAfterAdjustStartAndEnd", null), j([b], r.prototype, "updateZIndexByOverlap", null), r;
})(), yp = /* @__PURE__ */ (function() {
  var r = function(t, e) {
    return r = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(o, n) {
      o.__proto__ = n;
    } || function(o, n) {
      for (var i in n) Object.prototype.hasOwnProperty.call(n, i) && (o[i] = n[i]);
    }, r(t, e);
  };
  return function(t, e) {
    if (typeof e != "function" && e !== null) throw new TypeError("Class extends value " + String(e) + " is not a constructor or null");
    r(t, e);
    function o() {
      this.constructor = t;
    }
    t.prototype = e === null ? Object.create(e) : (o.prototype = e.prototype, new o());
  };
})(), Ie = function() {
  return Ie = Object.assign || function(r) {
    for (var t, e = 1, o = arguments.length; e < o; e++) {
      t = arguments[e];
      for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && (r[n] = t[n]);
    }
    return r;
  }, Ie.apply(this, arguments);
}, It = function(r, t, e, o) {
  var n = arguments.length, i = n < 3 ? t : o === null ? o = Object.getOwnPropertyDescriptor(t, e) : o, a;
  if (typeof Reflect == "object" && typeof Reflect.decorate == "function") i = Reflect.decorate(r, t, e, o);
  else for (var s = r.length - 1; s >= 0; s--) (a = r[s]) && (i = (n < 3 ? a(i) : n > 3 ? a(t, e, i) : a(t, e)) || i);
  return n > 3 && i && Object.defineProperty(t, e, i), i;
}, Ln = function(r, t) {
  var e = typeof Symbol == "function" && r[Symbol.iterator];
  if (!e) return r;
  var o = e.call(r), n, i = [], a;
  try {
    for (; (t === void 0 || t-- > 0) && !(n = o.next()).done; ) i.push(n.value);
  } catch (s) {
    a = { error: s };
  } finally {
    try {
      n && !n.done && (e = o.return) && e.call(o);
    } finally {
      if (a) throw a.error;
    }
  }
  return i;
}, vi = (function(r) {
  yp(t, r);
  function t(e, o) {
    var n = r.call(this, e, o) || this;
    return n.modelType = G.BEZIER_EDGE, n.path = "", n.initEdgeData(e), n.setAttributes(), n;
  }
  return t.prototype.initEdgeData = function(e) {
    this.offset = He(e, "properties.offset", 100), r.prototype.initEdgeData.call(this, e);
  }, t.prototype.getEdgeStyle = function() {
    var e = this.graphModel.theme.bezier, o = r.prototype.getEdgeStyle.call(this), n = this.properties.style, i = n === void 0 ? {} : n;
    return Ie(Ie(Ie({}, o), R(e)), R(i));
  }, t.prototype.getTextPosition = function() {
    if (this.pointsList && this.pointsList.length > 0) {
      var e = 0, o = 0;
      return this.pointsList.forEach(function(n) {
        var i = n.x, a = n.y;
        e += i, o += a;
      }), {
        x: e / this.pointsList.length,
        y: o / this.pointsList.length
      };
    }
    return {
      x: (this.startPoint.x + this.endPoint.x) / 2,
      y: (this.startPoint.y + this.endPoint.y) / 2
    };
  }, t.prototype.getData = function() {
    var e = r.prototype.getData.call(this), o = this.pointsList.map(function(n) {
      return {
        x: n.x,
        y: n.y
      };
    });
    return Ie(Ie({}, e), { pointsList: o });
  }, t.prototype.getControls = function() {
    var e = this.startPoint, o = this.endPoint;
    return fs({
      start: e,
      end: o,
      sourceNode: this.sourceNode,
      targetNode: this.targetNode,
      offset: this.offset
    });
  }, t.prototype.getPath = function(e) {
    var o = Ln(e, 4), n = o[0], i = o[1], a = o[2], s = o[3];
    return "M ".concat(n.x, " ").concat(n.y, `
    C `).concat(i.x, " ").concat(i.y, `,
    `).concat(a.x, " ").concat(a.y, `,
    `).concat(s.x, " ").concat(s.y);
  }, t.prototype.initPoints = function() {
    this.pointsList.length > 0 ? this.path = this.getPath(this.pointsList) : this.updatePoints();
  }, t.prototype.updatePoints = function() {
    var e = this.getControls(), o = e.sNext, n = e.ePre;
    this.updatePath(o, n);
  }, t.prototype.updatePath = function(e, o) {
    e = R(e), o = R(o);
    var n = {
      x: this.startPoint.x,
      y: this.startPoint.y
    }, i = {
      x: this.endPoint.x,
      y: this.endPoint.y
    };
    if (!e || !o) {
      var a = this.getControls();
      e = a.sNext, o = a.ePre;
    }
    this.pointsList = [
      n,
      e,
      o,
      i
    ], this.path = this.getPath(this.pointsList);
  }, t.prototype.updateStartPoint = function(e) {
    this.startPoint = Object.assign({}, e), this.updatePoints();
  }, t.prototype.updateEndPoint = function(e) {
    this.endPoint = Object.assign({}, e), this.updatePoints();
  }, t.prototype.moveStartPoint = function(e, o) {
    this.startPoint.x += e, this.startPoint.y += o;
    var n = Ln(this.pointsList, 3), i = n[1], a = n[2];
    i.x += e, i.y += o, this.updatePath(i, a);
  }, t.prototype.moveEndPoint = function(e, o) {
    this.endPoint.x += e, this.endPoint.y += o;
    var n = Ln(this.pointsList, 3), i = n[1], a = n[2];
    a.x += e, a.y += o, this.updatePath(i, a);
  }, t.prototype.updateAdjustAnchor = function(e, o) {
    var n;
    o === "sNext" ? this.pointsList[1] = e : o === "ePre" && (this.pointsList[2] = e), this.path = this.getPath(this.pointsList), !((n = this.text) === null || n === void 0) && n.value && this.setText(U({}, this.text, this.textPosition));
  }, t.prototype.getAdjustStart = function() {
    return this.pointsList[0] || this.startPoint;
  }, t.prototype.getAdjustEnd = function() {
    var e = this.pointsList;
    return e[e.length - 1] || this.endPoint;
  }, t.prototype.updateAfterAdjustStartAndEnd = function(e) {
    var o = e.startPoint, n = e.endPoint, i = e.sourceNode, a = e.targetNode, s = fs({
      start: o,
      end: n,
      sourceNode: i,
      targetNode: a,
      offset: this.offset
    }), l = s.sNext, u = s.ePre;
    this.pointsList = [
      o,
      l,
      u,
      n
    ], this.initPoints();
  }, It([A], t.prototype, "offset", void 0), It([A], t.prototype, "path", void 0), It([b], t.prototype, "initPoints", null), It([b], t.prototype, "updatePoints", null), It([b], t.prototype, "updateStartPoint", null), It([b], t.prototype, "updateEndPoint", null), It([b], t.prototype, "moveStartPoint", null), It([b], t.prototype, "moveEndPoint", null), It([b], t.prototype, "updateAdjustAnchor", null), It([b], t.prototype, "getAdjustStart", null), It([b], t.prototype, "getAdjustEnd", null), It([b], t.prototype, "updateAfterAdjustStartAndEnd", null), t;
})(On), gp = /* @__PURE__ */ (function() {
  var r = function(t, e) {
    return r = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(o, n) {
      o.__proto__ = n;
    } || function(o, n) {
      for (var i in n) Object.prototype.hasOwnProperty.call(n, i) && (o[i] = n[i]);
    }, r(t, e);
  };
  return function(t, e) {
    if (typeof e != "function" && e !== null) throw new TypeError("Class extends value " + String(e) + " is not a constructor or null");
    r(t, e);
    function o() {
      this.constructor = t;
    }
    t.prototype = e === null ? Object.create(e) : (o.prototype = e.prototype, new o());
  };
})(), Hr = function() {
  return Hr = Object.assign || function(r) {
    for (var t, e = 1, o = arguments.length; e < o; e++) {
      t = arguments[e];
      for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && (r[n] = t[n]);
    }
    return r;
  }, Hr.apply(this, arguments);
}, Os = function(r, t) {
  var e = typeof Symbol == "function" && r[Symbol.iterator];
  if (!e) return r;
  var o = e.call(r), n, i = [], a;
  try {
    for (; (t === void 0 || t-- > 0) && !(n = o.next()).done; ) i.push(n.value);
  } catch (s) {
    a = { error: s };
  } finally {
    try {
      n && !n.done && (e = o.return) && e.call(o);
    } finally {
      if (a) throw a.error;
    }
  }
  return i;
}, _p = function(r, t, e) {
  if (e || arguments.length === 2)
    for (var o = 0, n = t.length, i; o < n; o++) (i || !(o in t)) && (i || (i = Array.prototype.slice.call(t, 0, o)), i[o] = t[o]);
  return r.concat(i || Array.prototype.slice.call(t));
}, yi = (function(r) {
  gp(t, r);
  function t() {
    var e = r.apply(this, _p([], Os(arguments), !1)) || this;
    return e.modelType = G.LINE_EDGE, e;
  }
  return t.prototype.getEdgeStyle = function() {
    var e = this.graphModel.theme.line, o = r.prototype.getEdgeStyle.call(this), n = this.properties.style, i = n === void 0 ? {} : n;
    return Hr(Hr(Hr({}, o), R(e)), R(i));
  }, t.prototype.initEdgeData = function(e) {
    r.prototype.initEdgeData.call(this, e), this.points = this.getPath([this.startPoint, this.endPoint]);
  }, t.prototype.getPath = function(e) {
    var o = Os(e, 2), n = o[0], i = o[1];
    return "".concat(n.x, ",").concat(n.y, " ").concat(i.x, ",").concat(i.y);
  }, t.prototype.getTextPosition = function() {
    return {
      x: (this.startPoint.x + this.endPoint.x) / 2,
      y: (this.startPoint.y + this.endPoint.y) / 2
    };
  }, t;
})(On), mp = /* @__PURE__ */ (function() {
  var r = function(t, e) {
    return r = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(o, n) {
      o.__proto__ = n;
    } || function(o, n) {
      for (var i in n) Object.prototype.hasOwnProperty.call(n, i) && (o[i] = n[i]);
    }, r(t, e);
  };
  return function(t, e) {
    if (typeof e != "function" && e !== null) throw new TypeError("Class extends value " + String(e) + " is not a constructor or null");
    r(t, e);
    function o() {
      this.constructor = t;
    }
    t.prototype = e === null ? Object.create(e) : (o.prototype = e.prototype, new o());
  };
})(), Gr = function() {
  return Gr = Object.assign || function(r) {
    for (var t, e = 1, o = arguments.length; e < o; e++) {
      t = arguments[e];
      for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && (r[n] = t[n]);
    }
    return r;
  }, Gr.apply(this, arguments);
}, xt = function(r, t, e, o) {
  var n = arguments.length, i = n < 3 ? t : o === null ? o = Object.getOwnPropertyDescriptor(t, e) : o, a;
  if (typeof Reflect == "object" && typeof Reflect.decorate == "function") i = Reflect.decorate(r, t, e, o);
  else for (var s = r.length - 1; s >= 0; s--) (a = r[s]) && (i = (n < 3 ? a(i) : n > 3 ? a(t, e, i) : a(t, e)) || i);
  return n > 3 && i && Object.defineProperty(t, e, i), i;
}, ws = function(r, t) {
  var e = typeof Symbol == "function" && r[Symbol.iterator];
  if (!e) return r;
  var o = e.call(r), n, i = [], a;
  try {
    for (; (t === void 0 || t-- > 0) && !(n = o.next()).done; ) i.push(n.value);
  } catch (s) {
    a = { error: s };
  } finally {
    try {
      n && !n.done && (e = o.return) && e.call(o);
    } finally {
      if (a) throw a.error;
    }
  }
  return i;
}, xp = function(r, t, e) {
  if (e || arguments.length === 2)
    for (var o = 0, n = t.length, i; o < n; o++) (i || !(o in t)) && (i || (i = Array.prototype.slice.call(t, 0, o)), i[o] = t[o]);
  return r.concat(i || Array.prototype.slice.call(t));
}, Ss = function(r) {
  return !!r && Number.isFinite(r.x) && Number.isFinite(r.y);
}, As = (function(r) {
  mp(t, r);
  function t() {
    var e = r.apply(this, xp([], ws(arguments), !1)) || this;
    return e.modelType = G.POLYLINE_EDGE, e.draggingPointList = [], e;
  }
  return t.prototype.initEdgeData = function(e) {
    var o = He(e, "properties.offset");
    if (this.offset = typeof o == "number" ? o : this.getDefaultOffset(), e.pointsList) {
      var n = this.orthogonalizePath(e.pointsList);
      e.pointsList = n, this.pointsList = n;
    }
    r.prototype.initEdgeData.call(this, e);
  }, t.prototype.setAttributes = function() {
    var e = this.properties.offset;
    e && e !== this.offset && (this.offset = e, this.updatePoints());
  }, t.prototype.orthogonalizePath = function(e) {
    if (!Array.isArray(e) || e.length < 2) return e;
    var o = function(E, x) {
      var O = E[E.length - 1];
      (!O || O.x !== x.x || O.y !== x.y) && E.push({
        x: x.x,
        y: x.y
      });
    }, n = function(E, x) {
      return E.x === x.x || E.y === x.y;
    }, i = function(E, x) {
      return Math.abs(E.x - x.x) + Math.abs(E.y - x.y);
    }, a = [];
    o(a, e[0]);
    for (var s, l = 0; l < e.length - 1; l++) {
      var u = a[a.length - 1], c = e[l + 1];
      if (!(!u || !c)) {
        if (n(u, c)) {
          o(a, c), s = u.x === c.x ? $.VERTICAL : $.HORIZONTAL;
          continue;
        }
        var d = {
          x: c.x,
          y: u.y
        }, f = {
          x: u.x,
          y: c.y
        }, p = s === $.VERTICAL ? f : s === $.HORIZONTAL || i(u, d) <= i(u, f) ? d : f;
        (p.x !== u.x || p.y !== u.y) && o(a, p), o(a, c);
        var v = a[a.length - 2], h = a[a.length - 1];
        s = v && h ? v.x === h.x ? $.VERTICAL : $.HORIZONTAL : s;
      }
    }
    for (var g = [], l = 0; l < a.length; l++) {
      var y = a[l - 1], _ = a[l], c = a[l + 1];
      y && _ && c && (y.x === _.x && _.x === c.x || y.y === _.y && _.y === c.y) || o(g, _);
    }
    return g.length >= 2 && (g[0] = {
      x: e[0].x,
      y: e[0].y
    }, g[g.length - 1] = {
      x: e[e.length - 1].x,
      y: e[e.length - 1].y
    }), g.length < 2 || g.every(function(E, x, O) {
      return x === 0 ? !0 : n(O[x - 1], O[x]);
    }) ? g : [{
      x: e[0].x,
      y: e[0].y
    }, {
      x: e[e.length - 1].x,
      y: e[e.length - 1].y
    }];
  }, t.prototype.getDefaultOffset = function() {
    var e = this.getArrowStyle();
    return (typeof e.offset == "number" ? e.offset : 0) + 5;
  }, t.prototype.getEdgeStyle = function() {
    var e = this.graphModel.theme.polyline, o = r.prototype.getEdgeStyle.call(this), n = this.properties.style, i = n === void 0 ? {} : n;
    return Gr(Gr(Gr({}, o), R(e)), R(i));
  }, t.prototype.getTextPosition = function() {
    var e, o = (e = this.text) === null || e === void 0 ? void 0 : e.value;
    if (this.dbClickPosition && !o) {
      var n = this.dbClickPosition;
      return {
        x: n.x,
        y: n.y
      };
    }
    var i = Me(this.points), a = ws(df(i), 2), s = a[0], l = a[1];
    return {
      x: (s.x + l.x) / 2,
      y: (s.y + l.y) / 2
    };
  }, t.prototype.getAfterAnchor = function(e, o, n) {
    var i, a;
    return n.forEach(function(s) {
      var l;
      e === $.HORIZONTAL ? l = Math.abs(o.y - s.y) : e === $.VERTICAL && (l = Math.abs(o.x - s.x)), (!a || a > l) && (a = l, i = s);
    }), i;
  }, t.prototype.getCrossPoint = function(e, o, n) {
    var i;
    return e === $.HORIZONTAL ? i = {
      x: n.x,
      y: o.y
    } : e === $.VERTICAL && (i = {
      x: o.x,
      y: n.y
    }), i;
  }, t.prototype.removeCrossPoints = function(e, o, n) {
    var i = n.map(function(h) {
      return h;
    });
    if (e === 1) {
      var a = i[e], s = i[o], l = i[e - 1];
      if (ls(l, a, this.sourceNode)) {
        var u = us(a, s, this.sourceNode);
        if (u) {
          var c = cs(a, s, this.sourceNode);
          c && (i[e] = c, i.splice(e - 1, 1), e--, o--);
        }
      } else {
        var d = this.sourceNode.anchors;
        d.forEach(function(h) {
          (h.x === l.x && h.x === a.x || h.y === l.y && h.y === a.y) && Kt(h.x, h.y, a.x, a.y) < Kt(l.x, l.y, a.x, a.y) && (i[e - 1] = h);
        });
      }
    }
    if (o === n.length - 2) {
      var f = i[e], p = i[o], v = i[o + 1];
      if (ls(p, v, this.targetNode)) {
        var u = us(f, p, this.targetNode);
        if (u) {
          var c = cs(f, p, this.targetNode);
          c && (i[o] = c, i.splice(o + 1, 1));
        }
      } else {
        var d = this.targetNode.anchors;
        d.forEach(function(g) {
          (g.x === v.x && g.x === p.x || g.y === v.y && g.y === p.y) && Kt(g.x, g.y, p.x, p.y) < Kt(v.x, v.y, p.x, p.y) && (i[o + 1] = g);
        });
      }
    }
    return i;
  }, t.prototype.getDraggingPoints = function(e, o, n, i, a) {
    var s = a.map(function(c) {
      return c;
    }), l = this.getAfterAnchor(e, n, i), u = this.getCrossPoint(e, n, l);
    return o === "start" ? (s.unshift(u), s.unshift(l)) : (s.push(u), s.push(l)), s;
  }, t.prototype.updateCrossPoints = function(e) {
    var o = e.map(function(_) {
      return _;
    }), n = e[0], i = e[1], a = e[o.length - 2], s = e[o.length - 1], l = this, u = l.sourceNode, c = l.targetNode, d = u.modelType, f = c.modelType, p = on(n, i), v = o[0];
    switch (d) {
      case G.RECT_NODE:
        if (u.radius !== 0) {
          var h = gs(n, u);
          h || (v = ys(n, p, u));
        }
        break;
      case G.CIRCLE_NODE:
        v = li(n, p, u);
        break;
      case G.ELLIPSE_NODE:
        v = _s(n, p, u);
        break;
      case G.DIAMOND_NODE:
        v = So(n, p, u);
        break;
      case G.POLYGON_NODE:
        v = So(n, p, u);
    }
    Ss(v) && (o[0] = v);
    var g = on(a, s), y = o[o.length - 1];
    switch (f) {
      case G.RECT_NODE:
        if (c.radius !== 0) {
          var h = gs(s, c);
          h || (y = ys(s, g, c));
        }
        break;
      case G.CIRCLE_NODE:
        y = li(s, g, c);
        break;
      case G.ELLIPSE_NODE:
        y = _s(s, g, c);
        break;
      case G.DIAMOND_NODE:
        y = So(s, g, c);
        break;
      case G.POLYGON_NODE:
        y = So(s, g, c);
    }
    return Ss(y) && (o[o.length - 1] = y), o;
  }, t.prototype.updatePath = function(e) {
    this.pointsList = this.orthogonalizePath(e), this.points = this.getPath(this.pointsList);
  }, t.prototype.getData = function() {
    var e = r.prototype.getData.call(this), o = this.pointsList.map(function(n) {
      return {
        x: n.x,
        y: n.y
      };
    });
    return Object.assign({}, e, { pointsList: o });
  }, t.prototype.getPath = function(e) {
    return e.map(function(o) {
      return "".concat(o.x, ",").concat(o.y);
    }).join(" ");
  }, t.prototype.initPoints = function() {
    this.pointsList.length > 0 ? this.points = this.getPath(this.pointsList) : this.updatePoints();
  }, t.prototype.updatePoints = function() {
    var e = ss({
      x: this.startPoint.x,
      y: this.startPoint.y
    }, {
      x: this.endPoint.x,
      y: this.endPoint.y
    }, this.sourceNode, this.targetNode, this.offset || 0);
    this.pointsList = this.orthogonalizePath(e), this.points = this.pointsList.map(function(o) {
      return "".concat(o.x, ",").concat(o.y);
    }).join(" ");
  }, t.prototype.updateStartPoint = function(e) {
    this.startPoint = Object.assign({}, e), this.updatePoints();
  }, t.prototype.moveStartPoint = function(e, o) {
    this.startPoint.x += e, this.startPoint.y += o, this.updatePoints();
  }, t.prototype.updateEndPoint = function(e) {
    this.endPoint = Object.assign({}, e), this.updatePoints();
  }, t.prototype.moveEndPoint = function(e, o) {
    this.endPoint.x += e, this.endPoint.y += o, this.updatePoints();
  }, t.prototype.updatePointsList = function(e, o) {
    this.pointsList.forEach(function(a) {
      a.x += e, a.y += o;
    });
    var n = this.pointsList[0];
    this.startPoint = Object.assign({}, n);
    var i = this.pointsList[this.pointsList.length - 1];
    this.endPoint = Object.assign({}, i), this.initPoints();
  }, t.prototype.dragAppendStart = function() {
    this.draggingPointList = this.pointsList.map(function(e) {
      return e;
    });
  }, t.prototype.dragAppendSimple = function(e, o) {
    var n;
    this.isDragging = !0;
    var i = e.start, a = e.end, s = e.startIndex, l = e.endIndex, u = e.direction, c = this.pointsList, d = c;
    return u === $.HORIZONTAL ? (c[s] = {
      x: i.x,
      y: i.y + o.y
    }, c[l] = {
      x: a.x,
      y: a.y + o.y
    }, d = this.pointsList.map(function(f) {
      return f;
    })) : u === $.VERTICAL && (c[s] = {
      x: i.x + o.x,
      y: i.y
    }, c[l] = {
      x: a.x + o.x,
      y: a.y
    }, d = this.pointsList.map(function(f) {
      return f;
    })), this.updatePointsAfterDrag(d), this.draggingPointList = d, !((n = this.text) === null || n === void 0) && n.value && this.setText(U({}, this.text, this.textPosition)), {
      start: U({}, c[s]),
      end: U({}, c[l]),
      startIndex: s,
      endIndex: l,
      direction: u
    };
  }, t.prototype.dragAppend = function(e, o) {
    var n;
    this.isDragging = !0;
    var i = e.start, a = e.end, s = e.startIndex, l = e.endIndex, u = e.direction, c = this.pointsList;
    if (u === $.HORIZONTAL) {
      c[s] = {
        x: i.x,
        y: i.y + o.y
      }, c[l] = {
        x: a.x,
        y: a.y + o.y
      };
      var d = this.pointsList.map(function(g) {
        return g;
      });
      if (s !== 0 && l !== this.pointsList.length - 1 && (d = this.removeCrossPoints(s, l, d)), s === 0) {
        var f = {
          x: i.x,
          y: i.y + o.y
        }, p = ve(f, this.sourceNode);
        if (!p) {
          var v = this.sourceNode.anchors;
          d = this.getDraggingPoints(u, "start", f, v, d);
        }
      }
      if (l === this.pointsList.length - 1) {
        var h = {
          x: a.x,
          y: a.y + o.y
        }, p = ve(h, this.targetNode);
        if (!p) {
          var v = this.targetNode.anchors;
          d = this.getDraggingPoints(u, "end", h, v, d);
        }
      }
      this.updatePointsAfterDrag(d), this.draggingPointList = d;
    } else if (u === $.VERTICAL) {
      c[s] = {
        x: i.x + o.x,
        y: i.y
      }, c[l] = {
        x: a.x + o.x,
        y: a.y
      };
      var d = this.pointsList.map(function(y) {
        return y;
      });
      if (s !== 0 && l !== this.pointsList.length - 1 && (d = this.removeCrossPoints(s, l, d)), s === 0) {
        var f = {
          x: i.x + o.x,
          y: i.y
        }, p = ve(f, this.sourceNode);
        if (!p) {
          var v = this.sourceNode.anchors;
          d = this.getDraggingPoints(u, "start", f, v, d);
        }
      }
      if (l === this.pointsList.length - 1) {
        var h = {
          x: a.x + o.x,
          y: a.y
        }, p = ve(h, this.targetNode);
        if (!p) {
          var v = this.targetNode.anchors;
          d = this.getDraggingPoints(u, "end", h, v, d);
        }
      }
      this.updatePointsAfterDrag(d), this.draggingPointList = d;
    }
    return !((n = this.text) === null || n === void 0) && n.value && this.setText(U({}, this.text, this.textPosition)), {
      start: U({}, c[s]),
      end: U({}, c[l]),
      startIndex: s,
      endIndex: l,
      direction: u
    };
  }, t.prototype.dragAppendEnd = function() {
    if (this.draggingPointList) {
      var e = tu(Me(this.points));
      this.pointsList = e.map(function(i) {
        return i;
      }), this.draggingPointList = [];
      var o = e[0];
      this.startPoint = U({}, o);
      var n = e[e.length - 1];
      this.endPoint = U({}, n);
    }
    this.isDragging = !1;
  }, t.prototype.updatePointsAfterDrag = function(e) {
    var o = this.updateCrossPoints(e);
    this.points = o.map(function(n) {
      return "".concat(n.x, ",").concat(n.y);
    }).join(" ");
  }, t.prototype.getAdjustStart = function() {
    return this.pointsList[0] || this.startPoint;
  }, t.prototype.getAdjustEnd = function() {
    var e = this.pointsList;
    return e[e.length - 1] || this.endPoint;
  }, t.prototype.updateAfterAdjustStartAndEnd = function(e) {
    var o = e.startPoint, n = e.endPoint, i = e.sourceNode, a = e.targetNode;
    this.pointsList = this.orthogonalizePath(ss({
      x: o.x,
      y: o.y
    }, {
      x: n.x,
      y: n.y
    }, i, a, this.offset || 0)), this.initPoints();
  }, xt([A], t.prototype, "offset", void 0), xt([A], t.prototype, "dbClickPosition", void 0), xt([b], t.prototype, "initPoints", null), xt([b], t.prototype, "updatePoints", null), xt([b], t.prototype, "updateStartPoint", null), xt([b], t.prototype, "moveStartPoint", null), xt([b], t.prototype, "updateEndPoint", null), xt([b], t.prototype, "moveEndPoint", null), xt([b], t.prototype, "updatePointsList", null), xt([b], t.prototype, "dragAppendStart", null), xt([b], t.prototype, "dragAppendSimple", null), xt([b], t.prototype, "dragAppend", null), xt([b], t.prototype, "dragAppendEnd", null), xt([b], t.prototype, "updatePointsAfterDrag", null), xt([b], t.prototype, "getAdjustStart", null), xt([b], t.prototype, "getAdjustEnd", null), xt([b], t.prototype, "updateAfterAdjustStartAndEnd", null), t;
})(On), ft = function() {
  return ft = Object.assign || function(r) {
    for (var t, e = 1, o = arguments.length; e < o; e++) {
      t = arguments[e];
      for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && (r[n] = t[n]);
    }
    return r;
  }, ft.apply(this, arguments);
}, I = function(r, t, e, o) {
  var n = arguments.length, i = n < 3 ? t : o === null ? o = Object.getOwnPropertyDescriptor(t, e) : o, a;
  if (typeof Reflect == "object" && typeof Reflect.decorate == "function") i = Reflect.decorate(r, t, e, o);
  else for (var s = r.length - 1; s >= 0; s--) (a = r[s]) && (i = (n < 3 ? a(i) : n > 3 ? a(t, e, i) : a(t, e)) || i);
  return n > 3 && i && Object.defineProperty(t, e, i), i;
}, Ms = function(r) {
  var t = typeof Symbol == "function" && Symbol.iterator, e = t && r[t], o = 0;
  if (e) return e.call(r);
  if (r && typeof r.length == "number") return { next: function() {
    return r && o >= r.length && (r = void 0), {
      value: r && r[o++],
      done: !r
    };
  } };
  throw new TypeError(t ? "Object is not iterable." : "Symbol.iterator is not defined.");
}, Ep = function(r, t) {
  var e = typeof Symbol == "function" && r[Symbol.iterator];
  if (!e) return r;
  var o = e.call(r), n, i = [], a;
  try {
    for (; (t === void 0 || t-- > 0) && !(n = o.next()).done; ) i.push(n.value);
  } catch (s) {
    a = { error: s };
  } finally {
    try {
      n && !n.done && (e = o.return) && e.call(o);
    } finally {
      if (a) throw a.error;
    }
  }
  return i;
}, Ce = (function() {
  function r(t, e) {
    var o;
    this.BaseType = dt.NODE, this.id = "", this.type = "", this.x = 0, this.y = 0, this.textMode = Xt.TEXT, this.text = {
      value: "",
      x: 0,
      y: 0,
      draggable: !1,
      editable: !0
    }, this._width = 100, this._height = 80, this.minWidth = 30, this.minHeight = 30, this.maxWidth = 2e3, this.maxHeight = 2e3, this.anchorsOffset = [], this.virtual = !1, this.isSelected = !1, this.isHovered = !1, this.isShowAnchor = !1, this.isDragging = !1, this.isHitable = !0, this.isHittable = !0, this.draggable = !0, this.visible = !0, this.rotatable = !0, this.resizable = !0, this.zIndex = 1, this.state = J.DEFAULT, this.autoToFront = !0, this.style = {}, this._rotate = 0, this.modelType = G.NODE, this.additionStateData = {}, this.targetRules = [], this.sourceRules = [], this.moveRules = [], this.resizeRules = [], this.hasSetTargetRules = !1, this.hasSetSourceRules = !1, this.graphModel = e, this.properties = (o = t.properties) !== null && o !== void 0 ? o : {}, this.initNodeData(t), this.setAttributes();
  }
  return Object.defineProperty(r.prototype, "width", {
    get: function() {
      return this._width;
    },
    set: function(t) {
      this._width = t;
    },
    enumerable: !1,
    configurable: !0
  }), Object.defineProperty(r.prototype, "height", {
    get: function() {
      return this._height;
    },
    set: function(t) {
      this._height = t;
    },
    enumerable: !1,
    configurable: !0
  }), Object.defineProperty(r.prototype, "rotate", {
    get: function() {
      return this._rotate;
    },
    set: function(t) {
      this._rotate = t;
      var e = this, o = e.x, n = o === void 0 ? 0 : o, i = e.y, a = i === void 0 ? 0 : i;
      this.transform = new nn(-n, -a).rotate(t).translate(n, a).toString();
    },
    enumerable: !1,
    configurable: !0
  }), Object.defineProperty(r.prototype, "incoming", {
    get: function() {
      return {
        nodes: this.graphModel.getNodeIncomingNode(this.id),
        edges: this.graphModel.getNodeIncomingEdge(this.id)
      };
    },
    enumerable: !1,
    configurable: !0
  }), Object.defineProperty(r.prototype, "outgoing", {
    get: function() {
      return {
        nodes: this.graphModel.getNodeOutgoingNode(this.id),
        edges: this.graphModel.getNodeOutgoingEdge(this.id)
      };
    },
    enumerable: !1,
    configurable: !0
  }), r.prototype.initNodeData = function(t) {
    var e = this;
    if (t.properties || (t.properties = {}), !t.id) {
      var o = this.graphModel.idGenerator, n = o && o(t.type);
      t.id = this.createId() || n || $e();
    }
    this.formatText(t), U(this, Sf(t));
    var i = this.graphModel, a = i.overlapMode, s = i.eventCenter;
    this.updateZIndexByOverlap(a, t.zIndex || ao()), s.on("overlap:change", function(l) {
      var u = l.overlapMode;
      e.updateZIndexByOverlap(u, e.zIndex || ao());
    });
  }, r.prototype.setAttributes = function() {
  }, r.prototype.createId = function() {
    return null;
  }, r.prototype.setTextMode = function(t) {
    this.textMode = t;
  }, r.prototype.formatText = function(t) {
    var e, o, n, i = this.graphModel.editConfigModel, a = i.nodeTextDraggable, s = i.nodeTextEdit, l = t.x, u = t.y, c = t.text, d = {
      value: "",
      x: l,
      y: u,
      draggable: a,
      editable: s
    };
    c && (typeof c == "string" ? d.value = c : (d = ft(ft({}, d), {
      x: (e = c.x) !== null && e !== void 0 ? e : l,
      y: (o = c.y) !== null && o !== void 0 ? o : u,
      value: (n = c.value) !== null && n !== void 0 ? n : ""
    }), cr(c.draggable) || (d.draggable = c.draggable), cr(c.editable) || (d.editable = c.editable))), t.text = d;
  }, r.prototype.resize = function(t) {
    var e = t.width, o = t.height, n = t.deltaX, i = t.deltaY;
    return this.isAllowResizeNode(n, i, e, o) ? (this.move(n / 2, i / 2), this.width = e, this.height = o, this.setProperties({
      width: e,
      height: o
    }), this.getData()) : this.getData();
  }, r.prototype.proportionalResize = function() {
  }, r.prototype.getData = function() {
    var t = this.text, e = t.x, o = t.y, n = t.value, i = this.properties;
    Pe(i) && (i = ie(i)), yt(i.width) && (i.width = this.width), yt(i.height) && (i.height = this.height);
    var a = {
      id: this.id,
      type: this.type,
      x: this.x,
      y: this.y,
      properties: i
    };
    return this.rotate && (a.rotate = this.rotate), [mt.INCREASE, mt.STATIC].includes(this.graphModel.overlapMode) && (a.zIndex = this.zIndex), n && (a.text = {
      x: e,
      y: o,
      value: n
    }), a;
  }, r.prototype.getHistoryData = function() {
    return this.getData();
  }, r.prototype.getProperties = function() {
    return ie(this.properties);
  }, r.prototype.getOuterGAttributes = function() {
    return { className: "" };
  }, r.prototype.getNodeStyle = function() {
    return ft(ft({}, this.graphModel.theme.baseNode), this.style);
  }, r.prototype.getTextStyle = function() {
    var t = this.graphModel.theme.nodeText, e = this.properties.textStyle, o = e === void 0 ? {} : e;
    return ft(ft({}, R(t)), R(o));
  }, r.prototype.getRotateControlStyle = function() {
    var t = this.graphModel.theme.rotateControl;
    return R(t);
  }, r.prototype.getResizeControlStyle = function() {
    var t = this.graphModel.theme.resizeControl;
    return R(t);
  }, r.prototype.getResizeOutlineStyle = function() {
    var t = this.graphModel.theme.resizeOutline, e = ft({}, t);
    if (this.isHovered) {
      var o = t.hover || {};
      e = ft(ft({}, e), o);
    }
    return R(e);
  }, r.prototype.getAnchorStyle = function(t) {
    var e = this.graphModel.theme.anchor;
    return R(e);
  }, r.prototype.getAnchorLineStyle = function(t) {
    var e = this.graphModel.theme.anchorLine;
    return R(e);
  }, r.prototype.getOutlineStyle = function() {
    var t = this.graphModel.theme.outline;
    return R(t);
  }, r.prototype.isAllowConnectedAsSource = function(t, e, o, n) {
    var i = this.hasSetSourceRules ? this.sourceRules : this.getConnectedSourceRules();
    this.hasSetSourceRules = !0;
    for (var a = !0, s = "", l = 0; l < i.length; l++) {
      var u = i[l];
      if (!u.validate.call(this, this, t, e, o, n)) {
        a = !1, s = u.message;
        break;
      }
    }
    return {
      isAllPass: a,
      msg: s
    };
  }, r.prototype.getConnectedSourceRules = function() {
    return this.sourceRules;
  }, r.prototype.isAllowConnectedAsTarget = function(t, e, o, n) {
    var i = this.hasSetTargetRules ? this.targetRules : this.getConnectedTargetRules();
    this.hasSetTargetRules = !0;
    for (var a = !0, s = "", l = 0; l < i.length; l++) {
      var u = i[l];
      if (!u.validate.call(this, t, this, e, o, n)) {
        a = !1, s = u.message;
        break;
      }
    }
    return {
      isAllPass: a,
      msg: s
    };
  }, r.prototype.isAllowMoveNode = function(t, e) {
    var o, n, i = !0, a = !0, s = this.moveRules.concat(this.graphModel.nodeMoveRules);
    try {
      for (var l = Ms(s), u = l.next(); !u.done; u = l.next()) {
        var c = u.value, d = c(this, t, e);
        if (!d) return !1;
        if (typeof d == "object") {
          var f = d;
          if (!f.x && !f.y) return !1;
          i = i && f.x, a = a && f.y;
        }
      }
    } catch (p) {
      o = { error: p };
    } finally {
      try {
        u && !u.done && (n = l.return) && n.call(l);
      } finally {
        if (o) throw o.error;
      }
    }
    return {
      x: i,
      y: a
    };
  }, r.prototype.getConnectedTargetRules = function() {
    return this.targetRules;
  }, r.prototype.getAnchorsByOffset = function() {
    var t = this, e = t.anchorsOffset, o = t.id, n = t.x, i = t.y;
    return e && e.length > 0 ? e.map(function(a, s) {
      return a.length ? (a = a, {
        id: "".concat(o, "_").concat(s),
        x: n + a[0],
        y: i + a[1]
      }) : (a = a, ft(ft({}, a), {
        x: n + a.x,
        y: i + a.y,
        id: a.id || "".concat(o, "_").concat(s)
      }));
    }) : this.getDefaultAnchor();
  }, r.prototype.getDefaultAnchor = function() {
    return [];
  }, r.prototype.getTargetAnchor = function(t) {
    var e, o = this.graphModel.customTargetAnchor;
    return (e = o == null ? void 0 : o(this, t)) !== null && e !== void 0 ? e : bf(t, this);
  }, r.prototype.getBounds = function() {
    return {
      minX: this.x - this.width / 2,
      minY: this.y - this.height / 2,
      maxX: this.x + this.width / 2,
      maxY: this.y + this.height / 2
    };
  }, Object.defineProperty(r.prototype, "anchors", {
    get: function() {
      var t = this.getAnchorsByOffset(), e = this, o = e.x, n = e.y, i = e.rotate;
      return t.forEach(function(a) {
        var s = a.x, l = a.y, u = Ep(new vo([
          s,
          l,
          1
        ]).translate(-o, -n).rotate(i).translate(o, n)[0], 2), c = u[0], d = u[1];
        a.x = c, a.y = d;
      }), t;
    },
    enumerable: !1,
    configurable: !0
  }), r.prototype.getAnchorInfo = function(t) {
    if (!yt(t))
      for (var e = 0; e < this.anchors.length; e++) {
        var o = this.anchors[e];
        if (o.id === t) return o;
      }
  }, r.prototype.addNodeMoveRules = function(t) {
    this.moveRules.includes(t) || this.moveRules.push(t);
  }, r.prototype.isAllowMoveByXORY = function(t, e, o) {
    var n, i;
    if (o)
      n = !0, i = !0;
    else {
      var a = this.isAllowMoveNode(t, e);
      typeof a == "boolean" ? (n = a, i = a) : (n = a.x, i = a.y);
    }
    return {
      isAllowMoveX: n,
      isAllowMoveY: i
    };
  }, r.prototype.move = function(t, e, o) {
    o === void 0 && (o = !1);
    var n = this.isAllowMoveByXORY(t, e, o), i = n.isAllowMoveX, a = n.isAllowMoveY;
    return i && (this.x = this.x + t, this.text && this.moveText(t, 0)), a && (this.y = this.y + e, this.text && this.moveText(0, e)), (i || a) && (this.rotate = this._rotate), i || a;
  }, r.prototype.getMoveDistance = function(t, e, o) {
    o === void 0 && (o = !1);
    var n = this.isAllowMoveByXORY(t, e, o), i = n.isAllowMoveX, a = n.isAllowMoveY, s = 0, l = 0;
    return i && t && (this.x = this.x + t, this.text && this.moveText(t, 0), s = t), a && e && (this.y = this.y + e, this.text && this.moveText(0, e), l = e), this.transform = new nn(-this.x, -this.y).rotate(this.rotate).translate(this.x, this.y).toString(), [s, l];
  }, r.prototype.moveTo = function(t, e, o) {
    o === void 0 && (o = !1);
    var n = t - this.x, i = e - this.y;
    return !o && !this.isAllowMoveNode(n, i) ? !1 : (this.text && this.moveText(n, i), this.x = t, this.y = e, !0);
  }, r.prototype.moveText = function(t, e) {
    var o = this.text, n = o.x, i = o.y, a = o.value, s = o.draggable, l = o.editable;
    this.text = {
      value: a,
      editable: l,
      draggable: s,
      x: n + t,
      y: i + e
    };
  }, r.prototype.updateText = function(t) {
    this.text = ft(ft({}, ie(this.text)), { value: t });
  }, r.prototype.addNodeResizeRules = function(t) {
    this.resizeRules.includes(t) || this.resizeRules.push(t);
  }, r.prototype.isAllowResizeNode = function(t, e, o, n) {
    var i, a, s = this.resizeRules.concat(this.graphModel.nodeResizeRules);
    try {
      for (var l = Ms(s), u = l.next(); !u.done; u = l.next()) {
        var c = u.value;
        if (!c(this, t, e, o, n)) return !1;
      }
    } catch (d) {
      i = { error: d };
    } finally {
      try {
        u && !u.done && (a = l.return) && a.call(l);
      } finally {
        if (i) throw i.error;
      }
    }
    return !0;
  }, r.prototype.setSelected = function(t) {
    t === void 0 && (t = !0), this.isSelected = t;
  }, r.prototype.setHovered = function(t) {
    t === void 0 && (t = !0), this.isHovered = t, this.setIsShowAnchor(t);
  }, r.prototype.setIsShowAnchor = function(t) {
    t === void 0 && (t = !0), this.isShowAnchor = t;
  }, r.prototype.setRotatable = function(t) {
    t === void 0 && (t = !0), this.rotatable = t;
  }, r.prototype.setResizable = function(t) {
    t === void 0 && (t = !0), this.resizable = t;
  }, r.prototype.setHitable = function(t) {
    t === void 0 && (t = !0), this.isHitable = t;
  }, r.prototype.setHittable = function(t) {
    t === void 0 && (t = !0), this.isHittable = t;
  }, r.prototype.setElementState = function(t, e) {
    this.state = t, this.additionStateData = e;
  }, r.prototype.updateProperties = function(t, e) {
    var o = ie(this.properties);
    this.properties = t, this.setAttributes(), this.graphModel.eventCenter.emit(L.NODE_PROPERTIES_CHANGE, {
      id: this.id,
      keys: e,
      preProperties: o,
      properties: t
    });
  }, r.prototype.setProperty = function(t, e) {
    var o = ie(this.properties), n = R(o);
    Iu(n, t, Mt(e)), this.updateProperties(n, [t]);
  }, r.prototype.setProperties = function(t) {
    var e = ie(this.properties), o = ft(ft({}, e), Mt(t)), n = [];
    Lu(t, function(i, a) {
      (da(e, a) && e[a] !== i || !da(e, a)) && n.push(a);
    }), this.updateProperties(o, n);
  }, r.prototype.deleteProperty = function(t) {
    delete this.properties[t], this.setAttributes();
  }, r.prototype.setStyle = function(t, e) {
    var o;
    this.style = ft(ft({}, this.style), (o = {}, o[t] = Mt(e), o));
  }, r.prototype.setStyles = function(t) {
    this.style = ft(ft({}, this.style), Mt(t));
  }, r.prototype.updateStyles = function(t) {
    this.style = ft({}, Mt(t));
  }, r.prototype.setZIndex = function(t) {
    t === void 0 && (t = 1), this.zIndex = t;
  }, r.prototype.updateAttributes = function(t) {
    U(this, t);
  }, r.prototype.updateZIndexByOverlap = function(t, e) {
    switch (t) {
      case mt.DEFAULT:
        this.zIndex = 1;
        break;
      case mt.EDGE_TOP:
        this.zIndex = 0;
        break;
      case mt.INCREASE:
        this.zIndex = e;
    }
  }, r.BaseType = dt.NODE, I([A], r.prototype, "type", void 0), I([A], r.prototype, "x", void 0), I([A], r.prototype, "y", void 0), I([A], r.prototype, "textMode", void 0), I([A], r.prototype, "text", void 0), I([A], r.prototype, "properties", void 0), I([A], r.prototype, "_width", void 0), I([A], r.prototype, "_height", void 0), I([A], r.prototype, "anchorsOffset", void 0), I([A], r.prototype, "isSelected", void 0), I([A], r.prototype, "isHovered", void 0), I([A], r.prototype, "isShowAnchor", void 0), I([A], r.prototype, "isDragging", void 0), I([A], r.prototype, "isHitable", void 0), I([A], r.prototype, "isHittable", void 0), I([A], r.prototype, "draggable", void 0), I([A], r.prototype, "visible", void 0), I([A], r.prototype, "rotatable", void 0), I([A], r.prototype, "resizable", void 0), I([A], r.prototype, "zIndex", void 0), I([A], r.prototype, "state", void 0), I([A], r.prototype, "autoToFront", void 0), I([A], r.prototype, "style", void 0), I([A], r.prototype, "transform", void 0), I([A], r.prototype, "_rotate", void 0), I([ot], r.prototype, "incoming", null), I([ot], r.prototype, "outgoing", null), I([b], r.prototype, "setTextMode", null), I([b], r.prototype, "addNodeMoveRules", null), I([b], r.prototype, "move", null), I([b], r.prototype, "getMoveDistance", null), I([b], r.prototype, "moveTo", null), I([b], r.prototype, "moveText", null), I([b], r.prototype, "updateText", null), I([b], r.prototype, "addNodeResizeRules", null), I([b], r.prototype, "setSelected", null), I([b], r.prototype, "setHovered", null), I([b], r.prototype, "setIsShowAnchor", null), I([b], r.prototype, "setRotatable", null), I([b], r.prototype, "setResizable", null), I([b], r.prototype, "setHitable", null), I([b], r.prototype, "setHittable", null), I([b], r.prototype, "setElementState", null), I([b], r.prototype, "setProperty", null), I([b], r.prototype, "setProperties", null), I([b], r.prototype, "deleteProperty", null), I([b], r.prototype, "setStyle", null), I([b], r.prototype, "setStyles", null), I([b], r.prototype, "updateStyles", null), I([b], r.prototype, "setZIndex", null), I([b], r.prototype, "updateAttributes", null), I([b], r.prototype, "updateZIndexByOverlap", null), r;
})(), bp = /* @__PURE__ */ (function() {
  var r = function(t, e) {
    return r = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(o, n) {
      o.__proto__ = n;
    } || function(o, n) {
      for (var i in n) Object.prototype.hasOwnProperty.call(n, i) && (o[i] = n[i]);
    }, r(t, e);
  };
  return function(t, e) {
    if (typeof e != "function" && e !== null) throw new TypeError("Class extends value " + String(e) + " is not a constructor or null");
    r(t, e);
    function o() {
      this.constructor = t;
    }
    t.prototype = e === null ? Object.create(e) : (o.prototype = e.prototype, new o());
  };
})(), zr = function() {
  return zr = Object.assign || function(r) {
    for (var t, e = 1, o = arguments.length; e < o; e++) {
      t = arguments[e];
      for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && (r[n] = t[n]);
    }
    return r;
  }, zr.apply(this, arguments);
}, jn = function(r, t, e, o) {
  var n = arguments.length, i = n < 3 ? t : o === null ? o = Object.getOwnPropertyDescriptor(t, e) : o, a;
  if (typeof Reflect == "object" && typeof Reflect.decorate == "function") i = Reflect.decorate(r, t, e, o);
  else for (var s = r.length - 1; s >= 0; s--) (a = r[s]) && (i = (n < 3 ? a(i) : n > 3 ? a(t, e, i) : a(t, e)) || i);
  return n > 3 && i && Object.defineProperty(t, e, i), i;
}, Ps = (function(r) {
  bp(t, r);
  function t(e, o) {
    var n = r.call(this, e, o) || this;
    return n.modelType = G.CIRCLE_NODE, n.r = 50, n.initNodeData(e), n.setAttributes(), n;
  }
  return Object.defineProperty(t.prototype, "width", {
    get: function() {
      return this.r * 2;
    },
    enumerable: !1,
    configurable: !0
  }), Object.defineProperty(t.prototype, "height", {
    get: function() {
      return this.r * 2;
    },
    enumerable: !1,
    configurable: !0
  }), t.prototype.setAttributes = function() {
    r.prototype.setAttributes.call(this);
    var e = this.properties.r;
    e && (this.r = e);
  }, t.prototype.getNodeStyle = function() {
    var e = r.prototype.getNodeStyle.call(this), o = this.graphModel.theme.circle, n = this.properties.style, i = n === void 0 ? {} : n;
    return zr(zr(zr({}, e), R(o)), R(i));
  }, t.prototype.getDefaultAnchor = function() {
    var e = this, o = e.x, n = e.y, i = e.r;
    return [
      {
        x: o,
        y: n - i,
        id: "".concat(this.id, "_0")
      },
      {
        x: o + i,
        y: n,
        id: "".concat(this.id, "_1")
      },
      {
        x: o,
        y: n + i,
        id: "".concat(this.id, "_2")
      },
      {
        x: o - i,
        y: n,
        id: "".concat(this.id, "_3")
      }
    ];
  }, t.prototype.resize = function(e) {
    var o = e.width, n = e.deltaX, i = e.deltaY;
    return this.move(n / 2, i / 2), this.r = o, this.setProperties({ r: o }), this.getData();
  }, jn([A], t.prototype, "r", void 0), jn([ot], t.prototype, "width", null), jn([ot], t.prototype, "height", null), t;
})(Ce), Op = /* @__PURE__ */ (function() {
  var r = function(t, e) {
    return r = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(o, n) {
      o.__proto__ = n;
    } || function(o, n) {
      for (var i in n) Object.prototype.hasOwnProperty.call(n, i) && (o[i] = n[i]);
    }, r(t, e);
  };
  return function(t, e) {
    if (typeof e != "function" && e !== null) throw new TypeError("Class extends value " + String(e) + " is not a constructor or null");
    r(t, e);
    function o() {
      this.constructor = t;
    }
    t.prototype = e === null ? Object.create(e) : (o.prototype = e.prototype, new o());
  };
})(), $r = function() {
  return $r = Object.assign || function(r) {
    for (var t, e = 1, o = arguments.length; e < o; e++) {
      t = arguments[e];
      for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && (r[n] = t[n]);
    }
    return r;
  }, $r.apply(this, arguments);
}, Je = function(r, t, e, o) {
  var n = arguments.length, i = n < 3 ? t : o === null ? o = Object.getOwnPropertyDescriptor(t, e) : o, a;
  if (typeof Reflect == "object" && typeof Reflect.decorate == "function") i = Reflect.decorate(r, t, e, o);
  else for (var s = r.length - 1; s >= 0; s--) (a = r[s]) && (i = (n < 3 ? a(i) : n > 3 ? a(t, e, i) : a(t, e)) || i);
  return n > 3 && i && Object.defineProperty(t, e, i), i;
}, Mo = function(r, t) {
  var e = typeof Symbol == "function" && r[Symbol.iterator];
  if (!e) return r;
  var o = e.call(r), n, i = [], a;
  try {
    for (; (t === void 0 || t-- > 0) && !(n = o.next()).done; ) i.push(n.value);
  } catch (s) {
    a = { error: s };
  } finally {
    try {
      n && !n.done && (e = o.return) && e.call(o);
    } finally {
      if (a) throw a.error;
    }
  }
  return i;
}, Ts = (function(r) {
  Op(t, r);
  function t(e, o) {
    var n = r.call(this, e, o) || this;
    return n.modelType = G.DIAMOND_NODE, n.rx = 30, n.ry = 50, n.initNodeData(e), n.setAttributes(), n;
  }
  return t.prototype.setAttributes = function() {
    r.prototype.setAttributes.call(this);
    var e = this.properties, o = e.rx, n = e.ry;
    o && (this.rx = o), n && (this.ry = n);
  }, t.prototype.getNodeStyle = function() {
    var e = r.prototype.getNodeStyle.call(this), o = this.graphModel.theme.diamond, n = this.properties.style, i = n === void 0 ? {} : n;
    return $r($r($r({}, e), R(o)), R(i));
  }, Object.defineProperty(t.prototype, "points", {
    get: function() {
      var e = this, o = e.x, n = e.y, i = e.rx, a = e.ry;
      return [
        [o, n - a],
        [o + i, n],
        [o, n + a],
        [o - i, n]
      ];
    },
    enumerable: !1,
    configurable: !0
  }), Object.defineProperty(t.prototype, "pointsPosition", {
    get: function() {
      return ce(this.points, function(e) {
        var o = Mo(e, 2);
        return {
          x: o[0],
          y: o[1]
        };
      });
    },
    enumerable: !1,
    configurable: !0
  }), Object.defineProperty(t.prototype, "width", {
    get: function() {
      var e = Number.MAX_SAFE_INTEGER, o = Number.MIN_SAFE_INTEGER;
      return pt(this.points, function(n) {
        var i = Mo(n, 1)[0];
        i < e && (e = i), i > o && (o = i);
      }), o - e;
    },
    enumerable: !1,
    configurable: !0
  }), Object.defineProperty(t.prototype, "height", {
    get: function() {
      var e = Number.MAX_SAFE_INTEGER, o = Number.MIN_SAFE_INTEGER;
      return pt(this.points, function(n) {
        var i = Mo(n, 2)[1];
        i < e && (e = i), i > o && (o = i);
      }), o - e;
    },
    enumerable: !1,
    configurable: !0
  }), t.prototype.getDefaultAnchor = function() {
    var e = this;
    return ce(this.points, function(o, n) {
      var i = Mo(o, 2);
      return {
        x: i[0],
        y: i[1],
        id: "".concat(e.id, "_").concat(n)
      };
    });
  }, t.prototype.resize = function(e) {
    var o = e.width, n = e.height, i = e.deltaX, a = e.deltaY;
    return this.move(i / 2, a / 2), this.rx = o, this.ry = n, this.setProperties({
      rx: o,
      ry: n
    }), this.getData();
  }, Je([A], t.prototype, "rx", void 0), Je([A], t.prototype, "ry", void 0), Je([ot], t.prototype, "points", null), Je([ot], t.prototype, "pointsPosition", null), Je([ot], t.prototype, "width", null), Je([ot], t.prototype, "height", null), t;
})(Ce), wp = /* @__PURE__ */ (function() {
  var r = function(t, e) {
    return r = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(o, n) {
      o.__proto__ = n;
    } || function(o, n) {
      for (var i in n) Object.prototype.hasOwnProperty.call(n, i) && (o[i] = n[i]);
    }, r(t, e);
  };
  return function(t, e) {
    if (typeof e != "function" && e !== null) throw new TypeError("Class extends value " + String(e) + " is not a constructor or null");
    r(t, e);
    function o() {
      this.constructor = t;
    }
    t.prototype = e === null ? Object.create(e) : (o.prototype = e.prototype, new o());
  };
})(), Ur = function() {
  return Ur = Object.assign || function(r) {
    for (var t, e = 1, o = arguments.length; e < o; e++) {
      t = arguments[e];
      for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && (r[n] = t[n]);
    }
    return r;
  }, Ur.apply(this, arguments);
}, Po = function(r, t, e, o) {
  var n = arguments.length, i = n < 3 ? t : o === null ? o = Object.getOwnPropertyDescriptor(t, e) : o, a;
  if (typeof Reflect == "object" && typeof Reflect.decorate == "function") i = Reflect.decorate(r, t, e, o);
  else for (var s = r.length - 1; s >= 0; s--) (a = r[s]) && (i = (n < 3 ? a(i) : n > 3 ? a(t, e, i) : a(t, e)) || i);
  return n > 3 && i && Object.defineProperty(t, e, i), i;
}, Ns = (function(r) {
  wp(t, r);
  function t(e, o) {
    var n = r.call(this, e, o) || this;
    return n.modelType = G.ELLIPSE_NODE, n.rx = 30, n.ry = 45, n.initNodeData(e), n.setAttributes(), n;
  }
  return t.prototype.setAttributes = function() {
    r.prototype.setAttributes.call(this);
    var e = this.properties, o = e.rx, n = e.ry;
    o && (this.rx = o), n && (this.ry = n);
  }, t.prototype.getNodeStyle = function() {
    var e = r.prototype.getNodeStyle.call(this), o = this.graphModel.theme.ellipse, n = this.properties.style, i = n === void 0 ? {} : n;
    return Ur(Ur(Ur({}, e), R(o)), R(i));
  }, Object.defineProperty(t.prototype, "width", {
    get: function() {
      return this.rx * 2;
    },
    enumerable: !1,
    configurable: !0
  }), Object.defineProperty(t.prototype, "height", {
    get: function() {
      return this.ry * 2;
    },
    enumerable: !1,
    configurable: !0
  }), t.prototype.getDefaultAnchor = function() {
    var e = this, o = e.x, n = e.y, i = e.rx, a = e.ry;
    return [
      {
        x: o,
        y: n - a,
        id: "".concat(this.id, "_0")
      },
      {
        x: o + i,
        y: n,
        id: "".concat(this.id, "_1")
      },
      {
        x: o,
        y: n + a,
        id: "".concat(this.id, "_2")
      },
      {
        x: o - i,
        y: n,
        id: "".concat(this.id, "_3")
      }
    ];
  }, t.prototype.resize = function(e) {
    var o = e.width, n = e.height, i = e.deltaX, a = e.deltaY;
    return this.move(i / 2, a / 2), this.rx = o, this.ry = n, this.setProperties({
      rx: o,
      ry: n
    }), this.getData();
  }, Po([A], t.prototype, "rx", void 0), Po([A], t.prototype, "ry", void 0), Po([ot], t.prototype, "width", null), Po([ot], t.prototype, "height", null), t;
})(Ce), Sp = /* @__PURE__ */ (function() {
  var r = function(t, e) {
    return r = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(o, n) {
      o.__proto__ = n;
    } || function(o, n) {
      for (var i in n) Object.prototype.hasOwnProperty.call(n, i) && (o[i] = n[i]);
    }, r(t, e);
  };
  return function(t, e) {
    if (typeof e != "function" && e !== null) throw new TypeError("Class extends value " + String(e) + " is not a constructor or null");
    r(t, e);
    function o() {
      this.constructor = t;
    }
    t.prototype = e === null ? Object.create(e) : (o.prototype = e.prototype, new o());
  };
})(), ir = function() {
  return ir = Object.assign || function(r) {
    for (var t, e = 1, o = arguments.length; e < o; e++) {
      t = arguments[e];
      for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && (r[n] = t[n]);
    }
    return r;
  }, ir.apply(this, arguments);
}, To = function(r, t, e, o) {
  var n = arguments.length, i = n < 3 ? t : o === null ? o = Object.getOwnPropertyDescriptor(t, e) : o, a;
  if (typeof Reflect == "object" && typeof Reflect.decorate == "function") i = Reflect.decorate(r, t, e, o);
  else for (var s = r.length - 1; s >= 0; s--) (a = r[s]) && (i = (n < 3 ? a(i) : n > 3 ? a(t, e, i) : a(t, e)) || i);
  return n > 3 && i && Object.defineProperty(t, e, i), i;
}, No = function(r, t) {
  var e = typeof Symbol == "function" && r[Symbol.iterator];
  if (!e) return r;
  var o = e.call(r), n, i = [], a;
  try {
    for (; (t === void 0 || t-- > 0) && !(n = o.next()).done; ) i.push(n.value);
  } catch (s) {
    a = { error: s };
  } finally {
    try {
      n && !n.done && (e = o.return) && e.call(o);
    } finally {
      if (a) throw a.error;
    }
  }
  return i;
}, Ds = (function(r) {
  Sp(t, r);
  function t(e, o) {
    var n = r.call(this, e, o) || this;
    return n.modelType = G.POLYGON_NODE, n.points = [
      [50, 0],
      [100, 50],
      [50, 100],
      [0, 50]
    ], n.initNodeData(e), n.setAttributes(), n;
  }
  return t.prototype.setAttributes = function() {
    r.prototype.setAttributes.call(this);
    var e = this.properties, o = e.points, n = e.width, i = e.height, a = o || this.points;
    this.points = gf(a, n, i);
  }, t.prototype.getNodeStyle = function() {
    var e = r.prototype.getNodeStyle.call(this), o = this.graphModel, n = o.theme.polygon, i = o.customStyles.polygon, a = this.properties.style, s = a === void 0 ? {} : a;
    return ir(ir(ir(ir({}, e), R(n)), R(i)), R(s));
  }, Object.defineProperty(t.prototype, "pointsPosition", {
    get: function() {
      var e = this, o = e.x, n = e.y, i = e.width, a = e.height;
      return this.points.map(function(s) {
        return {
          x: s[0] + o - i / 2,
          y: s[1] + n - a / 2
        };
      });
    },
    enumerable: !1,
    configurable: !0
  }), Object.defineProperty(t.prototype, "width", {
    get: function() {
      var e = Number.MAX_SAFE_INTEGER, o = Number.MIN_SAFE_INTEGER;
      return this.points.forEach(function(n) {
        var i = No(n, 1)[0];
        i < e && (e = i), i > o && (o = i);
      }), o - e;
    },
    enumerable: !1,
    configurable: !0
  }), Object.defineProperty(t.prototype, "height", {
    get: function() {
      var e = Number.MAX_SAFE_INTEGER, o = Number.MIN_SAFE_INTEGER;
      return this.points.forEach(function(n) {
        var i = No(n, 2)[1];
        i < e && (e = i), i > o && (o = i);
      }), o - e;
    },
    enumerable: !1,
    configurable: !0
  }), t.prototype.getDefaultAnchor = function() {
    var e = this, o = this, n = o.x, i = o.y, a = o.width, s = o.height;
    return o.points.map(function(l, u) {
      var c = No(l, 2), d = c[0], f = c[1];
      return {
        x: n + d - a / 2,
        y: i + f - s / 2,
        id: "".concat(e.id, "_").concat(u)
      };
    });
  }, t.prototype.resize = function(e) {
    var o = this, n = e.width, i = e.height, a = e.deltaX, s = e.deltaY;
    this.move(a / 2, s / 2);
    var l = ce(this.points, function(u) {
      var c = No(u, 2), d = c[0], f = c[1];
      return [d * n / o.width, f * i / o.height];
    });
    return this.points = l, this.properties.points = l, this.getData();
  }, To([A], t.prototype, "points", void 0), To([ot], t.prototype, "pointsPosition", null), To([ot], t.prototype, "width", null), To([ot], t.prototype, "height", null), t;
})(Ce), Ap = /* @__PURE__ */ (function() {
  var r = function(t, e) {
    return r = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(o, n) {
      o.__proto__ = n;
    } || function(o, n) {
      for (var i in n) Object.prototype.hasOwnProperty.call(n, i) && (o[i] = n[i]);
    }, r(t, e);
  };
  return function(t, e) {
    if (typeof e != "function" && e !== null) throw new TypeError("Class extends value " + String(e) + " is not a constructor or null");
    r(t, e);
    function o() {
      this.constructor = t;
    }
    t.prototype = e === null ? Object.create(e) : (o.prototype = e.prototype, new o());
  };
})(), Vr = function() {
  return Vr = Object.assign || function(r) {
    for (var t, e = 1, o = arguments.length; e < o; e++) {
      t = arguments[e];
      for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && (r[n] = t[n]);
    }
    return r;
  }, Vr.apply(this, arguments);
}, Mp = function(r, t, e, o) {
  var n = arguments.length, i = n < 3 ? t : o === null ? o = Object.getOwnPropertyDescriptor(t, e) : o, a;
  if (typeof Reflect == "object" && typeof Reflect.decorate == "function") i = Reflect.decorate(r, t, e, o);
  else for (var s = r.length - 1; s >= 0; s--) (a = r[s]) && (i = (n < 3 ? a(i) : n > 3 ? a(t, e, i) : a(t, e)) || i);
  return n > 3 && i && Object.defineProperty(t, e, i), i;
}, Cs = (function(r) {
  Ap(t, r);
  function t(e, o) {
    var n = r.call(this, e, o) || this;
    return n.modelType = G.RECT_NODE, n.radius = 0, n.initNodeData(e), n.setAttributes(), n;
  }
  return t.prototype.setAttributes = function() {
    r.prototype.setAttributes.call(this);
    var e = this.properties, o = e.width, n = e.height, i = e.radius, a = this.getNodeStyle().radius;
    yt(o) || (this.width = o), yt(n) || (this.height = n), yt(i) || (this.radius = i), yt(a) || (this.radius = a);
  }, t.prototype.getDefaultAnchor = function() {
    var e = this, o = e.x, n = e.y, i = e.width, a = e.height;
    return [
      {
        x: o,
        y: n - a / 2,
        id: "".concat(this.id, "_0")
      },
      {
        x: o + i / 2,
        y: n,
        id: "".concat(this.id, "_1")
      },
      {
        x: o,
        y: n + a / 2,
        id: "".concat(this.id, "_2")
      },
      {
        x: o - i / 2,
        y: n,
        id: "".concat(this.id, "_3")
      }
    ];
  }, t.prototype.getNodeStyle = function() {
    var e = r.prototype.getNodeStyle.call(this), o = this.graphModel.theme.rect, n = this.properties.style, i = n === void 0 ? {} : n;
    return Vr(Vr(Vr({}, e), R(o)), R(i));
  }, Mp([A], t.prototype, "radius", void 0), t;
})(Ce), Pp = /* @__PURE__ */ (function() {
  var r = function(t, e) {
    return r = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(o, n) {
      o.__proto__ = n;
    } || function(o, n) {
      for (var i in n) Object.prototype.hasOwnProperty.call(n, i) && (o[i] = n[i]);
    }, r(t, e);
  };
  return function(t, e) {
    if (typeof e != "function" && e !== null) throw new TypeError("Class extends value " + String(e) + " is not a constructor or null");
    r(t, e);
    function o() {
      this.constructor = t;
    }
    t.prototype = e === null ? Object.create(e) : (o.prototype = e.prototype, new o());
  };
})(), Fr = function() {
  return Fr = Object.assign || function(r) {
    for (var t, e = 1, o = arguments.length; e < o; e++) {
      t = arguments[e];
      for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && (r[n] = t[n]);
    }
    return r;
  }, Fr.apply(this, arguments);
}, Ls = function(r, t, e, o) {
  var n = arguments.length, i = n < 3 ? t : o === null ? o = Object.getOwnPropertyDescriptor(t, e) : o, a;
  if (typeof Reflect == "object" && typeof Reflect.decorate == "function") i = Reflect.decorate(r, t, e, o);
  else for (var s = r.length - 1; s >= 0; s--) (a = r[s]) && (i = (n < 3 ? a(i) : n > 3 ? a(t, e, i) : a(t, e)) || i);
  return n > 3 && i && Object.defineProperty(t, e, i), i;
}, Tp = function(r, t) {
  var e = typeof Symbol == "function" && r[Symbol.iterator];
  if (!e) return r;
  var o = e.call(r), n, i = [], a;
  try {
    for (; (t === void 0 || t-- > 0) && !(n = o.next()).done; ) i.push(n.value);
  } catch (s) {
    a = { error: s };
  } finally {
    try {
      n && !n.done && (e = o.return) && e.call(o);
    } finally {
      if (a) throw a.error;
    }
  }
  return i;
}, Np = function(r, t, e) {
  if (e || arguments.length === 2)
    for (var o = 0, n = t.length, i; o < n; o++) (i || !(o in t)) && (i || (i = Array.prototype.slice.call(t, 0, o)), i[o] = t[o]);
  return r.concat(i || Array.prototype.slice.call(t));
}, js = (function(r) {
  Pp(t, r);
  function t() {
    var e = r.apply(this, Np([], Tp(arguments), !1)) || this;
    return e.modelType = G.TEXT_NODE, e;
  }
  return t.prototype.getTextStyle = function() {
    var e = r.prototype.getTextStyle.call(this), o = this.graphModel.theme.text, n = this.properties.textStyle;
    return Fr(Fr(Fr({}, e), R(o)), R(n));
  }, Object.defineProperty(t.prototype, "width", {
    get: function() {
      var e = String(this.text.value).split(/[\r\n]/g), o = this.getTextStyle().fontSize;
      return xs({
        rows: e,
        fontSize: o,
        rowsLength: e.length
      }).width;
    },
    enumerable: !1,
    configurable: !0
  }), Object.defineProperty(t.prototype, "height", {
    get: function() {
      var e = String(this.text.value).split(/[\r\n]/g), o = this.getTextStyle().fontSize;
      return xs({
        rows: e,
        fontSize: o,
        rowsLength: e.length
      }).height;
    },
    enumerable: !1,
    configurable: !0
  }), Ls([ot], t.prototype, "width", null), Ls([ot], t.prototype, "height", null), t;
})(Ce), Dp = /* @__PURE__ */ (function() {
  var r = function(t, e) {
    return r = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(o, n) {
      o.__proto__ = n;
    } || function(o, n) {
      for (var i in n) Object.prototype.hasOwnProperty.call(n, i) && (o[i] = n[i]);
    }, r(t, e);
  };
  return function(t, e) {
    if (typeof e != "function" && e !== null) throw new TypeError("Class extends value " + String(e) + " is not a constructor or null");
    r(t, e);
    function o() {
      this.constructor = t;
    }
    t.prototype = e === null ? Object.create(e) : (o.prototype = e.prototype, new o());
  };
})(), ar = function() {
  return ar = Object.assign || function(r) {
    for (var t, e = 1, o = arguments.length; e < o; e++) {
      t = arguments[e];
      for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && (r[n] = t[n]);
    }
    return r;
  }, ar.apply(this, arguments);
}, gi = (function(r) {
  Dp(t, r);
  function t(e, o) {
    var n = r.call(this, e, o) || this;
    return n.modelType = G.HTML_NODE, n.setAttributes(), n;
  }
  return t.prototype.setAttributes = function() {
    r.prototype.setAttributes.call(this);
    var e = this.properties, o = e.width, n = e.height;
    o && (this.width = o), n && (this.height = n);
  }, t.prototype.getDefaultAnchor = function() {
    var e = this, o = e.x, n = e.y, i = e.width, a = e.height;
    return [
      {
        x: o,
        y: n - a / 2,
        id: "".concat(this.id, "_0")
      },
      {
        x: o + i / 2,
        y: n,
        id: "".concat(this.id, "_1")
      },
      {
        x: o,
        y: n + a / 2,
        id: "".concat(this.id, "_2")
      },
      {
        x: o - i / 2,
        y: n,
        id: "".concat(this.id, "_3")
      }
    ];
  }, t.prototype.getNodeStyle = function() {
    var e = r.prototype.getNodeStyle.call(this), o = this.graphModel.theme, n = o.baseNode, i = o.html, a = this.properties.style, s = a === void 0 ? {} : a;
    return ar(ar(ar(ar({}, e), R(n)), R(i)), R(s));
  }, t;
})(Ce), W = function(r, t, e, o) {
  var n = arguments.length, i = n < 3 ? t : o === null ? o = Object.getOwnPropertyDescriptor(t, e) : o, a;
  if (typeof Reflect == "object" && typeof Reflect.decorate == "function") i = Reflect.decorate(r, t, e, o);
  else for (var s = r.length - 1; s >= 0; s--) (a = r[s]) && (i = (n < 3 ? a(i) : n > 3 ? a(t, e, i) : a(t, e)) || i);
  return n > 3 && i && Object.defineProperty(t, e, i), i;
}, Cp = {
  stopZoomGraph: !1,
  stopScrollGraph: !1,
  stopMoveGraph: !1,
  adjustEdge: !1,
  adjustEdgeStartAndEnd: !1,
  adjustNodePosition: !1,
  hideAnchors: !0,
  allowRotate: !1,
  allowResize: !1,
  nodeSelectedOutline: !0,
  textEdit: !1,
  nodeTextEdit: !1,
  edgeTextEdit: !1,
  textDraggable: !1,
  nodeTextDraggable: !1,
  edgeTextDraggable: !1
}, Do = [
  "isSilentMode",
  "stopZoomGraph",
  "stopScrollGraph",
  "stopMoveGraph",
  "snapGrid",
  "adjustEdge",
  "adjustEdgeMiddle",
  "adjustEdgeStartAndEnd",
  "adjustEdgeStart",
  "adjustEdgeEnd",
  "adjustNodePosition",
  "hideAnchors",
  "allowRotate",
  "allowResize",
  "autoExpand",
  "hoverOutline",
  "nodeSelectedOutline",
  "edgeSelectedOutline",
  "textEdit",
  "nodeTextEdit",
  "edgeTextEdit",
  "textDraggable",
  "nodeTextDraggable",
  "edgeTextDraggable",
  "multipleSelectKey",
  "textMode",
  "nodeTextMode",
  "edgeTextMode",
  "nodeTextMultiple",
  "edgeTextMultiple",
  "nodeTextVertical",
  "edgeTextVertical",
  "isPinching"
], Lp = (function() {
  function r(t) {
    this.isSilentMode = !1, this.stopZoomGraph = !1, this.stopMoveGraph = !1, this.stopScrollGraph = !1, this.snapGrid = !1, this.isPinching = !1, this.textMode = Xt.TEXT, this.textEdit = !0, this.textDraggable = !1, this.nodeTextEdit = !0, this.nodeTextDraggable = !1, this.nodeTextMultiple = !1, this.nodeTextVertical = !1, this.nodeTextMode = Xt.TEXT, this.edgeTextMode = Xt.TEXT, this.edgeTextEdit = !0, this.edgeTextDraggable = !1, this.edgeTextMultiple = !1, this.edgeTextVertical = !1, this.hideAnchors = !1, this.allowRotate = !1, this.allowResize = !1, this.hoverOutline = !0, this.nodeSelectedOutline = !0, this.adjustNodePosition = !0, this.autoExpand = !1, this.adjustEdge = !0, this.adjustEdgeMiddle = !1, this.adjustEdgeStartAndEnd = !1, this.adjustEdgeStart = !1, this.adjustEdgeEnd = !1, this.edgeSelectedOutline = !0, this.multipleSelectKey = "", U(this, this.computeConfig(t));
  }
  return r.prototype.updateEditConfig = function(t) {
    var e = this.computeConfig(t);
    U(this, e);
  }, r.prototype.computeConfig = function(t) {
    var e = t.isSilentMode, o = t.textDraggable, n = t.textMode, i = t.textEdit, a = t.adjustEdgeStartAndEnd, s = {};
    if (e === !1 && U(s, this.stagedConfig), e === !0 && e !== this.isSilentMode) {
      var l = rr(Cp, Do);
      this.stagedConfig = rr(this, Do), U(s, l);
    }
    cr(i) || U(s, {
      nodeTextEdit: i,
      edgeTextEdit: i
    }), cr(o) || U(s, {
      nodeTextDraggable: o,
      edgeTextDraggable: o
    }), n && U(s, {
      nodeTextMode: n,
      edgeTextMode: n
    }), $n(a) && U(s, {
      adjustEdgeStart: a,
      adjustEdgeEnd: a
    });
    var u = rr(t, Do);
    return U(s, u);
  }, r.prototype.updateTextMode = function(t) {
    this.textMode = t, this.edgeTextMode = t, this.nodeTextMode = t;
  }, r.prototype.getConfig = function() {
    return rr(this, Do);
  }, W([A], r.prototype, "isSilentMode", void 0), W([A], r.prototype, "stopZoomGraph", void 0), W([A], r.prototype, "stopMoveGraph", void 0), W([A], r.prototype, "stopScrollGraph", void 0), W([A], r.prototype, "snapGrid", void 0), W([A], r.prototype, "isPinching", void 0), W([A], r.prototype, "textMode", void 0), W([A], r.prototype, "textEdit", void 0), W([A], r.prototype, "textDraggable", void 0), W([A], r.prototype, "nodeTextEdit", void 0), W([A], r.prototype, "nodeTextDraggable", void 0), W([A], r.prototype, "nodeTextMultiple", void 0), W([A], r.prototype, "nodeTextVertical", void 0), W([A], r.prototype, "nodeTextMode", void 0), W([A], r.prototype, "edgeTextMode", void 0), W([A], r.prototype, "edgeTextEdit", void 0), W([A], r.prototype, "edgeTextDraggable", void 0), W([A], r.prototype, "edgeTextMultiple", void 0), W([A], r.prototype, "edgeTextVertical", void 0), W([A], r.prototype, "hideAnchors", void 0), W([A], r.prototype, "allowRotate", void 0), W([A], r.prototype, "allowResize", void 0), W([A], r.prototype, "hoverOutline", void 0), W([A], r.prototype, "nodeSelectedOutline", void 0), W([A], r.prototype, "adjustNodePosition", void 0), W([A], r.prototype, "autoExpand", void 0), W([A], r.prototype, "adjustEdge", void 0), W([A], r.prototype, "adjustEdgeMiddle", void 0), W([A], r.prototype, "adjustEdgeStartAndEnd", void 0), W([A], r.prototype, "adjustEdgeStart", void 0), W([A], r.prototype, "adjustEdgeEnd", void 0), W([A], r.prototype, "edgeSelectedOutline", void 0), W([b], r.prototype, "updateEditConfig", null), W([b], r.prototype, "updateTextMode", null), r;
})(), jp = "*", Rp = (function() {
  function r() {
    this._events = {};
  }
  return r.prototype.on = function(t, e, o) {
    var n = this;
    t == null || t.split(",").forEach(function(i) {
      i = i.trim(), n._events[i] || (n._events[i] = []), n._events[i].push({
        callback: e,
        once: !!o
      });
    });
  }, r.prototype.once = function(t, e) {
    var o = this;
    t == null || t.split(",").forEach(function(n) {
      n = n.trim(), o.on(n, e, !0);
    });
  }, r.prototype.emit = function(t, e) {
    var o = this;
    t == null || t.split(",").forEach(function(n) {
      var i = o._events[n] || [], a = o._events[jp] || [], s = function(l) {
        for (var u = l.length, c = 0; c < u; c++)
          if (l[c]) {
            var d = l[c], f = d.callback;
            d.once && (l.splice(c, 1), l.length === 0 && delete o._events[n], u--, c--), f.apply(o, [e]);
          }
      };
      s(i), s(a);
    });
  }, r.prototype.off = function(t, e) {
    var o = this;
    t || (this._events = {}), t.split(",").forEach(function(n) {
      if (!e) delete o._events[n];
      else {
        for (var i = o._events[n] || [], a = i.length, s = 0; s < a; s++) i[s].callback === e && (i.splice(s, 1), a--, s--);
        i.length === 0 && delete o._events[n];
      }
    });
  }, r.prototype.getEvents = function() {
    return this._events;
  }, r.prototype.destroy = function() {
    this._events = {};
  }, r;
})(), Ip = /* @__PURE__ */ (function() {
  var r = function(t, e) {
    return r = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(o, n) {
      o.__proto__ = n;
    } || function(o, n) {
      for (var i in n) Object.prototype.hasOwnProperty.call(n, i) && (o[i] = n[i]);
    }, r(t, e);
  };
  return function(t, e) {
    if (typeof e != "function" && e !== null) throw new TypeError("Class extends value " + String(e) + " is not a constructor or null");
    r(t, e);
    function o() {
      this.constructor = t;
    }
    t.prototype = e === null ? Object.create(e) : (o.prototype = e.prototype, new o());
  };
})(), kp = function(r, t, e, o) {
  var n = arguments.length, i = n < 3 ? t : o === null ? o = Object.getOwnPropertyDescriptor(t, e) : o, a;
  if (typeof Reflect == "object" && typeof Reflect.decorate == "function") i = Reflect.decorate(r, t, e, o);
  else for (var s = r.length - 1; s >= 0; s--) (a = r[s]) && (i = (n < 3 ? a(i) : n > 3 ? a(t, e, i) : a(t, e)) || i);
  return n > 3 && i && Object.defineProperty(t, e, i), i;
}, Bp = (function(r) {
  Ip(t, r);
  function t(e) {
    var o = r.call(this) || this;
    o.stepScrollX = 0, o.stepScrollY = 0, o.pointers = /* @__PURE__ */ new Map(), o.onDragging = function(s) {
      var l = s.deltaX, u = s.deltaY;
      o.longPressTimer && (clearTimeout(o.longPressTimer), o.longPressTimer = void 0), o.setState({ isDragging: !0 });
      var c = o.props.graphModel, d = c.transformModel;
      c.editConfigModel.stopMoveGraph !== !0 && d.translate(l, u);
    }, o.onDragEnd = function() {
      o.setState({ isDragging: !1 });
    }, o.zoomHandler = function(s) {
      var l = o.props, u = l.graphModel, c = u.editConfigModel, d = u.transformModel, f = u.gridSize, p = l.graphModel, v = s.deltaX, h = s.deltaY, g = c.stopScrollGraph, y = c.stopZoomGraph;
      if (!g && !s.ctrlKey && !s.metaKey) {
        if (s.preventDefault(), o.stepScrollX += v, o.stepScrollY += h, Math.abs(o.stepScrollX) >= f) {
          var _ = o.stepScrollX % f, E = o.stepScrollX - _;
          d.translate(-E * d.SCALE_X, 0), o.stepScrollX = _;
        }
        if (Math.abs(o.stepScrollY) >= f) {
          var x = o.stepScrollY % f, O = o.stepScrollY - x;
          d.translate(0, -O * d.SCALE_Y), o.stepScrollY = x;
        }
        return;
      }
      if (!y) {
        s.preventDefault();
        var M = p.getPointByClient({
          x: s.clientX,
          y: s.clientY
        }).canvasOverlayPosition, P = M.x, m = M.y;
        d.zoom(s.deltaY < 0, [P, m]);
      }
    }, o.clickHandler = function(s) {
      if (s.target.getAttribute("name") === "canvas-overlay") {
        var l = o.props.graphModel;
        if (l.selectElements.size > 0 && l.clearSelectElements(), o.state.isDragging) return;
        l.eventCenter.emit(L.BLANK_CLICK, { e: s });
      }
    }, o.handleContextMenu = function(s) {
      if (s.target.getAttribute("name") === "canvas-overlay") {
        s.preventDefault();
        var l = o.props.graphModel, u = l.getPointByClient({
          x: s.clientX,
          y: s.clientY
        });
        l.eventCenter.emit(L.BLANK_CONTEXTMENU, {
          e: s,
          position: u
        });
      }
    }, o.pointerDownHandler = function(s) {
      var l = o.props.graphModel, u = l.eventCenter, c = l.editConfigModel, d = l.transformModel.SCALE_X, f = l.gridSize;
      if (o.pointers.set(s.pointerId, {
        x: s.clientX,
        y: s.clientY
      }), o.longPressTimer && clearTimeout(o.longPressTimer), s.pointerType === "touch" && (o.longPressTimer = window.setTimeout(function() {
        o.handleContextMenu(s);
      }, 500)), o.pointers.size === 2) {
        var p = o.props.graphModel, v = p.transformModel, h = p.editConfigModel, g = Array.from(o.pointers.values()), y = g[0].x - g[1].x, _ = g[0].y - g[1].y, E = (g[0].x + g[1].x) / 2, x = (g[0].y + g[1].y) / 2;
        o.pinchStartDistance = Math.hypot(y, _), o.pinchStartScale = v.SCALE_X, o.stepDrag.cancelDrag(), o.pinchLastCenterX = E, o.pinchLastCenterY = x, h.updateEditConfig({ isPinching: !0 });
        return;
      }
      var O = c.adjustEdge, M = c.adjustNodePosition, P = c.stopMoveGraph, m = s.target, w = !O && !M;
      (m.getAttribute("name") === "canvas-overlay" || w) && (P !== !0 ? (o.stepDrag.setStep(f * d), o.stepDrag.handleMouseDown(s)) : u.emit(L.BLANK_MOUSEDOWN, { e: s }));
    }, o.pointerMoveHandler = function(s) {
      var l;
      if (o.pointers.set(s.pointerId, {
        x: s.clientX,
        y: s.clientY
      }), o.pinchStartDistance && o.pointers.size >= 2) {
        var u = o.props, c = u.graphModel, d = u.graphModel, f = d.editConfigModel, p = d.transformModel;
        if (f.stopZoomGraph) return;
        o.longPressTimer && clearTimeout(o.longPressTimer);
        var v = Array.from(o.pointers.values()), h = v[0].x - v[1].x, g = v[0].y - v[1].y, y = Math.hypot(h, g), _ = ((l = o.pinchStartScale) !== null && l !== void 0 ? l : p.SCALE_X) * (y / o.pinchStartDistance), E = (v[0].x + v[1].x) / 2, x = (v[0].y + v[1].y) / 2, O = c.getPointByClient({
          x: E,
          y: x
        }).canvasOverlayPosition, M = O.x, P = O.y;
        if (p.zoom(_, [M, P]), !f.stopMoveGraph || f.isPinching) {
          var m = o.pinchLastCenterX === void 0 ? 0 : E - o.pinchLastCenterX, w = o.pinchLastCenterY === void 0 ? 0 : x - o.pinchLastCenterY;
          p.translate(m, w), o.pinchLastCenterX = E, o.pinchLastCenterY = x;
        }
        s.preventDefault();
      }
    }, o.pointerUpHandler = function(s) {
      o.pointers.delete(s.pointerId), o.longPressTimer && (clearTimeout(o.longPressTimer), o.longPressTimer = void 0), o.pointers.size < 2 && (o.pinchStartDistance = void 0, o.pinchStartScale = void 0, o.pinchLastCenterX = void 0, o.pinchLastCenterY = void 0, o.props.graphModel.editConfigModel.updateEditConfig({ isPinching: !1 }), o.clickHandler(s));
    };
    var n = e.graphModel, i = n.gridSize, a = n.eventCenter;
    return o.stepDrag = new de({
      onDragging: o.onDragging,
      onDragEnd: o.onDragEnd,
      step: i,
      eventType: "BLANK",
      isStopPropagation: !1,
      eventCenter: a,
      model: void 0
    }), o.state = { isDragging: !1 }, o;
  }
  return t.prototype.render = function() {
    var e = this.props.graphModel.transformModel.getTransformStyle().transform, o = this.props.children, n = this.state.isDragging;
    return S("svg", {
      xmlns: "http://www.w3.org/2000/svg",
      width: "100%",
      height: "100%",
      name: "canvas-overlay",
      onWheel: this.zoomHandler,
      onPointerDown: this.pointerDownHandler,
      onPointerMove: this.pointerMoveHandler,
      onPointerUp: this.pointerUpHandler,
      onPointerCancel: this.pointerUpHandler,
      onContextMenu: this.handleContextMenu,
      style: {
        touchAction: "none",
        WebkitUserSelect: "none"
      },
      className: n ? "lf-canvas-overlay lf-dragging" : "lf-canvas-overlay lf-drag-able",
      children: S("g", {
        transform: e,
        children: o
      })
    });
  }, t = kp([Rt], t), t;
})(V), fu = /* @__PURE__ */ (function() {
  var r = function(t, e) {
    return r = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(o, n) {
      o.__proto__ = n;
    } || function(o, n) {
      for (var i in n) Object.prototype.hasOwnProperty.call(n, i) && (o[i] = n[i]);
    }, r(t, e);
  };
  return function(t, e) {
    if (typeof e != "function" && e !== null) throw new TypeError("Class extends value " + String(e) + " is not a constructor or null");
    r(t, e);
    function o() {
      this.constructor = t;
    }
    t.prototype = e === null ? Object.create(e) : (o.prototype = e.prototype, new o());
  };
})(), so = function() {
  return so = Object.assign || function(r) {
    for (var t, e = 1, o = arguments.length; e < o; e++) {
      t = arguments[e];
      for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && (r[n] = t[n]);
    }
    return r;
  }, so.apply(this, arguments);
}, Xp = function(r, t, e, o) {
  var n = arguments.length, i = n < 3 ? t : o === null ? o = Object.getOwnPropertyDescriptor(t, e) : o, a;
  if (typeof Reflect == "object" && typeof Reflect.decorate == "function") i = Reflect.decorate(r, t, e, o);
  else for (var s = r.length - 1; s >= 0; s--) (a = r[s]) && (i = (n < 3 ? a(i) : n > 3 ? a(t, e, i) : a(t, e)) || i);
  return n > 3 && i && Object.defineProperty(t, e, i), i;
}, Yp = function(r, t) {
  var e = typeof Symbol == "function" && r[Symbol.iterator];
  if (!e) return r;
  var o = e.call(r), n, i = [], a;
  try {
    for (; (t === void 0 || t-- > 0) && !(n = o.next()).done; ) i.push(n.value);
  } catch (s) {
    a = { error: s };
  } finally {
    try {
      n && !n.done && (e = o.return) && e.call(o);
    } finally {
      if (a) throw a.error;
    }
  }
  return i;
}, Rs = (function(r) {
  fu(t, r);
  function t() {
    var e = r.call(this) || this;
    return e.onDragging = function(o) {
      var n = o.event, i = e.props, a = i.graphModel, s = i.bezierModel, l = i.type, u = a.getPointByClient({
        x: n.clientX,
        y: n.clientY
      }).canvasOverlayPosition, c = u.x, d = u.y;
      s.updateAdjustAnchor({
        x: c,
        y: d
      }, l), a.eventCenter.emit(L.EDGE_ADJUST, { data: s.getData() });
    }, e.onDragEnd = function() {
      var o = e.props.bezierModel;
      o.isDragging = !1;
    }, e.dragHandler = new de({
      onDragging: e.onDragging,
      onDragEnd: e.onDragEnd
    }), e;
  }
  return t.prototype.render = function() {
    var e = this, o = this.props.position, n = o.x, i = o.y, a = this.props.bezierModel.getEdgeStyle().adjustAnchor;
    return S(Er, so({
      className: "lf-bezier-adjust-anchor",
      x: n,
      y: i
    }, a, { onPointerDown: function(s) {
      e.dragHandler.handleMouseDown(s);
    } }));
  }, t;
})(V), Hp = (function(r) {
  fu(t, r);
  function t() {
    return r !== null && r.apply(this, arguments) || this;
  }
  return t.prototype.getBezierAdjust = function(e, o) {
    var n = e.path, i = e.id, a = Yp(ia(n), 4), s = a[0], l = a[1], u = a[2], c = a[3], d = e.getEdgeStyle().adjustLine, f = [];
    return f.push(S(xr, so({
      x1: s.x,
      y1: s.y,
      x2: l.x,
      y2: l.y
    }, d))), f.push(S(Rs, {
      position: l,
      bezierModel: e,
      graphModel: o,
      type: "sNext"
    }, "".concat(i, "_ePre"))), f.push(S(xr, so({
      x1: c.x,
      y1: c.y,
      x2: u.x,
      y2: u.y
    }, d))), f.push(S(Rs, {
      position: u,
      bezierModel: e,
      graphModel: o,
      type: "ePre"
    }, "".concat(i, "_sNext"))), f;
  }, t.prototype.selectedBezierEdge = function() {
    for (var e = this.props.graphModel, o = e.edges, n = [], i = 0; i < o.length; i++) {
      var a = o[i];
      a.isSelected && a.modelType === G.BEZIER_EDGE && a.draggable && n.push(this.getBezierAdjust(a, e));
    }
    return n;
  }, t.prototype.render = function() {
    return S("g", {
      className: "lf-bezier-adjust",
      children: this.selectedBezierEdge()
    });
  }, t = Xp([Rt], t), t;
})(V), Gp = /* @__PURE__ */ (function() {
  var r = function(t, e) {
    return r = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(o, n) {
      o.__proto__ = n;
    } || function(o, n) {
      for (var i in n) Object.prototype.hasOwnProperty.call(n, i) && (o[i] = n[i]);
    }, r(t, e);
  };
  return function(t, e) {
    if (typeof e != "function" && e !== null) throw new TypeError("Class extends value " + String(e) + " is not a constructor or null");
    r(t, e);
    function o() {
      this.constructor = t;
    }
    t.prototype = e === null ? Object.create(e) : (o.prototype = e.prototype, new o());
  };
})(), zp = function(r, t, e, o) {
  var n = arguments.length, i = n < 3 ? t : o === null ? o = Object.getOwnPropertyDescriptor(t, e) : o, a;
  if (typeof Reflect == "object" && typeof Reflect.decorate == "function") i = Reflect.decorate(r, t, e, o);
  else for (var s = r.length - 1; s >= 0; s--) (a = r[s]) && (i = (n < 3 ? a(i) : n > 3 ? a(t, e, i) : a(t, e)) || i);
  return n > 3 && i && Object.defineProperty(t, e, i), i;
}, $p = (function(r) {
  Gp(t, r);
  function t() {
    return r !== null && r.apply(this, arguments) || this;
  }
  return t.prototype.render = function() {
    var e = this.props.background;
    return S("div", {
      className: "lf-background",
      children: S("div", {
        style: Du(e) ? e : {},
        className: "lf-background-area"
      })
    });
  }, t = zp([Rt], t), t;
})(V), _i = function() {
  return _i = Object.assign || function(r) {
    for (var t, e = 1, o = arguments.length; e < o; e++) {
      t = arguments[e];
      for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && (r[n] = t[n]);
    }
    return r;
  }, _i.apply(this, arguments);
}, Up = function(r) {
  var t = typeof Symbol == "function" && Symbol.iterator, e = t && r[t], o = 0;
  if (e) return e.call(r);
  if (r && typeof r.length == "number") return { next: function() {
    return r && o >= r.length && (r = void 0), {
      value: r && r[o++],
      done: !r
    };
  } };
  throw new TypeError(t ? "Object is not iterable." : "Symbol.iterator is not defined.");
}, Br = {
  opacity: 1,
  boldIndices: [5],
  dashArrayConfig: { pattern: [2, 1] },
  customBoldWidth: 2
};
function Vp(r) {
  var t, e, o, n, i = Math.max(0, Math.min(1, (o = r.opacity) !== null && o !== void 0 ? o : Br.opacity)), a = /* @__PURE__ */ new Set(), s = Array.isArray(r.boldIndices) ? r.boldIndices : Br.boldIndices;
  try {
    for (var l = Up(s), u = l.next(); !u.done; u = l.next()) {
      var c = u.value;
      typeof c == "number" && Number.isFinite(c) && c > 0 && a.add(Math.floor(c));
    }
  } catch (v) {
    t = { error: v };
  } finally {
    try {
      u && !u.done && (e = l.return) && e.call(l);
    } finally {
      if (t) throw t.error;
    }
  }
  var d = Array.from(a), f = { pattern: Array.isArray((n = r.dashArrayConfig) === null || n === void 0 ? void 0 : n.pattern) ? r.dashArrayConfig.pattern : Br.dashArrayConfig.pattern }, p = r.customBoldWidth;
  return {
    opacity: i,
    boldIndices: d.length ? d : Br.boldIndices,
    dashArrayConfig: f,
    customBoldWidth: p
  };
}
function Is(r) {
  return r === !1 ? {
    mode: "disabled",
    config: {
      opacity: 1,
      boldIndices: [],
      dashArrayConfig: { pattern: [] }
    }
  } : r === !0 || r == null ? {
    mode: "default",
    config: _i({}, Br)
  } : {
    mode: "custom",
    config: Vp(r)
  };
}
var Fp = /* @__PURE__ */ (function() {
  var r = function(t, e) {
    return r = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(o, n) {
      o.__proto__ = n;
    } || function(o, n) {
      for (var i in n) Object.prototype.hasOwnProperty.call(n, i) && (o[i] = n[i]);
    }, r(t, e);
  };
  return function(t, e) {
    if (typeof e != "function" && e !== null) throw new TypeError("Class extends value " + String(e) + " is not a constructor or null");
    r(t, e);
    function o() {
      this.constructor = t;
    }
    t.prototype = e === null ? Object.create(e) : (o.prototype = e.prototype, new o());
  };
})(), Wp = function(r, t, e, o) {
  var n = arguments.length, i = n < 3 ? t : o === null ? o = Object.getOwnPropertyDescriptor(t, e) : o, a;
  if (typeof Reflect == "object" && typeof Reflect.decorate == "function") i = Reflect.decorate(r, t, e, o);
  else for (var s = r.length - 1; s >= 0; s--) (a = r[s]) && (i = (n < 3 ? a(i) : n > 3 ? a(t, e, i) : a(t, e)) || i);
  return n > 3 && i && Object.defineProperty(t, e, i), i;
}, Kp = function(r, t) {
  var e = typeof Symbol == "function" && r[Symbol.iterator];
  if (!e) return r;
  var o = e.call(r), n, i = [], a;
  try {
    for (; (t === void 0 || t-- > 0) && !(n = o.next()).done; ) i.push(n.value);
  } catch (s) {
    a = { error: s };
  } finally {
    try {
      n && !n.done && (e = o.return) && e.call(o);
    } finally {
      if (a) throw a.error;
    }
  }
  return i;
}, Zp = function(r, t, e) {
  if (e || arguments.length === 2)
    for (var o = 0, n = t.length, i; o < n; o++) (i || !(o in t)) && (i || (i = Array.prototype.slice.call(t, 0, o)), i[o] = t[o]);
  return r.concat(i || Array.prototype.slice.call(t));
}, ur = (function(r) {
  Fp(t, r);
  function t(e) {
    var o = r.call(this, e) || this;
    return o.id = $e(), o.gridOptions = o.props.graphModel.grid, o;
  }
  return t.prototype.renderDot = function() {
    var e = this.gridOptions, o = e.config, n = e.size, i = n === void 0 ? 1 : n, a = e.visible, s = o != null ? o : {}, l = s.color, u = s.thickness, c = Math.min(Math.max(2, u === void 0 ? 2 : u), i / 4);
    return S("g", {
      fill: l,
      opacity: a ? 1 : 0,
      children: [
        S("circle", {
          cx: 0,
          cy: 0,
          r: c / 2
        }),
        S("circle", {
          cx: 0,
          cy: i,
          r: c / 2
        }),
        S("circle", {
          cx: i,
          cy: 0,
          r: c / 2
        }),
        S("circle", {
          cx: i,
          cy: i,
          r: c / 2
        })
      ]
    });
  }, t.prototype.getDashArrayForSize = function(e) {
    var o, n = (o = e == null ? void 0 : e.pattern) === null || o === void 0 ? void 0 : o.filter(function(i) {
      return typeof i == "number" && i > 0;
    });
    return (n == null ? void 0 : n.join(",")) || "2,1";
  }, t.prototype.getPeriod = function(e) {
    var o = Array.isArray(e == null ? void 0 : e.boldIndices) ? e.boldIndices.filter(function(n) {
      return typeof n == "number" && n > 0;
    }) : [];
    return o.length ? Math.max.apply(Math, Zp([], Kp(o), !1)) : 0;
  }, t.prototype.getBoldStrokeWidth = function(e, o, n, i) {
    if (typeof (e == null ? void 0 : e.customBoldWidth) == "number") return e.customBoldWidth;
    var a = Math.max(1, n != null ? n : 1), s = Math.max(1, i != null ? i : this.getPeriod(e));
    return Math.min(a, o * s / 2) / 2;
  }, t.prototype.renderMeshEdgeLines = function(e, o, n, i, a) {
    var s = [
      { d: "M 0 0 H ".concat(e) },
      { d: "M 0 ".concat(e, " H ").concat(e) },
      { d: "M 0 0 V ".concat(e) },
      { d: "M ".concat(e, " 0 V ").concat(e) }
    ];
    return S("g", {
      opacity: i,
      fill: "transparent",
      children: s.map(function(l) {
        return S("path", {
          d: l.d,
          stroke: o,
          strokeWidth: n / 2,
          strokeDasharray: a,
          strokeLinecap: "butt",
          fill: "transparent"
        });
      })
    });
  }, t.prototype.renderMesh = function() {
    var e, o, n = this.gridOptions, i = n.config, a = n.size, s = a === void 0 ? 1 : a, l = n.visible, u = n.majorBold, c = Is(u).config, d = c.opacity, f = (e = i == null ? void 0 : i.color) !== null && e !== void 0 ? e : "#D7DEEB", p = (o = i == null ? void 0 : i.thickness) !== null && o !== void 0 ? o : 1, v = Math.min(Math.max(1, p), s / 2), h = l ? d : 0, g = u === !1 ? void 0 : this.getDashArrayForSize(c.dashArrayConfig);
    return this.renderMeshEdgeLines(s, f, v, h, g);
  }, t.prototype.render = function() {
    var e = this, o, n, i, a = this.props.graphModel, s = a.transformModel, l = a.grid;
    this.gridOptions = l;
    var u = this.gridOptions, c = u.type, d = u.config, f = d === void 0 ? {} : d, p = u.size, v = p === void 0 ? 1 : p, h = u.majorBold, g = h !== !1 && !yt(h), y = Is(h).config, _ = [
      s.SCALE_X,
      s.SKEW_Y,
      s.SKEW_X,
      s.SCALE_Y,
      s.TRANSLATE_X,
      s.TRANSLATE_Y
    ].join(","), E = "matrix(".concat(_, ")"), x = Math.min(Math.max(2, (o = f.thickness) !== null && o !== void 0 ? o : 1), v / 4), O = g ? y.opacity : 1;
    return S("div", {
      className: "lf-grid",
      children: S("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        version: "1.1",
        width: "100%",
        height: "100%",
        children: [
          S("defs", { children: [
            S("pattern", {
              id: this.id,
              patternUnits: "userSpaceOnUse",
              patternTransform: E,
              x: "0",
              y: "0",
              width: v,
              height: v,
              children: [c === "dot" && this.renderDot(), c === "mesh" && this.renderMesh()]
            }),
            c === "dot" && y.boldIndices.length ? S("pattern", {
              id: "".concat(this.id, "-dot-major"),
              patternUnits: "userSpaceOnUse",
              patternTransform: E,
              x: "0",
              y: "0",
              width: v * this.getPeriod(y),
              height: v * this.getPeriod(y),
              children: S("g", {
                fill: (i = (n = this.gridOptions.config) === null || n === void 0 ? void 0 : n.color) !== null && i !== void 0 ? i : "#D7DEEB",
                opacity: this.gridOptions.visible ? O : 0,
                children: [
                  S("circle", {
                    cx: 0,
                    cy: 0,
                    r: x * 1.5 / 2
                  }),
                  S("circle", {
                    cx: v * this.getPeriod(y),
                    cy: 0,
                    r: x * 1.5 / 2
                  }),
                  S("circle", {
                    cx: 0,
                    cy: v * this.getPeriod(y),
                    r: x * 1.5 / 2
                  }),
                  S("circle", {
                    cx: v * this.getPeriod(y),
                    cy: v * this.getPeriod(y),
                    r: x * 1.5 / 2
                  })
                ]
              })
            }) : null,
            c === "mesh" && y.boldIndices.length ? S("pattern", {
              id: "".concat(this.id, "-major"),
              patternUnits: "userSpaceOnUse",
              patternTransform: E,
              x: "0",
              y: "0",
              width: v * this.getPeriod(y),
              height: v * this.getPeriod(y),
              children: y.boldIndices.map(function(M) {
                var P, m, w, T, D, B;
                return S("g", { children: [S("path", {
                  d: "M ".concat(v * M, " 0 V ").concat(v * e.getPeriod(y)),
                  stroke: (m = (P = e.gridOptions.config) === null || P === void 0 ? void 0 : P.color) !== null && m !== void 0 ? m : "#D7DEEB",
                  strokeWidth: e.getBoldStrokeWidth(y, v, ((w = e.gridOptions.config) !== null && w !== void 0 ? w : {}).thickness, e.getPeriod(y)),
                  opacity: e.gridOptions.visible ? O : 0,
                  fill: "transparent"
                }), S("path", {
                  d: "M 0 ".concat(v * M, " H ").concat(v * e.getPeriod(y)),
                  stroke: (D = (T = e.gridOptions.config) === null || T === void 0 ? void 0 : T.color) !== null && D !== void 0 ? D : "#D7DEEB",
                  strokeWidth: e.getBoldStrokeWidth(y, v, ((B = e.gridOptions.config) !== null && B !== void 0 ? B : {}).thickness, e.getPeriod(y)),
                  opacity: e.gridOptions.visible ? O : 0,
                  fill: "transparent"
                })] });
              })
            }) : null
          ] }),
          S("rect", {
            width: "100%",
            height: "100%",
            fill: "url(#".concat(this.id, ")")
          }),
          c === "dot" && g && y.boldIndices.length ? S("rect", {
            width: "100%",
            height: "100%",
            fill: "url(#".concat(this.id, "-dot-major)")
          }) : null,
          c === "mesh" && g && y.boldIndices.length ? S("rect", {
            width: "100%",
            height: "100%",
            fill: "url(#".concat(this.id, "-major)")
          }) : null
        ]
      })
    });
  }, t = Wp([Rt], t), t;
})(V);
(function(r) {
  function t(e) {
    var o = R(na);
    return typeof e == "number" ? U(o, { size: e }) : typeof e == "boolean" ? U(o, { visible: e }) : U(o, e);
  }
  r.getGridOptions = t;
})(ur || (ur = {}));
var qp = /* @__PURE__ */ (function() {
  var r = function(t, e) {
    return r = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(o, n) {
      o.__proto__ = n;
    } || function(o, n) {
      for (var i in n) Object.prototype.hasOwnProperty.call(n, i) && (o[i] = n[i]);
    }, r(t, e);
  };
  return function(t, e) {
    if (typeof e != "function" && e !== null) throw new TypeError("Class extends value " + String(e) + " is not a constructor or null");
    r(t, e);
    function o() {
      this.constructor = t;
    }
    t.prototype = e === null ? Object.create(e) : (o.prototype = e.prototype, new o());
  };
})(), Jp = function(r, t, e, o) {
  var n = arguments.length, i = n < 3 ? t : o === null ? o = Object.getOwnPropertyDescriptor(t, e) : o, a;
  if (typeof Reflect == "object" && typeof Reflect.decorate == "function") i = Reflect.decorate(r, t, e, o);
  else for (var s = r.length - 1; s >= 0; s--) (a = r[s]) && (i = (n < 3 ? a(i) : n > 3 ? a(t, e, i) : a(t, e)) || i);
  return n > 3 && i && Object.defineProperty(t, e, i), i;
}, Qp = (function(r) {
  qp(t, r);
  function t() {
    return r !== null && r.apply(this, arguments) || this;
  }
  return t.prototype.render = function() {
    var e = this.props.graphModel.transformModel.getTransformStyle().transform, o = this.props.children;
    return S("svg", {
      xmlns: "http://www.w3.org/2000/svg",
      version: "1.1",
      width: "100%",
      height: "100%",
      className: "modification-overlay",
      children: S("g", {
        transform: e,
        children: o
      })
    });
  }, t = Jp([Rt], t), t;
})(V), th = /* @__PURE__ */ (function() {
  var r = function(t, e) {
    return r = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(o, n) {
      o.__proto__ = n;
    } || function(o, n) {
      for (var i in n) Object.prototype.hasOwnProperty.call(n, i) && (o[i] = n[i]);
    }, r(t, e);
  };
  return function(t, e) {
    if (typeof e != "function" && e !== null) throw new TypeError("Class extends value " + String(e) + " is not a constructor or null");
    r(t, e);
    function o() {
      this.constructor = t;
    }
    t.prototype = e === null ? Object.create(e) : (o.prototype = e.prototype, new o());
  };
})(), sr = function() {
  return sr = Object.assign || function(r) {
    for (var t, e = 1, o = arguments.length; e < o; e++) {
      t = arguments[e];
      for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && (r[n] = t[n]);
    }
    return r;
  }, sr.apply(this, arguments);
}, eh = function(r, t, e, o) {
  var n = arguments.length, i = n < 3 ? t : o === null ? o = Object.getOwnPropertyDescriptor(t, e) : o, a;
  if (typeof Reflect == "object" && typeof Reflect.decorate == "function") i = Reflect.decorate(r, t, e, o);
  else for (var s = r.length - 1; s >= 0; s--) (a = r[s]) && (i = (n < 3 ? a(i) : n > 3 ? a(t, e, i) : a(t, e)) || i);
  return n > 3 && i && Object.defineProperty(t, e, i), i;
}, rh = (function(r) {
  th(t, r);
  function t() {
    return r !== null && r.apply(this, arguments) || this;
  }
  return t.prototype.renderRectOutline = function(e, o, n, i) {
    var a = o || {}, s = a.widthOffset, l = s === void 0 ? i.widthOffset : s, u = a.heightOffset, c = u === void 0 ? i.heightOffset : u, d = En(e, l, c), f = d.x, p = d.y, v = d.width, h = d.height;
    return S(Te, sr({
      className: n,
      x: f,
      y: p,
      width: v,
      height: h
    }, o));
  }, t.prototype.getNodesOutline = function() {
    var e = this.props.graphModel, o = e.nodes, n = e.editConfigModel, i = n.hoverOutline, a = n.nodeSelectedOutline, s = [];
    return o.forEach(function(l) {
      if (l.isHovered || l.isSelected) {
        var u = l.isHovered, c = l.isSelected, d = l.x, f = l.y, p = l.width, v = l.height;
        if (a && c || i && u) {
          var h = l.getOutlineStyle() || {}, g = {};
          if (Object.keys(h).forEach(function(_) {
            _ !== "hover" && (g[_] = h[_]);
          }), u) {
            var y = h.hover;
            g = sr(sr({}, g), y);
          }
          s.push(S(Te, sr({
            transform: l.transform,
            className: "lf-outline-node",
            x: d,
            y: f,
            width: p + 4,
            height: v + 4
          }, g)));
        }
      }
    }), s;
  }, t.prototype.getEdgeOutline = function() {
    for (var e = this.props.graphModel, o = e.edges, n = e.editConfigModel, i = n.edgeSelectedOutline, a = n.hoverOutline, s = [], l = 0; l < o.length; l++) {
      var u = o[l];
      (i && u.isSelected || a && u.isHovered) && (u.modelType === G.LINE_EDGE ? s.push(this.getLineOutline(u)) : u.modelType === G.POLYLINE_EDGE ? s.push(this.getPolylineOutline(u)) : u.modelType === G.BEZIER_EDGE && s.push(this.getBezierOutline(u)));
    }
    return s;
  }, t.prototype.getLineOutline = function(e) {
    var o = e.startPoint, n = e.endPoint, i = e.getOutlineStyle();
    return this.renderRectOutline([o, n], i, "lf-outline-edge", {
      widthOffset: 10,
      heightOffset: 10
    });
  }, t.prototype.getPolylineOutline = function(e) {
    var o = e.points, n = Me(o), i = e.getOutlineStyle();
    return this.renderRectOutline(n, i, "lf-outline", {
      widthOffset: 8,
      heightOffset: 16
    });
  }, t.prototype.getBezierOutline = function(e) {
    var o = e.path, n = ia(o), i = e.getOutlineStyle();
    return this.renderRectOutline(n, i, "lf-outline", {
      widthOffset: 8,
      heightOffset: 16
    });
  }, t.prototype.render = function() {
    return S("g", {
      className: "lf-outline",
      children: [this.getNodesOutline(), this.getEdgeOutline()]
    });
  }, t = eh([Rt], t), t;
})(V), oh = /* @__PURE__ */ (function() {
  var r = function(t, e) {
    return r = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(o, n) {
      o.__proto__ = n;
    } || function(o, n) {
      for (var i in n) Object.prototype.hasOwnProperty.call(n, i) && (o[i] = n[i]);
    }, r(t, e);
  };
  return function(t, e) {
    if (typeof e != "function" && e !== null) throw new TypeError("Class extends value " + String(e) + " is not a constructor or null");
    r(t, e);
    function o() {
      this.constructor = t;
    }
    t.prototype = e === null ? Object.create(e) : (o.prototype = e.prototype, new o());
  };
})(), be = function() {
  return be = Object.assign || function(r) {
    for (var t, e = 1, o = arguments.length; e < o; e++) {
      t = arguments[e];
      for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && (r[n] = t[n]);
    }
    return r;
  }, be.apply(this, arguments);
}, nh = function(r, t, e, o) {
  var n = arguments.length, i = n < 3 ? t : o === null ? o = Object.getOwnPropertyDescriptor(t, e) : o, a;
  if (typeof Reflect == "object" && typeof Reflect.decorate == "function") i = Reflect.decorate(r, t, e, o);
  else for (var s = r.length - 1; s >= 0; s--) (a = r[s]) && (i = (n < 3 ? a(i) : n > 3 ? a(t, e, i) : a(t, e)) || i);
  return n > 3 && i && Object.defineProperty(t, e, i), i;
}, ih = (function(r) {
  oh(t, r);
  function t() {
    return r !== null && r.apply(this, arguments) || this;
  }
  return t.prototype.render = function() {
    var e = this.props.snaplineModel, o = e != null ? e : {}, n = o.position, i = o.isShowHorizontal, a = o.isShowVertical, s = e == null ? void 0 : e.getStyle(), l = n != null ? n : {}, u = l.x, c = u === void 0 ? 0 : u, d = l.y, f = d === void 0 ? 0 : d, p = be(be({
      x1: -1e5,
      y1: f,
      x2: 1e5,
      y2: f
    }, s), { stroke: i ? s == null ? void 0 : s.stroke : "none" }), v = be(be({
      x1: c,
      y1: -1e5,
      x2: c,
      y2: 1e5
    }, s), { stroke: a ? s == null ? void 0 : s.stroke : "none" });
    return S("g", {
      className: "lf-snapline",
      children: [S(xr, be({}, p)), S(xr, be({}, v))]
    });
  }, t = nh([Rt], t), t;
})(V), ah = /* @__PURE__ */ (function() {
  var r = function(t, e) {
    return r = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(o, n) {
      o.__proto__ = n;
    } || function(o, n) {
      for (var i in n) Object.prototype.hasOwnProperty.call(n, i) && (o[i] = n[i]);
    }, r(t, e);
  };
  return function(t, e) {
    if (typeof e != "function" && e !== null) throw new TypeError("Class extends value " + String(e) + " is not a constructor or null");
    r(t, e);
    function o() {
      this.constructor = t;
    }
    t.prototype = e === null ? Object.create(e) : (o.prototype = e.prototype, new o());
  };
})(), sh = function(r, t, e, o) {
  var n = arguments.length, i = n < 3 ? t : o === null ? o = Object.getOwnPropertyDescriptor(t, e) : o, a;
  if (typeof Reflect == "object" && typeof Reflect.decorate == "function") i = Reflect.decorate(r, t, e, o);
  else for (var s = r.length - 1; s >= 0; s--) (a = r[s]) && (i = (n < 3 ? a(i) : n > 3 ? a(t, e, i) : a(t, e)) || i);
  return n > 3 && i && Object.defineProperty(t, e, i), i;
}, lh = (function(r) {
  ah(t, r);
  function t() {
    return r !== null && r.apply(this, arguments) || this;
  }
  return t.prototype.componentDidMount = function() {
    this.triggerToolRender();
  }, t.prototype.componentDidUpdate = function() {
    this.triggerToolRender();
  }, t.prototype.getTools = function() {
    var e = this.props, o = e.tool, n = e.graphModel, i = n.textEditElement, a = o.getTools().map(function(s) {
      return Ot(s, {
        textEditElement: i,
        graphModel: n,
        lf: o.instance
      });
    });
    return o.components = a, a;
  }, t.prototype.triggerToolRender = function() {
    var e = this.props, o = e.tool, n = e.graphModel, i = document.querySelector("#ToolOverlay_".concat(n.flowId)), a = o.getInstance();
    a.components.forEach(function(s) {
      return s(a, i);
    }), a.components = [];
  }, t.prototype.render = function() {
    var e = this.props.graphModel;
    return S("div", {
      className: "lf-tool-overlay",
      id: "ToolOverlay_".concat(e.flowId),
      children: this.getTools()
    });
  }, t = sh([Rt], t), t;
})(V), zt = function(r, t, e, o) {
  var n = arguments.length, i = n < 3 ? t : o === null ? o = Object.getOwnPropertyDescriptor(t, e) : o, a;
  if (typeof Reflect == "object" && typeof Reflect.decorate == "function") i = Reflect.decorate(r, t, e, o);
  else for (var s = r.length - 1; s >= 0; s--) (a = r[s]) && (i = (n < 3 ? a(i) : n > 3 ? a(t, e, i) : a(t, e)) || i);
  return n > 3 && i && Object.defineProperty(t, e, i), i;
}, Qe = function(r, t) {
  var e = typeof Symbol == "function" && r[Symbol.iterator];
  if (!e) return r;
  var o = e.call(r), n, i = [], a;
  try {
    for (; (t === void 0 || t-- > 0) && !(n = o.next()).done; ) i.push(n.value);
  } catch (s) {
    a = { error: s };
  } finally {
    try {
      n && !n.done && (e = o.return) && e.call(o);
    } finally {
      if (a) throw a.error;
    }
  }
  return i;
}, uh = {
  false: [
    -1 / 0,
    -1 / 0,
    1 / 0,
    1 / 0
  ],
  true: [
    -1 / 0,
    -1 / 0,
    1 / 0,
    1 / 0
  ],
  vertical: [
    -1 / 0,
    0,
    1 / 0,
    0
  ],
  horizontal: [
    0,
    -1 / 0,
    0,
    1 / 0
  ]
}, ch = (function() {
  function r(t, e) {
    this.MINI_SCALE_SIZE = 0.2, this.MAX_SCALE_SIZE = 16, this.SCALE_X = 1, this.SKEW_Y = 0, this.SKEW_X = 0, this.SCALE_Y = 1, this.TRANSLATE_X = 0, this.TRANSLATE_Y = 0, this.ZOOM_SIZE = 0.04, this.translateLimitMinX = -1 / 0, this.translateLimitMinY = -1 / 0, this.translateLimitMaxX = 1 / 0, this.translateLimitMaxY = 1 / 0, this.eventCenter = t;
    var o = e.stopMoveGraph, n = o === void 0 ? !1 : o;
    this.updateTranslateLimits(n);
  }
  return r.prototype.setZoomMiniSize = function(t) {
    this.MINI_SCALE_SIZE = t;
  }, r.prototype.setZoomMaxSize = function(t) {
    this.MAX_SCALE_SIZE = t;
  }, r.prototype.HtmlPointToCanvasPoint = function(t) {
    var e = Qe(t, 2), o = e[0], n = e[1];
    return [(o - this.TRANSLATE_X) / this.SCALE_X, (n - this.TRANSLATE_Y) / this.SCALE_Y];
  }, r.prototype.CanvasPointToHtmlPoint = function(t) {
    var e = Qe(t, 2), o = e[0], n = e[1];
    return [o * this.SCALE_X + this.TRANSLATE_X, n * this.SCALE_Y + this.TRANSLATE_Y];
  }, r.prototype.moveCanvasPointByHtml = function(t, e, o) {
    var n = Qe(t, 2), i = n[0], a = n[1];
    return [i + e / this.SCALE_X, a + o / this.SCALE_Y];
  }, r.prototype.fixDeltaXY = function(t, e) {
    return [t / this.SCALE_X, e / this.SCALE_Y];
  }, r.prototype.getTransformStyle = function() {
    var t = [
      this.SCALE_X,
      this.SKEW_Y,
      this.SKEW_X,
      this.SCALE_Y,
      this.TRANSLATE_X,
      this.TRANSLATE_Y
    ].join(",");
    return { transform: "matrix(".concat(t, ")") };
  }, r.prototype.zoom = function(t, e) {
    t === void 0 && (t = !1);
    var o = this.SCALE_X, n = this.SCALE_Y;
    return typeof t == "number" ? (o = t, n = t) : t ? (o += this.ZOOM_SIZE, n += this.ZOOM_SIZE) : (o -= this.ZOOM_SIZE, n -= this.ZOOM_SIZE), o < this.MINI_SCALE_SIZE || o > this.MAX_SCALE_SIZE ? "".concat(this.SCALE_X * 100, "%") : (e && (this.TRANSLATE_X -= (o - this.SCALE_X) * e[0], this.TRANSLATE_Y -= (n - this.SCALE_Y) * e[1]), this.SCALE_X = o, this.SCALE_Y = n, this.emitGraphTransform("zoom"), "".concat(this.SCALE_X * 100, "%"));
  }, r.prototype.emitGraphTransform = function(t) {
    this.eventCenter.emit(L.GRAPH_TRANSFORM, {
      type: t,
      transform: {
        SCALE_X: this.SCALE_X,
        SKEW_Y: this.SKEW_Y,
        SKEW_X: this.SKEW_X,
        SCALE_Y: this.SCALE_Y,
        TRANSLATE_X: this.TRANSLATE_X,
        TRANSLATE_Y: this.TRANSLATE_Y
      }
    });
  }, r.prototype.resetZoom = function() {
    this.SCALE_X = 1, this.SCALE_Y = 1, this.emitGraphTransform("resetZoom");
  }, r.prototype.translate = function(t, e) {
    this.TRANSLATE_X + t <= this.translateLimitMaxX && this.TRANSLATE_X + t >= this.translateLimitMinX && (this.TRANSLATE_X += t), this.TRANSLATE_Y + e <= this.translateLimitMaxY && this.TRANSLATE_Y + e >= this.translateLimitMinY && (this.TRANSLATE_Y += e), this.emitGraphTransform("translate");
  }, r.prototype.focusOn = function(t, e, o, n) {
    var i = Qe(this.CanvasPointToHtmlPoint([t, e]), 2), a = i[0], s = i[1], l = Qe([o / 2 - a, n / 2 - s], 2), u = l[0], c = l[1];
    this.TRANSLATE_X += u, this.TRANSLATE_Y += c, this.emitGraphTransform("focusOn");
  }, r.prototype.updateTranslateLimits = function(t) {
    var e = Qe(Array.isArray(t) && t.length === 4 ? t : uh[t.toString()], 4);
    this.translateLimitMinX = e[0], this.translateLimitMinY = e[1], this.translateLimitMaxX = e[2], this.translateLimitMaxY = e[3];
  }, zt([A], r.prototype, "SCALE_X", void 0), zt([A], r.prototype, "SKEW_Y", void 0), zt([A], r.prototype, "SKEW_X", void 0), zt([A], r.prototype, "SCALE_Y", void 0), zt([A], r.prototype, "TRANSLATE_X", void 0), zt([A], r.prototype, "TRANSLATE_Y", void 0), zt([A], r.prototype, "ZOOM_SIZE", void 0), zt([b], r.prototype, "zoom", null), zt([b], r.prototype, "resetZoom", null), zt([b], r.prototype, "translate", null), zt([b], r.prototype, "focusOn", null), r;
})(), dh = /* @__PURE__ */ (function() {
  var r = function(t, e) {
    return r = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(o, n) {
      o.__proto__ = n;
    } || function(o, n) {
      for (var i in n) Object.prototype.hasOwnProperty.call(n, i) && (o[i] = n[i]);
    }, r(t, e);
  };
  return function(t, e) {
    if (typeof e != "function" && e !== null) throw new TypeError("Class extends value " + String(e) + " is not a constructor or null");
    r(t, e);
    function o() {
      this.constructor = t;
    }
    t.prototype = e === null ? Object.create(e) : (o.prototype = e.prototype, new o());
  };
})(), Rn = function(r, t) {
  var e = typeof Symbol == "function" && r[Symbol.iterator];
  if (!e) return r;
  var o = e.call(r), n, i = [], a;
  try {
    for (; (t === void 0 || t-- > 0) && !(n = o.next()).done; ) i.push(n.value);
  } catch (s) {
    a = { error: s };
  } finally {
    try {
      n && !n.done && (e = o.return) && e.call(o);
    } finally {
      if (a) throw a.error;
    }
  }
  return i;
}, fh = (function(r) {
  dh(t, r);
  function t(e, o) {
    var n = r.call(this, e, o) || this;
    return n.parentTransform = o.parentTransform, n;
  }
  return t.prototype.setParentTransform = function(e) {
    this.parentTransform = e;
  }, t.prototype.getCumulativeScale = function() {
    var e = this.SCALE_X, o = this.SCALE_Y;
    if (this.parentTransform)
      if (this.parentTransform instanceof t) {
        var n = this.parentTransform.getCumulativeScale();
        e *= n.scaleX, o *= n.scaleY;
      } else
        e *= this.parentTransform.SCALE_X, o *= this.parentTransform.SCALE_Y;
    return {
      scaleX: e,
      scaleY: o
    };
  }, t.prototype.getCumulativeTranslate = function() {
    var e = this.TRANSLATE_X, o = this.TRANSLATE_Y;
    if (this.parentTransform && this.parentTransform instanceof t) {
      var n = this.parentTransform.getCumulativeScale(), i = n.scaleX, a = n.scaleY;
      e = i * e, o = a * o;
    }
    return {
      translateX: e,
      translateY: o
    };
  }, t.prototype.HtmlPointToCanvasPoint = function(e) {
    var o = Rn(e, 2), n = o[0], i = o[1], a = this.getCumulativeScale(), s = a.scaleX, l = a.scaleY, u = this.getCumulativeTranslate(), c = u.translateX, d = u.translateY;
    return [(n - c) / s, (i - d) / l];
  }, t.prototype.CanvasPointToHtmlPoint = function(e) {
    var o = Rn(e, 2), n = o[0], i = o[1], a = this.getCumulativeScale(), s = a.scaleX, l = a.scaleY, u = this.getCumulativeTranslate(), c = u.translateX, d = u.translateY;
    return [n * s + c, i * l + d];
  }, t.prototype.moveCanvasPointByHtml = function(e, o, n) {
    var i = Rn(e, 2), a = i[0], s = i[1], l = this.getCumulativeScale(), u = l.scaleX, c = l.scaleY;
    return [a + o / u, s + n / c];
  }, t.prototype.fixDeltaXY = function(e, o) {
    var n = this.getCumulativeScale(), i = n.scaleX, a = n.scaleY;
    return [e / i, o / a];
  }, t;
})(ch), At = function() {
  return At = Object.assign || function(r) {
    for (var t, e = 1, o = arguments.length; e < o; e++) {
      t = arguments[e];
      for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && (r[n] = t[n]);
    }
    return r;
  }, At.apply(this, arguments);
}, C = function(r, t, e, o) {
  var n = arguments.length, i = n < 3 ? t : o === null ? o = Object.getOwnPropertyDescriptor(t, e) : o, a;
  if (typeof Reflect == "object" && typeof Reflect.decorate == "function") i = Reflect.decorate(r, t, e, o);
  else for (var s = r.length - 1; s >= 0; s--) (a = r[s]) && (i = (n < 3 ? a(i) : n > 3 ? a(t, e, i) : a(t, e)) || i);
  return n > 3 && i && Object.defineProperty(t, e, i), i;
}, ph = function(r) {
  var t = typeof Symbol == "function" && Symbol.iterator, e = t && r[t], o = 0;
  if (e) return e.call(r);
  if (r && typeof r.length == "number") return { next: function() {
    return r && o >= r.length && (r = void 0), {
      value: r && r[o++],
      done: !r
    };
  } };
  throw new TypeError(t ? "Object is not iterable." : "Symbol.iterator is not defined.");
}, _t = function(r, t) {
  var e = typeof Symbol == "function" && r[Symbol.iterator];
  if (!e) return r;
  var o = e.call(r), n, i = [], a;
  try {
    for (; (t === void 0 || t-- > 0) && !(n = o.next()).done; ) i.push(n.value);
  } catch (s) {
    a = { error: s };
  } finally {
    try {
      n && !n.done && (e = o.return) && e.call(o);
    } finally {
      if (a) throw a.error;
    }
  }
  return i;
}, Dt = function(r, t, e) {
  if (e || arguments.length === 2)
    for (var o = 0, n = t.length, i; o < n; o++) (i || !(o in t)) && (i || (i = Array.prototype.slice.call(t, 0, o)), i[o] = t[o]);
  return r.concat(i || Array.prototype.slice.call(t));
}, hh = (function() {
  function r(t) {
    var e = this, o, n;
    this.themeMode = "default", this.modelMap = /* @__PURE__ */ new Map(), this.nodeModelMap = /* @__PURE__ */ new Map(), this.edgeModelMap = /* @__PURE__ */ new Map(), this.elementsModelMap = /* @__PURE__ */ new Map(), this.nodeMoveRules = [], this.nodeResizeRules = [], this.nodes = [], this.edges = [], this.overlapMode = mt.DEFAULT, this.gridSize = 1, this.partial = !1, this.waitCleanEffects = [];
    var i = t.container, a = t.partial, s = t.background, l = s === void 0 ? {} : s, u = t.grid, c = t.idGenerator, d = t.edgeGenerator, f = t.animation, p = t.customTrajectory, v = t.customTargetAnchor;
    this.themeMode = t.themeMode || "default";
    var h = Ye[this.themeMode] || Ye.default, g = Xe[this.themeMode] || Xe.default;
    this.rootEl = i, this.partial = !!a, this.background = l, this.customStyles = t.style || {}, this.theme = du(t.style, t.themeMode), this.grid = ur.getGridOptions(typeof u == "object" && u !== null ? U({}, h, u) : u != null ? u : !1), this.theme.grid = R(this.grid), t.snapGrid && (this.gridSize = this.grid.size || 1), l && (this.background = R(U({}, g, l)), this.theme.background = R(U({}, g, l))), this.edgeType = t.edgeType || "polyline", this.animation = Rd(f), this.overlapMode = t.overlapMode || mt.DEFAULT, this.isMiniMap = t.isMiniMap || !1, this.width = (o = t.width) !== null && o !== void 0 ? o : this.rootEl.getBoundingClientRect().width, this.isContainerWidth = yt(t.width), this.height = (n = t.height) !== null && n !== void 0 ? n : this.rootEl.getBoundingClientRect().height, this.isContainerHeight = yt(t.height);
    var y = new ResizeObserver(qs((function(_) {
      var E, x;
      try {
        for (var O = ph(_), M = O.next(); !M.done; M = O.next()) {
          var P = M.value;
          if (P.target === e.rootEl) {
            if (!document.body.contains(e.rootEl)) return;
            e.resize(), e.eventCenter.emit("graph:resize", {
              target: e.rootEl,
              contentRect: P.contentRect
            });
          }
        }
      } catch (m) {
        E = { error: m };
      } finally {
        try {
          M && !M.done && (x = O.return) && x.call(O);
        } finally {
          if (E) throw E.error;
        }
      }
    }), 16));
    y.observe(this.rootEl), this.waitCleanEffects.push(function() {
      y.disconnect();
    }), this.eventCenter = new Rp(), this.editConfigModel = new Lp(t), this.transformModel = new fh(this.eventCenter, t), this.flowId = $e(), this.idGenerator = c, this.edgeGenerator = vf(this, d), this.customTrajectory = p, this.customTargetAnchor = v;
  }
  return Object.defineProperty(r.prototype, "nodesMap", {
    get: function() {
      return this.nodes.reduce(function(t, e, o) {
        return t[e.id] = {
          index: o,
          model: e
        }, t;
      }, {});
    },
    enumerable: !1,
    configurable: !0
  }), Object.defineProperty(r.prototype, "edgesMap", {
    get: function() {
      return this.edges.reduce(function(t, e, o) {
        return t[e.id] = {
          index: o,
          model: e
        }, t;
      }, {});
    },
    enumerable: !1,
    configurable: !0
  }), Object.defineProperty(r.prototype, "modelsMap", {
    get: function() {
      return Dt(Dt([], _t(this.nodes), !1), _t(this.edges), !1).reduce(function(t, e) {
        return t[e.id] = e, t;
      }, {});
    },
    enumerable: !1,
    configurable: !0
  }), Object.defineProperty(r.prototype, "sortElements", {
    get: function() {
      for (var t = function(l) {
        return Dt([], _t(l), !1).sort(function(u, c) {
          return u.zIndex - c.zIndex;
        });
      }, e = t(Dt(Dt([], _t(this.nodes), !1), _t(this.edges), !1)), o = [], n = [-200, -200], i = [this.width + 200, this.height + 200], a = 0; a < e.length; a++) {
        var s = e[a];
        s.visible && (!this.partial || s.isSelected || this.isElementInArea(s, n, i, !1, !1)) && o.push(s);
      }
      return o;
    },
    enumerable: !1,
    configurable: !0
  }), Object.defineProperty(r.prototype, "textEditElement", {
    get: function() {
      var t = this.nodes.find(function(o) {
        return o.state === J.TEXT_EDIT;
      }), e = this.edges.find(function(o) {
        return o.state === J.TEXT_EDIT;
      });
      return t || e;
    },
    enumerable: !1,
    configurable: !0
  }), Object.defineProperty(r.prototype, "selectElements", {
    get: function() {
      var t = /* @__PURE__ */ new Map();
      return this.nodes.forEach(function(e) {
        e.isSelected && t.set(e.id, e);
      }), this.edges.forEach(function(e) {
        e.isSelected && t.set(e.id, e);
      }), t;
    },
    enumerable: !1,
    configurable: !0
  }), Object.defineProperty(r.prototype, "selectNodes", {
    get: function() {
      var t = [];
      return this.nodes.forEach(function(e) {
        e.isSelected && t.push(e);
      }), t;
    },
    enumerable: !1,
    configurable: !0
  }), r.prototype.getAreaElement = function(t, e, o, n, i) {
    var a = this;
    o === void 0 && (o = !0), n === void 0 && (n = !0), i === void 0 && (i = !1);
    var s = [];
    return pt(Dt(Dt([], _t(this.nodes), !1), _t(this.edges), !1), function(l) {
      var u = a.isElementInArea(l, t, e, o, n);
      (!i || l.visible) && u && s.push(l);
    }), s;
  }, r.prototype.getModel = function(t) {
    return this.modelMap.get(t);
  }, r.prototype.getNodeModelById = function(t) {
    var e;
    return this.fakeNode && t === this.fakeNode.id ? this.fakeNode : (e = this.nodesMap[t]) === null || e === void 0 ? void 0 : e.model;
  }, r.prototype.getPointByClient = function(t) {
    var e = t.x, o = t.y, n = this.rootEl.getBoundingClientRect(), i = {
      x: e - n.left,
      y: o - n.top
    }, a = _t(this.transformModel.HtmlPointToCanvasPoint([i.x, i.y]), 2);
    return {
      domOverlayPosition: i,
      canvasOverlayPosition: {
        x: a[0],
        y: a[1]
      }
    };
  }, r.prototype.isElementInArea = function(t, e, o, n, i) {
    var a;
    if (n === void 0 && (n = !0), i === void 0 && (i = !0), t.BaseType === dt.NODE) {
      t = t;
      for (var s = Ct(t), l = s.minX, u = s.minY, c = s.maxX, d = s.maxY, f = [
        {
          x: l,
          y: u
        },
        {
          x: c,
          y: u
        },
        {
          x: c,
          y: d
        },
        {
          x: l,
          y: d
        }
      ], p = i, v = 0; v < f.length; v++) {
        var h = f[v], g = h.x, y = h.y;
        if (a = _t(this.transformModel.CanvasPointToHtmlPoint([g, y]), 2), g = a[0], y = a[1], Dn([g, y], e, o) !== i) {
          p = !i;
          break;
        }
      }
      return p;
    }
    if (t.BaseType === dt.EDGE) {
      t = t;
      var _ = t.startPoint, E = t.endPoint, x = this.transformModel.CanvasPointToHtmlPoint([_.x, _.y]), O = this.transformModel.CanvasPointToHtmlPoint([E.x, E.y]), M = Dn(x, e, o), P = Dn(O, e, o);
      return n ? M && P : M || P;
    }
    return !1;
  }, r.prototype.graphDataToModel = function(t) {
    var e = this;
    if (!t) {
      this.clearData();
      return;
    }
    if (this.elementsModelMap.clear(), this.nodeModelMap.clear(), this.edgeModelMap.clear(), t.nodes ? this.nodes = ce(t.nodes, function(n) {
      var i = e.getModelAfterSnapToGrid(n);
      return e.elementsModelMap.set(i.id, i), e.nodeModelMap.set(i.id, i), i;
    }) : this.nodes = [], t.edges) {
      var o = this.edgeType;
      this.edges = ce(t.edges, function(n) {
        var i, a = e.getModel((i = n.type) !== null && i !== void 0 ? i : o);
        if (!a) throw new Error("找不到".concat(n.type, "对应的边。"));
        var s = new a(n, e);
        return e.edgeModelMap.set(s.id, s), e.elementsModelMap.set(s.id, s), s;
      });
    } else this.edges = [];
  }, r.prototype.modelToGraphData = function() {
    var t = [];
    this.edges.forEach(function(o) {
      var n = o.getData();
      n && !o.virtual && t.push(n);
    });
    var e = [];
    return this.nodes.forEach(function(o) {
      var n = o.getData();
      n && !o.virtual && e.push(n);
    }), {
      nodes: e,
      edges: t
    };
  }, r.prototype.modelToHistoryData = function() {
    for (var t = !1, e = [], o = 0; o < this.nodes.length; o++) {
      var n = this.nodes[o];
      if (n.isDragging) {
        t = !0;
        break;
      } else e.push(n.getHistoryData());
    }
    if (t) return !1;
    for (var i = !1, a = [], s = 0; s < this.edges.length; s++) {
      var l = this.edges[s];
      if (l.isDragging) {
        i = !0;
        break;
      }
      l.virtual || a.push(l.getHistoryData());
    }
    return i ? !1 : {
      nodes: e,
      edges: a
    };
  }, r.prototype.getEdgeModelById = function(t) {
    var e;
    return (e = this.edgesMap[t]) === null || e === void 0 ? void 0 : e.model;
  }, r.prototype.getElement = function(t) {
    return this.modelsMap[t];
  }, r.prototype.getNodeEdges = function(t) {
    for (var e = [], o = 0; o < this.edges.length; o++) {
      var n = this.edges[o], i = n.sourceNodeId === t, a = n.targetNodeId === t;
      (i || a) && e.push(n);
    }
    return e;
  }, r.prototype.getSelectElements = function(t) {
    t === void 0 && (t = !0);
    var e = this.selectElements, o = {
      nodes: [],
      edges: []
    };
    return e.forEach(function(n) {
      if (n.BaseType === dt.NODE && o.nodes.push(n.getData()), n.BaseType === dt.EDGE) {
        var i = n.getData(), a = e.get(i.sourceNodeId) && e.get(i.targetNodeId);
        (t || a) && o.edges.push(i);
      }
    }), o;
  }, r.prototype.updateAttributes = function(t, e) {
    var o = this.getElement(t);
    o == null || o.updateAttributes(e);
  }, r.prototype.changeNodeId = function(t, e) {
    return e || (e = $e()), this.nodesMap[e] || !this.nodesMap[t] ? "" : (this.edges.forEach(function(o) {
      o.sourceNodeId === t && (o.sourceNodeId = e), o.targetNodeId === t && (o.targetNodeId = e);
    }), this.nodesMap[t].model.id = e, this.nodesMap[e] = this.nodesMap[t], e);
  }, r.prototype.changeEdgeId = function(t, e) {
    return e || (e = $e()), this.edgesMap[e] || !this.edgesMap[t] ? "" : (this.edges.forEach(function(o) {
      o.id === t && o.changeEdgeId(e);
    }), e);
  }, r.prototype.getTextModel = function(t) {
    var e = this.editConfigModel, o = e.textMode, n = e.nodeTextMode, i = e.edgeTextMode;
    if (t.BaseType === dt.NODE) return t.textMode || n || o || Xt.TEXT;
    if (t.BaseType === dt.EDGE) return t.textMode || i || o || Xt.TEXT;
  }, r.prototype.setOverlapMode = function(t) {
    this.overlapMode = t, this.eventCenter.emit("overlap:change", { overlapMode: t });
  }, r.prototype.setTextMode = function(t, e) {
    this.editConfigModel.updateEditConfig({ textMode: t });
  }, r.prototype.setFakeNode = function(t) {
    this.fakeNode = t;
  }, r.prototype.removeFakeNode = function() {
    this.fakeNode = null;
  }, r.prototype.setModel = function(t, e) {
    return this.modelMap.set(t, e);
  }, r.prototype.toFront = function(t) {
    var e, o, n, i = ((e = this.nodesMap[t]) === null || e === void 0 ? void 0 : e.model) || ((o = this.edgesMap[t]) === null || o === void 0 ? void 0 : o.model);
    if (i) {
      if (this.overlapMode === mt.STATIC) return;
      if (this.overlapMode === mt.INCREASE) {
        this.setElementZIndex(t, "top");
        return;
      }
      (n = this.topElement) === null || n === void 0 || n.setZIndex(), i.setZIndex(Fd), this.topElement = i;
    }
  }, r.prototype.setElementZIndex = function(t, e) {
    var o, n, i = ((o = this.nodesMap[t]) === null || o === void 0 ? void 0 : o.model) || ((n = this.edgesMap[t]) === null || n === void 0 ? void 0 : n.model);
    if (i) {
      var a = void 0;
      typeof e == "number" ? a = e : (e === "top" && (a = ao()), e === "bottom" && (a = vp())), i.setZIndex(a);
    }
  }, r.prototype.deleteNode = function(t) {
    var e = this.nodesMap[t].model, o = e.getData();
    this.deleteEdgeBySource(t), this.deleteEdgeByTarget(t), this.nodes.splice(this.nodesMap[t].index, 1), this.eventCenter.emit(L.NODE_DELETE, {
      data: o,
      model: e
    });
  }, r.prototype.addNode = function(t, e, o) {
    e === void 0 && (e = L.NODE_ADD);
    var n = Mt(t), i = n.id;
    i && this.nodesMap[i] && delete n.id;
    var a = this.getModelAfterSnapToGrid(n);
    this.nodes.push(a);
    var s = { data: a.getData() };
    return o && (s.e = o), this.eventCenter.emit(e, s), a;
  }, r.prototype.getModelAfterSnapToGrid = function(t) {
    var e = this.getModel(t.type), o = this.editConfigModel.snapGrid;
    if (!e) throw new Error("找不到".concat(t.type, "对应的节点，请确认是否已注册此类型节点。"));
    var n = t.x, i = t.y;
    n && i && (t.x = mr(n, this.gridSize, o), t.y = mr(i, this.gridSize, o), typeof t.text == "object" && t.text !== null && (t.text.x += t.x - n, t.text.y += t.y - i));
    var a = new e(t, this);
    return this.nodeModelMap.set(a.id, a), this.elementsModelMap.set(a.id, a), a;
  }, r.prototype.cloneNode = function(t) {
    var e = this.getNodeModelById(t), o = e == null ? void 0 : e.getData();
    if (o) {
      o.x += 30, o.y += 30, o.id = "", typeof o.text == "object" && o.text !== null && (o.text.x += 30, o.text.y += 30);
      var n = this.addNode(o);
      return n.setSelected(!0), e == null || e.setSelected(!1), n.getData();
    }
  }, r.prototype.moveNode = function(t, e, o, n) {
    var i;
    n === void 0 && (n = !1);
    var a = this.nodesMap[t];
    if (a) {
      var s = a.model;
      i = _t(s.getMoveDistance(e, o, n), 2), e = i[0], o = i[1], this.moveEdge(t, e, o);
    }
  }, r.prototype.moveNode2Coordinate = function(t, e, o, n) {
    n === void 0 && (n = !1);
    var i = this.nodesMap[t];
    if (i) {
      var a = i.model, s = a.x, l = a.y, u = e - s, c = o - l;
      this.moveNode(t, u, c, n);
    }
  }, r.prototype.editText = function(t) {
    this.setElementStateById(t, J.TEXT_EDIT);
  }, r.prototype.addEdge = function(t) {
    var e = Mt(t), o = e.type;
    o || (o = this.edgeType), e.id && this.edgesMap[e.id] && (delete e.id, delete e.sourceAnchorId, delete e.targetAnchorId);
    var n = this.getModel(o);
    if (!n) throw new Error("找不到".concat(o, "对应的边，请确认是否已注册此类型边。"));
    var i = new n(At(At({}, e), { type: o }), this);
    this.edgeModelMap.set(i.id, i), this.elementsModelMap.set(i.id, i);
    var a = i.getData();
    return this.edges.push(i), this.eventCenter.emit(L.EDGE_ADD, { data: a }), i;
  }, r.prototype.moveEdge = function(t, e, o) {
    for (var n = 0; n < this.edges.length; n++) {
      var i = this.edges[n], a = i.textPosition, s = a.x, l = a.y, u = this.edges[n].sourceNodeId === t, c = this.edges[n].targetNodeId === t;
      u && i.moveStartPoint(e, o), c && i.moveEndPoint(e, o), (u || c) && this.handleEdgeTextMove(i, s, l);
    }
  }, r.prototype.handleEdgeTextMove = function(t, e, o) {
    var n;
    if (t.customTextPosition) {
      t.resetTextPosition();
      return;
    }
    if (t.modelType === G.POLYLINE_EDGE && (!((n = t.text) === null || n === void 0) && n.value)) {
      var i = t.text, a = ru(i, t.points);
      t.moveText(a.x - i.x, a.y - i.y);
    }
    var s = t.textPosition, l = s.x, u = s.y;
    t.moveText(l - e, u - o);
  }, r.prototype.deleteEdgeBySourceAndTarget = function(t, e) {
    for (var o = 0; o < this.edges.length; o++) if (this.edges[o].sourceNodeId === t && this.edges[o].targetNodeId === e) {
      var n = this.edges[o].getData();
      this.edges.splice(o, 1), o--, this.eventCenter.emit(L.EDGE_DELETE, { data: n });
    }
  }, r.prototype.deleteEdgeById = function(t) {
    if (this.edgesMap[t]) {
      var e = this.edgesMap[t].index, o = this.edgesMap[t].model.getData();
      this.edges.splice(e, 1), this.eventCenter.emit(L.EDGE_DELETE, { data: o });
    }
  }, r.prototype.deleteEdgeBySource = function(t) {
    for (var e = 0; e < this.edges.length; e++) if (this.edges[e].sourceNodeId === t) {
      var o = this.edges[e].getData();
      this.edges.splice(e, 1), e--, this.eventCenter.emit(L.EDGE_DELETE, { data: o });
    }
  }, r.prototype.deleteEdgeByTarget = function(t) {
    for (var e = 0; e < this.edges.length; e++) if (this.edges[e].targetNodeId === t) {
      var o = this.edges[e].getData();
      this.edges.splice(e, 1), e--, this.eventCenter.emit(L.EDGE_DELETE, { data: o });
    }
  }, r.prototype.setElementStateById = function(t, e, o) {
    this.nodes.forEach(function(n) {
      n.id === t ? n.setElementState(e, o) : n.setElementState(J.DEFAULT);
    }), this.edges.forEach(function(n) {
      n.id === t ? n.setElementState(e, o) : n.setElementState(J.DEFAULT);
    });
  }, r.prototype.updateText = function(t, e) {
    var o = Ue(Dt(Dt([], _t(this.nodes), !1), _t(this.edges), !1), function(n) {
      return n.id === t;
    });
    o == null || o.updateText(e);
  }, r.prototype.selectNodeById = function(t, e) {
    var o;
    e === void 0 && (e = !1), e || this.clearSelectElements();
    var n = (o = this.nodesMap[t]) === null || o === void 0 ? void 0 : o.model;
    n == null || n.setSelected(!0);
  }, r.prototype.selectEdgeById = function(t, e) {
    var o;
    e === void 0 && (e = !1), e || this.clearSelectElements();
    var n = (o = this.edgesMap[t]) === null || o === void 0 ? void 0 : o.model;
    n == null || n.setSelected(!0);
  }, r.prototype.selectElementById = function(t, e) {
    e === void 0 && (e = !1), e || this.clearSelectElements();
    var o = this.getElement(t);
    o == null || o.setSelected(!0);
  }, r.prototype.deselectElementById = function(t) {
    var e = this.getElement(t);
    e && e.setSelected(!1);
  }, r.prototype.clearSelectElements = function() {
    var t;
    this.selectElements.forEach(function(e) {
      e == null || e.setSelected(!1), e == null || e.setHovered(!1);
    }), this.selectElements.clear(), [mt.DEFAULT, mt.EDGE_TOP].includes(this.overlapMode) && ((t = this.topElement) === null || t === void 0 || t.setZIndex());
  }, r.prototype.moveNodes = function(t, e, o, n) {
    var i, a, s, l = this;
    n === void 0 && (n = !1);
    for (var u = t.reduce(function(E, x) {
      var O, M = (O = l.nodesMap[x]) === null || O === void 0 ? void 0 : O.model;
      return M && (E[x] = M.getMoveDistance(e, o, n)), E;
    }, {}), c = 0; c < this.edges.length; c++) {
      var d = this.edges[c], f = d.textPosition, p = f.x, v = f.y, h = u[d.sourceNodeId], g = u[d.targetNodeId], y = void 0, _ = void 0;
      h && g && d.modelType === G.POLYLINE_EDGE ? (i = _t(h, 2), y = i[0], _ = i[1], d.updatePointsList(y, _)) : (h && (a = _t(h, 2), y = a[0], _ = a[1], d.moveStartPoint(y, _)), g && (s = _t(g, 2), y = s[0], _ = s[1], d.moveEndPoint(y, _))), (h || g) && this.handleEdgeTextMove(d, p, v);
    }
  }, r.prototype.addNodeMoveRules = function(t) {
    this.nodeMoveRules.includes(t) || this.nodeMoveRules.push(t);
  }, r.prototype.addNodeResizeRules = function(t) {
    this.nodeResizeRules.includes(t) || this.nodeResizeRules.push(t);
  }, r.prototype.setDefaultEdgeType = function(t) {
    this.edgeType = t;
  }, r.prototype.changeNodeType = function(t, e) {
    var o = this.getNodeModelById(t);
    if (o) {
      var n = o.getData();
      n.type = e;
      var i = this.getModel(e);
      if (!i) throw new Error("找不到".concat(e, "对应的节点，请确认是否已注册此类型节点。"));
      var a = new i(n, this);
      this.nodes.splice(this.nodesMap[t].index, 1, a), this.getNodeEdges(t).forEach(function(s) {
        if (s.sourceNodeId === t) {
          var l = ms(a, s.startPoint, a.width, a.height);
          s.updateStartPoint(l);
        }
        if (s.targetNodeId === t) {
          var l = ms(a, s.endPoint, a.width, a.height);
          s.updateEndPoint(l);
        }
      });
    }
  }, r.prototype.changeEdgeType = function(t, e) {
    var o = this.getEdgeModelById(t);
    if (o && o.type !== e) {
      var n = o.getData();
      n.type = e;
      var i = this.getModel(e);
      if (!i) throw new Error("找不到".concat(e, "对应的节点，请确认是否已注册此类型节点。"));
      delete n.pointsList;
      var a = new i(n, this);
      this.edges.splice(this.edgesMap[t].index, 1, a);
    }
  }, r.prototype.getNodeIncomingEdge = function(t) {
    var e = [];
    return this.edges.forEach(function(o) {
      o.targetNodeId === t && e.push(o);
    }), e;
  }, r.prototype.getNodeOutgoingEdge = function(t) {
    var e = [];
    return this.edges.forEach(function(o) {
      o.sourceNodeId === t && e.push(o);
    }), e;
  }, r.prototype.getAnchorIncomingEdge = function(t) {
    var e = [];
    return this.edges.forEach(function(o) {
      o.targetAnchorId === t && e.push(o);
    }), e;
  }, r.prototype.getAnchorOutgoingEdge = function(t) {
    var e = [];
    return this.edges.forEach(function(o) {
      o.sourceAnchorId === t && e.push(o);
    }), e;
  }, r.prototype.getNodeIncomingNode = function(t) {
    var e = this, o = [];
    return this.edges.forEach(function(n) {
      var i;
      n.targetNodeId === t && o.push((i = e.nodesMap[n.sourceNodeId]) === null || i === void 0 ? void 0 : i.model);
    }), o;
  }, r.prototype.getNodeOutgoingNode = function(t) {
    var e = this, o = [];
    return this.edges.forEach(function(n) {
      n.sourceNodeId === t && o.push(e.nodesMap[n.targetNodeId].model);
    }), o;
  }, r.prototype.setTheme = function(t, e) {
    var o;
    if (e && (this.themeMode = e, Xe[e] && this.updateBackgroundOptions(At(At({}, typeof this.background == "object" ? this.background : {}), Xe[e])), Ye[e] && this.updateGridOptions(ur.getGridOptions(At(At({}, this.grid), Ye[e])))), t.background && this.updateBackgroundOptions(t.background), t.grid) {
      var n = ur.getGridOptions((o = t.grid) !== null && o !== void 0 ? o : !1);
      this.updateGridOptions(n);
    }
    this.theme = fp(At(At({}, this.customStyles), t), e), this.customStyles = At(At({}, this.customStyles), t);
  }, r.prototype.getTheme = function() {
    var t = this, e = t.background, o = t.grid;
    return At(At({}, R(this.theme)), {
      background: e,
      grid: o
    });
  }, r.prototype.updateGridOptions = function(t) {
    Bi(this.grid, t);
  }, r.prototype.updateGridSize = function(t) {
    this.gridSize = t;
  }, r.prototype.updateBackgroundOptions = function(t) {
    $n(t) || $n(this.background) ? this.background = t : this.background = At(At({}, this.background), t);
  }, r.prototype.resize = function(t, e) {
    if (this.rootEl && document.body.contains(this.rootEl)) {
      var o = this.rootEl.offsetParent !== null;
      if (o)
        try {
          this.width = t != null ? t : this.rootEl.getBoundingClientRect().width, this.isContainerWidth = yt(t), this.height = e != null ? e : this.rootEl.getBoundingClientRect().height, this.isContainerHeight = yt(e), o && (!this.width || this.height);
        } catch (n) {
        }
    }
  }, r.prototype.clearData = function() {
    this.nodes = [], this.edges = [], this.edgeModelMap.clear(), this.nodeModelMap.clear(), this.elementsModelMap.clear();
  }, r.prototype.getVirtualRectSize = function() {
    var t = this.nodes, e = [], o = [];
    t.forEach(function(c) {
      var d = c.x, f = c.y, p = c.width, v = c.height, h = c.getNodeStyle().strokeWidth, g = h === void 0 ? 0 : h, y = d + p / 2 + g, _ = d - p / 2 - g, E = f + v / 2 + g, x = f - v / 2 - g;
      e = e.concat([y, _].filter(function(O) {
        return !Number.isNaN(O);
      })), o = o.concat([E, x].filter(function(O) {
        return !Number.isNaN(O);
      }));
    });
    var n = Math.min.apply(Math, Dt([], _t(e), !1)), i = Math.max.apply(Math, Dt([], _t(e), !1)), a = Math.min.apply(Math, Dt([], _t(o), !1)), s = Math.max.apply(Math, Dt([], _t(o), !1)), l = i - n || 0, u = s - a || 0;
    return {
      width: l,
      height: u,
      x: n + l / 2,
      y: a + u / 2
    };
  }, r.prototype.translateCenter = function() {
    var t = this, e = t.nodes, o = t.width, n = t.height, i = t.rootEl, a = t.transformModel;
    if (e.length) {
      var s = o || i.clientWidth, l = n || i.clientHeight, u = this.getVirtualRectSize(), c = u.x, d = u.y;
      a.focusOn(c, d, s, l);
    }
  }, r.prototype.fitView = function(t, e) {
    t === void 0 && (t = 20), e === void 0 && (e = 20);
    var o = this, n = o.nodes, i = o.width, a = o.height, s = o.rootEl, l = o.transformModel;
    if (n.length) {
      var u = i || s.clientWidth, c = a || s.clientHeight, d = this.getVirtualRectSize(), f = d.width, p = d.height, v = d.x, h = d.y, g = (f + e) / u, y = (p + t) / c, _ = 1 / Math.max(g, y), E = [u / 2, c / 2];
      l.zoom(_, E), l.focusOn(v, h, u, c);
    }
  }, r.prototype.openEdgeAnimation = function(t) {
    var e = this.getEdgeModelById(t);
    e == null || e.openEdgeAnimation();
  }, r.prototype.closeEdgeAnimation = function(t) {
    var e = this.getEdgeModelById(t);
    e == null || e.closeEdgeAnimation();
  }, r.prototype.getPartial = function() {
    return this.partial;
  }, r.prototype.setPartial = function(t) {
    this.partial = t;
  }, r.prototype.destroy = function() {
    try {
      this.waitCleanEffects.forEach(function(t) {
        t();
      });
    } catch (t) {
    }
    this.waitCleanEffects.length = 0, this.eventCenter.destroy();
  }, C([A], r.prototype, "width", void 0), C([A], r.prototype, "height", void 0), C([A], r.prototype, "theme", void 0), C([A], r.prototype, "themeMode", void 0), C([A], r.prototype, "grid", void 0), C([A], r.prototype, "edgeType", void 0), C([A], r.prototype, "nodes", void 0), C([A], r.prototype, "edges", void 0), C([A], r.prototype, "fakeNode", void 0), C([A], r.prototype, "overlapMode", void 0), C([A], r.prototype, "background", void 0), C([A], r.prototype, "gridSize", void 0), C([A], r.prototype, "transformModel", void 0), C([A], r.prototype, "editConfigModel", void 0), C([A], r.prototype, "partial", void 0), C([ot], r.prototype, "nodesMap", null), C([ot], r.prototype, "edgesMap", null), C([ot], r.prototype, "modelsMap", null), C([ot], r.prototype, "sortElements", null), C([ot], r.prototype, "textEditElement", null), C([ot], r.prototype, "selectElements", null), C([ot], r.prototype, "selectNodes", null), C([b], r.prototype, "setOverlapMode", null), C([b], r.prototype, "setTextMode", null), C([b], r.prototype, "setFakeNode", null), C([b], r.prototype, "removeFakeNode", null), C([b], r.prototype, "setModel", null), C([b], r.prototype, "toFront", null), C([b], r.prototype, "setElementZIndex", null), C([b], r.prototype, "deleteNode", null), C([b], r.prototype, "addNode", null), C([b], r.prototype, "cloneNode", null), C([b], r.prototype, "moveNode", null), C([b], r.prototype, "moveNode2Coordinate", null), C([b], r.prototype, "editText", null), C([b], r.prototype, "addEdge", null), C([b], r.prototype, "moveEdge", null), C([b], r.prototype, "deleteEdgeBySourceAndTarget", null), C([b], r.prototype, "deleteEdgeById", null), C([b], r.prototype, "deleteEdgeBySource", null), C([b], r.prototype, "deleteEdgeByTarget", null), C([b], r.prototype, "setElementStateById", null), C([b], r.prototype, "updateText", null), C([b], r.prototype, "selectNodeById", null), C([b], r.prototype, "selectEdgeById", null), C([b], r.prototype, "selectElementById", null), C([b], r.prototype, "deselectElementById", null), C([b], r.prototype, "clearSelectElements", null), C([b], r.prototype, "moveNodes", null), C([b], r.prototype, "setDefaultEdgeType", null), C([b], r.prototype, "changeNodeType", null), C([b], r.prototype, "changeEdgeType", null), C([b], r.prototype, "getNodeIncomingEdge", null), C([b], r.prototype, "getNodeOutgoingEdge", null), C([b], r.prototype, "getAnchorIncomingEdge", null), C([b], r.prototype, "getAnchorOutgoingEdge", null), C([b], r.prototype, "getNodeIncomingNode", null), C([b], r.prototype, "getNodeOutgoingNode", null), C([b], r.prototype, "setTheme", null), C([b], r.prototype, "getTheme", null), C([b], r.prototype, "resize", null), C([b], r.prototype, "clearData", null), C([b], r.prototype, "translateCenter", null), C([b], r.prototype, "fitView", null), C([b], r.prototype, "openEdgeAnimation", null), C([b], r.prototype, "closeEdgeAnimation", null), C([b], r.prototype, "setPartial", null), r;
})(), ke = function() {
  return ke = Object.assign || function(r) {
    for (var t, e = 1, o = arguments.length; e < o; e++) {
      t = arguments[e];
      for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && (r[n] = t[n]);
    }
    return r;
  }, ke.apply(this, arguments);
}, Nr = function(r, t, e, o) {
  var n = arguments.length, i = n < 3 ? t : o === null ? o = Object.getOwnPropertyDescriptor(t, e) : o, a;
  if (typeof Reflect == "object" && typeof Reflect.decorate == "function") i = Reflect.decorate(r, t, e, o);
  else for (var s = r.length - 1; s >= 0; s--) (a = r[s]) && (i = (n < 3 ? a(i) : n > 3 ? a(t, e, i) : a(t, e)) || i);
  return n > 3 && i && Object.defineProperty(t, e, i), i;
}, vh = (function() {
  function r(t, e) {
    e === void 0 && (e = 1), this.isShowHorizontal = !1, this.isShowVertical = !1, this.position = {
      x: 0,
      y: 0
    }, this.graphModel = t, this.epsilon = e;
  }
  return r.prototype.getStyle = function() {
    return ke({}, this.graphModel.theme.snapline);
  }, r.prototype.getCenterSnapLine = function(t, e) {
    for (var o = t.x, n = t.y, i = !1, a = !1, s = 0; s < e.length; s++) {
      var l = e[s];
      if (l.id !== t.id && ($t(o, l.x, this.epsilon) && (i = !0), $t(n, l.y, this.epsilon) && (a = !0), i && a))
        break;
    }
    return {
      isShowVertical: i,
      isShowHorizontal: a,
      position: {
        x: o,
        y: n
      }
    };
  }, r.prototype.getHorizontalSnapline = function(t, e) {
    var o = !1, n = 0, i = t.id, a;
    if (i) {
      var s = this.graphModel.fakeNode;
      if (s && s.id === i) a = Ct(s);
      else {
        var l = this.graphModel.getNodeModelById(i);
        l && (a = Ct(l));
      }
    }
    for (var u = 0; u < e.length; u++) {
      var c = e[u];
      if (c.id !== t.id) {
        var d = Ct(c);
        if ($t(d.minY, a == null ? void 0 : a.minY, this.epsilon) || $t(d.maxY, a == null ? void 0 : a.minY, this.epsilon)) {
          o = !0, n = a.minY;
          break;
        }
        if ($t(d.minY, a == null ? void 0 : a.maxY, this.epsilon) || $t(d.maxY, a == null ? void 0 : a.maxY, this.epsilon)) {
          o = !0, n = a.maxY;
          break;
        }
      }
    }
    return {
      isShowHorizontal: o,
      isShowVertical: this.isShowVertical,
      position: ke(ke({}, this.position), { y: n })
    };
  }, r.prototype.getVerticalSnapline = function(t, e) {
    var o = !1, n = 0, i = t.id, a;
    if (i) {
      var s = this.graphModel.fakeNode;
      if (s && s.id === i) a = Ct(s);
      else {
        var l = this.graphModel.getNodeModelById(i);
        l && (a = Ct(l));
      }
    }
    for (var u = 0; u < e.length; u++) {
      var c = e[u];
      if (c.id !== t.id) {
        var d = Ct(c);
        if ($t(d.minX, a == null ? void 0 : a.minX, this.epsilon)) {
          o = !0, n = a.minX;
          break;
        }
        if ($t(d.minX, a == null ? void 0 : a.minX, this.epsilon) || $t(d.maxX, a == null ? void 0 : a.minX, this.epsilon)) {
          o = !0, n = a.minX;
          break;
        }
        if ($t(d.minX, a == null ? void 0 : a.maxX, this.epsilon) || $t(d.maxX, a == null ? void 0 : a.maxX, this.epsilon)) {
          o = !0, n = a.maxX;
          break;
        }
      }
    }
    return {
      isShowHorizontal: this.isShowHorizontal,
      isShowVertical: o,
      position: ke(ke({}, this.position), { x: n })
    };
  }, r.prototype.getSnapLinePosition = function(t, e) {
    var o = this.getCenterSnapLine(t, e), n = o.isShowHorizontal, i = o.isShowVertical;
    if (!n) {
      var a = this.getHorizontalSnapline(t, e);
      a.isShowHorizontal && (o.isShowHorizontal = a.isShowHorizontal, o.position.y = a.position.y);
    }
    if (!i) {
      var s = this.getVerticalSnapline(t, e);
      s.isShowVertical && (o.isShowVertical = s.isShowVertical, o.position.x = s.position.x);
    }
    return o;
  }, r.prototype.setSnaplineInfo = function(t) {
    var e = t.isShowHorizontal, o = t.isShowVertical, n = t.position;
    this.position = n, this.isShowHorizontal = e, this.isShowVertical = o;
  }, r.prototype.clearSnapline = function() {
    this.position = {
      x: 0,
      y: 0
    }, this.isShowHorizontal = !1, this.isShowVertical = !1;
  }, r.prototype.setNodeSnapLine = function(t) {
    var e = this.graphModel.nodes, o = this.getSnapLinePosition(t, e);
    this.setSnaplineInfo(o);
  }, Nr([A], r.prototype, "isShowHorizontal", void 0), Nr([A], r.prototype, "isShowVertical", void 0), Nr([A], r.prototype, "position", void 0), Nr([b], r.prototype, "clearSnapline", null), Nr([b], r.prototype, "setNodeSnapLine", null), r;
})();
function $t(r, t, e) {
  return Math.abs(r - t) <= e;
}
var yh = /* @__PURE__ */ (function() {
  var r = function(t, e) {
    return r = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(o, n) {
      o.__proto__ = n;
    } || function(o, n) {
      for (var i in n) Object.prototype.hasOwnProperty.call(n, i) && (o[i] = n[i]);
    }, r(t, e);
  };
  return function(t, e) {
    if (typeof e != "function" && e !== null) throw new TypeError("Class extends value " + String(e) + " is not a constructor or null");
    r(t, e);
    function o() {
      this.constructor = t;
    }
    t.prototype = e === null ? Object.create(e) : (o.prototype = e.prototype, new o());
  };
})(), gh = function(r, t, e, o) {
  var n = arguments.length, i = n < 3 ? t : o === null ? o = Object.getOwnPropertyDescriptor(t, e) : o, a;
  if (typeof Reflect == "object" && typeof Reflect.decorate == "function") i = Reflect.decorate(r, t, e, o);
  else for (var s = r.length - 1; s >= 0; s--) (a = r[s]) && (i = (n < 3 ? a(i) : n > 3 ? a(t, e, i) : a(t, e)) || i);
  return n > 3 && i && Object.defineProperty(t, e, i), i;
}, _h = function(r, t) {
  var e = typeof Symbol == "function" && r[Symbol.iterator];
  if (!e) return r;
  var o = e.call(r), n, i = [], a;
  try {
    for (; (t === void 0 || t-- > 0) && !(n = o.next()).done; ) i.push(n.value);
  } catch (s) {
    a = { error: s };
  } finally {
    try {
      n && !n.done && (e = o.return) && e.call(o);
    } finally {
      if (a) throw a.error;
    }
  }
  return i;
}, mh = function(r, t, e) {
  if (e || arguments.length === 2)
    for (var o = 0, n = t.length, i; o < n; o++) (i || !(o in t)) && (i || (i = Array.prototype.slice.call(t, 0, o)), i[o] = t[o]);
  return r.concat(i || Array.prototype.slice.call(t));
}, xh = (function(r) {
  yh(t, r);
  function t() {
    var e = r.apply(this, mh([], _h(arguments), !1)) || this;
    return e.handleResize = function() {
      var o = e.props, n = o.graphModel, i = o.options, a = n.width, s = n.height, l = n.isContainerWidth, u = n.isContainerHeight, c = a, d = s, f = !1;
      l && (c = void 0, f = !0), u && (d = void 0, f = !0), f && n.resize(c, d), i.width = a, i.height = s;
    }, e.throttleResize = Qs(e.handleResize, 200), e;
  }
  return t.prototype.componentDidMount = function() {
    window.addEventListener("resize", this.throttleResize);
  }, t.prototype.componentDidUpdate = function() {
    var e = this.props.graphModel.modelToGraphData();
    this.props.graphModel.eventCenter.emit(L.GRAPH_UPDATED, { data: e });
  }, t.prototype.componentWillUnmount = function() {
    window.removeEventListener("resize", this.throttleResize);
  }, t.prototype.getComponent = function(e, o, n) {
    n === void 0 && (n = "canvas-overlay");
    var i = this.props.getView, a = i(e.type);
    return a ? S(a, {
      model: e,
      graphModel: o,
      overlay: n
    }, e.id) : null;
  }, t.prototype.render = function() {
    var e = this, o = this.props, n = o.graphModel, i = o.tool, a = o.options, s = o.dnd, l = o.snaplineModel, u = {};
    a.width && (u.width = "".concat(n.width, "px")), a.height && (u.height = "".concat(n.height, "px"));
    var c = n.fakeNode, d = n.editConfigModel, f = n.background, p = d.adjustEdge;
    return S("div", {
      className: "lf-graph",
      "flow-id": n.flowId,
      style: u,
      children: [
        S(Bp, {
          graphModel: n,
          dnd: s,
          children: [S("g", {
            className: "lf-base",
            children: ce(n.sortElements, function(v) {
              return e.getComponent(v, n);
            })
          }), c ? this.getComponent(c, n) : ""]
        }),
        S(Qp, {
          graphModel: n,
          children: [
            S(rh, { graphModel: n }),
            p ? S(Hp, { graphModel: n }) : "",
            a.snapline !== !1 ? S(ih, { snaplineModel: l }) : ""
          ]
        }),
        S(lh, {
          graphModel: n,
          tool: i
        }),
        f && S($p, { background: f }),
        S(ur, { graphModel: n })
      ]
    });
  }, t = gh([Rt], t), t;
})(V), Eh = /* @__PURE__ */ (function() {
  var r = function(t, e) {
    return r = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(o, n) {
      o.__proto__ = n;
    } || function(o, n) {
      for (var i in n) Object.prototype.hasOwnProperty.call(n, i) && (o[i] = n[i]);
    }, r(t, e);
  };
  return function(t, e) {
    if (typeof e != "function" && e !== null) throw new TypeError("Class extends value " + String(e) + " is not a constructor or null");
    r(t, e);
    function o() {
      this.constructor = t;
    }
    t.prototype = e === null ? Object.create(e) : (o.prototype = e.prototype, new o());
  };
})(), oe = function() {
  return oe = Object.assign || function(r) {
    for (var t, e = 1, o = arguments.length; e < o; e++) {
      t = arguments[e];
      for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && (r[n] = t[n]);
    }
    return r;
  }, oe.apply(this, arguments);
}, bh = function(r, t) {
  var e = typeof Symbol == "function" && r[Symbol.iterator];
  if (!e) return r;
  var o = e.call(r), n, i = [], a;
  try {
    for (; (t === void 0 || t-- > 0) && !(n = o.next()).done; ) i.push(n.value);
  } catch (s) {
    a = { error: s };
  } finally {
    try {
      n && !n.done && (e = o.return) && e.call(o);
    } finally {
      if (a) throw a.error;
    }
  }
  return i;
}, Oh = (function(r) {
  Eh(t, r);
  function t() {
    var e = r.call(this) || this;
    return e.onDragStart = function(o) {
      var n = o.event, i = e.props, a = i.anchorData, s = i.nodeModel, l = i.graphModel;
      l.selectNodeById(s.id), s.autoToFront && l.toFront(s.id), l.eventCenter.emit(L.ANCHOR_DRAGSTART, {
        data: a,
        e: n,
        nodeModel: s
      }), e.setState({
        startX: a.x,
        startY: a.y,
        endX: a.x,
        endY: a.y
      });
    }, e.onDragging = function(o) {
      var n = o.event, i = e.props, a = i.graphModel, s = i.nodeModel, l = i.anchorData, u = a.transformModel, c = a.eventCenter, d = a.width, f = a.height, p = a.editConfigModel, v = p.autoExpand, h = p.stopMoveGraph;
      if (n) {
        var g = n.clientX, y = n.clientY, _ = a.getPointByClient({
          x: g,
          y
        }), E = _.domOverlayPosition, x = E.x, O = E.y, M = _.canvasOverlayPosition, P = M.x, m = M.y;
        e.t && un(e.t);
        var w = [], T = 10;
        x < 10 ? w = [T, 0] : x + 10 > d ? w = [-T, 0] : O < 10 ? w = [0, T] : O + 10 > f && (w = [0, -T]), e.setState({
          endX: P,
          endY: m,
          dragging: !0
        }), e.moveAnchorEnd(P, m, n), w.length > 0 && !h && v && (e.t = su(function() {
          var D = bh(w, 2), B = D[0], Z = D[1];
          u.translate(B, Z);
          var et = e.state, ht = et.endX, vt = et.endY;
          e.setState({
            endX: ht - B,
            endY: vt - Z
          }), e.moveAnchorEnd(ht - B, vt - Z, n);
        })), c.emit(L.ANCHOR_DRAG, {
          data: l,
          e: n,
          nodeModel: s
        });
      }
    }, e.onDragEnd = function(o) {
      var n = o.event;
      e.t && un(e.t);
      var i = e.checkEnd(n);
      e.setState({
        startX: 0,
        startY: 0,
        endX: 0,
        endY: 0,
        dragging: !1
      }), e.sourceRuleResults.clear(), e.targetRuleResults.clear();
      var a = e.props, s = a.graphModel, l = a.nodeModel, u = a.anchorData;
      e.preTargetNode && (e.preTargetNode.setHovered(!1), e.preTargetNode = void 0), s.eventCenter.emit(L.ANCHOR_DRAGEND, {
        data: u,
        e: n,
        nodeModel: l,
        edgeModel: i != null ? i : void 0
      });
    }, e.checkEnd = function(o) {
      var n, i = e.props, a = i.graphModel, s = i.nodeModel, l = i.anchorData, u = l.x, c = l.y, d = l.id, f = e.state, p = f.endX, v = f.endY, h = f.dragging, g = sn({
        x: p,
        y: v
      }, a);
      if (e.preTargetNode && e.preTargetNode.state !== J.DEFAULT && e.preTargetNode.setElementState(J.DEFAULT), !!h && g && g.node) {
        var y = g.node, _ = g.anchor.id, E = "".concat(s.id, "_").concat(y.id, "_").concat(_, "_").concat(d), x = e.sourceRuleResults.get(E) || {}, O = x.isAllPass, M = x.msg, P = e.targetRuleResults.get(E) || {}, m = P.isAllPass, w = P.msg;
        if (O && m) {
          y.setElementState(J.DEFAULT);
          var T = a.getNodeModelById(g.node.id), D = (n = a.edgeGenerator) === null || n === void 0 ? void 0 : n.call(a, s.getData(), T == null ? void 0 : T.getData()), B = a.addEdge(oe(oe({}, D), {
            sourceNodeId: s.id,
            sourceAnchorId: d,
            startPoint: {
              x: u,
              y: c
            },
            targetNodeId: g.node.id,
            targetAnchorId: g.anchor.id,
            endPoint: {
              x: g.anchor.x,
              y: g.anchor.y
            }
          })), Z = e.props.anchorData;
          return a.eventCenter.emit(L.ANCHOR_DROP, {
            data: Z,
            e: o,
            nodeModel: s,
            edgeModel: B
          }), B;
        }
        var et = y.getData();
        return a.eventCenter.emit(L.CONNECTION_NOT_ALLOWED, {
          data: et,
          msg: w || M || "不允许添加连线"
        }), null;
      }
    }, e.sourceRuleResults = /* @__PURE__ */ new Map(), e.targetRuleResults = /* @__PURE__ */ new Map(), e.state = {
      startX: 0,
      startY: 0,
      endX: 0,
      endY: 0,
      dragging: !1
    }, e.dragHandler = new de({
      onDragStart: e.onDragStart,
      onDragging: e.onDragging,
      onDragEnd: e.onDragEnd
    }), e;
  }
  return t.prototype.getAnchorShape = function() {
    var e = this.props, o = e.anchorData, n = e.style, i = e.node.getAnchorShape(o);
    if (i) return i;
    var a = o.x, s = o.y, l = oe(oe({}, n), n == null ? void 0 : n.hover);
    return S("g", { children: [S(Er, oe({ className: "lf-node-anchor-hover" }, l, {
      x: a,
      y: s
    })), S(Er, oe({ className: "lf-node-anchor" }, n, {
      x: a,
      y: s
    }))] });
  }, Object.defineProperty(t.prototype, "customTrajectory", {
    get: function() {
      return this.props.graphModel.customTrajectory;
    },
    enumerable: !1,
    configurable: !0
  }), Object.defineProperty(t.prototype, "relateEdges", {
    get: function() {
      var e = this.props, o = e.graphModel, n = o.getAnchorIncomingEdge, i = o.getAnchorOutgoingEdge, a = e.anchorData.id;
      return {
        incomingEdgeList: n(a),
        outgoingEdgeList: i(a)
      };
    },
    enumerable: !1,
    configurable: !0
  }), t.prototype.moveAnchorEnd = function(e, o, n) {
    var i = this.props, a = i.graphModel, s = i.nodeModel, l = i.anchorData, u = sn({
      x: e,
      y: o
    }, a);
    if (u) {
      var c = u.node, d = u.anchor.id;
      if (this.preTargetNode && this.preTargetNode !== u.node && this.preTargetNode.setElementState(J.DEFAULT), l.id === d) return;
      if (this.preTargetNode = c, this.validateAndSetState(c, d, u.anchor, s, l), !c.isHovered) {
        var f = c.getData();
        n && a.eventCenter.emit(L.NODE_MOUSEENTER, {
          data: f,
          e: n
        }), c.setHovered(!0);
      }
    } else if (this.preTargetNode && this.preTargetNode.state !== J.DEFAULT) {
      this.preTargetNode.setElementState(J.DEFAULT);
      var p = this.preTargetNode.getData();
      n && a.eventCenter.emit(L.NODE_MOUSELEAVE, {
        data: p,
        e: n
      }), this.preTargetNode.setHovered(!1), this.preTargetNode = void 0;
    }
  }, t.prototype.validateAndSetState = function(e, o, n, i, a) {
    var s, l, u = "".concat(i.id, "_").concat(e.id, "_").concat(o, "_").concat(a.id);
    if (!this.targetRuleResults.has(u)) {
      var c = i.isAllowConnectedAsSource(e, a, n), d = e.isAllowConnectedAsTarget(i, a, n);
      this.sourceRuleResults.set(u, ln(c)), this.targetRuleResults.set(u, ln(d));
    }
    var f = ((s = this.sourceRuleResults.get(u)) !== null && s !== void 0 ? s : {}).isAllPass, p = ((l = this.targetRuleResults.get(u)) !== null && l !== void 0 ? l : {}).isAllPass;
    f && p ? e.setElementState(J.ALLOW_CONNECT) : e.setElementState(J.NOT_ALLOW_CONNECT);
  }, t.prototype.isShowLine = function() {
    var e = this.state, o = e.startX, n = e.startY, i = e.endX, a = e.endY;
    return Kt(o, n, i, a) > 10;
  }, t.prototype.render = function() {
    var e = this, o = this.state, n = o.startX, i = o.startY, a = o.endX, s = o.endY, l = this.props, u = l.anchorData, c = l.edgeStyle, d = l.nodeModel, f = l.graphModel, p = u.edgeAddable;
    return S("g", {
      className: "lf-anchor",
      children: [S("g", {
        onClick: function(v) {
          v.stopPropagation(), f.eventCenter.emit(L.ANCHOR_CLICK, {
            data: u,
            e: v,
            nodeModel: d
          });
        },
        onPointerDown: function(v) {
          f.eventCenter.emit(L.ANCHOR_MOUSEDOWN, {
            data: u,
            e: v,
            nodeModel: d
          }), p !== !1 && e.dragHandler.handleMouseDown(v);
        },
        children: this.getAnchorShape()
      }), this.isShowLine() && (this.customTrajectory ? this.customTrajectory(oe({
        sourcePoint: {
          x: n,
          y: i
        },
        targetPoint: {
          x: a,
          y: s
        }
      }, c)) : S(xr, oe({
        x1: n,
        y1: i,
        x2: a,
        y2: s
      }, c, { "pointer-events": "none" })))]
    });
  }, t;
})(V), wh = /* @__PURE__ */ (function() {
  var r = function(t, e) {
    return r = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(o, n) {
      o.__proto__ = n;
    } || function(o, n) {
      for (var i in n) Object.prototype.hasOwnProperty.call(n, i) && (o[i] = n[i]);
    }, r(t, e);
  };
  return function(t, e) {
    if (typeof e != "function" && e !== null) throw new TypeError("Class extends value " + String(e) + " is not a constructor or null");
    r(t, e);
    function o() {
      this.constructor = t;
    }
    t.prototype = e === null ? Object.create(e) : (o.prototype = e.prototype, new o());
  };
})(), mi = function() {
  return mi = Object.assign || function(r) {
    for (var t, e = 1, o = arguments.length; e < o; e++) {
      t = arguments[e];
      for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && (r[n] = t[n]);
    }
    return r;
  }, mi.apply(this, arguments);
}, Sh = (function(r) {
  wh(t, r);
  function t(e) {
    var o = r.call(this, e) || this;
    return o.style = {}, o.onDragging = function(n) {
      var i, a = n.event, s = o.props, l = s.graphModel, u = s.nodeModel, c = s.eventCenter, d = l.selectNodes, f = u.x, p = u.y, v = a.clientX, h = a.clientY, g = l.getPointByClient({
        x: v,
        y: h
      }).canvasOverlayPosition, y = g.x, _ = g.y, E = new St(y - f, _ - p), x = ((i = o.normal) === null || i === void 0 ? void 0 : i.angle(E)) - o.defaultAngle;
      u.transform = new nn(-f, -p).rotate(x).translate(f, p).toString(), u.rotate = x;
      var O = ce(d, function(P) {
        return P.id;
      });
      O.indexOf(u.id) === -1 && (O = [u.id]);
      var M = Ru(O, function(P, m) {
        var w = l.getNodeModelById(m);
        return P[m] = w == null ? void 0 : w.getMoveDistance(0, 0, !1), P;
      }, {});
      O.forEach(function(P) {
        l.getNodeEdges(P).forEach(function(m) {
          if (M[m.sourceNodeId]) {
            var w = l.getNodeModelById(m.sourceNodeId), T = w.anchors.find(function(D) {
              return D.id === m.sourceAnchorId;
            });
            m.updateStartPoint(T);
          }
          if (M[m.targetNodeId]) {
            var w = l.getNodeModelById(m.targetNodeId), T = w.anchors.find(function(Z) {
              return Z.id === m.targetAnchorId;
            });
            m.updateEndPoint(T);
          }
        });
      }), c.emit(L.NODE_ROTATE, {
        e: a,
        model: u,
        data: u.getData()
      });
    }, o.style = e.style, o.stepperDrag = new de({ onDragging: o.onDragging }), o;
  }
  return t.prototype.render = function() {
    var e = this, o = this.props.nodeModel, n = o.x, i = o.y, a = o.width, s = o.height, l = n + a / 2 + 20, u = i - s / 2 - 20;
    return this.normal = new St(1, 0), this.defaultAngle = this.normal.angle(new St(l - n, u - i)), o.defaultAngle = this.defaultAngle, S("g", {
      className: "lf-rotate-control",
      children: S("g", {
        onPointerDown: function(c) {
          e.stepperDrag.handleMouseDown(c);
        },
        children: S(Er, mi({}, this.style, {
          cx: l,
          cy: u
        }))
      })
    });
  }, t;
})(V), Ah = /* @__PURE__ */ Ks(((r, t) => {
  (function() {
    "use strict";
    var e = {}.hasOwnProperty;
    function o() {
      for (var a = "", s = 0; s < arguments.length; s++) {
        var l = arguments[s];
        l && (a = i(a, n(l)));
      }
      return a;
    }
    function n(a) {
      if (typeof a == "string" || typeof a == "number") return a;
      if (typeof a != "object") return "";
      if (Array.isArray(a)) return o.apply(null, a);
      if (a.toString !== Object.prototype.toString && !a.toString.toString().includes("[native code]")) return a.toString();
      var s = "";
      for (var l in a) e.call(a, l) && a[l] && (s = i(s, l));
      return s;
    }
    function i(a, s) {
      return s ? a ? a + " " + s : a + s : a;
    }
    typeof t != "undefined" && t.exports ? (o.default = o, t.exports = o) : typeof define == "function" && typeof define.amd == "object" && define.amd ? define("classnames", [], function() {
      return o;
    }) : window.classNames = o;
  })();
})), Mh = /* @__PURE__ */ Zs(Ah()), Ph = /* @__PURE__ */ (function() {
  var r = function(t, e) {
    return r = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(o, n) {
      o.__proto__ = n;
    } || function(o, n) {
      for (var i in n) Object.prototype.hasOwnProperty.call(n, i) && (o[i] = n[i]);
    }, r(t, e);
  };
  return function(t, e) {
    if (typeof e != "function" && e !== null) throw new TypeError("Class extends value " + String(e) + " is not a constructor or null");
    r(t, e);
    function o() {
      this.constructor = t;
    }
    t.prototype = e === null ? Object.create(e) : (o.prototype = e.prototype, new o());
  };
})(), xi = function() {
  return xi = Object.assign || function(r) {
    for (var t, e = 1, o = arguments.length; e < o; e++) {
      t = arguments[e];
      for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && (r[n] = t[n]);
    }
    return r;
  }, xi.apply(this, arguments);
}, Th = function(r, t) {
  var e = typeof Symbol == "function" && r[Symbol.iterator];
  if (!e) return r;
  var o = e.call(r), n, i = [], a;
  try {
    for (; (t === void 0 || t-- > 0) && !(n = o.next()).done; ) i.push(n.value);
  } catch (s) {
    a = { error: s };
  } finally {
    try {
      n && !n.done && (e = o.return) && e.call(o);
    } finally {
      if (a) throw a.error;
    }
  }
  return i;
}, pu = (function(r) {
  Ph(t, r);
  function t(e) {
    var o = r.call(this) || this;
    o.mouseDownHandler = function(i) {
      var a = o.props, s = a.draggable, l = a.model, u = a.graphModel.editConfigModel.nodeTextDraggable;
      (s != null ? s : u) && (i.stopPropagation(), o.stepperDrag.model = l, o.stepperDrag.handleMouseDown(i));
    }, o.onDragging = function(i) {
      var a = i.deltaX, s = i.deltaY, l = o.props, u = l.model, c = l.graphModel.transformModel;
      if (a || s) {
        var d = Th(c.fixDeltaXY(a, s), 2), f = d[0], p = d[1];
        u.moveText(f, p);
      }
    }, o.dbClickHandler = function() {
      var i = o.props, a = i.editable, s = i.graphModel.eventCenter, l = i.model;
      a && l.setElementState(J.TEXT_EDIT), s.emit(L.TEXT_DBCLICK, {
        data: l.text,
        model: l
      });
    };
    var n = e.draggable;
    return o.stepperDrag = new de({
      onDragging: o.onDragging,
      step: 1,
      eventType: "TEXT",
      isStopPropagation: n
    }), o;
  }
  return t.prototype.getShape = function() {
    var e = this.props, o = e.model, n = e.graphModel.editConfigModel, i = o.text, a = i.value, s = i.x, l = i.y, u = i.editable, c = i.draggable, d = {
      x: s,
      y: l,
      className: "",
      value: a
    }, f = o.getTextStyle(), p = n.nodeTextDraggable || c;
    return S(lu, xi({}, d, f, {
      className: (0, Mh.default)({
        "lf-element-text": u,
        "lf-text-draggable": !u && p,
        "lf-text-disabled": !u && !p
      }),
      model: o
    }));
  }, t.prototype.render = function() {
    if (this.props.model.text) return S("g", {
      onPointerDown: this.mouseDownHandler,
      onDblClick: this.dbClickHandler,
      children: this.getShape()
    });
  }, t;
})(V), Nh = /* @__PURE__ */ (function() {
  var r = function(t, e) {
    return r = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(o, n) {
      o.__proto__ = n;
    } || function(o, n) {
      for (var i in n) Object.prototype.hasOwnProperty.call(n, i) && (o[i] = n[i]);
    }, r(t, e);
  };
  return function(t, e) {
    if (typeof e != "function" && e !== null) throw new TypeError("Class extends value " + String(e) + " is not a constructor or null");
    r(t, e);
    function o() {
      this.constructor = t;
    }
    t.prototype = e === null ? Object.create(e) : (o.prototype = e.prototype, new o());
  };
})(), Ut = function() {
  return Ut = Object.assign || function(r) {
    for (var t, e = 1, o = arguments.length; e < o; e++) {
      t = arguments[e];
      for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && (r[n] = t[n]);
    }
    return r;
  }, Ut.apply(this, arguments);
}, Co = function(r, t) {
  var e = typeof Symbol == "function" && r[Symbol.iterator];
  if (!e) return r;
  var o = e.call(r), n, i = [], a;
  try {
    for (; (t === void 0 || t-- > 0) && !(n = o.next()).done; ) i.push(n.value);
  } catch (s) {
    a = { error: s };
  } finally {
    try {
      n && !n.done && (e = o.return) && e.call(o);
    } finally {
      if (a) throw a.error;
    }
  }
  return i;
}, Dh = (function(r) {
  Nh(t, r);
  function t(e) {
    var o = r.call(this, e) || this;
    return o.setHoverOn = function() {
      o.setState({ isHovered: !0 });
    }, o.setHoverOff = function() {
      o.setState({ isHovered: !1 });
    }, o.state = { isHovered: !1 }, o;
  }
  return t.prototype.getBackground = function() {
    var e = this.state.isHovered, o = this.props.model, n = o.text, i = o.getTextStyle(), a = i.background || {};
    if (e && i.hover && i.hover.background && (a = Ut(Ut({}, a), i.hover.background)), n != null && n.value && (a == null ? void 0 : a.fill) !== "transparent") {
      var s = i.fontSize, l = i.textWidth, u = i.lineHeight, c = i.overflowMode, d = a.wrapPadding, f = n == null ? void 0 : n.value.split(/[\r\n]/g), p = f.length, v = n.x, h = n.y, g = {};
      if (c === "autoWrap" && l) {
        var y = au({
          rows: f,
          style: {
            fontSize: "".concat(s, "px"),
            width: "".concat(l, "px"),
            lineHeight: u,
            padding: d
          },
          rowsLength: p,
          className: "lf-get-text-height"
        });
        g = Ut(Ut({}, a), {
          x: v,
          y: h,
          width: l,
          height: y
        });
      } else {
        var _ = yf({
          rows: f,
          rowsLength: p,
          fontSize: s
        }), E = _.width, x = _.height;
        if (c === "ellipsis" && (E = l, x = s + 2), typeof a.wrapPadding == "string") {
          var O = a.wrapPadding.split(",").filter(function(ut) {
            return ut.trim();
          }).map(function(ut) {
            return parseFloat(ut.trim());
          });
          if (O.length > 0 && O.length <= 4) {
            if (O.length === 1) {
              var M = Co(O, 1)[0];
              O = [
                M,
                M,
                M,
                M
              ];
            } else if (O.length === 2) {
              var P = Co(O, 2), m = P[0], w = P[1];
              O = [
                m,
                w,
                m,
                w
              ];
            } else if (O.length === 3) {
              var T = Co(O, 3), D = T[0], w = T[1];
              O = [
                D,
                w,
                T[2],
                w
              ];
            }
            var B = Co(O, 4), Z = B[0], et = B[1], ht = B[2], vt = B[3];
            E += et + vt, x += Z + ht, v = v + (et - vt) / 2, h = h + (ht - Z) / 2;
          }
        }
        g = Ut(Ut({}, a), {
          x: v - 1,
          y: h - 1,
          width: E,
          height: x
        });
      }
      return S(Te, Ut({}, g));
    }
    return null;
  }, t.prototype.getShape = function() {
    var e = this.props.model, o = e.text, n = o.x, i = o.y, a = o.value;
    if (!a) return null;
    var s = e.getTextStyle(), l = Ut({
      x: n,
      y: i,
      value: a,
      model: e,
      className: "lf-element-text"
    }, s);
    return S("g", {
      className: "lf-line-text",
      onMouseEnter: this.setHoverOn,
      onMouseLeave: this.setHoverOff,
      children: [this.getBackground(), S(lu, Ut({}, l))]
    });
  }, t;
})(pu), Ch = /* @__PURE__ */ (function() {
  var r = function(t, e) {
    return r = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(o, n) {
      o.__proto__ = n;
    } || function(o, n) {
      for (var i in n) Object.prototype.hasOwnProperty.call(n, i) && (o[i] = n[i]);
    }, r(t, e);
  };
  return function(t, e) {
    if (typeof e != "function" && e !== null) throw new TypeError("Class extends value " + String(e) + " is not a constructor or null");
    r(t, e);
    function o() {
      this.constructor = t;
    }
    t.prototype = e === null ? Object.create(e) : (o.prototype = e.prototype, new o());
  };
})(), dn = function() {
  return dn = Object.assign || function(r) {
    for (var t, e = 1, o = arguments.length; e < o; e++) {
      t = arguments[e];
      for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && (r[n] = t[n]);
    }
    return r;
  }, dn.apply(this, arguments);
}, Lh = function(r, t) {
  var e = {};
  for (var o in r) Object.prototype.hasOwnProperty.call(r, o) && t.indexOf(o) < 0 && (e[o] = r[o]);
  if (r != null && typeof Object.getOwnPropertySymbols == "function")
    for (var n = 0, o = Object.getOwnPropertySymbols(r); n < o.length; n++) t.indexOf(o[n]) < 0 && Object.prototype.propertyIsEnumerable.call(r, o[n]) && (e[o[n]] = r[o[n]]);
  return e;
}, Lo = function(r, t) {
  var e = typeof Symbol == "function" && r[Symbol.iterator];
  if (!e) return r;
  var o = e.call(r), n, i = [], a;
  try {
    for (; (t === void 0 || t-- > 0) && !(n = o.next()).done; ) i.push(n.value);
  } catch (s) {
    a = { error: s };
  } finally {
    try {
      n && !n.done && (e = o.return) && e.call(o);
    } finally {
      if (a) throw a.error;
    }
  }
  return i;
}, Le = (function(r) {
  Ch(t, r);
  function t(e) {
    var o = r.call(this) || this;
    o.onDragStart = function(l) {
      var u = l.event, c = o.props, d = c.model, f = c.graphModel;
      if (u) {
        var p = f.getPointByClient({
          x: u.clientX,
          y: u.clientY
        }).canvasOverlayPosition, v = p.x, h = p.y;
        o.moveOffset = {
          dx: d.x - v,
          dy: d.y - h
        };
      }
    }, o.onDragging = function(l) {
      var u, c, d, f, p = l.event, v = o.props, h = v.model, g = v.graphModel, y = g.editConfigModel, _ = y.stopMoveGraph, E = y.autoExpand, x = y.snapGrid, O = g.transformModel, M = g.selectNodes, P = g.width, m = g.height, w = g.gridSize, T = p, D = T.clientX, B = T.clientY, Z = o.mouseDownPosition, et = Z.x, ht = Z.y;
      (D - et > w || B - ht > w) && (h.isDragging = !0);
      var vt = g.getPointByClient({
        x: D,
        y: B
      }).canvasOverlayPosition, ut = vt.x, rt = vt.y, gt = Lo(O.CanvasPointToHtmlPoint([ut, rt]), 2), ge = gt[0], je = gt[1];
      if (ut = ut + ((c = (u = o.moveOffset) === null || u === void 0 ? void 0 : u.dx) !== null && c !== void 0 ? c : 0), rt = rt + ((f = (d = o.moveOffset) === null || d === void 0 ? void 0 : d.dy) !== null && f !== void 0 ? f : 0), ut = mr(ut, w, x), rt = mr(rt, w, x), !P || !m) {
        g.moveNode2Coordinate(h.id, ut, rt);
        return;
      }
      if (!(E && !_ && (ge < 0 || je < 0 || ge > P || je > m))) {
        var Y = Lo(O.CanvasPointToHtmlPoint([ut - h.width / 2, rt - h.height / 2]), 2), q = Y[0], nt = Y[1], F = Lo(O.CanvasPointToHtmlPoint([ut + h.width / 2, rt + h.height / 2]), 2), at = F[0], Gt = F[1], tt = Math.max(w, 20), ct = [];
        q < 0 ? ct = [tt, 0] : at > g.width ? ct = [-tt, 0] : nt < 0 ? ct = [0, tt] : Gt > g.height && (ct = [0, -tt]), o.t && un(o.t);
        var Tt = M.map(function(_e) {
          return _e.id;
        });
        Tt.indexOf(h.id) === -1 && (Tt = [h.id]), ct.length > 0 && !_ && E ? o.t = su(function() {
          var _e = Lo(ct, 2), me = _e[0], xe = _e[1];
          O.translate(me != null ? me : 0, xe != null ? xe : 0);
          var Eu = -(me != null ? me : 0) / O.SCALE_X, bu = -(xe != null ? xe : 0) / O.SCALE_X;
          g.moveNodes(Tt, Eu, bu);
        }) : g.moveNodes(Tt, ut - h.x, rt - h.y);
      }
    }, o.onDragEnd = function() {
      o.t && un(o.t);
      var l = o.props.model;
      l.isDragging = !1;
    }, o.onMouseOut = function(l) {
      Id() && o.setHoverOff(l);
    }, o.handleMouseUp = function() {
      o.mouseUpDrag = o.props.model.isDragging, o.longPressTimer && (clearTimeout(o.longPressTimer), o.longPressTimer = void 0);
    }, o.handleClick = function(l) {
      var u = o.mouseUpDrag === !1, c = (/* @__PURE__ */ new Date()).getTime();
      if (o.startTime) {
        var d = c - o.startTime, f = o.props, p = f.model, v = f.graphModel;
        if (!(!u && d > 300)) {
          u || (o.onDragEnd(), o.handleMouseUp());
          var h = {
            data: p.getData(),
            e: l,
            position: v.getPointByClient({
              x: l.clientX,
              y: l.clientY
            }),
            isSelected: !1,
            isMultiple: !1
          }, g = l.button === 2, y = l.detail === 2;
          if (!g) {
            var _ = v.editConfigModel, E = nu(l, _);
            if (h.isMultiple = E, p.isSelected && !y && E ? (h.isSelected = !1, p.setSelected(!1)) : (v.selectNodeById(p.id, E), h.isSelected = !0, _.isSilentMode || o.toFront()), y)
              _.nodeTextEdit && p.text.editable && _.textMode === Xt.TEXT && (p.setSelected(!1), v.setElementStateById(p.id, J.TEXT_EDIT)), v.eventCenter.emit(L.NODE_DBCLICK, h);
            else {
              v.eventCenter.emit(L.ELEMENT_CLICK, h), v.eventCenter.emit(L.NODE_CLICK, h);
              var x = l.currentTarget;
              (!yt(window) && ki(window.requestAnimationFrame) ? window.requestAnimationFrame.bind(window) : function(O) {
                return setTimeout(O, 0);
              })(function() {
                x.focus();
              });
            }
          }
        }
      }
    }, o.handleContextMenu = function(l) {
      l.preventDefault();
      var u = o.props, c = u.model, d = u.graphModel, f = d.editConfigModel, p = c.getData(), v = d.getPointByClient({
        x: l.clientX,
        y: l.clientY
      });
      d.setElementStateById(c.id, J.SHOW_MENU, v.domOverlayPosition), c.isSelected || d.selectNodeById(c.id), d.eventCenter.emit(L.NODE_CONTEXTMENU, {
        data: p,
        e: l,
        position: v
      }), f.isSilentMode || o.toFront();
    }, o.handleMouseDown = function(l) {
      var u = o.props, c = u.model, d = u.graphModel;
      o.mouseDownPosition = {
        x: l.clientX,
        y: l.clientY
      }, o.startTime = (/* @__PURE__ */ new Date()).getTime(), d.editConfigModel.adjustNodePosition && c.draggable && o.stepDrag && o.stepDrag.handleMouseDown(l), o.longPressTimer && clearTimeout(o.longPressTimer), l.pointerType === "touch" && (o.longPressTimer = window.setTimeout(function() {
        o.props.model.isDragging || o.handleContextMenu(l);
      }, 500));
    }, o.handleFocus = function() {
      var l = o.props, u = l.model;
      l.graphModel.eventCenter.emit(L.NODE_FOCUS, { data: u.getData() });
    }, o.handleBlur = function() {
      if (o.props) {
        var l = o.props, u = l.model;
        l.graphModel.eventCenter.emit(L.NODE_BLUR, { data: u.getData() });
      }
    }, o.setHoverOn = function(l) {
      var u = o.props, c = u.model, d = u.graphModel;
      if (!c.isHovered) {
        var f = c.getData();
        c.setHovered(!0), d.eventCenter.emit(L.NODE_MOUSEENTER, {
          data: f,
          e: l
        });
      }
    }, o.setHoverOff = function(l) {
      var u = o.props, c = u.model, d = u.graphModel, f = c.getData();
      c.isHovered && (c.setHovered(!1), d.eventCenter.emit(L.NODE_MOUSELEAVE, {
        data: f,
        e: l
      }));
    };
    var n = e.graphModel, i = n.gridSize, a = n.eventCenter, s = e.model;
    return o.stepDrag = new de({
      onDragStart: o.onDragStart,
      onDragging: o.onDragging,
      onDragEnd: o.onDragEnd,
      step: i,
      eventType: "NODE",
      isStopPropagation: !1,
      eventCenter: a,
      model: s
    }), o.modelDisposer = Tl(function() {
      return o.props;
    }, function(l) {
      l && l.model && o.stepDrag.setModel(l.model);
    }), o;
  }
  return t.prototype.componentWillUnmount = function() {
    this.modelDisposer && this.modelDisposer(), this.render.$mobx && this.render.$mobx.dispose();
  }, t.prototype.componentDidMount = function() {
  }, t.prototype.componentDidUpdate = function() {
  }, t.prototype.getAnchorShape = function(e) {
    return null;
  }, t.prototype.getAnchors = function() {
    var e = this, o = this.props, n = o.model, i = o.graphModel, a = n.isSelected, s = n.isHitable, l = n.isDragging, u = n.isShowAnchor;
    return s && (a || u) && !l ? ce(n.anchors, function(c, d) {
      var f = n.getAnchorLineStyle(c), p = n.getAnchorStyle(c);
      return S(Oh, {
        anchorData: c,
        node: e,
        style: p,
        edgeStyle: f,
        anchorIndex: d,
        nodeModel: n,
        graphModel: i,
        setHoverOff: e.setHoverOff
      });
    }) : [];
  }, t.prototype.getRotateControl = function() {
    var e = this.props, o = e.model, n = e.graphModel, i = n.editConfigModel, a = i.isSilentMode, s = i.allowRotate, l = o.isSelected, u = o.isHitable, c = o.rotatable, d = o.isHovered, f = s && c, p = o.getRotateControlStyle();
    if (!a && u && (l || d) && f) return S(Sh, {
      graphModel: n,
      nodeModel: o,
      eventCenter: n.eventCenter,
      style: p
    });
  }, t.prototype.getResizeControl = function() {
    var e = this.props, o = e.model, n = e.graphModel, i = n.editConfigModel, a = i.isSilentMode, s = i.allowResize, l = o.isSelected, u = o.isHitable, c = o.resizable, d = o.isHovered, f = s && c, p = o.getResizeControlStyle();
    return !a && u && (l || d) && f ? S(Uf, {
      style: p,
      model: o,
      graphModel: n
    }) : null;
  }, t.prototype.getText = function() {
    var e, o = this.props, n = o.model, i = o.graphModel, a = i.editConfigModel;
    if (a.nodeTextMode !== Xt.TEXT || n.state === J.TEXT_EDIT) return null;
    if (n.text) {
      var s = !1;
      return a.nodeTextDraggable && n.text.draggable && (s = !0), S(pu, {
        editable: a.nodeTextEdit && ((e = n.text.editable) !== null && e !== void 0 ? e : !0),
        model: n,
        graphModel: i,
        draggable: s
      });
    }
    return null;
  }, t.prototype.getStateClassName = function() {
    var e = this.props.model, o = e.state, n = e.isDragging, i = e.isSelected, a = "lf-node";
    switch (o) {
      case J.ALLOW_CONNECT:
        a += " lf-node-allow";
        break;
      case J.NOT_ALLOW_CONNECT:
        a += " lf-node-not-allow";
        break;
      default:
        a += " lf-node-default";
    }
    return n && (a += " lf-dragging"), i && (a += " lf-node-selected"), a;
  }, t.prototype.toFront = function() {
    var e = this.props, o = e.model, n = e.graphModel;
    o.autoToFront && n.toFront(o.id);
  }, t.prototype.render = function() {
    var e = this.props, o = e.model, n = e.graphModel, i = n.editConfigModel, a = i.hideAnchors, s = i.adjustNodePosition, l = i.allowRotate, u = i.allowResize, c = n.gridSize, d = n.transformModel.SCALE_X, f = o.isHitable, p = o.draggable, v = o.transform, h = o.getOuterGAttributes(), g = h.className, y = g === void 0 ? "" : g, _ = Lh(h, ["className"]), E = S("g", {
      className: "lf-node-content",
      children: [S("g", {
        transform: v,
        children: [
          this.getShape(),
          this.getText(),
          u && this.getResizeControl(),
          l && this.getRotateControl()
        ]
      }), !a && this.getAnchors()]
    }), x;
    return f ? (s && p && this.stepDrag.setStep(c * d), x = S("g", dn({
      className: "".concat(this.getStateClassName(), " ").concat(y),
      onPointerDown: this.handleMouseDown,
      onPointerUp: this.handleMouseUp,
      onClick: this.handleClick,
      onMouseEnter: this.setHoverOn,
      onMouseOver: this.setHoverOn,
      onMouseLeave: this.setHoverOff,
      onMouseOut: this.onMouseOut,
      onContextMenu: this.handleContextMenu,
      onFocus: this.handleFocus,
      onBlur: this.handleBlur
    }, _, { children: E }))) : x = S("g", dn({ className: "".concat(this.getStateClassName(), " ").concat(y) }, _, { children: E })), x;
  }, t.isObserved = !1, t;
})(V), jh = /* @__PURE__ */ (function() {
  var r = function(t, e) {
    return r = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(o, n) {
      o.__proto__ = n;
    } || function(o, n) {
      for (var i in n) Object.prototype.hasOwnProperty.call(n, i) && (o[i] = n[i]);
    }, r(t, e);
  };
  return function(t, e) {
    if (typeof e != "function" && e !== null) throw new TypeError("Class extends value " + String(e) + " is not a constructor or null");
    r(t, e);
    function o() {
      this.constructor = t;
    }
    t.prototype = e === null ? Object.create(e) : (o.prototype = e.prototype, new o());
  };
})(), Ei = function() {
  return Ei = Object.assign || function(r) {
    for (var t, e = 1, o = arguments.length; e < o; e++) {
      t = arguments[e];
      for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && (r[n] = t[n]);
    }
    return r;
  }, Ei.apply(this, arguments);
}, ks = (function(r) {
  jh(t, r);
  function t() {
    return r !== null && r.apply(this, arguments) || this;
  }
  return t.prototype.getShape = function() {
    var e = this.props.model, o = e.getNodeStyle();
    return S(Te, Ei({}, o, {
      x: e.x,
      y: e.y,
      width: e.width,
      height: e.height,
      radius: e.radius
    }));
  }, t;
})(Le), Rh = /* @__PURE__ */ (function() {
  var r = function(t, e) {
    return r = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(o, n) {
      o.__proto__ = n;
    } || function(o, n) {
      for (var i in n) Object.prototype.hasOwnProperty.call(n, i) && (o[i] = n[i]);
    }, r(t, e);
  };
  return function(t, e) {
    if (typeof e != "function" && e !== null) throw new TypeError("Class extends value " + String(e) + " is not a constructor or null");
    r(t, e);
    function o() {
      this.constructor = t;
    }
    t.prototype = e === null ? Object.create(e) : (o.prototype = e.prototype, new o());
  };
})(), bi = function() {
  return bi = Object.assign || function(r) {
    for (var t, e = 1, o = arguments.length; e < o; e++) {
      t = arguments[e];
      for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && (r[n] = t[n]);
    }
    return r;
  }, bi.apply(this, arguments);
}, Bs = (function(r) {
  Rh(t, r);
  function t() {
    return r !== null && r.apply(this, arguments) || this;
  }
  return t.prototype.getShape = function() {
    var e = this.props.model, o = e.x, n = e.y, i = e.r, a = e.getNodeStyle();
    return S(Er, bi({}, a, {
      x: o,
      y: n,
      r: i
    }));
  }, t;
})(Le), Ih = /* @__PURE__ */ (function() {
  var r = function(t, e) {
    return r = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(o, n) {
      o.__proto__ = n;
    } || function(o, n) {
      for (var i in n) Object.prototype.hasOwnProperty.call(n, i) && (o[i] = n[i]);
    }, r(t, e);
  };
  return function(t, e) {
    if (typeof e != "function" && e !== null) throw new TypeError("Class extends value " + String(e) + " is not a constructor or null");
    r(t, e);
    function o() {
      this.constructor = t;
    }
    t.prototype = e === null ? Object.create(e) : (o.prototype = e.prototype, new o());
  };
})(), fn = function() {
  return fn = Object.assign || function(r) {
    for (var t, e = 1, o = arguments.length; e < o; e++) {
      t = arguments[e];
      for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && (r[n] = t[n]);
    }
    return r;
  }, fn.apply(this, arguments);
}, Xs = (function(r) {
  Ih(t, r);
  function t() {
    return r !== null && r.apply(this, arguments) || this;
  }
  return t.prototype.getShape = function() {
    var e = this.props.model, o = e, n = o.x, i = o.y, a = o.width, s = o.height, l = o.points, u = e.getNodeStyle(), c = { transform: "matrix(1 0 0 1 ".concat(n - a / 2, " ").concat(i - s / 2, ")") };
    return S("g", fn({}, c, { children: S(uu, fn({}, u, {
      points: l,
      x: n,
      y: i
    })) }));
  }, t;
})(Le), kh = /* @__PURE__ */ (function() {
  var r = function(t, e) {
    return r = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(o, n) {
      o.__proto__ = n;
    } || function(o, n) {
      for (var i in n) Object.prototype.hasOwnProperty.call(n, i) && (o[i] = n[i]);
    }, r(t, e);
  };
  return function(t, e) {
    if (typeof e != "function" && e !== null) throw new TypeError("Class extends value " + String(e) + " is not a constructor or null");
    r(t, e);
    function o() {
      this.constructor = t;
    }
    t.prototype = e === null ? Object.create(e) : (o.prototype = e.prototype, new o());
  };
})(), Oi = function() {
  return Oi = Object.assign || function(r) {
    for (var t, e = 1, o = arguments.length; e < o; e++) {
      t = arguments[e];
      for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && (r[n] = t[n]);
    }
    return r;
  }, Oi.apply(this, arguments);
}, Ys = (function(r) {
  kh(t, r);
  function t() {
    return r !== null && r.apply(this, arguments) || this;
  }
  return t.prototype.getShape = function() {
    var e = this.props.model, o = e.getNodeStyle();
    return S("g", { children: S(uu, Oi({}, o, {
      points: e.points,
      x: e.x,
      y: e.y
    })) });
  }, t;
})(Le), Bh = /* @__PURE__ */ (function() {
  var r = function(t, e) {
    return r = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(o, n) {
      o.__proto__ = n;
    } || function(o, n) {
      for (var i in n) Object.prototype.hasOwnProperty.call(n, i) && (o[i] = n[i]);
    }, r(t, e);
  };
  return function(t, e) {
    if (typeof e != "function" && e !== null) throw new TypeError("Class extends value " + String(e) + " is not a constructor or null");
    r(t, e);
    function o() {
      this.constructor = t;
    }
    t.prototype = e === null ? Object.create(e) : (o.prototype = e.prototype, new o());
  };
})(), wi = function() {
  return wi = Object.assign || function(r) {
    for (var t, e = 1, o = arguments.length; e < o; e++) {
      t = arguments[e];
      for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && (r[n] = t[n]);
    }
    return r;
  }, wi.apply(this, arguments);
}, Hs = (function(r) {
  Bh(t, r);
  function t() {
    return r !== null && r.apply(this, arguments) || this;
  }
  return t.prototype.getShape = function() {
    var e = this.props.model, o = e.getNodeStyle();
    return S(Bf, wi({}, o, {
      x: e.x,
      y: e.y,
      rx: e.rx,
      ry: e.ry
    }));
  }, t;
})(Le), Xh = /* @__PURE__ */ (function() {
  var r = function(t, e) {
    return r = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(o, n) {
      o.__proto__ = n;
    } || function(o, n) {
      for (var i in n) Object.prototype.hasOwnProperty.call(n, i) && (o[i] = n[i]);
    }, r(t, e);
  };
  return function(t, e) {
    if (typeof e != "function" && e !== null) throw new TypeError("Class extends value " + String(e) + " is not a constructor or null");
    r(t, e);
    function o() {
      this.constructor = t;
    }
    t.prototype = e === null ? Object.create(e) : (o.prototype = e.prototype, new o());
  };
})(), Wr = function() {
  return Wr = Object.assign || function(r) {
    for (var t, e = 1, o = arguments.length; e < o; e++) {
      t = arguments[e];
      for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && (r[n] = t[n]);
    }
    return r;
  }, Wr.apply(this, arguments);
}, Gs = (function(r) {
  Xh(t, r);
  function t() {
    return r !== null && r.apply(this, arguments) || this;
  }
  return t.prototype.getBackground = function() {
    var e = this.props.model, o = e.getTextStyle(), n = e.width, i = e.height, a = e.x, s = e.y, l = Wr(Wr({}, o.background), {
      x: a,
      y: s,
      width: n,
      height: i
    });
    return S(Te, Wr({}, l));
  }, t.prototype.getResizeControl = function() {
    return null;
  }, t.prototype.getShape = function() {
    return S("g", { children: this.getBackground() });
  }, t;
})(Le), Yh = /* @__PURE__ */ (function() {
  var r = function(t, e) {
    return r = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(o, n) {
      o.__proto__ = n;
    } || function(o, n) {
      for (var i in n) Object.prototype.hasOwnProperty.call(n, i) && (o[i] = n[i]);
    }, r(t, e);
  };
  return function(t, e) {
    if (typeof e != "function" && e !== null) throw new TypeError("Class extends value " + String(e) + " is not a constructor or null");
    r(t, e);
    function o() {
      this.constructor = t;
    }
    t.prototype = e === null ? Object.create(e) : (o.prototype = e.prototype, new o());
  };
})(), Kr = function() {
  return Kr = Object.assign || function(r) {
    for (var t, e = 1, o = arguments.length; e < o; e++) {
      t = arguments[e];
      for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && (r[n] = t[n]);
    }
    return r;
  }, Kr.apply(this, arguments);
}, Hh = function(r, t) {
  var e = typeof Symbol == "function" && r[Symbol.iterator];
  if (!e) return r;
  var o = e.call(r), n, i = [], a;
  try {
    for (; (t === void 0 || t-- > 0) && !(n = o.next()).done; ) i.push(n.value);
  } catch (s) {
    a = { error: s };
  } finally {
    try {
      n && !n.done && (e = o.return) && e.call(o);
    } finally {
      if (a) throw a.error;
    }
  }
  return i;
}, Gh = function(r, t, e) {
  if (e || arguments.length === 2)
    for (var o = 0, n = t.length, i; o < n; o++) (i || !(o in t)) && (i || (i = Array.prototype.slice.call(t, 0, o)), i[o] = t[o]);
  return r.concat(i || Array.prototype.slice.call(t));
}, Si = (function(r) {
  Yh(t, r);
  function t() {
    var e = r.apply(this, Gh([], Hh(arguments), !1)) || this;
    return e.ref = Hi(), e;
  }
  return Object.defineProperty(t.prototype, "rootEl", {
    get: function() {
      return this.ref.current;
    },
    enumerable: !1,
    configurable: !0
  }), t.prototype.setHtml = function(e) {
    e.appendChild(document.createElement("div"));
  }, t.prototype.confirmUpdate = function(e) {
    this.setHtml(e);
  }, t.prototype.shouldUpdate = function() {
    return this.preProperties && this.preProperties === this.currentProperties ? !1 : (this.preProperties = this.currentProperties, !0);
  }, t.prototype.componentDidMount = function() {
    this.shouldUpdate() && this.rootEl && this.setHtml(this.rootEl);
  }, t.prototype.componentDidUpdate = function() {
    this.shouldUpdate() && this.rootEl && this.confirmUpdate(this.rootEl);
  }, t.prototype.componentWillUnmount = function() {
    r.prototype.componentWillUnmount.call(this), this.rootEl.innerHTML = "";
  }, t.prototype.getShape = function() {
    var e = this.props.model, o = e.x, n = e.y, i = e.height, a = e.width, s = e.getNodeStyle();
    return this.currentProperties = JSON.stringify(e.properties), S("g", { children: [
      s.shadow && S("defs", { children: S("filter", {
        id: "shadow",
        x: "-50%",
        y: "-50%",
        width: "200%",
        height: "200%",
        children: S("feDropShadow", Kr({}, s.shadow))
      }) }),
      S("rect", Kr({
        x: o - a / 2,
        y: n - i / 2,
        width: a,
        height: i,
        rx: s.radius,
        ry: s.radius
      }, s, { filter: "url(#shadow)" })),
      S("foreignObject", Kr({}, s, {
        x: o - a / 2,
        y: n - i / 2,
        width: a,
        height: i,
        ref: this.ref
      }))
    ] });
  }, t;
})(Le), zh = /* @__PURE__ */ (function() {
  var r = function(t, e) {
    return r = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(o, n) {
      o.__proto__ = n;
    } || function(o, n) {
      for (var i in n) Object.prototype.hasOwnProperty.call(n, i) && (o[i] = n[i]);
    }, r(t, e);
  };
  return function(t, e) {
    if (typeof e != "function" && e !== null) throw new TypeError("Class extends value " + String(e) + " is not a constructor or null");
    r(t, e);
    function o() {
      this.constructor = t;
    }
    t.prototype = e === null ? Object.create(e) : (o.prototype = e.prototype, new o());
  };
})(), Vt = function() {
  return Vt = Object.assign || function(r) {
    for (var t, e = 1, o = arguments.length; e < o; e++) {
      t = arguments[e];
      for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && (r[n] = t[n]);
    }
    return r;
  }, Vt.apply(this, arguments);
}, $h = function(r, t) {
  var e = {};
  for (var o in r) Object.prototype.hasOwnProperty.call(r, o) && t.indexOf(o) < 0 && (e[o] = r[o]);
  if (r != null && typeof Object.getOwnPropertySymbols == "function")
    for (var n = 0, o = Object.getOwnPropertySymbols(r); n < o.length; n++) t.indexOf(o[n]) < 0 && Object.prototype.propertyIsEnumerable.call(r, o[n]) && (e[o[n]] = r[o[n]]);
  return e;
}, Uh = function(r, t) {
  var e = typeof Symbol == "function" && r[Symbol.iterator];
  if (!e) return r;
  var o = e.call(r), n, i = [], a;
  try {
    for (; (t === void 0 || t-- > 0) && !(n = o.next()).done; ) i.push(n.value);
  } catch (s) {
    a = { error: s };
  } finally {
    try {
      n && !n.done && (e = o.return) && e.call(o);
    } finally {
      if (a) throw a.error;
    }
  }
  return i;
}, se;
(function(r) {
  r.SOURCE = "SOURCE", r.TARGET = "TARGET";
})(se || (se = {}));
var zs = (function(r) {
  zh(t, r);
  function t(e) {
    var o = r.call(this) || this;
    o.handleMouseDown = function(s) {
      o.stepDrag && o.stepDrag.handleMouseDown(s);
    }, o.onDragStart = function() {
      var s = o.props, l = s.x, u = s.y, c = s.edgeModel;
      o.oldEdge = {
        startPoint: c.startPoint,
        endPoint: c.endPoint,
        pointsList: c.pointsList
      }, o.setState({
        endX: l,
        endY: u,
        dragging: !0
      });
    }, o.onDragging = function(s) {
      var l = s.deltaX, u = s.deltaY, c = o.state, d = c.endX, f = c.endY, p = o.props, v = p.graphModel, h = p.type, g = v.transformModel, y = v.editConfigModel, _ = Uh(g.moveCanvasPointByHtml([d, f], l, u), 2), E = _[0], x = _[1];
      o.setState({
        endX: E,
        endY: x,
        dragging: !0
      });
      var O = o.props.edgeModel, M = sn({
        x: d,
        y: f
      }, v);
      if (M && M.node && o.isAllowAdjust(M).pass) {
        var P = O.startPoint, m = O.endPoint, w = O.sourceNode, T = O.targetNode, D = h === se.SOURCE ? {
          startPoint: {
            x: M.anchor.x,
            y: M.anchor.y
          },
          endPoint: {
            x: m.x,
            y: m.y
          },
          sourceNode: M.node,
          targetNode: T
        } : {
          startPoint: {
            x: P.x,
            y: P.y
          },
          endPoint: {
            x: M.anchor.x,
            y: M.anchor.y
          },
          sourceNode: w,
          targetNode: M.node
        };
        O.updateAfterAdjustStartAndEnd(D);
      } else h === se.SOURCE ? O.updateStartPoint({
        x: E,
        y: x
      }) : O.updateEndPoint({
        x: E,
        y: x
      });
      O.text.value && y.adjustEdge && O.setText(Object.assign({}, O.text, O.textPosition));
    }, o.onDragEnd = function(s) {
      var l, u, c, d = s.event;
      try {
        o.setState({ dragging: !1 });
        var f = o.props, p = f.graphModel, v = f.edgeModel, h = f.type, g = o.state, y = g.endX, _ = g.endY, E = g.dragging, x = sn({
          x: y,
          y: _
        }, p);
        if (!E) return;
        var O = !1, M = void 0;
        if (x && x.node) {
          var P = o.isAllowAdjust(x), m = P.pass, w = P.msg, T = P.newTargetNode;
          if (m) {
            var D = v.getData(), B = D.text, Z = D.sourceAnchorId, et = Z === void 0 ? "" : Z, ht = D.targetAnchorId, vt = ht === void 0 ? "" : ht, ut = $h(D, [
              "text",
              "sourceAnchorId",
              "targetAnchorId"
            ]);
            if (M = Vt(Vt({
              sourceAnchorId: et,
              targetAnchorId: vt
            }, ut), { text: (B == null ? void 0 : B.value) || "" }), h === se.SOURCE) {
              var rt = p.getNodeModelById(x.node.id), gt = p.getNodeModelById(v.targetNodeId), ge = (l = p.edgeGenerator) === null || l === void 0 ? void 0 : l.call(p, rt == null ? void 0 : rt.getData(), gt == null ? void 0 : gt.getData(), M);
              M = Vt(Vt({}, ge), {
                sourceNodeId: x.node.id,
                sourceAnchorId: x.anchor.id,
                startPoint: {
                  x: x.anchor.x,
                  y: x.anchor.y
                },
                targetNodeId: v.targetNodeId,
                endPoint: Vt({}, v.endPoint)
              }), v.sourceNodeId === x.node.id && v.sourceAnchorId === x.anchor.id && (O = !0);
            } else if (h === se.TARGET) {
              var rt = p.getNodeModelById(v.sourceNodeId), gt = p.getNodeModelById(x.node.id), ge = (u = p.edgeGenerator) === null || u === void 0 ? void 0 : u.call(p, rt == null ? void 0 : rt.getData(), gt == null ? void 0 : gt.getData(), M);
              M = Vt(Vt({}, ge), {
                sourceNodeId: v.sourceNodeId,
                startPoint: Vt({}, v.startPoint),
                targetNodeId: x.node.id,
                targetAnchorId: x.anchor.id,
                endPoint: {
                  x: x.anchor.x,
                  y: x.anchor.y
                }
              }), v.targetNodeId === x.node.id && v.targetAnchorId === x.anchor.id && (O = !0);
            }
          } else {
            O = !0;
            var je = T.getData();
            p.eventCenter.emit(L.CONNECTION_NOT_ALLOWED, {
              data: je,
              msg: w
            });
          }
        } else O = !0;
        if (O)
          o.recoveryEdge();
        else {
          var Y = v.getData();
          p.deleteEdgeById(v.id);
          var q = p.addEdge(Vt({}, M));
          p.eventCenter.emit(L.EDGE_EXCHANGE_NODE, { data: {
            newEdge: q.getData(),
            oldEdge: Y
          } });
        }
        (c = o.preTargetNode) === null || c === void 0 || c.setElementState(J.DEFAULT);
      } finally {
        var p = o.props.graphModel;
        p.eventCenter.emit(L.ADJUST_POINT_DRAGEND, {
          e: d,
          data: o.stepDragData
        });
      }
    }, o.recoveryEdge = function() {
      var s = o.props.edgeModel, l = o.oldEdge, u = l.startPoint, c = l.endPoint, d = l.pointsList;
      s.updateStartPoint(u), s.updateEndPoint(c), s.modelType !== G.LINE_EDGE && (s.pointsList = d != null ? d : [], s.initPoints());
    }, o.getAdjustPointStyle = function() {
      return o.props.graphModel.theme.edgeAdjust;
    }, o.state = {
      dragging: !1,
      endX: 0,
      endY: 0
    }, o.targetRuleResults = /* @__PURE__ */ new Map(), o.sourceRuleResults = /* @__PURE__ */ new Map();
    var n = e.type, i = e.edgeModel, a = e.graphModel.eventCenter;
    return o.stepDragData = {
      type: n,
      edgeData: i.getData()
    }, o.stepDrag = new de({
      onDragStart: o.onDragStart,
      onDragging: o.onDragging,
      onDragEnd: o.onDragEnd,
      eventType: "ADJUST_POINT",
      isStopPropagation: !1,
      eventCenter: a,
      data: o.stepDragData
    }), o;
  }
  return t.prototype.isAllowAdjust = function(e) {
    var o = this.props, n = o.edgeModel, i = n.id, a = n.sourceNode, s = n.targetNode, l = n.sourceAnchorId, u = n.targetAnchorId, c = o.type, d, f, p, v;
    if (c === se.SOURCE ? (d = e.node, f = s, p = e.anchor, v = s.getAnchorInfo(u)) : (d = a, f = e.node, v = e.anchor, p = a.getAnchorInfo(l)), this.preTargetNode && this.preTargetNode !== e.node && this.preTargetNode.setElementState(J.DEFAULT), this.preTargetNode = e.node, v.id === p.id) return {
      pass: !1,
      msg: "",
      newTargetNode: f
    };
    var h = "".concat(d.id, "_").concat(f.id, "_").concat(p.id, "_").concat(v.id);
    if (!this.targetRuleResults.has(h)) {
      var g = d.isAllowConnectedAsSource(f, p, v, i), y = f.isAllowConnectedAsTarget(d, p, v, i);
      this.sourceRuleResults.set(h, ln(g)), this.targetRuleResults.set(h, ln(y));
    }
    var _ = this.sourceRuleResults.get(h), E = _.isAllPass, x = _.msg, O = this.targetRuleResults.get(h), M = O.isAllPass, P = O.msg, m = E && M ? J.ALLOW_CONNECT : J.NOT_ALLOW_CONNECT;
    return c === se.SOURCE ? d.setElementState(m) : f.setElementState(m), {
      pass: E && M,
      msg: P || x,
      newTargetNode: f
    };
  }, t.prototype.render = function() {
    var e = this.props, o = e.x, n = e.y, i = e.getAdjustPointShape, a = e.edgeModel, s = this.state.dragging;
    return S("g", {
      pointerEvents: s ? "none" : "",
      onPointerDown: this.handleMouseDown,
      children: s ? "" : i(o, n, a)
    });
  }, t;
})(V), Vh = /* @__PURE__ */ (function() {
  var r = function(t, e) {
    return r = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(o, n) {
      o.__proto__ = n;
    } || function(o, n) {
      for (var i in n) Object.prototype.hasOwnProperty.call(n, i) && (o[i] = n[i]);
    }, r(t, e);
  };
  return function(t, e) {
    if (typeof e != "function" && e !== null) throw new TypeError("Class extends value " + String(e) + " is not a constructor or null");
    r(t, e);
    function o() {
      this.constructor = t;
    }
    t.prototype = e === null ? Object.create(e) : (o.prototype = e.prototype, new o());
  };
})(), Ai = function() {
  return Ai = Object.assign || function(r) {
    for (var t, e = 1, o = arguments.length; e < o; e++) {
      t = arguments[e];
      for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && (r[n] = t[n]);
    }
    return r;
  }, Ai.apply(this, arguments);
}, uy = (function(r) {
  Vh(t, r);
  function t() {
    return r !== null && r.apply(this, arguments) || this;
  }
  return t.prototype.getArrowAttributes = function() {
    var e = this.props, o = e.arrowInfo, n = e.style, i = o.start, a = o.end, s = {
      start: i,
      end: a,
      offset: n.offset,
      verticalLength: n.verticalLength,
      type: "end"
    }, l = ro(s), u = l.leftX, c = l.leftY, d = l.rightX, f = l.rightY;
    return Ai({ d: "M".concat(u, " ").concat(c, " L").concat(a.x, " ").concat(a.y, " L").concat(d, " ").concat(f, " z") }, n);
  }, t.prototype.getShape = function() {
    var e = this.getArrowAttributes(), o = e.d, n = e.strokeWidth, i = e.stroke, a = e.fill;
    return S(no, {
      d: o,
      fill: a,
      strokeWidth: n,
      stroke: i
    });
  }, t.prototype.render = function() {
    return S("g", {
      className: "lf-arrow",
      children: this.getShape()
    });
  }, t;
})(V), Fh = /* @__PURE__ */ (function() {
  var r = function(t, e) {
    return r = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(o, n) {
      o.__proto__ = n;
    } || function(o, n) {
      for (var i in n) Object.prototype.hasOwnProperty.call(n, i) && (o[i] = n[i]);
    }, r(t, e);
  };
  return function(t, e) {
    if (typeof e != "function" && e !== null) throw new TypeError("Class extends value " + String(e) + " is not a constructor or null");
    r(t, e);
    function o() {
      this.constructor = t;
    }
    t.prototype = e === null ? Object.create(e) : (o.prototype = e.prototype, new o());
  };
})(), Zr = function() {
  return Zr = Object.assign || function(r) {
    for (var t, e = 1, o = arguments.length; e < o; e++) {
      t = arguments[e];
      for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && (r[n] = t[n]);
    }
    return r;
  }, Zr.apply(this, arguments);
}, Wh = function(r, t) {
  var e = typeof Symbol == "function" && r[Symbol.iterator];
  if (!e) return r;
  var o = e.call(r), n, i = [], a;
  try {
    for (; (t === void 0 || t-- > 0) && !(n = o.next()).done; ) i.push(n.value);
  } catch (s) {
    a = { error: s };
  } finally {
    try {
      n && !n.done && (e = o.return) && e.call(o);
    } finally {
      if (a) throw a.error;
    }
  }
  return i;
}, wn = (function(r) {
  Fh(t, r);
  function t() {
    var e = r.call(this) || this;
    return e.textRef = Hi(), e.handleHover = function(o, n) {
      var i = e.props, a = i.model, s = i.graphModel.eventCenter;
      a.setHovered(o);
      var l = o ? L.EDGE_MOUSEENTER : L.EDGE_MOUSELEAVE, u = a.getData();
      s.emit(l, {
        data: u,
        e: n
      });
    }, e.setHoverOn = function(o) {
      e.props.model.isHovered || (e.textRef && e.textRef.current && e.textRef.current.setHoverOn(), e.handleHover(!0, o));
    }, e.setHoverOff = function(o) {
      e.props.model.isHovered && (e.textRef && e.textRef.current && e.textRef.current.setHoverOff(), e.handleHover(!1, o));
    }, e.handleContextMenu = function(o) {
      o.preventDefault(), e.contextMenuTime = (/* @__PURE__ */ new Date()).getTime(), e.clickTimer && clearTimeout(e.clickTimer);
      var n = e.props, i = n.model, a = n.graphModel, s = a.editConfigModel, l = a.getPointByClient({
        x: o.clientX,
        y: o.clientY
      });
      a.setElementStateById(i.id, J.SHOW_MENU, l.domOverlayPosition), s.isSilentMode || e.toFront(), i.isSelected || a.selectEdgeById(i.id);
      var u = i == null ? void 0 : i.getData();
      a.eventCenter.emit(L.EDGE_CONTEXTMENU, {
        data: u,
        e: o,
        position: l
      });
    }, e.handleMouseDown = function(o) {
      o.stopPropagation(), e.startTime = (/* @__PURE__ */ new Date()).getTime(), e.longPressTimer && clearTimeout(e.longPressTimer), o.pointerType === "touch" && (e.longPressTimer = window.setTimeout(function() {
        e.props.model.isDragging || e.handleContextMenu(o);
      }, 500));
    }, e.handleMouseUp = function() {
      e.mouseUpDrag = e.props.model.isDragging, e.longPressTimer && (clearTimeout(e.longPressTimer), e.longPressTimer = void 0);
    }, e.handleClick = function(o) {
      if (e.startTime && !e.mouseUpDrag && o.button !== 2) {
        var n = o.detail === 2, i = e.props, a = i.model, s = i.graphModel, l = a == null ? void 0 : a.getData(), u = s.getPointByClient({
          x: o.clientX,
          y: o.clientY
        });
        if (n) {
          var c = s.editConfigModel, d = s.textEditElement, f = a.id, p = a.text, v = a.modelType;
          if (d && d.id === f && s.setElementStateById(f, J.DEFAULT), c.edgeTextEdit && p.editable && (a.setSelected(!1), s.setElementStateById(f, J.TEXT_EDIT)), v === G.POLYLINE_EDGE) {
            var h = a, g = s.getPointByClient({
              x: o.x,
              y: o.y
            }).canvasOverlayPosition, y = g.x, _ = g.y;
            h.dbClickPosition = ru({
              x: y,
              y: _
            }, h.points);
          }
          s.eventCenter.emit(L.EDGE_DBCLICK, {
            data: l,
            e: o,
            position: u
          });
        } else {
          s.eventCenter.emit(L.ELEMENT_CLICK, {
            data: l,
            e: o,
            position: u
          }), s.eventCenter.emit(L.EDGE_CLICK, {
            data: l,
            e: o,
            position: u
          });
          var E = o.currentTarget;
          (!yt(window) && ki(window.requestAnimationFrame) ? window.requestAnimationFrame.bind(window) : function(O) {
            return setTimeout(O, 0);
          })(function() {
            E.focus();
          });
        }
        var x = s.editConfigModel;
        s.selectEdgeById(a.id, nu(o, x)), x.isSilentMode || e.toFront();
      }
    }, e.handleFocus = function() {
      var o = e.props, n = o.model;
      o.graphModel.eventCenter.emit(L.EDGE_FOCUS, { data: n.getData() });
    }, e.handleBlur = function() {
      var o = e.props, n = o.model;
      o.graphModel.eventCenter.emit(L.EDGE_BLUR, { data: n.getData() });
    }, e;
  }
  return t.prototype.getShape = function() {
    return S("g", { children: this.getEdge() });
  }, t.prototype.getTextStyle = function() {
  }, t.prototype.getText = function() {
    var e, o = this.props, n = o.model, i = o.graphModel, a = i.editConfigModel;
    if (a.edgeTextMode !== Xt.TEXT || n.state === J.TEXT_EDIT) return null;
    if (n.text) {
      var s = !1;
      return a.edgeTextDraggable && n.text.draggable && (s = !0), S(Dh, {
        ref: this.textRef,
        editable: a.edgeTextEdit && ((e = n.text.editable) !== null && e !== void 0 ? e : !0),
        model: n,
        graphModel: i,
        draggable: s
      });
    }
    return null;
  }, t.prototype.getArrowInfo = function() {
    var e = this.props.model, o = e.startPoint, n = e.endPoint, i = e.isSelected;
    return {
      start: o,
      end: n,
      hover: this.state.hover,
      isSelected: i
    };
  }, t.prototype.getLastTwoPoints = function() {
    var e = this.props.model;
    return [e.startPoint, e.endPoint];
  }, t.prototype.getArrowStyle = function() {
    return null;
  }, t.prototype.getArrow = function() {
    var e = this.props.model, o = e.id, n = e.getArrowStyle(), i = n.refY, a = i === void 0 ? 0 : i, s = n.refX, l = s === void 0 ? 2 : s, u = Wh(this.getLastTwoPoints(), 2), c = u[0], d = u[1], f = "auto";
    if (c && d) {
      var p = d.x - c.x, v = d.y - c.y;
      if (p !== 0 || v !== 0) {
        var h = lp(sp({
          x: p,
          y: v,
          z: 0
        }));
        Number.isFinite(h) && !Number.isNaN(h) && (f = h);
      }
    }
    return S("g", { children: S("defs", { children: [S("marker", {
      id: "marker-start-".concat(o),
      refX: -l,
      refY: a,
      overflow: "visible",
      orient: "auto",
      markerUnits: "userSpaceOnUse",
      children: this.getStartArrow()
    }), S("marker", {
      id: "marker-end-".concat(o),
      refX: l,
      refY: a,
      overflow: "visible",
      orient: f,
      markerUnits: "userSpaceOnUse",
      children: this.getEndArrow()
    })] }) });
  }, t.prototype.getArrowPath = function(e, o) {
    var n = o.stroke, i = o.fill, a = i === void 0 ? n : i, s = o.strokeWidth, l = o.offset, u = l === void 0 ? 10 : l, c = o.verticalLength, d = o.strokeLinecap, f = o.strokeLinejoin, p = o.transform, v = "";
    switch (e) {
      case "solid":
        v = "M".concat(-u / 4, ",0 L").concat(3 * u / 4, ",").concat(c, " L").concat(3 * u / 4, ",-").concat(c, " Z");
        break;
      case "hollow":
        v = "M".concat(-u / 4, ",0 L").concat(3 * u / 4, ",").concat(c, " L").concat(-u / 4, ",0 L").concat(3 * u / 4, ",-").concat(c, " L").concat(-u / 4, ",0 Z");
        break;
      case "diamond":
        v = "M".concat(-u / 2, ",0 L0,").concat(c, " L").concat(u / 2, ",0 L0,-").concat(c, " L").concat(-u / 2, ",0 Z");
        break;
      case "circle":
        v = "M".concat(-u / 2, ",0 A").concat(u / 4, ",").concat(u / 4, " 0 1,0 ").concat(u / 2, ",0 A").concat(u / 4, ",").concat(u / 4, " 0 1,0 ").concat(-u / 2, ",0 Z");
        break;
      default:
        v = "";
    }
    return S("path", {
      d: v,
      stroke: n,
      fill: a,
      strokeWidth: s,
      strokeLinecap: d,
      strokeLinejoin: f,
      transform: p
    });
  }, t.prototype.getStartArrow = function() {
    var e = this.props.model.getArrowStyle(), o = e.stroke, n = e.strokeWidth, i = e.offset, a = e.verticalLength, s = e.startArrowType, l = s === void 0 ? "none" : s, u = e.strokeLinecap, c = e.strokeLinejoin;
    return this.getArrowPath(l, {
      stroke: o,
      strokeWidth: n,
      offset: i,
      verticalLength: a,
      strokeLinecap: u,
      strokeLinejoin: c
    });
  }, t.prototype.getEndArrow = function() {
    var e = this.props.model.getArrowStyle(), o = e.stroke, n = e.strokeWidth, i = e.offset, a = e.verticalLength, s = e.endArrowType, l = s === void 0 ? "solid" : s, u = e.strokeLinecap, c = e.strokeLinejoin;
    return this.getArrowPath(l, {
      stroke: o,
      strokeWidth: n,
      offset: i,
      verticalLength: a,
      strokeLinecap: u,
      strokeLinejoin: c,
      transform: "rotate(180)"
    });
  }, t.prototype.getAdjustPointShape = function(e, o, n) {
    var i = n.getAdjustPointStyle();
    return S(Er, Zr({ className: "lf-edge-adjust-point" }, i, {
      x: e,
      y: o
    }));
  }, t.prototype.getAdjustPoints = function() {
    var e = this.props, o = e.model, n = e.graphModel, i = n.editConfigModel, a = i.adjustEdgeStartAndEnd, s = i.adjustEdgeStart, l = i.adjustEdgeEnd, u = o.getAdjustStart(), c = o.getAdjustEnd();
    return S("g", { children: [a && s && S(zs, Zr({ type: se.SOURCE }, u, {
      getAdjustPointShape: this.getAdjustPointShape,
      edgeModel: o,
      graphModel: n
    })), a && l && S(zs, Zr({ type: se.TARGET }, c, {
      getAdjustPointShape: this.getAdjustPointShape,
      edgeModel: o,
      graphModel: n
    }))] });
  }, t.prototype.getAnimation = function() {
  }, t.prototype.getAppendWidth = function() {
    return S("g", {});
  }, t.prototype.getAppend = function() {
    return S("g", {
      className: "lf-edge-append",
      children: this.getAppendWidth()
    });
  }, t.prototype.getEdge = function() {
    return null;
  }, t.prototype.toFront = function() {
    var e = this.props, o = e.graphModel, n = e.model;
    o.toFront(n.id);
  }, t.prototype.render = function() {
    var e = this.props.model, o = e.isSelected, n = e.isHitable, i = e.isShowAdjustPoint;
    return S("g", { children: [S("g", {
      className: [
        "lf-edge",
        !n && "pointer-none",
        o && "lf-edge-selected"
      ].filter(Boolean).join(" "),
      style: {
        touchAction: "none",
        WebkitTouchCallout: "none"
      },
      onClick: this.handleClick,
      onContextMenu: this.handleContextMenu,
      onPointerDown: this.handleMouseDown,
      onPointerUp: this.handleMouseUp,
      onPointerCancel: this.handleMouseUp,
      onMouseOver: this.setHoverOn,
      onMouseEnter: this.setHoverOn,
      onMouseLeave: this.setHoverOff,
      onFocus: this.handleFocus,
      onBlur: this.handleBlur,
      children: [
        this.getShape(),
        this.getAppend(),
        this.getText(),
        this.getArrow()
      ]
    }), i && o ? this.getAdjustPoints() : ""] });
  }, t.isObserved = !1, t;
})(V), Kh = /* @__PURE__ */ (function() {
  var r = function(t, e) {
    return r = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(o, n) {
      o.__proto__ = n;
    } || function(o, n) {
      for (var i in n) Object.prototype.hasOwnProperty.call(n, i) && (o[i] = n[i]);
    }, r(t, e);
  };
  return function(t, e) {
    if (typeof e != "function" && e !== null) throw new TypeError("Class extends value " + String(e) + " is not a constructor or null");
    r(t, e);
    function o() {
      this.constructor = t;
    }
    t.prototype = e === null ? Object.create(e) : (o.prototype = e.prototype, new o());
  };
})(), Mi = function() {
  return Mi = Object.assign || function(r) {
    for (var t, e = 1, o = arguments.length; e < o; e++) {
      t = arguments[e];
      for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && (r[n] = t[n]);
    }
    return r;
  }, Mi.apply(this, arguments);
}, Zh = function(r, t) {
  var e = typeof Symbol == "function" && r[Symbol.iterator];
  if (!e) return r;
  var o = e.call(r), n, i = [], a;
  try {
    for (; (t === void 0 || t-- > 0) && !(n = o.next()).done; ) i.push(n.value);
  } catch (s) {
    a = { error: s };
  } finally {
    try {
      n && !n.done && (e = o.return) && e.call(o);
    } finally {
      if (a) throw a.error;
    }
  }
  return i;
}, Pi = (function(r) {
  Kh(t, r);
  function t() {
    return r !== null && r.apply(this, arguments) || this;
  }
  return t.prototype.getEdge = function() {
    var e = this.props.model, o = e.getEdgeStyle(), n = e, i = n.path, a = n.isAnimation, s = n.arrowConfig, l = e.getEdgeAnimationStyle(), u = l.strokeDasharray, c = l.stroke, d = l.strokeDashoffset, f = l.animationName, p = l.animationDuration, v = l.animationIterationCount, h = l.animationTimingFunction, g = l.animationDirection;
    return S(no, Mi({ d: i }, o, s, a ? {
      strokeDasharray: u,
      stroke: c,
      style: {
        strokeDashoffset: d,
        animationName: f,
        animationDuration: p,
        animationIterationCount: v,
        animationTimingFunction: h,
        animationDirection: g
      }
    } : {}));
  }, t.prototype.getAppendWidth = function() {
    var e = this.props.model.path;
    return S(no, {
      d: e,
      strokeWidth: 10,
      stroke: "transparent",
      fill: "none"
    });
  }, t.prototype.getArrowInfo = function() {
    var e = this.props.model, o = this.state.hover, n = e.isSelected, i = e.getArrowStyle().offset, a = e.pointsList.map(function(l) {
      return {
        x: l.x,
        y: l.y
      };
    }), s = Zh(ps(a, i), 2);
    return {
      start: s[0],
      end: s[1],
      hover: o,
      isSelected: n
    };
  }, t.prototype.getLastTwoPoints = function() {
    var e = this.props.model, o = e.getArrowStyle().offset, n = e.pointsList.map(function(i) {
      return {
        x: i.x,
        y: i.y
      };
    });
    return ps(n, o);
  }, t;
})(wn), qh = /* @__PURE__ */ (function() {
  var r = function(t, e) {
    return r = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(o, n) {
      o.__proto__ = n;
    } || function(o, n) {
      for (var i in n) Object.prototype.hasOwnProperty.call(n, i) && (o[i] = n[i]);
    }, r(t, e);
  };
  return function(t, e) {
    if (typeof e != "function" && e !== null) throw new TypeError("Class extends value " + String(e) + " is not a constructor or null");
    r(t, e);
    function o() {
      this.constructor = t;
    }
    t.prototype = e === null ? Object.create(e) : (o.prototype = e.prototype, new o());
  };
})(), Ti = function() {
  return Ti = Object.assign || function(r) {
    for (var t, e = 1, o = arguments.length; e < o; e++) {
      t = arguments[e];
      for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && (r[n] = t[n]);
    }
    return r;
  }, Ti.apply(this, arguments);
}, Ni = (function(r) {
  qh(t, r);
  function t() {
    return r !== null && r.apply(this, arguments) || this;
  }
  return t.prototype.getEdge = function() {
    var e = this.props.model, o = e.startPoint, n = e.endPoint, i = e.isAnimation, a = e.arrowConfig, s = e.getEdgeStyle(), l = e.getEdgeAnimationStyle(), u = l.strokeDasharray, c = l.stroke, d = l.strokeDashoffset, f = l.animationName, p = l.animationDuration, v = l.animationIterationCount, h = l.animationTimingFunction, g = l.animationDirection;
    return S(xr, Ti({}, s, {
      x1: o.x,
      y1: o.y,
      x2: n.x,
      y2: n.y
    }, a, i ? {
      strokeDasharray: u,
      stroke: c,
      style: {
        strokeDashoffset: d,
        animationName: f,
        animationDuration: p,
        animationIterationCount: v,
        animationTimingFunction: h,
        animationDirection: g
      }
    } : {}));
  }, t.prototype.getAppendWidth = function() {
    var e = this.props.model, o = {
      start: e.startPoint,
      end: e.endPoint
    }, n = pf(o), i = n.d, a = n.strokeWidth, s = n.fill, l = n.strokeDasharray, u = n.stroke;
    return S(no, {
      d: i,
      fill: s,
      strokeWidth: a,
      stroke: u,
      strokeDasharray: l
    });
  }, t;
})(wn), Jh = /* @__PURE__ */ (function() {
  var r = function(t, e) {
    return r = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(o, n) {
      o.__proto__ = n;
    } || function(o, n) {
      for (var i in n) Object.prototype.hasOwnProperty.call(n, i) && (o[i] = n[i]);
    }, r(t, e);
  };
  return function(t, e) {
    if (typeof e != "function" && e !== null) throw new TypeError("Class extends value " + String(e) + " is not a constructor or null");
    r(t, e);
    function o() {
      this.constructor = t;
    }
    t.prototype = e === null ? Object.create(e) : (o.prototype = e.prototype, new o());
  };
})(), Be = function() {
  return Be = Object.assign || function(r) {
    for (var t, e = 1, o = arguments.length; e < o; e++) {
      t = arguments[e];
      for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && (r[n] = t[n]);
    }
    return r;
  }, Be.apply(this, arguments);
}, Qh = function(r, t) {
  var e = typeof Symbol == "function" && r[Symbol.iterator];
  if (!e) return r;
  var o = e.call(r), n, i = [], a;
  try {
    for (; (t === void 0 || t-- > 0) && !(n = o.next()).done; ) i.push(n.value);
  } catch (s) {
    a = { error: s };
  } finally {
    try {
      n && !n.done && (e = o.return) && e.call(o);
    } finally {
      if (a) throw a.error;
    }
  }
  return i;
}, $s = (function(r) {
  Jh(t, r);
  function t() {
    var e = r.call(this) || this;
    return e.onDragStart = function() {
      var o = e.props.model;
      o.dragAppendStart(), e.isShowAdjustPointTemp = o.isShowAdjustPoint, o.isShowAdjustPoint = !1;
    }, e.onDragging = function(o) {
      var n = o.deltaX, i = o.deltaY, a = e.props, s = a.model, l = a.graphModel;
      e.isDragging = !0;
      var u = l.transformModel, c = l.editConfigModel, d = Qh(u.fixDeltaXY(n, i), 2), f = d[0], p = d[1], v = s;
      c.adjustEdgeMiddle ? e.appendInfo = v.dragAppendSimple(e.appendInfo, {
        x: f,
        y: p
      }) : e.appendInfo = v.dragAppend(e.appendInfo, {
        x: f,
        y: p
      });
    }, e.onDragEnd = function() {
      var o, n = e.props, i = n.model, a = n.graphModel.eventCenter, s = i;
      s.dragAppendEnd(), e.isDragging = !1, s.isShowAdjustPoint = (o = e.isShowAdjustPointTemp) !== null && o !== void 0 ? o : !1, e.appendInfo = void 0, a.emit(L.EDGE_ADJUST, { data: s.getData() });
    }, e.beforeDragStart = function(o, n) {
      n.draggable && e.drag.handleMouseDown(o), e.appendInfo = n;
    }, e.drag = new de({
      onDragStart: e.onDragStart,
      onDragging: e.onDragging,
      onDragEnd: e.onDragEnd,
      isStopPropagation: !1
    }), e;
  }
  return t.prototype.getEdge = function() {
    var e, o, n = this.props.model, i = n.points, a = n.isAnimation, s = n.arrowConfig, l = n.properties, u = n.getEdgeStyle(), c = n.getEdgeAnimationStyle(), d = c.strokeDasharray, f = c.stroke, p = c.strokeDashoffset, v = c.animationName, h = c.animationDuration, g = c.animationIterationCount, y = c.animationTimingFunction, _ = c.animationDirection, E = (o = (e = l == null ? void 0 : l.radius) !== null && e !== void 0 ? e : u == null ? void 0 : u.radius) !== null && o !== void 0 ? o : 0, x = (function() {
      if (!E || E <= 0) return i;
      var O = Me(i);
      return ou(O, E, !1).map(function(M) {
        return "".concat(M.x, ",").concat(M.y);
      }).join(" ");
    })();
    return S(Hf, Be({ points: x }, u, s, a ? {
      strokeDasharray: d,
      stroke: f,
      style: {
        strokeDashoffset: p,
        animationName: v,
        animationDuration: h,
        animationIterationCount: g,
        animationTimingFunction: y,
        animationDirection: _
      }
    } : {}));
  }, t.prototype.getArrowInfo = function() {
    var e = this.props.model, o = e.points, n = e.isSelected, i = this.state.hover, a = Me(o), s = a[0], l = a[0];
    return a.length >= 2 && (s = a[a.length - 2], l = a[a.length - 1]), {
      start: s,
      end: l,
      hover: i,
      isSelected: n
    };
  }, t.prototype.getLastTwoPoints = function() {
    var e = this.props.model.points, o = Me(e), n = o[0], i = o[0];
    return o.length >= 2 && (n = o[o.length - 2], i = o[o.length - 1]), [n, i];
  }, t.prototype.getAppendAttributes = function(e) {
    var o = e.start, n = e.end, i;
    if (o.x === n.x && o.y === n.y) i = "";
    else {
      var a = {
        start: o,
        end: n,
        offset: 10,
        verticalLength: 5
      }, s = ro(Be(Be({}, a), { type: "start" })), l = ro(Be(Be({}, a), { type: "end" }));
      i = "M".concat(s.leftX, " ").concat(s.leftY, `
      L`).concat(s.rightX, " ").concat(s.rightY, `
      L`).concat(l.rightX, " ").concat(l.rightY, `
      L`).concat(l.leftX, " ").concat(l.leftY, " z");
    }
    return {
      d: i,
      fill: "transparent",
      stroke: "transparent",
      strokeWidth: 1,
      strokeDasharray: "4, 4"
    };
  }, t.prototype.getAppendShape = function(e) {
    var o = this.getAppendAttributes(e), n = o.d, i = o.strokeWidth, a = o.fill, s = o.strokeDasharray, l = o.stroke;
    return S(no, {
      d: n,
      fill: a,
      strokeWidth: i,
      stroke: l,
      strokeDasharray: s
    });
  }, t.prototype.getAppendWidth = function() {
    for (var e = this, o = this.props, n = o.model, i = o.graphModel, a = n.pointsList, s = n.draggable, l = [], u = a.length, c = function(p) {
      var v = "lf-polyline-append", h = {
        start: {
          x: a[p].x,
          y: a[p].y
        },
        end: {
          x: a[p + 1].x,
          y: a[p + 1].y
        },
        startIndex: p,
        endIndex: p + 1,
        direction: $.HORIZONTAL,
        draggable: !0
      }, g = S("g", {
        className: v,
        children: d.getAppendShape(h)
      }), y = i.editConfigModel, _ = y.adjustEdge, E = y.adjustEdgeMiddle;
      if (_ && s) {
        var x = h.startIndex, O = h.endIndex;
        h.draggable = !(E && (x === 0 || O === u - 1)), h.start.x === h.end.x ? (h.draggable && (v += "-ew-resize"), h.direction = $.VERTICAL) : h.start.y === h.end.y && (h.draggable && (v += "-ns-resize"), h.direction = $.HORIZONTAL), g = S("g", {
          className: d.isDragging ? "lf-dragging" : "lf-drag-able",
          onPointerDown: function(M) {
            return e.beforeDragStart(M, h);
          },
          children: S("g", {
            className: v,
            children: d.getAppendShape(h)
          })
        });
      }
      l.push(g);
    }, d = this, f = 0; f < u - 1; f++) c(f);
    return S("g", { children: l });
  }, t;
})(wn), lr = function() {
  return lr = Object.assign || function(r) {
    for (var t, e = 1, o = arguments.length; e < o; e++) {
      t = arguments[e];
      for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && (r[n] = t[n]);
    }
    return r;
  }, lr.apply(this, arguments);
}, tv = (function() {
  function r(t) {
    var e = this;
    this.nodeConfig = null, this.fakeNode = null, this.stopDrag = function() {
      e.nodeConfig = null, e.docPointerMove && window.document.removeEventListener("pointermove", e.docPointerMove), e.docPointerUp && window.document.removeEventListener("pointerup", e.docPointerUp);
    }, this.dragEnter = function(n) {
      !e.nodeConfig || e.fakeNode || (e.fakeNode = e.lf.createFakeNode(lr(lr({}, e.nodeConfig), e.clientToLocalPoint({
        x: n.clientX,
        y: n.clientY
      }))));
    }, this.onDragOver = function(n) {
      if (e.lf.graphModel.eventCenter.emit(L.BLANK_CANVAS_MOUSEMOVE, { e: n }), n.preventDefault(), e.fakeNode) {
        var i = e.clientToLocalPoint({
          x: n.clientX,
          y: n.clientY
        }), a = i.x, s = i.y;
        e.fakeNode.moveTo(a, s);
        var l = e.fakeNode.getData();
        e.lf.setNodeSnapLine(l), e.lf.graphModel.eventCenter.emit(L.NODE_DND_DRAG, {
          data: l,
          e: n
        });
      }
      return !1;
    }, this.onDragLeave = function() {
      e.fakeNode && (e.lf.removeNodeSnapLine(), e.lf.graphModel.removeFakeNode(), e.fakeNode = null);
    }, this.onDrop = function(n) {
      !e.lf.graphModel || !n || !e.nodeConfig || (e.lf.addNode(lr(lr({}, e.nodeConfig), e.clientToLocalPoint({
        x: n.clientX,
        y: n.clientY
      })), L.NODE_DND_ADD, n), n.preventDefault(), n.stopPropagation(), e.nodeConfig = null, e.lf.removeNodeSnapLine(), e.lf.graphModel.removeFakeNode(), e.fakeNode = null);
    };
    var o = t.lf;
    this.lf = o;
  }
  return r.prototype.clientToLocalPoint = function(t) {
    var e = t.x, o = t.y, n = He(this.lf.options, ["grid", "size"]), i = this.lf.graphModel.getPointByClient({
      x: e,
      y: o
    }).canvasOverlayPosition, a = i.x, s = i.y, l = this.lf.graphModel.editConfigModel.snapGrid;
    return {
      x: mr(a, n, l),
      y: mr(s, n, l)
    };
  }, r.prototype.isInsideCanvas = function(t) {
    var e = this.lf.graphModel.rootEl.querySelector('[name="canvas-overlay"]'), o = window.document.elementFromPoint(t.clientX, t.clientY);
    return o === e || o !== null && !!e && e.contains(o);
  }, r.prototype.startDrag = function(t) {
    var e = this, o = this.lf.graphModel.editConfigModel;
    o != null && o.isSilentMode || (this.nodeConfig = t, this.docPointerMove = function(n) {
      if (e.nodeConfig) {
        if (!e.isInsideCanvas(n)) {
          e.onDragLeave();
          return;
        }
        if (!e.fakeNode) {
          e.dragEnter(n);
          return;
        }
        e.onDragOver(n);
      }
    }, this.docPointerUp = function(n) {
      e.nodeConfig && (e.isInsideCanvas(n) ? e.onDrop(n) : e.onDragLeave(), n.preventDefault(), n.stopPropagation(), e.stopDrag());
    }, window.document.addEventListener("pointermove", this.docPointerMove), window.document.addEventListener("pointerup", this.docPointerUp));
  }, r;
})();
function ev(r, t) {
  r.on("node:mousemove", function(e) {
    var o = e.data;
    t.setNodeSnapLine(o);
  }), r.on("node:mouseup", function() {
    t.clearSnapline();
  });
}
var rv = /* @__PURE__ */ (function() {
  var r = function(t, e) {
    return r = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(o, n) {
      o.__proto__ = n;
    } || function(o, n) {
      for (var i in n) Object.prototype.hasOwnProperty.call(n, i) && (o[i] = n[i]);
    }, r(t, e);
  };
  return function(t, e) {
    if (typeof e != "function" && e !== null) throw new TypeError("Class extends value " + String(e) + " is not a constructor or null");
    r(t, e);
    function o() {
      this.constructor = t;
    }
    t.prototype = e === null ? Object.create(e) : (o.prototype = e.prototype, new o());
  };
})(), fe = function() {
  return fe = Object.assign || function(r) {
    for (var t, e = 1, o = arguments.length; e < o; e++) {
      t = arguments[e];
      for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && (r[n] = t[n]);
    }
    return r;
  }, fe.apply(this, arguments);
}, ov = function(r, t, e, o) {
  var n = arguments.length, i = n < 3 ? t : o === null ? o = Object.getOwnPropertyDescriptor(t, e) : o, a;
  if (typeof Reflect == "object" && typeof Reflect.decorate == "function") i = Reflect.decorate(r, t, e, o);
  else for (var s = r.length - 1; s >= 0; s--) (a = r[s]) && (i = (n < 3 ? a(i) : n > 3 ? a(t, e, i) : a(t, e)) || i);
  return n > 3 && i && Object.defineProperty(t, e, i), i;
}, nv = function(r, t) {
  var e = typeof Symbol == "function" && r[Symbol.iterator];
  if (!e) return r;
  var o = e.call(r), n, i = [], a;
  try {
    for (; (t === void 0 || t-- > 0) && !(n = o.next()).done; ) i.push(n.value);
  } catch (s) {
    a = { error: s };
  } finally {
    try {
      n && !n.done && (e = o.return) && e.call(o);
    } finally {
      if (a) throw a.error;
    }
  }
  return i;
}, iv = (function(r) {
  rv(t, r);
  function t(e) {
    var o = r.call(this, e) || this;
    return o.ref = Hi(), o.__prevText = {
      type: "",
      text: "",
      id: ""
    }, o.keyupHandler = function(n) {
      var i = o.props.graphModel.textEditElement;
      n.key === "Enter" && n.altKey && (i == null || i.setElementState(J.DEFAULT));
    }, o.inputHandler = function(n) {
      var i = n.target.innerText, a = o.props.graphModel.textEditElement;
      a && (o.__prevText = {
        type: a.type,
        text: i.replace(/(\r\n)+$|(\n)+$/, ""),
        id: a.id
      });
    }, o.keydownHandler = function(n) {
      n.stopPropagation();
    }, o.state = { style: {
      left: 0,
      top: 0
    } }, o;
  }
  return t.getDerivedStateFromProps = function(e) {
    var o, n = e.textEditElement, i = e.graphModel, a = i.transformModel, s = i.theme, l = s.inputText, u;
    if (n) {
      if (!(!((o = n.text) === null || o === void 0) && o.value) && n.BaseType === dt.EDGE) {
        var c = n.text, d = n.textPosition, f = d.x, p = d.y;
        c.x = f, c.y = p, n.setText(c);
      }
      var v = {
        resize: "auto",
        whiteSpace: "normal",
        wordBreak: "break-all"
      };
      if (n.BaseType === dt.EDGE) {
        var h = s.edgeText, g = h.overflowMode, y = h.lineHeight, _ = h.wrapPadding, E = h.textWidth;
        E && g === "autoWrap" && (u = fe(fe({}, v), {
          width: E,
          minWidth: E,
          lineHeight: y,
          padding: _
        }));
      } else if (n.BaseType === dt.NODE) {
        var x = s.nodeText, g = x.overflowMode, y = x.lineHeight, _ = x.wrapPadding, E = x.textWidth, O = n.width, M = n.modelType, P = n.textWidth || E || O;
        (M !== G.TEXT_NODE && g === "autoWrap" || M === G.TEXT_NODE && E) && (u = fe(fe({}, v), {
          width: P,
          minWidth: P,
          lineHeight: y,
          padding: _
        }));
      }
      var m = n.text, w = m.x, T = m.y, D = nv(a.CanvasPointToHtmlPoint([w, T]), 2), B = D[0], Z = D[1];
      return { style: fe(fe({
        left: B,
        top: Z
      }, u), l) };
    }
    return null;
  }, t.prototype.componentDidUpdate = function() {
    var e = this.props.graphModel;
    if (this.ref.current && (this.ref.current.focus(), this.placeCaretAtEnd(this.ref.current)), this.__prevText.id !== "") {
      var o = this.__prevText, n = o.text, i = o.id;
      e.updateText(i, n), e.eventCenter.emit(L.TEXT_UPDATE, { data: fe({}, this.__prevText) }), this.__prevText.id = "", this.__prevText.text = "", this.__prevText.type = "";
    }
  }, t.prototype.placeCaretAtEnd = function(e) {
    if (window.getSelection !== void 0 && document.createRange !== void 0) {
      var o = document.createRange();
      o.selectNodeContents(e), o.collapse(!1);
      var n = window.getSelection();
      n == null || n.removeAllRanges(), n == null || n.addRange(o);
    }
  }, t.prototype.render = function() {
    var e, o = this.props.graphModel.textEditElement, n = this.state.style;
    return o ? S("div", {
      contentEditable: !0,
      className: "lf-text-input",
      style: n,
      ref: this.ref,
      onKeyUp: this.keyupHandler,
      onKeyDown: this.keydownHandler,
      onKeyPress: this.keydownHandler,
      onInput: this.inputHandler,
      children: (e = o.text) === null || e === void 0 ? void 0 : e.value
    }, o.id) : null;
  }, t.toolName = "text-edit-tool", t = ov([Rt], t), t;
})(V), av = /* @__PURE__ */ (function() {
  var r = function(t, e) {
    return r = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(o, n) {
      o.__proto__ = n;
    } || function(o, n) {
      for (var i in n) Object.prototype.hasOwnProperty.call(n, i) && (o[i] = n[i]);
    }, r(t, e);
  };
  return function(t, e) {
    if (typeof e != "function" && e !== null) throw new TypeError("Class extends value " + String(e) + " is not a constructor or null");
    r(t, e);
    function o() {
      this.constructor = t;
    }
    t.prototype = e === null ? Object.create(e) : (o.prototype = e.prototype, new o());
  };
})(), sv = function(r, t, e, o) {
  var n = arguments.length, i = n < 3 ? t : o === null ? o = Object.getOwnPropertyDescriptor(t, e) : o, a;
  if (typeof Reflect == "object" && typeof Reflect.decorate == "function") i = Reflect.decorate(r, t, e, o);
  else for (var s = r.length - 1; s >= 0; s--) (a = r[s]) && (i = (n < 3 ? a(i) : n > 3 ? a(t, e, i) : a(t, e)) || i);
  return n > 3 && i && Object.defineProperty(t, e, i), i;
}, In = function(r, t) {
  var e = typeof Symbol == "function" && r[Symbol.iterator];
  if (!e) return r;
  var o = e.call(r), n, i = [], a;
  try {
    for (; (t === void 0 || t-- > 0) && !(n = o.next()).done; ) i.push(n.value);
  } catch (s) {
    a = { error: s };
  } finally {
    try {
      n && !n.done && (e = o.return) && e.call(o);
    } finally {
      if (a) throw a.error;
    }
  }
  return i;
}, lv = function(r, t, e) {
  if (e || arguments.length === 2)
    for (var o = 0, n = t.length, i; o < n; o++) (i || !(o in t)) && (i || (i = Array.prototype.slice.call(t, 0, o)), i[o] = t[o]);
  return r.concat(i || Array.prototype.slice.call(t));
}, uv = (function(r) {
  av(t, r);
  function t(e) {
    var o = r.call(this, e) || this;
    o.handleMouseDown = function(s) {
      var l = o.props, u = l.graphModel.gridSize, c = l.lf.getTransform().SCALE_X;
      o.stepDrag.setStep(u * c), o.stepDrag.handleMouseDown(s);
    }, o.handleWheelEvent = function(s) {
      var l, u;
      s.preventDefault();
      var c = s.deltaX, d = s.deltaY, f = s.clientX, p = s.clientY, v = s.ctrlKey, h = new WheelEvent("wheel", {
        deltaX: c,
        deltaY: d,
        clientX: f,
        clientY: p,
        ctrlKey: v
      });
      (u = (l = o.props.lf.container) === null || l === void 0 ? void 0 : l.querySelector('.lf-canvas-overlay[name="canvas-overlay"]')) === null || u === void 0 || u.dispatchEvent(h);
    }, o.onDragging = function(s) {
      var l = s.deltaX, u = s.deltaY, c = o.props, d = c.graphModel, f = c.lf.getTransform(), p = f.SCALE_X, v = f.SCALE_Y, h = d.getSelectElements(!0);
      d.moveNodes(h.nodes.map(function(g) {
        return g.id;
      }), l / p, u / v);
    }, o.handleContextMenu = function(s) {
      s.preventDefault();
      var l = o.props, u = l.graphModel, c = l.graphModel, d = c.eventCenter, f = c.selectElements, p = u.getPointByClient({
        x: s.clientX,
        y: s.clientY
      }), v = {
        nodes: [],
        edges: []
      };
      lv([], In(f.values()), !1).forEach(function(h) {
        h.BaseType === dt.NODE && v.nodes.push(h.getData()), h.BaseType === dt.EDGE && v.edges.push(h.getData());
      }), d.emit(L.SELECTION_CONTEXTMENU, {
        data: v,
        e: s,
        position: p
      });
    };
    var n = e.graphModel, i = n.gridSize, a = n.eventCenter;
    return o.stepDrag = new de({
      onDragging: o.onDragging,
      step: i,
      eventType: "SELECTION",
      eventCenter: a
    }), o;
  }
  return t.prototype.render = function() {
    var e, o, n = this.props.graphModel, i = n.selectElements, a = n.transformModel, s = n.theme, l = this.props.lf.getTransform(), u = l.SCALE_X, c = l.SCALE_Y, d = s.multiSelect || {}, f = d.xPadding, p = f === void 0 ? 8 : f, v = d.yPadding, h = v === void 0 ? 8 : v;
    if (!(i.size <= 1)) {
      var g = Number.MAX_SAFE_INTEGER, y = Number.MAX_SAFE_INTEGER, _ = Number.MIN_SAFE_INTEGER, E = Number.MIN_SAFE_INTEGER;
      i.forEach(function(O) {
        var M;
        O.BaseType === dt.NODE && (M = Kd(O)), O.BaseType === dt.EDGE && (M = Qd(O)), M !== void 0 && (g = Math.min(g, M.x), y = Math.min(y, M.y), _ = Math.max(_, M.x1), E = Math.max(E, M.y1));
      }), e = In(a.CanvasPointToHtmlPoint([g, y]), 2), g = e[0], y = e[1], o = In(a.CanvasPointToHtmlPoint([_, E]), 2), _ = o[0], E = o[1];
      var x = {
        left: "".concat(g - 20 * u / 2 - p / 2, "px"),
        top: "".concat(y - 20 * c / 2 - h / 2, "px"),
        width: "".concat(_ - g + 20 * u + p, "px"),
        height: "".concat(E - y + 20 * c + h, "px"),
        "border-width": "".concat(2 * u, "px")
      };
      return S("div", {
        className: "lf-multiple-select",
        style: x,
        onPointerDown: this.handleMouseDown,
        onContextMenu: this.handleContextMenu,
        onWheel: this.handleWheelEvent
      });
    }
  }, t.toolName = "multiple-select-tool", t = sv([Rt], t), t;
})(V), kn = function(r, t, e, o) {
  var n = arguments.length, i = n < 3 ? t : o === null ? o = Object.getOwnPropertyDescriptor(t, e) : o, a;
  if (typeof Reflect == "object" && typeof Reflect.decorate == "function") i = Reflect.decorate(r, t, e, o);
  else for (var s = r.length - 1; s >= 0; s--) (a = r[s]) && (i = (n < 3 ? a(i) : n > 3 ? a(t, e, i) : a(t, e)) || i);
  return n > 3 && i && Object.defineProperty(t, e, i), i;
}, cv = [iv, uv], dv = (function() {
  function r(t) {
    var e = this;
    this.toolMap = /* @__PURE__ */ new Map(), this.disabledToolMap = /* @__PURE__ */ new Map(), this.instance = t, pt(cv, function(n) {
      e.isDisabled(n.toolName) || e.registerTool(n.toolName, n);
    });
    var o = t.graphModel;
    o.eventCenter.on("".concat(L.GRAPH_TRANSFORM, ",").concat(L.NODE_CLICK, ",").concat(L.BLANK_CLICK, " "), function() {
      var n, i = o.textEditElement, a = o.editConfigModel, s = a.edgeTextEdit, l = a.nodeTextEdit;
      (s || l) && i && ((n = o.textEditElement) === null || n === void 0 || n.setElementState(J.DEFAULT));
    });
  }
  return r.prototype.isDisabled = function(t) {
    var e;
    return ((e = this.instance.options.disabledTools) === null || e === void 0 ? void 0 : e.indexOf(t)) !== -1;
  }, r.prototype.registerTool = function(t, e) {
    this.toolMap.set(t, e);
  }, r.prototype.disableTool = function(t) {
    var e = this.toolMap.get(t);
    if (e)
      return this.disabledToolMap.set(t, e), this.toolMap.delete(t), !0;
    throw new Error("禁用失败，不存在名为 ".concat(e, " 的工具"));
  }, r.prototype.enableTool = function(t) {
    var e = this.disabledToolMap.get(t);
    if (e)
      return this.toolMap.set(t, e), this.disabledToolMap.delete(t), !0;
    throw new Error("不存在名为 ".concat(e, " 的工具"));
  }, r.prototype.getTools = function() {
    return Array.from(this.toolMap.values());
  }, r.prototype.getInstance = function() {
    return this.instance;
  }, r.prototype.destroy = function() {
    this.toolMap.clear(), this.disabledToolMap.clear();
  }, kn([A], r.prototype, "toolMap", void 0), kn([b], r.prototype, "disableTool", null), kn([b], r.prototype, "enableTool", null), r;
})();
function fv(r) {
  throw new Error("[mobx-utils] " + r);
}
function pn(r, t) {
  t === void 0 && (t = "Illegal state"), r || fv(t);
}
var hu = function(r) {
  return r && r !== Object.prototype && Object.getOwnPropertyNames(r).concat(hu(Object.getPrototypeOf(r)) || []);
}, pv = function(r) {
  var t = hu(r);
  return t.filter(function(e, o) {
    return t.indexOf(e) === o;
  });
}, hv = function(r) {
  return pv(r).filter(function(t) {
    return t !== "constructor" && !~t.indexOf("__");
  });
}, vu = "pending", sa = "fulfilled", la = "rejected";
function vv(r) {
  switch (this.state) {
    case vu:
      return r.pending && r.pending(this.value);
    case la:
      return r.rejected && r.rejected(this.value);
    case sa:
      return r.fulfilled ? r.fulfilled(this.value) : this.value;
  }
}
function Us(r, t) {
  if (pn(arguments.length <= 2, "fromPromise expects up to two arguments"), pn(typeof r == "function" || typeof r == "object" && r && typeof r.then == "function", "Please pass a promise or function to fromPromise"), r.isPromiseBasedObservable === !0) return r;
  typeof r == "function" && (r = new Promise(r));
  var e = r;
  r.then(b("observableFromPromise-resolve", function(n) {
    e.value = n, e.state = sa;
  }), b("observableFromPromise-reject", function(n) {
    e.value = n, e.state = la;
  })), e.isPromiseBasedObservable = !0, e.case = vv;
  var o = t && t.state === "fulfilled" ? t.value : void 0;
  return Qn(e, {
    value: o,
    state: vu
  }, {}, { deep: !1 }), e;
}
(function(r) {
  r.reject = b("fromPromise.reject", function(e) {
    var o = r(Promise.reject(e));
    return o.state = la, o.value = e, o;
  });
  function t(e) {
    e === void 0 && (e = void 0);
    var o = r(Promise.resolve(e));
    return o.state = sa, o.value = e, o;
  }
  r.resolve = b("fromPromise.resolve", t);
})(Us || (Us = {}));
var jo = function(r, t, e, o) {
  var n = arguments.length, i = n < 3 ? t : o === null ? o = Object.getOwnPropertyDescriptor(t, e) : o, a;
  if (typeof Reflect == "object" && typeof Reflect.decorate == "function") i = Reflect.decorate(r, t, e, o);
  else for (var s = r.length - 1; s >= 0; s--) (a = r[s]) && (i = (n < 3 ? a(i) : n > 3 ? a(t, e, i) : a(t, e)) || i);
  return n > 3 && i && Object.defineProperty(t, e, i), i;
}, cy = (function() {
  function r(t, e) {
    var o = this;
    jc(function() {
      o.current = e, o.subscription = t.subscribe(o);
    });
  }
  return r.prototype.dispose = function() {
    this.subscription && this.subscription.unsubscribe();
  }, r.prototype.next = function(t) {
    this.current = t;
  }, r.prototype.complete = function() {
    this.dispose();
  }, r.prototype.error = function(t) {
    this.current = t, this.dispose();
  }, jo([A.ref], r.prototype, "current", void 0), jo([b.bound], r.prototype, "next", null), jo([b.bound], r.prototype, "complete", null), jo([b.bound], r.prototype, "error", null), r;
})(), hn = function() {
  return hn = Object.assign || function(r) {
    for (var t, e = 1, o = arguments.length; e < o; e++) {
      t = arguments[e];
      for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && (r[n] = t[n]);
    }
    return r;
  }, hn.apply(this, arguments);
}, Dr = function(r, t, e, o) {
  var n = arguments.length, i = n < 3 ? t : o === null ? o = Object.getOwnPropertyDescriptor(t, e) : o, a;
  if (typeof Reflect == "object" && typeof Reflect.decorate == "function") i = Reflect.decorate(r, t, e, o);
  else for (var s = r.length - 1; s >= 0; s--) (a = r[s]) && (i = (n < 3 ? a(i) : n > 3 ? a(t, e, i) : a(t, e)) || i);
  return n > 3 && i && Object.defineProperty(t, e, i), i;
}, yv = [
  "model",
  "reset",
  "submit",
  "isDirty",
  "isPropertyDirty",
  "resetProperty"
], dy = (function() {
  function r(t) {
    var e = this;
    this.model = t, this.localValues = A.map({}), this.localComputedValues = A.map({}), this.isPropertyDirty = function(o) {
      return e.localValues.has(o);
    }, pn(Ht(t), "createViewModel expects an observable object"), hv(t).forEach(function(o) {
      if (!(o === k || o === "__mobxDidRunLazyInitializers")) {
        if (pn(yv.indexOf(o) === -1, "The propertyname " + o + " is reserved and cannot be used with viewModels"), Oa(t, o)) {
          var n = ho(t, o).derivation;
          e.localComputedValues.set(o, ot(n.bind(e)));
        }
        var i = Object.getOwnPropertyDescriptor(t, o), a = i ? { enumerable: i.enumerable } : {};
        Object.defineProperty(e, o, hn(hn({}, a), {
          configurable: !0,
          get: function() {
            return Oa(t, o) ? e.localComputedValues.get(o).get() : e.isPropertyDirty(o) ? e.localValues.get(o) : e.model[o];
          },
          set: b(function(s) {
            s !== e.model[o] ? e.localValues.set(o, s) : e.localValues.delete(o);
          })
        }));
      }
    });
  }
  return Object.defineProperty(r.prototype, "isDirty", {
    get: function() {
      return this.localValues.size > 0;
    },
    enumerable: !1,
    configurable: !0
  }), Object.defineProperty(r.prototype, "changedValues", {
    get: function() {
      return this.localValues.toJS();
    },
    enumerable: !1,
    configurable: !0
  }), r.prototype.submit = function() {
    var t = this;
    gr(this.localValues).forEach(function(e) {
      var o = t.localValues.get(e), n = t.model[e];
      ee(n) ? n.replace(o) : Pt(n) ? (n.clear(), n.merge(o)) : Il(o) || (t.model[e] = o);
    }), this.localValues.clear();
  }, r.prototype.reset = function() {
    this.localValues.clear();
  }, r.prototype.resetProperty = function(t) {
    this.localValues.delete(t);
  }, Dr([ot], r.prototype, "isDirty", null), Dr([ot], r.prototype, "changedValues", null), Dr([b.bound], r.prototype, "submit", null), Dr([b.bound], r.prototype, "reset", null), Dr([b.bound], r.prototype, "resetProperty", null), r;
})();
function Bn(r) {
  if (!r) return "ROOT";
  for (var t = []; r.parent; )
    t.push(r.path), r = r.parent;
  return t.reverse().join("/");
}
function Xn(r) {
  return Ht(r) || ee(r) || Pt(r);
}
function gv(r, t) {
  var e = /* @__PURE__ */ new WeakMap();
  function o(s) {
    var l = e.get(s.object);
    n(s, l), t(s, Bn(l), r);
  }
  function n(s, l) {
    switch (s.type) {
      case "add":
        i(s.newValue, l, s.name);
        break;
      case "update":
        a(s.oldValue), i(s.newValue, l, s.name || "" + s.index);
        break;
      case "remove":
      case "delete":
        a(s.oldValue);
        break;
      case "splice":
        s.removed.map(a), s.added.forEach(function(d, f) {
          return i(d, l, "" + (s.index + f));
        });
        for (var u = s.index + s.addedCount; u < s.object.length; u++) if (Xn(s.object[u])) {
          var c = e.get(s.object[u]);
          c && (c.path = "" + u);
        }
    }
  }
  function i(s, l, u) {
    if (Xn(s)) {
      var c = e.get(s);
      if (c) {
        if (c.parent !== l || c.path !== u) throw new Error("The same observable object cannot appear twice in the same tree," + (" trying to assign it to '" + Bn(l) + "/" + u + "',") + (" but it already exists at '" + Bn(c.parent) + "/" + c.path + "'"));
      } else {
        var d = {
          parent: l,
          path: u,
          dispose: kl(s, o)
        };
        e.set(s, d), Uc(s).forEach(function(f) {
          var p = f[0], v = f[1];
          return i(v, d, p);
        });
      }
    }
  }
  function a(s) {
    if (Xn(s)) {
      var l = e.get(s);
      if (!l) return;
      e.delete(s), l.dispose(), $c(s).forEach(a);
    }
  }
  return i(r, void 0, ""), function() {
    a(r);
  };
}
var _v = /* @__PURE__ */ (function() {
  var r = function(t, e) {
    return r = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(o, n) {
      o.__proto__ = n;
    } || function(o, n) {
      for (var i in n) n.hasOwnProperty(i) && (o[i] = n[i]);
    }, r(t, e);
  };
  return function(t, e) {
    r(t, e);
    function o() {
      this.constructor = t;
    }
    t.prototype = e === null ? Object.create(e) : (o.prototype = e.prototype, new o());
  };
})(), fy = (function(r) {
  _v(t, r);
  function t(e, o, n) {
    var i = n === void 0 ? {} : n, a = i.name, s = a === void 0 ? "ogm" + (Math.random() * 1e3 | 0) : a, l = i.keyToName, u = l === void 0 ? function(f) {
      return "" + f;
    } : l, c = r.call(this) || this;
    c._keyToName = u, c._groupBy = o, c._ogmInfoKey = /* @__PURE__ */ Symbol("ogmInfo" + s), c._base = e;
    for (var d = 0; d < e.length; d++) c._addItem(e[d]);
    return c._disposeBaseObserver = kl(c._base, function(f) {
      if (f.type === "splice") Wt(function() {
        for (var p = 0, v = f.removed; p < v.length; p++) {
          var h = v[p];
          c._removeItem(h);
        }
        for (var g = 0, y = f.added; g < y.length; g++) {
          var _ = y[g];
          c._addItem(_);
        }
      });
      else if (f.type === "update") Wt(function() {
        c._removeItem(f.oldValue), c._addItem(f.newValue);
      });
      else throw new Error("illegal state");
    }), c;
  }
  return t.prototype.clear = function() {
    throw new Error("not supported");
  }, t.prototype.delete = function(e) {
    throw new Error("not supported");
  }, t.prototype.set = function(e, o) {
    throw new Error("not supported");
  }, t.prototype.dispose = function() {
    this._disposeBaseObserver();
    for (var e = 0; e < this._base.length; e++) {
      var o = this._base[e];
      o[this._ogmInfoKey].reaction(), delete o[this._ogmInfoKey];
    }
  }, t.prototype._getGroupArr = function(e) {
    var o = r.prototype.get.call(this, e);
    return o === void 0 && (o = A([], {
      name: "GroupArray[" + this._keyToName(e) + "]",
      deep: !1
    }), r.prototype.set.call(this, e, o)), o;
  }, t.prototype._removeFromGroupArr = function(e, o) {
    var n = r.prototype.get.call(this, e);
    n.length === 1 ? r.prototype.delete.call(this, e) : (o === n.length - 1 || (n[o] = n[n.length - 1], n[o][this._ogmInfoKey].groupArrIndex = o), n.length--);
  }, t.prototype._addItem = function(e) {
    var o = this, n = this._groupBy(e), i = this._getGroupArr(n), a = {
      groupByValue: n,
      groupArrIndex: i.length,
      reaction: Tl(function() {
        return o._groupBy(e);
      }, function(s, l) {
        var u = e[o._ogmInfoKey];
        o._removeFromGroupArr(u.groupByValue, u.groupArrIndex);
        var c = o._getGroupArr(s), d = c.length;
        c.push(e), u.groupByValue = s, u.groupArrIndex = d;
      })
    };
    Object.defineProperty(e, this._ogmInfoKey, {
      configurable: !0,
      enumerable: !1,
      value: a
    }), i.push(e);
  }, t.prototype._removeItem = function(e) {
    var o = e[this._ogmInfoKey];
    this._removeFromGroupArr(o.groupByValue, o.groupArrIndex), o.reaction(), delete e[this._ogmInfoKey];
  }, t;
})(ta), mv = (function() {
  function r(t, e) {
    this.base = t, this.args = e, this.closestIdx = 0, this.isDisposed = !1;
    for (var o = this.closest = this.root = t, n = 0; n < this.args.length - 1 && (o = o.get(e[n]), o); n++)
      this.closest = o;
    this.closestIdx = n;
  }
  return r.prototype.exists = function() {
    this.assertNotDisposed();
    var t = this.args.length;
    return this.closestIdx >= t - 1 && this.closest.has(this.args[t - 1]);
  }, r.prototype.get = function() {
    if (this.assertNotDisposed(), !this.exists()) throw new Error("Entry doesn't exist");
    return this.closest.get(this.args[this.args.length - 1]);
  }, r.prototype.set = function(t) {
    this.assertNotDisposed();
    for (var e = this.args.length, o = this.closest, n = this.closestIdx; n < e - 1; n++) {
      var i = /* @__PURE__ */ new Map();
      o.set(this.args[n], i), o = i;
    }
    this.closestIdx = e - 1, this.closest = o, o.set(this.args[e - 1], t);
  }, r.prototype.delete = function() {
    if (this.assertNotDisposed(), !this.exists()) throw new Error("Entry doesn't exist");
    var t = this.args.length;
    this.closest.delete(this.args[t - 1]);
    for (var e = this.root, o = [e], n = 0; n < t - 1; n++)
      e = e.get(this.args[n]), o.push(e);
    for (var n = o.length - 1; n > 0; n--) o[n].size === 0 && o[n - 1].delete(this.args[n - 1]);
    this.isDisposed = !0;
  }, r.prototype.assertNotDisposed = function() {
    if (this.isDisposed) throw new Error("Concurrent modification exception");
  }, r;
})(), py = (function() {
  function r() {
    this.store = /* @__PURE__ */ new Map(), this.argsLength = -1;
  }
  return r.prototype.entry = function(t) {
    if (this.argsLength === -1) this.argsLength = t.length;
    else if (this.argsLength !== t.length) throw new Error("DeepMap should be used with functions with a consistent length, expected: " + this.argsLength + ", got: " + t.length);
    return this.last && (this.last.isDisposed = !0), this.last = new mv(this.store, t);
  }, r;
})(), xv, Yn = Promise.resolve(), zo;
typeof queueMicrotask != "undefined" ? zo = queueMicrotask : typeof process != "undefined" && process.nextTick ? zo = function(r) {
  process.nextTick(r);
} : zo = function(r) {
  setTimeout(r, 0);
};
var Ev = function() {
  return new Promise(function(r) {
    zo(r);
  });
};
xv = function() {
  return Yn = Yn.then(Ev), Yn;
};
var Di = function() {
  return Di = Object.assign || function(r) {
    for (var t, e = 1, o = arguments.length; e < o; e++) {
      t = arguments[e];
      for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && (r[n] = t[n]);
    }
    return r;
  }, Di.apply(this, arguments);
}, bv = (function() {
  function r(t) {
    this.undos = [], this.redos = [], this.callbacks = [], this.stopWatch = null, this.curData = null, this.maxSize = 50, this.waitTime = 100, this.eventCenter = t;
  }
  return r.prototype.add = function(t) {
    fa(Cu(this.undos), t) || (this.undos.push(t), fa(this.curData, t) || (this.redos = []), this.eventCenter.emit(L.HISTORY_CHANGE, { data: {
      undos: this.undos,
      redos: this.redos,
      undoAble: this.undoAble(),
      redoAble: this.redoAble()
    } }), this.undos.length > this.maxSize && this.undos.shift());
  }, r.prototype.undoAble = function() {
    return this.undos.length > 1;
  }, r.prototype.undo = function() {
    if (this.undoAble()) {
      var t = this.undos.pop();
      this.redos.push(t);
      var e = this.undos.pop();
      return this.curData = R(e), e;
    }
  }, r.prototype.redoAble = function() {
    return this.redos.length > 0;
  }, r.prototype.redo = function() {
    if (this.redoAble()) {
      var t = this.redos.pop();
      return this.curData = R(t), t;
    }
  }, r.prototype.watch = function(t) {
    var e = this;
    this.stopWatch && this.stopWatch(), this.undos.push(t.modelToGraphData()), this.stopWatch = gv(t, qs(function() {
      var o = t.modelToHistoryData();
      o && e.add(Di({}, o));
    }, this.waitTime));
  }, r.prototype.destroy = function() {
    this.undos = [], this.redos = [], this.curData = null, this.stopWatch && this.stopWatch();
  }, r;
})(), Ov = /* @__PURE__ */ Ks(((r, t) => {
  (function(e, o, n) {
    if (!e) return;
    for (var i = {
      8: "backspace",
      9: "tab",
      13: "enter",
      16: "shift",
      17: "ctrl",
      18: "alt",
      20: "capslock",
      27: "esc",
      32: "space",
      33: "pageup",
      34: "pagedown",
      35: "end",
      36: "home",
      37: "left",
      38: "up",
      39: "right",
      40: "down",
      45: "ins",
      46: "del",
      91: "meta",
      93: "meta",
      224: "meta"
    }, a = {
      106: "*",
      107: "+",
      109: "-",
      110: ".",
      111: "/",
      186: ";",
      187: "=",
      188: ",",
      189: "-",
      190: ".",
      191: "/",
      192: "`",
      219: "[",
      220: "\\",
      221: "]",
      222: "'"
    }, s = {
      "~": "`",
      "!": "1",
      "@": "2",
      "#": "3",
      $: "4",
      "%": "5",
      "^": "6",
      "&": "7",
      "*": "8",
      "(": "9",
      ")": "0",
      _: "-",
      "+": "=",
      ":": ";",
      '"': "'",
      "<": ",",
      ">": ".",
      "?": "/",
      "|": "\\"
    }, l = {
      option: "alt",
      command: "meta",
      return: "enter",
      escape: "esc",
      plus: "+",
      mod: /Mac|iPod|iPhone|iPad/.test(navigator.platform) ? "meta" : "ctrl"
    }, u, c = 1; c < 20; ++c) i[111 + c] = "f" + c;
    for (c = 0; c <= 9; ++c) i[c + 96] = c.toString();
    function d(m, w, T) {
      if (m.addEventListener) {
        m.addEventListener(w, T, !1);
        return;
      }
      m.attachEvent("on" + w, T);
    }
    function f(m) {
      if (m.type == "keypress") {
        var w = String.fromCharCode(m.which);
        return m.shiftKey || (w = w.toLowerCase()), w;
      }
      return i[m.which] ? i[m.which] : a[m.which] ? a[m.which] : String.fromCharCode(m.which).toLowerCase();
    }
    function p(m, w) {
      return m.sort().join(",") === w.sort().join(",");
    }
    function v(m) {
      var w = [];
      return m.shiftKey && w.push("shift"), m.altKey && w.push("alt"), m.ctrlKey && w.push("ctrl"), m.metaKey && w.push("meta"), w;
    }
    function h(m) {
      if (m.preventDefault) {
        m.preventDefault();
        return;
      }
      m.returnValue = !1;
    }
    function g(m) {
      if (m.stopPropagation) {
        m.stopPropagation();
        return;
      }
      m.cancelBubble = !0;
    }
    function y(m) {
      return m == "shift" || m == "ctrl" || m == "alt" || m == "meta";
    }
    function _() {
      if (!u) {
        u = {};
        for (var m in i)
          m > 95 && m < 112 || i.hasOwnProperty(m) && (u[i[m]] = m);
      }
      return u;
    }
    function E(m, w, T) {
      return T || (T = _()[m] ? "keydown" : "keypress"), T == "keypress" && w.length && (T = "keydown"), T;
    }
    function x(m) {
      return m === "+" ? ["+"] : (m = m.replace(/\+{2}/g, "+plus"), m.split("+"));
    }
    function O(m, w) {
      var T, D, B, Z = [];
      for (T = x(m), B = 0; B < T.length; ++B)
        D = T[B], l[D] && (D = l[D]), w && w != "keypress" && s[D] && (D = s[D], Z.push("shift")), y(D) && Z.push(D);
      return w = E(D, Z, w), {
        key: D,
        modifiers: Z,
        action: w
      };
    }
    function M(m, w) {
      return m === null || m === o ? !1 : m === w ? !0 : M(m.parentNode, w);
    }
    function P(m) {
      var w = this;
      if (m = m || o, !(w instanceof P)) return new P(m);
      w.target = m, w._callbacks = {}, w._directMap = {};
      var T = {}, D, B = !1, Z = !1, et = !1;
      function ht(Y) {
        Y = Y || {};
        var q = !1, nt;
        for (nt in T) {
          if (Y[nt]) {
            q = !0;
            continue;
          }
          T[nt] = 0;
        }
        q || (et = !1);
      }
      function vt(Y, q, nt, F, at, Gt) {
        var tt, ct, Tt = [], _e = nt.type;
        if (!w._callbacks[Y]) return [];
        for (_e == "keyup" && y(Y) && (q = [Y]), tt = 0; tt < w._callbacks[Y].length; ++tt)
          if (ct = w._callbacks[Y][tt], !(!F && ct.seq && T[ct.seq] != ct.level) && _e == ct.action && (_e == "keypress" && !nt.metaKey && !nt.ctrlKey || p(q, ct.modifiers))) {
            var me = !F && ct.combo == at, xe = F && ct.seq == F && ct.level == Gt;
            (me || xe) && w._callbacks[Y].splice(tt, 1), Tt.push(ct);
          }
        return Tt;
      }
      function ut(Y, q, nt, F) {
        w.stopCallback(q, q.target || q.srcElement, nt, F) || Y(q, nt) === !1 && (h(q), g(q));
      }
      w._handleKey = function(Y, q, nt) {
        var F = vt(Y, q, nt), at, Gt = {}, tt = 0, ct = !1;
        for (at = 0; at < F.length; ++at) F[at].seq && (tt = Math.max(tt, F[at].level));
        for (at = 0; at < F.length; ++at) {
          if (F[at].seq) {
            if (F[at].level != tt) continue;
            ct = !0, Gt[F[at].seq] = 1, ut(F[at].callback, nt, F[at].combo, F[at].seq);
            continue;
          }
          ct || ut(F[at].callback, nt, F[at].combo);
        }
        var Tt = nt.type == "keypress" && Z;
        nt.type == et && !y(Y) && !Tt && ht(Gt), Z = ct && nt.type == "keydown";
      };
      function rt(Y) {
        typeof Y.which != "number" && (Y.which = Y.keyCode);
        var q = f(Y);
        if (q) {
          if (Y.type == "keyup" && B === q) {
            B = !1;
            return;
          }
          w.handleKey(q, v(Y), Y);
        }
      }
      function gt() {
        clearTimeout(D), D = setTimeout(ht, 1e3);
      }
      function ge(Y, q, nt, F) {
        T[Y] = 0;
        function at(Tt) {
          return function() {
            et = Tt, ++T[Y], gt();
          };
        }
        function Gt(Tt) {
          ut(nt, Tt, Y), F !== "keyup" && (B = f(Tt)), setTimeout(ht, 10);
        }
        for (var tt = 0; tt < q.length; ++tt) {
          var ct = tt + 1 === q.length ? Gt : at(F || O(q[tt + 1]).action);
          je(q[tt], ct, F, Y, tt);
        }
      }
      function je(Y, q, nt, F, at) {
        w._directMap[Y + ":" + nt] = q, Y = Y.replace(/\s+/g, " ");
        var Gt = Y.split(" "), tt;
        if (Gt.length > 1) {
          ge(Y, Gt, q, nt);
          return;
        }
        tt = O(Y, nt), w._callbacks[tt.key] = w._callbacks[tt.key] || [], vt(tt.key, tt.modifiers, { type: tt.action }, F, Y, at), w._callbacks[tt.key][F ? "unshift" : "push"]({
          callback: q,
          modifiers: tt.modifiers,
          action: tt.action,
          seq: F,
          level: at,
          combo: Y
        });
      }
      w._bindMultiple = function(Y, q, nt) {
        for (var F = 0; F < Y.length; ++F) je(Y[F], q, nt);
      }, d(m, "keypress", rt), d(m, "keydown", rt), d(m, "keyup", rt);
    }
    P.prototype.bind = function(m, w, T) {
      var D = this;
      return m = m instanceof Array ? m : [m], D._bindMultiple.call(D, m, w, T), D;
    }, P.prototype.unbind = function(m, w) {
      var T = this;
      return T.bind.call(T, m, function() {
      }, w);
    }, P.prototype.trigger = function(m, w) {
      var T = this;
      return T._directMap[m + ":" + w] && T._directMap[m + ":" + w]({}, m), T;
    }, P.prototype.reset = function() {
      var m = this;
      return m._callbacks = {}, m._directMap = {}, m;
    }, P.prototype.stopCallback = function(m, w) {
      var T = this;
      if ((" " + w.className + " ").indexOf(" mousetrap ") > -1 || M(w, T.target)) return !1;
      if ("composedPath" in m && typeof m.composedPath == "function") {
        var D = m.composedPath()[0];
        D !== m.target && (w = D);
      }
      return w.tagName == "INPUT" || w.tagName == "SELECT" || w.tagName == "TEXTAREA" || w.isContentEditable;
    }, P.prototype.handleKey = function() {
      var m = this;
      return m._handleKey.apply(m, arguments);
    }, P.addKeycodes = function(m) {
      for (var w in m) m.hasOwnProperty(w) && (i[w] = m[w]);
      u = null;
    }, P.init = function() {
      var m = P(o);
      for (var w in m) w.charAt(0) !== "_" && (P[w] = /* @__PURE__ */ (function(T) {
        return function() {
          return m[T].apply(m, arguments);
        };
      })(w));
    }, P.init(), e.Mousetrap = P, typeof t != "undefined" && t.exports && (t.exports = P), typeof define == "function" && define.amd && define(function() {
      return P;
    });
  })(typeof window != "undefined" ? window : null, typeof window != "undefined" ? document : null);
})), wv = /* @__PURE__ */ Zs(Ov()), Se = function() {
  return Se = Object.assign || function(r) {
    for (var t, e = 1, o = arguments.length; e < o; e++) {
      t = arguments[e];
      for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && (r[n] = t[n]);
    }
    return r;
  }, Se.apply(this, arguments);
}, Sv = function(r, t) {
  var e = {};
  for (var o in r) Object.prototype.hasOwnProperty.call(r, o) && t.indexOf(o) < 0 && (e[o] = r[o]);
  if (r != null && typeof Object.getOwnPropertySymbols == "function")
    for (var n = 0, o = Object.getOwnPropertySymbols(r); n < o.length; n++) t.indexOf(o[n]) < 0 && Object.prototype.propertyIsEnumerable.call(r, o[n]) && (e[o[n]] = r[o[n]]);
  return e;
}, re = null;
function Vs(r, t) {
  var e, o;
  return r.x += t, r.y += t, qr(r.text) || (r.text.x += t, r.text.y += t), qr((e = r.properties) === null || e === void 0 ? void 0 : e._label) || (o = r.properties) === null || o === void 0 || o._label.forEach(function(n) {
    n.x += t, n.y += t;
  }), r;
}
function Fs(r, t) {
  return r.startPoint && (r.startPoint.x += t, r.startPoint.y += t), r.endPoint && (r.endPoint.x += t, r.endPoint.y += t), r.pointsList && r.pointsList.length > 0 && r.pointsList.forEach(function(e) {
    e.x += t, e.y += t;
  }), qr(r.text) || (r.text.x += t, r.text.y += t), r;
}
function hy(r, t) {
  var e = r.x, o = r.y, n = r.text, i = n ? {
    x: n.x + t,
    y: n.y + t,
    value: n.value
  } : void 0;
  return Se(Se({}, r), {
    id: "",
    x: e + t,
    y: o + t,
    text: i
  });
}
function vy(r, t) {
  var e = r.startPoint, o = r.endPoint, n = r.pointsList, i = r.text, a = Sv(r, [
    "startPoint",
    "endPoint",
    "pointsList",
    "text"
  ]);
  a.id = "";
  var s = {
    x: e.x + t,
    y: e.y + t
  }, l = {
    x: o.x + t,
    y: o.y + t
  }, u = ce(n, function(d) {
    return {
      x: d.x + t,
      y: d.y + t
    };
  }), c = i ? Se(Se({}, i), {
    x: i.x + t,
    y: i.y + t
  }) : void 0;
  return Se(Se({}, a), {
    startPoint: s,
    endPoint: l,
    pointsList: u,
    text: c
  });
}
var tr = 40, Ro = 40;
function Av(r, t) {
  var e = r.keyboard, o = e.options.keyboard;
  e.on(["cmd + c", "ctrl + c"], function() {
    if (Ro = tr, !(o != null && o.enabled) || t.textEditElement) return !0;
    var n = r.options.guards, i = t.getSelectElements(!1);
    return !(!(n && n.beforeClone) || n.beforeClone(i)) || i.nodes.length === 0 && i.edges.length === 0 ? (re = null, !0) : (re = i, re.nodes.forEach(function(a) {
      return Vs(a, tr);
    }), re.edges.forEach(function(a) {
      return Fs(a, tr);
    }), !1);
  }), e.on(["cmd + v", "ctrl + v"], function() {
    if (!(o != null && o.enabled) || t.textEditElement) return !0;
    if (re && (re.nodes || re.edges)) {
      r.clearSelectElements();
      var n = r.addElements(re, Ro);
      if (!n) return !0;
      n.nodes.forEach(function(i) {
        return r.selectElementById(i.id, !0);
      }), n.edges.forEach(function(i) {
        return r.selectElementById(i.id, !0);
      }), re.nodes.forEach(function(i) {
        return Vs(i, tr);
      }), re.edges.forEach(function(i) {
        return Fs(i, tr);
      }), Ro = Ro + tr;
    }
    return !1;
  }), e.on(["cmd + z", "ctrl + z"], function() {
    return !(o != null && o.enabled) || t.textEditElement ? !0 : (r.undo(), !1);
  }), e.on(["cmd + y", "ctrl + y"], function() {
    return !(o != null && o.enabled) || t.textEditElement ? !0 : (r.redo(), !1);
  }), e.on(["backspace"], function() {
    if (!(o != null && o.enabled) || t.textEditElement) return !0;
    var n = t.getSelectElements(!0);
    return r.clearSelectElements(), n.edges.forEach(function(i) {
      return i.id && r.deleteEdge(i.id);
    }), n.nodes.forEach(function(i) {
      return i.id && r.deleteNode(i.id);
    }), !1;
  });
}
var Mv = (function() {
  function r(t) {
    t.keyboard || (t.keyboard = { enabled: !1 }), this.options = t;
    var e = t.lf;
    this.target = e.container, this.mousetrap = new wv.default(this.target), t.keyboard.enabled && !e.options.isSilentMode && this.enable(!0);
  }
  return r.prototype.initShortcuts = function() {
    var t = this, e, o = ((e = this.options.keyboard) !== null && e !== void 0 ? e : {}).shortcuts;
    if (o)
      if (Ii(o)) o.forEach(function(s) {
        var l = s.keys, u = s.callback, c = s.action;
        return t.on(l, u, c);
      });
      else {
        var n = o.keys, i = o.callback, a = o.action;
        this.on(n, i, a);
      }
  }, r.prototype.on = function(t, e, o) {
    this.mousetrap.bind(this.getKeys(t), e, o);
  }, Object.defineProperty(r.prototype, "disabled", {
    get: function() {
      var t, e;
      return ((e = (t = this.options) === null || t === void 0 ? void 0 : t.keyboard) === null || e === void 0 ? void 0 : e.enabled) !== !0;
    },
    enumerable: !1,
    configurable: !0
  }), r.prototype.off = function(t, e) {
    this.mousetrap.unbind(this.getKeys(t), e);
  }, r.prototype.enable = function(t) {
    (this.disabled || t) && (this.options.keyboard && (this.options.keyboard.enabled = !0), this.target instanceof HTMLElement && (this.target.setAttribute("tabindex", "-1"), this.target.style.outline = "none"));
  }, r.prototype.disable = function() {
    this.disabled || (this.options.keyboard && (this.options.keyboard.enabled = !1), this.target instanceof HTMLElement && this.target.removeAttribute("tabindex"));
  }, r.prototype.destroy = function() {
    this.mousetrap.reset();
  }, r.prototype.getKeys = function(t) {
    var e = this;
    return (Array.isArray(t) ? t : [t]).map(function(o) {
      return e.formatKey(o);
    });
  }, r.prototype.formatKey = function(t) {
    return t.toLowerCase().replace(/\s/g, "").replace("delete", "del").replace("cmd", "command");
  }, r;
})(), Oe = function() {
  return Oe = Object.assign || function(r) {
    for (var t, e = 1, o = arguments.length; e < o; e++) {
      t = arguments[e];
      for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && (r[n] = t[n]);
    }
    return r;
  }, Oe.apply(this, arguments);
}, Io = function(r, t) {
  var e = typeof Symbol == "function" && r[Symbol.iterator];
  if (!e) return r;
  var o = e.call(r), n, i = [], a;
  try {
    for (; (t === void 0 || t-- > 0) && !(n = o.next()).done; ) i.push(n.value);
  } catch (s) {
    a = { error: s };
  } finally {
    try {
      n && !n.done && (e = o.return) && e.call(o);
    } finally {
      if (a) throw a.error;
    }
  }
  return i;
}, Hn = function(r, t, e) {
  if (e || arguments.length === 2)
    for (var o = 0, n = t.length, i; o < n; o++) (i || !(o in t)) && (i || (i = Array.prototype.slice.call(t, 0, o)), i[o] = t[o]);
  return r.concat(i || Array.prototype.slice.call(t));
}, Gn = /* @__PURE__ */ Symbol("plugin registered by Logicflow.use"), Ci = (function() {
  function r(t) {
    var e = this, o;
    this.viewMap = /* @__PURE__ */ new Map(), this.components = [], this.extension = {}, this.setView = function(u, c) {
      return e.viewMap.set(u, c);
    }, this.getView = function(u) {
      return e.viewMap.get(u);
    };
    var n = to.get(t), i = n.container, a = n.width, s = n.height;
    this.options = n, this.container = this.initContainer(i, a, s), this.graphModel = new hh(Oe(Oe({}, n), { container: this.container })), this.plugins = (o = n.plugins) !== null && o !== void 0 ? o : [];
    var l = this.graphModel.eventCenter;
    this.tool = new dv(this), this.dnd = new tv({ lf: this }), this.history = new bv(l), this.keyboard = new Mv({
      lf: this,
      keyboard: n.keyboard
    }), n.snapline !== !1 && (this.snaplineModel = new vh(this.graphModel, n.snaplineEpsilon), ev(l, this.snaplineModel)), n.isSilentMode || (Av(this, this.graphModel), this.keyboard.initShortcuts()), this.defaultRegister(), this.installPlugins(n.disabledPlugins);
  }
  return r.prototype.initContainer = function(t, e, o) {
    var n = document.createElement("div");
    return n.style.position = "relative", n.style.width = e ? "".concat(e, "px") : "100%", n.style.height = o ? "".concat(o, "px") : "100%", t.innerHTML = "", t.appendChild(n), n;
  }, Object.defineProperty(r.prototype, Symbol.toStringTag, {
    get: function() {
      return r.toStringTag;
    },
    enumerable: !1,
    configurable: !0
  }), r.prototype.register = function(t, e, o) {
    if (o === void 0 && (o = !0), typeof t != "string") {
      this.registerElement(t);
      return;
    }
    var n = {
      BaseEdge: wn,
      BaseEdgeModel: On,
      BaseNode: Le,
      BaseNodeModel: Ce,
      RectNode: ks,
      RectNodeModel: Cs,
      CircleNode: Bs,
      CircleNodeModel: Ps,
      PolygonNode: Xs,
      PolygonNodeModel: Ds,
      TextNode: Gs,
      TextNodeModel: js,
      LineEdge: Ni,
      LineEdgeModel: yi,
      DiamondNode: Ys,
      DiamondNodeModel: Ts,
      PolylineEdge: $s,
      PolylineEdgeModel: As,
      BezierEdge: Pi,
      BezierEdgeModel: vi,
      EllipseNode: Hs,
      EllipseNodeModel: Ns,
      HtmlNode: Si,
      HtmlNodeModel: gi,
      h: Ot,
      type: t
    };
    if (this.viewMap.forEach(function(u) {
      var c = u.extendKey;
      c && (n[c] = u);
    }), this.graphModel.modelMap.forEach(function(u) {
      var c = u.extendKey;
      c && (n[c] = u);
    }), e) {
      var i = e(n), a = i.view, s = i.model, l = a;
      o && !l.isObserved && (l.isObserved = !0, l = Rt(l)), this.setView(t, l), this.graphModel.setModel(t, s);
    }
  }, r.prototype.registerElement = function(t) {
    var e = t.view;
    t.isObserverView !== !1 && !e.isObserved && (e.isObserved = !0, e = Rt(e)), this.setView(t.type, e), this.graphModel.setModel(t.type, t.model);
  }, r.prototype.batchRegister = function(t) {
    var e = this;
    t === void 0 && (t = []), pt(t, function(o) {
      e.registerElement(o);
    });
  }, r.prototype.defaultRegister = function() {
    var t = [
      {
        type: "rect",
        view: ks,
        model: Cs
      },
      {
        type: "circle",
        view: Bs,
        model: Ps
      },
      {
        type: "polygon",
        view: Xs,
        model: Ds
      },
      {
        type: "text",
        view: Gs,
        model: js
      },
      {
        type: "ellipse",
        view: Hs,
        model: Ns
      },
      {
        type: "diamond",
        view: Ys,
        model: Ts
      },
      {
        type: "html",
        view: Si,
        model: gi
      },
      {
        type: "line",
        view: Ni,
        model: yi
      },
      {
        type: "polyline",
        view: $s,
        model: As
      },
      {
        type: "bezier",
        view: Pi,
        model: vi
      }
    ];
    this.batchRegister(t);
  }, r.prototype.addNode = function(t, e, o) {
    return e === void 0 && (e = L.NODE_ADD), this.graphModel.addNode(t, e, o);
  }, r.prototype.deleteNode = function(t) {
    var e = this.graphModel.getNodeModelById(t);
    if (!e) return !1;
    var o = e.getData(), n = this.options.guards, i = n != null && n.beforeDelete ? n.beforeDelete(o) : !0;
    return i && this.graphModel.deleteNode(t), i;
  }, r.prototype.cloneNode = function(t) {
    var e = this.graphModel.getNodeModelById(t), o = e == null ? void 0 : e.getData();
    if (o) {
      var n = this.options.guards;
      if (!(n != null && n.beforeClone) || n.beforeClone(o)) return this.graphModel.cloneNode(t);
    }
  }, r.prototype.changeNodeId = function(t, e) {
    return this.graphModel.changeNodeId(t, e);
  }, r.prototype.changeNodeType = function(t, e) {
    this.graphModel.changeNodeType(t, e);
  }, r.prototype.getNodeModelById = function(t) {
    return this.graphModel.getNodeModelById(t);
  }, r.prototype.getNodeDataById = function(t) {
    var e = this.getNodeModelById(t);
    return e == null ? void 0 : e.getData();
  }, r.prototype.getNodeIncomingEdge = function(t) {
    return this.graphModel.getNodeIncomingEdge(t);
  }, r.prototype.getNodeOutgoingEdge = function(t) {
    return this.graphModel.getNodeOutgoingEdge(t);
  }, r.prototype.getNodeIncomingNode = function(t) {
    return this.graphModel.getNodeIncomingNode(t);
  }, r.prototype.getNodeOutgoingNode = function(t) {
    return this.graphModel.getNodeOutgoingNode(t);
  }, r.prototype.createFakeNode = function(t) {
    var e = this.graphModel.modelMap.get(t.type);
    if (!e)
      return null;
    var o = new e(Oe(Oe({}, t), { virtual: !0 }), this.graphModel);
    return this.graphModel.setFakeNode(o), o;
  }, r.prototype.removeFakeNode = function() {
    this.graphModel.removeFakeNode();
  }, r.prototype.setNodeSnapLine = function(t) {
    var e;
    (e = this.snaplineModel) === null || e === void 0 || e.setNodeSnapLine(t);
  }, r.prototype.removeNodeSnapLine = function() {
    var t;
    (t = this.snaplineModel) === null || t === void 0 || t.clearSnapline();
  }, r.prototype.setDefaultEdgeType = function(t) {
    this.graphModel.setDefaultEdgeType(t);
  }, r.prototype.addEdge = function(t) {
    return this.graphModel.addEdge(t);
  }, r.prototype.getEdgeDataById = function(t) {
    var e = this.getEdgeModelById(t);
    return e == null ? void 0 : e.getData();
  }, r.prototype.getEdgeModelById = function(t) {
    return this.graphModel.getEdgeModelById(t);
  }, r.prototype.getEdgeModels = function(t) {
    var e = t.sourceNodeId, o = t.targetNodeId, n = [], i = this.graphModel.edges;
    return e && o ? pt(i, function(a) {
      a.sourceNodeId === e && a.targetNodeId === o && n.push(a);
    }) : e ? pt(i, function(a) {
      a.sourceNodeId === e && n.push(a);
    }) : o && pt(i, function(a) {
      a.targetNodeId === o && n.push(a);
    }), n;
  }, r.prototype.changeEdgeId = function(t, e) {
    return this.graphModel.changeEdgeId(t, e);
  }, r.prototype.changeEdgeType = function(t, e) {
    this.graphModel.changeEdgeType(t, e);
  }, r.prototype.deleteEdge = function(t) {
    var e = this.graphModel.getEdgeModelById(t);
    if (!e) return !1;
    var o = e.getData(), n = this.options.guards, i = n != null && n.beforeDelete ? n.beforeDelete(o) : !0;
    return i && this.graphModel.deleteEdgeById(t), i;
  }, r.prototype.deleteEdgeByNodeId = function(t) {
    var e = t.sourceNodeId, o = t.targetNodeId;
    e && o ? this.graphModel.deleteEdgeBySourceAndTarget(e, o) : e ? this.graphModel.deleteEdgeBySource(e) : o && this.graphModel.deleteEdgeByTarget(o);
  }, r.prototype.getNodeEdges = function(t) {
    return this.graphModel.getNodeEdges(t);
  }, r.prototype.addElements = function(t, e) {
    var o = this, n = t.nodes, i = t.edges;
    e === void 0 && (e = 40);
    var a = {}, s = {
      nodes: [],
      edges: []
    };
    return pt(n, function(l) {
      var u = l.id, c = o.addNode(l);
      u && (a[u] = c.id), s.nodes.push(c);
    }), pt(i, function(l) {
      var u = l.sourceNodeId, c = l.targetNodeId;
      a[u] && (u = a[u]), a[c] && (c = a[c]);
      var d = o.graphModel.addEdge(Oe(Oe({}, l), {
        sourceNodeId: u,
        targetNodeId: c
      }));
      s.edges.push(d);
    }), s;
  }, r.prototype.selectElementById = function(t, e, o) {
    e === void 0 && (e = !1), o === void 0 && (o = !0), this.graphModel.selectElementById(t, e), !e && o && this.graphModel.toFront(t);
  }, r.prototype.deselectElementById = function(t) {
    this.graphModel.deselectElementById(t);
  }, r.prototype.getSelectElements = function(t) {
    return t === void 0 && (t = !0), this.graphModel.getSelectElements(t);
  }, r.prototype.clearSelectElements = function() {
    this.graphModel.clearSelectElements();
  }, r.prototype.getModelById = function(t) {
    return this.graphModel.getElement(t);
  }, r.prototype.getDataById = function(t) {
    var e;
    return (e = this.graphModel.getElement(t)) === null || e === void 0 ? void 0 : e.getData();
  }, r.prototype.deleteElement = function(t) {
    var e, o, n, i = this.getModelById(t);
    return i && (n = (o = (e = {}, e[dt.NODE] = this.deleteNode, e[dt.EDGE] = this.deleteEdge, e)[i.BaseType]) === null || o === void 0 ? void 0 : o.call(this, t)) !== null && n !== void 0 ? n : !1;
  }, r.prototype.setElementZIndex = function(t, e) {
    return this.graphModel.setElementZIndex(t, e);
  }, r.prototype.getAreaElement = function(t, e, o, n, i) {
    return o === void 0 && (o = !0), n === void 0 && (n = !0), i === void 0 && (i = !1), this.graphModel.getAreaElement(t, e, o, n, i).map(function(a) {
      return a.getData();
    });
  }, r.prototype.setProperties = function(t, e) {
    var o;
    (o = this.graphModel.getElement(t)) === null || o === void 0 || o.setProperties(Mt(e));
  }, r.prototype.getProperties = function(t) {
    var e;
    return (e = this.graphModel.getElement(t)) === null || e === void 0 ? void 0 : e.getProperties();
  }, r.prototype.deleteProperty = function(t, e) {
    var o;
    (o = this.graphModel.getElement(t)) === null || o === void 0 || o.deleteProperty(e);
  }, r.prototype.updateAttributes = function(t, e) {
    this.graphModel.updateAttributes(t, e);
  }, r.prototype.editText = function(t) {
    this.graphModel.editText(t);
  }, r.prototype.updateText = function(t, e) {
    this.graphModel.updateText(t, e);
  }, r.prototype.updateEditConfig = function(t) {
    var e = this.graphModel, o = e.editConfigModel, n = e.transformModel, i = o.snapGrid;
    if (o.updateEditConfig(t), (t == null ? void 0 : t.stopMoveGraph) !== void 0 && n.updateTranslateLimits(t.stopMoveGraph), t != null && t.isSilentMode ? this.keyboard.disable() : this.keyboard.enable(!0), !yt(t == null ? void 0 : t.snapGrid) && t.snapGrid !== i) {
      var a = this.graphModel.grid.size, s = a === void 0 ? 1 : a;
      this.graphModel.updateGridSize(t.snapGrid ? s : 1);
    }
    this.emit(L.EDIT_CONFIG_CHANGED, { data: o.getConfig() });
  }, r.prototype.getEditConfig = function() {
    return this.graphModel.editConfigModel.getConfig();
  }, r.prototype.setTheme = function(t, e) {
    this.graphModel.setTheme(t, e);
  }, r.prototype.getTheme = function() {
    return this.graphModel.getTheme();
  }, r.prototype.focusByElement = function(t) {
    var e = void 0, o = this.getNodeModelById(t);
    if (o) {
      var n = o.getData(), i = n.x, a = n.y;
      e = {
        x: i,
        y: a
      };
    }
    var s = this.getEdgeModelById(t);
    if (s) {
      var l = s.textPosition, i = l.x, a = l.y;
      e = {
        x: i,
        y: a
      };
    }
    e && this.focusByCoordinate(e);
  }, r.prototype.focusByCoordinate = function(t) {
    var e = this.graphModel, o = e.transformModel, n = e.width, i = e.height, a = t.x, s = t.y;
    o.focusOn(a, s, n, i);
  }, r.prototype.focusOn = function(t) {
    if (typeof t == "string") this.focusByElement(t);
    else if ("x" in t && "y" in t) this.focusByCoordinate(t);
    else {
      var e = t.id, o = t.coordinate;
      e && this.focusByElement(e), o && this.focusByCoordinate(o);
    }
  }, r.prototype.resize = function(t, e) {
    this.graphModel.resize(t, e), this.options.width = this.graphModel.width, this.options.height = this.graphModel.height;
  }, r.prototype.toFront = function(t) {
    this.graphModel.toFront(t);
  }, r.prototype.getPointByClient = function(t, e) {
    if (typeof t == "object") return this.graphModel.getPointByClient(t);
    if (typeof e == "number") return this.graphModel.getPointByClient({
      x: t,
      y: e
    });
  }, r.prototype.getGraphData = function() {
    for (var t = [], e = 0; e < arguments.length; e++) t[e] = arguments[e];
    var o = this.getGraphRawData();
    return this.adapterOut ? this.adapterOut.apply(this, Hn([o], Io(t), !1)) : o;
  }, r.prototype.getGraphRawData = function() {
    return this.graphModel.modelToGraphData();
  }, r.prototype.clearData = function() {
    this.graphModel.clearData(), this.render({});
  }, r.prototype.setOverlapMode = function(t) {
    this.graphModel.setOverlapMode(t);
  }, r.prototype.renderRawData = function(t) {
    this.graphModel.graphDataToModel(Mt(t)), this.options.history !== !1 && this.history.watch(this.graphModel), qa(S(xh, {
      getView: this.getView,
      tool: this.tool,
      options: this.options,
      dnd: this.dnd,
      snaplineModel: this.snaplineModel,
      graphModel: this.graphModel
    }), this.container), this.emit(L.GRAPH_RENDERED, {
      data: this.graphModel.modelToGraphData(),
      graphModel: this.graphModel
    });
  }, r.prototype.render = function(t) {
    var e = R(t);
    this.adapterIn && (e = this.adapterIn(e)), this.renderRawData(e);
  }, r.prototype.undo = function() {
    if (this.history.undoAble()) {
      var t = Mt(this.history.undo());
      this.clearSelectElements(), this.graphModel.graphDataToModel(t);
    }
  }, r.prototype.redo = function() {
    if (this.history.redoAble()) {
      var t = Mt(this.history.redo());
      this.clearSelectElements(), this.graphModel.graphDataToModel(t);
    }
  }, r.prototype.zoom = function(t, e) {
    return this.graphModel.transformModel.zoom(t, e);
  }, r.prototype.resetZoom = function() {
    this.graphModel.transformModel.resetZoom();
  }, r.prototype.setZoomMiniSize = function(t) {
    this.graphModel.transformModel.setZoomMiniSize(t);
  }, r.prototype.setZoomMaxSize = function(t) {
    this.graphModel.transformModel.setZoomMaxSize(t);
  }, r.prototype.getTransform = function() {
    var t = this.graphModel.transformModel;
    return {
      SCALE_X: t.SCALE_X,
      SCALE_Y: t.SCALE_Y,
      TRANSLATE_X: t.TRANSLATE_X,
      TRANSLATE_Y: t.TRANSLATE_Y
    };
  }, r.prototype.translate = function(t, e) {
    this.graphModel.transformModel.translate(t, e);
  }, r.prototype.resetTranslate = function() {
    var t = this.graphModel.transformModel, e = t.TRANSLATE_X, o = t.TRANSLATE_Y;
    this.translate(-e, -o);
  }, r.prototype.translateCenter = function() {
    this.graphModel.translateCenter();
  }, r.prototype.fitView = function(t, e) {
    e === void 0 && (e = t), this.graphModel.fitView(t, e);
  }, r.prototype.openEdgeAnimation = function(t) {
    this.graphModel.openEdgeAnimation(t);
  }, r.prototype.closeEdgeAnimation = function(t) {
    this.graphModel.closeEdgeAnimation(t);
  }, r.prototype.on = function(t, e) {
    this.graphModel.eventCenter.on(t, e);
  }, r.prototype.off = function(t, e) {
    this.graphModel.eventCenter.off(t, e);
  }, r.prototype.once = function(t, e) {
    this.graphModel.eventCenter.once(t, e);
  }, r.prototype.emit = function(t, e) {
    this.graphModel.eventCenter.emit(t, e);
  }, r.use = function(t, e) {
    var o, n = t.pluginName;
    if (!n) throw new Error("请给插件指定 pluginName!");
    this.extensions.set(n, (o = {}, o[Gn] = Gn, o.extension = t, o.props = e, o));
  }, r.addThemeMode = function(t, e) {
    up(t, e);
  }, r.removeThemeMode = function(t) {
    cp(t);
  }, r.clearThemeMode = function() {
    dp();
  }, r.prototype.installPlugins = function(t) {
    var e = this;
    t === void 0 && (t = []);
    var o = Array.from(r.extensions, function(i) {
      return Io(i, 2)[1];
    }), n = Hn(Hn([], Io(this.plugins), !1), Io(o), !1);
    pt(n, function(i) {
      var a, s;
      Gn in i ? (a = i.extension, s = i.props) : a = i;
      var l = a == null ? void 0 : a.pluginName;
      Nu(t, l) === -1 && e.installPlugin(a, s);
    });
  }, r.prototype.installPlugin = function(t, e) {
    var o, n;
    if ("pluginName" in t && "install" in t) {
      var i = t.pluginName, a = t.install, s = t.render;
      i && (a && a.call(t, this, r), s && this.components.push(s.bind(t)), this.extension[i] = t);
      return;
    }
    var l = t, u = l.pluginName, c = new l({
      lf: this,
      LogicFlow: r,
      props: e,
      options: (n = (o = this.options.pluginsOptions) === null || o === void 0 ? void 0 : o[u]) !== null && n !== void 0 ? n : {}
    });
    c.render && this.components.push(c.render.bind(c)), this.extension[u] = c;
  }, r.prototype.destroy = function() {
    var t;
    this.clearData(), qa(null, this.container), this.keyboard.destroy(), this.graphModel.destroy(), this.tool.destroy(), this.history.destroy();
    for (var e in this.extension) {
      var o = this.extension[e];
      "destroy" in o && ((t = o.destroy) === null || t === void 0 || t.call(o));
    }
  }, r.extensions = /* @__PURE__ */ new Map(), r;
})();
(function(r) {
  r.toStringTag = "LF.".concat(r.name);
})(Ci || (Ci = {}));
var Pv = Ci;
function Rt(r) {
  return oa(r);
}
var yy = Pv, z = /* @__PURE__ */ Ou({
  Vue: () => Pu,
  Vue2: () => {
  },
  del: () => Cv,
  install: () => Nv,
  isVue2: () => !1,
  isVue3: () => !0,
  set: () => Dv
});
Su(z, Tv);
function Nv() {
}
function Dv(r, t, e) {
  return Array.isArray(r) ? (r.length = Math.max(r.length, t), r.splice(t, 1, e), e) : (r[t] = e, e);
}
function Cv(r, t) {
  if (Array.isArray(r)) {
    r.splice(t, 1);
    return;
  }
  delete r[t];
}
var Lv = /* @__PURE__ */ (function() {
  var r = function(t, e) {
    return r = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(o, n) {
      o.__proto__ = n;
    } || function(o, n) {
      for (var i in n) Object.prototype.hasOwnProperty.call(n, i) && (o[i] = n[i]);
    }, r(t, e);
  };
  return function(t, e) {
    if (typeof e != "function" && e !== null) throw new TypeError("Class extends value " + String(e) + " is not a constructor or null");
    r(t, e);
    function o() {
      this.constructor = t;
    }
    t.prototype = e === null ? Object.create(e) : (o.prototype = e.prototype, new o());
  };
})(), ne = function() {
  return ne = Object.assign || function(r) {
    for (var t, e = 1, o = arguments.length; e < o; e++) {
      t = arguments[e];
      for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && (r[n] = t[n]);
    }
    return r;
  }, ne.apply(this, arguments);
}, yu = (function(r) {
  Lv(t, r);
  function t(e, o) {
    var n = r.call(this, e, o) || this, i = e.properties;
    if (i) {
      var a = i._showTitle, s = a === void 0 ? !1 : a, l = i.style, u = l === void 0 ? {} : l;
      if (s) {
        n.minWidth = 160, n.minHeight = 80, n.text.editable = !1;
        var c = n.width < n.minWidth ? n.minWidth : n.width, d = n.height < n.minHeight ? n.minHeight : n.height;
        n.setProperties(ne(ne({ _expanded: !1 }, i), {
          style: ne({ overflow: "visible" }, R(u)),
          width: c + 8,
          height: d + 8
        })), n.setNodeActions([{
          name: "复制",
          callback: function(f, p) {
            p.cloneNode(f.id);
          }
        }, {
          name: "删除",
          callback: function(f, p) {
            p.deleteNode(f.id);
          }
        }]);
      }
    }
    return n;
  }
  return t.prototype.setAttributes = function() {
    var e = this.properties, o = e.width, n = e.height, i = e.radius, a = e._showTitle, s = e._titleHeight;
    yt(o) || (this.width = o), yt(n) || (this.height = n), yt(i) || (this.radius = i), this.__baseHeight === void 0 && (this.__baseHeight = yt(n) ? this.height : n);
    var l = a ? s != null ? s : 28 : 0, u = yt(n) ? this.__baseHeight : n;
    this.height = u + l;
  }, t.prototype.getTextStyle = function() {
    var e = this.properties, o = e.refX, n = o === void 0 ? 0 : o, i = e.refY, a = i === void 0 ? 0 : i, s = e.textStyle, l = r.prototype.getTextStyle.call(this);
    return ne(ne(ne({}, l), R(s) || {}), { transform: "matrix(1 0 0 1 ".concat(n, " ").concat(a, ")") });
  }, t.prototype.getNodeStyle = function() {
    var e = r.prototype.getNodeStyle.call(this), o = this.properties.style;
    return ne(ne({}, e), R(o) || {});
  }, t.prototype.setNodeActions = function(e) {
    this.__actions = Ii(e) && !qr(e) ? R(e) : [];
  }, t;
})(gi), Li = /* @__PURE__ */ new WeakMap(), jv = /* @__PURE__ */ Object.create(null);
function Rv(r, t) {
  var e;
  if (!(typeof t != "object" || t === null))
    return (e = Li.get(t)) === null || e === void 0 ? void 0 : e.get(r);
}
function gy(r, t) {
  var e = r.type, o = r.component, n = r.effect, i = r.view, a = r.model;
  if (!e) throw new Error("You should specify type in config");
  var s = {
    component: o,
    effect: n
  }, l = Li.get(t.graphModel);
  l || (l = /* @__PURE__ */ new Map(), Li.set(t.graphModel, l)), l.set(e, s), jv[e] = s, t.register({
    type: e,
    view: i || gu,
    model: a || yu
  });
}
var Pr = !1, br = /* @__PURE__ */ new Map(), Or = /* @__PURE__ */ new Map(), vn = (0, z.reactive)({});
function Iv(r, t, e, o, n) {
  Pr && (n.isMiniMap && Bv(e, n.flowId), vn[r] = (0, z.markRaw)((0, z.defineComponent)({
    render: function() {
      return (0, z.h)(z.Teleport, { to: e }, [(0, z.h)(t, {
        node: o,
        graph: n
      })]);
    },
    provide: function() {
      return {
        getNode: function() {
          return o;
        },
        getGraph: function() {
          return n;
        }
      };
    }
  })));
}
function zn(r, t) {
  if (Pr && (delete vn[r], br.has(t))) {
    var e = Or.get(t) || [], o = e.indexOf(r);
    o > -1 && (e.splice(o, 1), e.length === 0 ? Xv(t) : Or.set(t, e));
  }
}
function Cr() {
  return Pr;
}
function kv() {
  return Pr = !0, (0, z.defineComponent)({
    props: { flowId: {
      type: String,
      required: !0
    } },
    setup: function(r) {
      return function() {
        var t = [];
        return Object.keys(vn).forEach(function(e) {
          if (e.startsWith(r.flowId)) {
            if (br.has(r.flowId)) {
              var o = Or.get(r.flowId) || [];
              o.includes(e) || (o.push(e), Or.set(r.flowId, o));
            }
            t.push(vn[e]);
          }
        }), (0, z.h)(z.Fragment, {}, t.map(function(e) {
          return (0, z.h)(e);
        }));
      };
    }
  });
}
function Bv(r, t) {
  if (!(!t || !r || !Pr)) {
    var e = kv();
    if (!br.has(t)) {
      var o = document.createElement("div");
      r.appendChild(o);
      var n = (0, z.createApp)(e, { flowId: t });
      n.mount(o), br.set(t, n), Or.set(t, []);
    }
  }
}
function Xv(r) {
  if (!(!r || !Pr)) {
    var t = br.get(r);
    t && (t.unmount(), br.delete(r), Or.delete(r));
  }
}
var Yv = (0, z.defineComponent)({
  name: "LFVueNodeTitleBar",
  props: {
    node: {
      type: Object,
      required: !0
    },
    graph: {
      type: Object,
      required: !0
    }
  },
  data: function() {
    return { showTooltip: !1 };
  },
  mounted: function() {
    var r = this, t, e, o = ((e = (t = this.node) === null || t === void 0 ? void 0 : t.properties) === null || e === void 0 ? void 0 : e.titleTrigger) === "hover" ? "hover" : "click", n = this.$refs.moreBtn || null, i = this.$refs.tooltip || null, a = function(s) {
      if (!(!i || !n)) {
        var l = s.target;
        r.showTooltip && !i.contains(l) && !n.contains(l) && (r.showTooltip = !1);
      }
    };
    o === "hover" && n && i ? (n.addEventListener("mouseenter", function() {
      r.showTooltip = !0;
    }), n.addEventListener("mouseleave", function() {
      r.showTooltip = !1;
    })) : o === "click" && n && (n.addEventListener("click", function(s) {
      s.stopPropagation(), r.showTooltip = !r.showTooltip;
    }), document.addEventListener("click", a), this.$once && this.$once("hook:beforeDestroy", function() {
      document.removeEventListener("click", a);
    }));
  },
  methods: {
    toggleExpand: function() {
      var r, t, e, o = !!(!((t = (r = this.node) === null || r === void 0 ? void 0 : r.properties) === null || t === void 0) && t._expanded);
      (e = this.node) === null || e === void 0 || e.setProperty("_expanded", !o);
    },
    runAction: function(r) {
      try {
        typeof (r == null ? void 0 : r.callback) == "function" && r.callback(this.node, this.graph);
      } finally {
        this.showTooltip = !1;
      }
    }
  },
  render: function() {
    var r = this, t, e, o = ((t = this.node) === null || t === void 0 ? void 0 : t.properties) || {}, n = o._icon, i = o._title || "", a = !!o._expanded, s = Js(o._titleHeight) ? o._titleHeight : 28, l = ((e = this.node) === null || e === void 0 ? void 0 : e.__actions) || [], u = !qr(l);
    return (0, z.h)("div", {
      class: a ? "lf-vue-node-title lf-vue-node-title-expanded" : "lf-vue-node-title",
      style: "height:".concat(a ? s : 18, "px;"),
      title: i
    }, [(0, z.h)("div", { class: "lf-vue-node-title-left" }, [n ? (0, z.h)("i", { class: "lf-vue-node-title-icon" }, n) : null, (0, z.h)("span", { class: "lf-vue-node-title-text" }, i)]), (0, z.h)("div", { class: "lf-vue-node-title-actions" }, [
      (0, z.h)("button", {
        ref: "expandBtn",
        class: "lf-vue-node-title-expand",
        onClick: function(c) {
          c.stopPropagation(), r.toggleExpand();
        },
        on: { click: function(c) {
          c.stopPropagation(), r.toggleExpand();
        } }
      }, [(0, z.h)("svg", {
        width: 14,
        height: 12,
        viewBox: "0 0 14 12",
        xmlns: "http://www.w3.org/2000/svg",
        class: "lf-vue-node-title-expand-icon",
        style: "transform:".concat(a ? "rotate(180deg)" : "rotate(0deg)", ";")
      }, [(0, z.h)("path", {
        d: "M0.5201124,5.47988755C0.23603013,5.7639699,0.24460429,6.2271326,0.53900635,6.5005059L6.3195491,11.8681526C6.7032304,12.2244282,7.2967696,12.2244282,7.6804514,11.8681526L13.460994,6.5005059C13.755396,6.2271326,13.76397,5.7639699,13.479888,5.47988755C13.211547,5.21154633,12.779465,5.20215771,12.499721,5.45858961L7.3378625,10.1902928C7.1467018,10.3655233,6.8532982,10.3655233,6.6621375,10.1902928L1.5002797,5.45858967C1.2205358,5.20215771,0.78845364,5.21154633,0.5201124,5.47988755Z",
        fill: "#474747"
      }), (0, z.h)("path", {
        d: "M0.5201124,0.47988755C0.23603013,0.7639699,0.24460429,1.2271326,0.53900635,1.5005059L6.3195491,6.8681526C6.7032304,7.2244282,7.2967696,7.2244282,7.6804514,6.8681526L13.460994,1.5005059C13.755396,1.2271326,13.76397,0.7639699,13.479888,0.47988755C13.211547,0.21154633,12.779465,0.20215771,12.499721,0.45858961L7.3378625,5.1902928C7.1467018,5.3655233,6.8532982,5.3655233,6.6621375,5.1902928L1.5002797,0.45858967C1.2205358,0.20215771,0.78845364,0.21154633,0.5201124,0.47988755Z",
        fill: "#9B9B9B"
      })])]),
      u && (0, z.h)("button", {
        ref: "moreBtn",
        class: "lf-vue-node-title-more"
      }, [(0, z.h)("i", { class: "lf-vue-node-title-more-icon" }, "⋯")]),
      (0, z.h)("div", {
        ref: "tooltip",
        class: "lf-vue-node-title-tooltip",
        style: "opacity:".concat(this.showTooltip ? 1 : 0, ";pointer-events:").concat(this.showTooltip ? "auto" : "none", ";")
      }, [(0, z.h)("div", { class: "lf-vue-node-title-tooltip-list" }, l.map(function(c) {
        return (0, z.h)("div", {
          class: "lf-vue-node-title-tooltip-item",
          onClick: function(d) {
            d.stopPropagation(), r.runAction(c);
          },
          on: { click: function(d) {
            d.stopPropagation(), r.runAction(c);
          } }
        }, (c == null ? void 0 : c.name) || "");
      }))])
    ])]);
  }
}), Hv = (0, z.defineComponent)({
  name: "LFVueNodeContainer",
  props: {
    node: {
      type: Object,
      required: !0
    },
    graph: {
      type: Object,
      required: !0
    }
  },
  render: function() {
    var r, t, e = ((r = this.node) === null || r === void 0 ? void 0 : r.properties) || {}, o = [], n = e.style.titleColor || "#E5EEFC";
    return e._showTitle && o.push((0, z.h)(Yv, {
      node: this.node,
      graph: this.graph
    })), e._expanded === !0 && o.push((0, z.h)("div", { class: "lf-vue-node-content-wrap" }, !((t = this.$slots) === null || t === void 0) && t.default ? this.$slots.default() : [])), (0, z.h)("div", {
      class: "lf-vue-node-container",
      style: " background: linear-gradient(180deg, ".concat(n, " 0%, #FFFFFF 24px)")
    }, o);
  }
}), Gv = /* @__PURE__ */ (function() {
  var r = function(t, e) {
    return r = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(o, n) {
      o.__proto__ = n;
    } || function(o, n) {
      for (var i in n) Object.prototype.hasOwnProperty.call(n, i) && (o[i] = n[i]);
    }, r(t, e);
  };
  return function(t, e) {
    if (typeof e != "function" && e !== null) throw new TypeError("Class extends value " + String(e) + " is not a constructor or null");
    r(t, e);
    function o() {
      this.constructor = t;
    }
    t.prototype = e === null ? Object.create(e) : (o.prototype = e.prototype, new o());
  };
})(), gu = (function(r) {
  Gv(t, r);
  function t() {
    var e = r !== null && r.apply(this, arguments) || this;
    return e.__throttledUpdate = Qs(function() {
      return e.measureAndUpdate();
    }, 80), e.measureAndUpdate = function() {
      try {
        var o = e.getComponentContainer();
        if (!o) return;
        var n = (o.firstElementChild || o).getBoundingClientRect(), i = pa(n.width), a = pa(n.height);
        if (i <= 0 || a <= 0 || i === e.__lastWidth && a === e.__lastHeight) return;
        e.__lastWidth = i, e.__lastHeight = a;
        var s = e.props.model.properties, l = He(s, "_showTitle") ? Js(He(s, "_titleHeight")) ? He(s, "_titleHeight") : 28 : 0, u = Tu(a - l, 1, Number.MAX_SAFE_INTEGER);
        e.props.model.setProperties({
          width: i,
          height: u
        });
      } catch (c) {
      }
    }, e;
  }
  return t.prototype.getComponentContainer = function() {
    return this.root;
  }, t.prototype.targetId = function() {
    return "".concat(this.props.graphModel.flowId, ":").concat(this.props.model.id);
  }, t.prototype.componentWillUnmount = function() {
    r.prototype.componentWillUnmount.call(this), this.unmount();
  }, t.prototype.setHtml = function(e) {
    if (!e.querySelector(".custom-vue-node-content")) {
      var o = document.createElement("div");
      o.className = "custom-vue-node-content", this.root = o, e.appendChild(o);
    }
    this.renderVueComponent(), this.startResizeObserver();
  }, t.prototype.confirmUpdate = function(e) {
    var o = (this.props.model.properties || {})._showTitle;
    o !== void 0 && o && this.setHtml(e);
  }, t.prototype.renderVueComponent = function() {
    var e;
    this.unmountVueComponent();
    var o = this.getComponentContainer(), n = this.props, i = n.model, a = n.graphModel, s = (i.properties || {})._showTitle, l = s === void 0 ? !1 : s, u = function(y) {
      return (0, z.defineComponent)({
        name: "LFVueNodeContainerWrapper",
        props: {
          node: {
            type: Object,
            required: !0
          },
          graph: {
            type: Object,
            required: !0
          }
        },
        render: function() {
          return l ? (0, z.h)(Hv, {
            node: this.node,
            graph: this.graph
          }, [(0, z.h)(y, {
            node: this.node,
            graph: this.graph
          })]) : (0, z.h)(y, {
            node: this.node,
            graph: this.graph
          });
        }
      });
    };
    if (o) {
      var c = Rv(i.type, a), d = this.props.graphModel.flowId;
      if (!c) {
        Cr() && d && zn(this.targetId(), d);
        return;
      }
      var f = c.component;
      if (!f) {
        Cr() && d && zn(this.targetId(), d);
        return;
      }
      if (f)
        if (0)
          var p, v;
        else if (Cr()) {
          var h = u(f);
          Iv(this.targetId(), h, o, i, a);
        } else {
          var g = u(f);
          this.vm = (0, z.createApp)({
            render: function() {
              return (0, z.h)(g, {
                node: i,
                graph: a
              });
            },
            provide: function() {
              return {
                getNode: function() {
                  return i;
                },
                getGraph: function() {
                  return a;
                }
              };
            }
          }), (e = this.vm) === null || e === void 0 || e.mount(o);
        }
    }
  }, t.prototype.startResizeObserver = function() {
    var e = this, o, n = this.getComponentContainer();
    if (n)
      try {
        if (ki(window.ResizeObserver)) {
          this.__resizeObserver = new window.ResizeObserver(function(a) {
            !Ii(a) || !a.length || (e.__resizeRafId && cancelAnimationFrame(e.__resizeRafId), e.__resizeRafId = requestAnimationFrame(e.__throttledUpdate));
          });
          var i = n.firstElementChild || n;
          (o = this.__resizeObserver) === null || o === void 0 || o.observe(i);
        } else
          window.addEventListener("resize", function() {
            return e.__throttledUpdate();
          }), this.__fallbackUnlisten = function() {
            return window.removeEventListener("resize", function() {
              return e.__throttledUpdate();
            });
          };
      } catch (a) {
      }
  }, t.prototype.stopResizeObserver = function() {
    try {
      this.__resizeObserver && (this.__resizeObserver.disconnect(), this.__resizeObserver = void 0), this.__resizeRafId && (cancelAnimationFrame(this.__resizeRafId), this.__resizeRafId = void 0), this.__fallbackUnlisten && (this.__fallbackUnlisten(), this.__fallbackUnlisten = void 0);
    } catch (e) {
    }
  }, t.prototype.unmountVueComponent = function() {
    var e = this.getComponentContainer();
    return this.stopResizeObserver(), this.vm && (this.vm.unmount(), this.vm = null), e && !Cr() && (e.innerHTML = ""), e;
  }, t.prototype.unmount = function() {
    Cr() && zn(this.targetId(), this.props.graphModel.flowId), this.unmountVueComponent();
  }, t;
})(Si), ji = "j-airag-vue-node", _y = { LINK_BODY: "link_body" }, my = "_" + Bo.LOOP_BODY, ko = {
  LINK_LOOP: "link_loop",
  LOOP_START: "loop_start",
  LOOP_END: "loop_end"
}, xy = [{
  field: "currentLoopTimes",
  name: "当前循环次数",
  type: "number"
}, {
  field: "currentLoopItem",
  name: "当前循环项",
  type: "any"
}];
function Ri(r, t, e) {
  for (var o = [], n = Math.max(r.length, t.length), i = 0, a = 0; a < n || i; ) {
    var s = a < r.length ? r[a] : 0, l = a < t.length ? t[a] : 0, u = i + s + l;
    o.push(u % e), i = Math.floor(u / e), a++;
  }
  return o;
}
function Ws(r, t, e) {
  if (r < 0) return null;
  if (r == 0) return [];
  for (var o = [], n = t; r & 1 && (o = Ri(o, n, e)), r = r >> 1, r !== 0; )
    n = Ri(n, n, e);
  return o;
}
function zv(r, t) {
  for (var e = r.split(""), o = [], n = e.length - 1; n >= 0; n--) {
    var i = parseInt(e[n], t);
    if (isNaN(i)) return null;
    o.push(i);
  }
  return o;
}
function $v(r, t, e) {
  var o = zv(r, t);
  if (o === null) return null;
  for (var n = [], i = [1], a = 0; a < o.length; a++)
    o[a] && (n = Ri(n, Ws(o[a], i, e), e)), i = Ws(t, i, e);
  for (var s = "", a = n.length - 1; a >= 0; a--) s += n[a].toString(e);
  return s;
}
function Uv(r) {
  return r.substring(0, 2) === "0x" && (r = r.substring(2)), r = r.toLowerCase(), $v(r, 16, 10);
}
var Vv = class {
  constructor(r) {
    r = r || {}, this.seq = 0, this.mid = (r.mid || 1) % 1023, this.offset = r.offset || 0, this.lastTime = 0;
  }
  generate() {
    const r = Date.now(), t = (r - this.offset).toString(2);
    if (this.lastTime == r) {
      if (this.seq++, this.seq > 4095)
        for (this.seq = 0; Date.now() <= r; ) ;
    } else this.seq = 0;
    this.lastTime = r;
    let e = this.seq.toString(2), o = this.mid.toString(2);
    for (; e.length < 12; ) e = "0" + e;
    for (; o.length < 10; ) o = "0" + o;
    const n = t + o + e;
    let i = "";
    for (let a = n.length; a > 0; a -= 4) i = parseInt(n.substring(a - 4, a), 2).toString(16) + i;
    return Uv(i);
  }
}, Fv = new Vv({
  mid: ju(0, 1023),
  offset: 1702944e6
});
function ua() {
  return Fv.generate();
}
var Lr = Mu(), Ey = class extends yu {
  constructor(r, t) {
    r.id || (r.id = ua()), delete r.text, super(r, t), this.type = r.type, this.nodeConfig = Au.get(r.type), this.initNodeData(r);
  }
  updateId(r) {
    if (!r || this.id === r) return;
    const t = this.id;
    Lr.removeProps(t), this.id = r, Lr.setProps(this);
  }
  initNodeData(r) {
    var t, e, o, n, i;
    if (!this.nodeConfig) return;
    r.properties = (t = r.properties) !== null && t !== void 0 ? t : {};
    const { params: a, methods: s } = this.nodeConfig;
    this.width = (e = (o = r.properties.width) !== null && o !== void 0 ? o : a == null ? void 0 : a.width) !== null && e !== void 0 ? e : 332, this.height = (n = (i = r.properties.height) !== null && i !== void 0 ? i : a == null ? void 0 : a.height) !== null && n !== void 0 ? n : 62, r.properties.width = this.width, r.properties.height = this.height, typeof (s == null ? void 0 : s.initNodeData) == "function" && s.initNodeData.call(this, r), super.initNodeData(r), Lr.setProps(this);
    const l = (u, c) => (u == null ? void 0 : u.id) === (c == null ? void 0 : c.id);
    this.sourceRules.push({
      validate: (u, c, d, f) => {
        if (u == null || c == null || l(u, c) || d == null || f == null) return !1;
        const p = u.type, v = c.type, h = p === Bo.LOOP_BODY ? u.id : Lr.nodeGroupMap.get(u.id), g = h === c.id ? c.id : Lr.nodeGroupMap.get(c.id);
        if ((h || g) && h !== g) return !1;
        if (v === Bo.LOOP_BODY) {
          if (d.type === "right" && f.type === ko.LOOP_END) return !0;
        } else if (p === Bo.LOOP_BODY && d.type === ko.LOOP_START && f.type === "left")
          return !0;
        return d.type === "right" && f.type === "left";
      },
      message: "右侧锚点只能连接左侧锚点！"
    }), this.targetRules.push({
      message: "左侧锚点只能连接右侧锚点！",
      validate: (u, c, d, f) => {
        if (l(u, c) || d == null || f == null) return !1;
        if (f.type === ko.LOOP_END || d.type === ko.LOOP_START) return !0;
        let p = !1;
        if (f.type === "left" && d.type === "right") {
          const v = this.graphModel.getNodeIncomingEdge(c.id);
          v && v.length > 0 ? p = !v.some((h) => h.sourceAnchorId === d.id) : p = !0;
        }
        return p ? !this.graphModel.$J.getAllPrevNodes(u).some((v) => v.id === c.id) : !1;
      }
    });
  }
  getTextStyle() {
    const r = super.getTextStyle();
    return r.color = "transparent", r;
  }
  getNodeStyle() {
    const r = super.getNodeStyle();
    return r.overflow = "visible", r;
  }
  getOutlineStyle() {
    const r = super.getOutlineStyle();
    return r.stroke = "none", r.hover && (r.hover.stroke = "none"), r;
  }
  getDefaultAnchor() {
    var r;
    if (!this.nodeConfig) return;
    const t = this.width / 2, e = this.height / 2, o = this.y - e + 62 / 2, n = [{
      x: this.x - t,
      y: o,
      id: `${this.id}_input`,
      type: "left"
    }, {
      x: this.x + t,
      y: o,
      id: `${this.id}_output`,
      type: "right"
    }], i = () => ({
      x: this.x,
      y: this.y - e,
      id: `${this.id}_top`,
      type: "top"
    }), a = () => ({
      x: this.x,
      y: this.y + e,
      id: `${this.id}_bottom`,
      type: "bottom"
    });
    return typeof ((r = this.nodeConfig.methods) === null || r === void 0 ? void 0 : r.getDefaultAnchor) == "function" ? this.nodeConfig.methods.getDefaultAnchor.call(this, n, {
      getTopAnchor: i,
      getBottomAnchor: a
    }) : n;
  }
  getAnchorLineStyle(r) {
    const t = super.getAnchorLineStyle();
    return t.stroke = "#999999", t;
  }
}, _u = "2 2 20 20", mu = `
<svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" viewBox="${_u}">
    <path fill="currentColor" d="M17 13h-4v4h-2v-4H7v-2h4V7h2v4h4m-5-9A10 10 0 0 0 2 12a10 10 0 0 0 10 10a10 10 0 0 0 10-10A10 10 0 0 0 12 2"/>
</svg>
`, Wv = `
<svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" viewBox="${_u}">
    <path fill="currentColor" d="M12 20a8 8 0 0 1-8-8a8 8 0 0 1 8-8a8 8 0 0 1 8 8a8 8 0 0 1-8 8m0-18A10 10 0 0 0 2 12a10 10 0 0 0 10 10a10 10 0 0 0 10-10A10 10 0 0 0 12 2" />
</svg>
`;
wu();
var by = 18 / 2, Oy = class extends gu {
  constructor(r) {
    super(r);
  }
  setHtml(r) {
    const t = document.createElement("div");
    t.className = `${ji}-content`, t.dataset.nodeId = this.props.model.id, this.root = t, r.appendChild(t), super.renderVueComponent();
  }
  confirmUpdate(r) {
  }
  getAnchorShape(r) {
    const { x: t, y: e, type: o, allowAdd: n } = r, i = o === "top", a = o === "left", s = typeof n == "boolean" ? n : o === "right", l = (() => {
      const c = a ? "targetAnchorId" : "sourceAnchorId";
      return this.props.graphModel.edges.some((d) => d[c] === r.id);
    })(), u = s ? (c) => {
      c.preventDefault(), c.stopPropagation(), this.props.graphModel.$J.doAction("toggle-add-node-drawer", {
        event: c,
        node: this.props.model,
        anchor: r
      });
    } : void 0;
    return Ot("foreignObject", ca(ca({}, r), {}, {
      width: 18,
      height: 18,
      x: a || i ? t - 10 : t - 8,
      y: e - 9,
      style: { "pointer-events": s ? void 0 : "none" }
    }), [Ot("div", {
      className: [
        `${ji}-anchor`,
        `${a ? "left" : "right"}`,
        `${l ? "has-edge" : ""}`,
        `${s ? "has-add" : ""}`
      ].join(" "),
      onClick: u,
      dangerouslySetInnerHTML: { __html: `${Wv}${s ? mu : ""}` }
    })]);
  }
};
function xu(r) {
  const t = {
    getActionRender: o.bind(r),
    getActionShape: e.bind(r)
  };
  function e() {
    if (this.props.model.isDisabled) return Ot("g", {});
    const { startPoint: n, endPoint: i, pointsList: a } = this.props.model;
    let s, l;
    if (a && a.length === 4) {
      const [u, c, d, f] = a;
      s = 0.125 * u.x + 0.375 * c.x + 0.375 * d.x + 0.125 * f.x, l = 0.125 * u.y + 0.375 * c.y + 0.375 * d.y + 0.125 * f.y;
    } else
      s = (n.x + i.x) / 2, l = (n.y + i.y) / 2;
    return Ot("foreignObject", {
      style: {},
      x: s - 20 / 2,
      y: l - 20 / 2,
      width: 20,
      height: 20
    }, t.getActionRender());
  }
  function o() {
    const { isSilentMode: n } = this.props.graphModel.editConfigModel, i = n ? !1 : this.props.model.isHovered;
    return Ot("div", {
      className: `${ji}-edge-action ${i ? "hover" : ""}`,
      onClick: (a) => {
        a.preventDefault(), a.stopPropagation(), this.props.graphModel.deleteEdgeById(this.props.model.id), this.props.graphModel.$J.repaintGraph();
      },
      dangerouslySetInnerHTML: { __html: mu }
    });
  }
  return t;
}
var Kv = class extends Pi {
  constructor() {
    super(), this.$hook = xu(this);
  }
  getEdge() {
    const r = super.getEdge(), t = this.props.model.isHovered, { isSilentMode: e } = this.props.graphModel.editConfigModel;
    return !e && t && (r.props.stroke = "#1890ff"), r;
  }
  getAppendWidth() {
    const r = this.$hook;
    return Ot("g", {}, super.getAppendWidth(), r.getActionShape());
  }
  getStartArrow() {
    return Ot("g", {});
  }
  getEndArrow() {
    return Ot("g", {});
  }
  toFront() {
  }
}, Zv = class extends vi {
  get isDisabled() {
    var r, t;
    return (r = (t = this.properties) === null || t === void 0 ? void 0 : t.disabled) !== null && r !== void 0 ? r : !1;
  }
  initEdgeData(r) {
    r.id || (r.id = ua()), super.initEdgeData(r);
  }
  getData() {
    return {
      id: this.id,
      type: this.type,
      sourceNodeId: this.sourceNodeId,
      targetNodeId: this.targetNodeId,
      sourceAnchorId: this.sourceAnchorId,
      targetAnchorId: this.targetAnchorId,
      pointsList: this.pointsList,
      properties: this.properties
    };
  }
  getEdgeStyle() {
    const r = super.getEdgeStyle();
    return r.stroke = "#afafaf", r.strokeWidth = 2, r;
  }
  getOutlineStyle() {
    const r = super.getOutlineStyle();
    return r.stroke = "none", r.hover && (r.hover.stroke = "none"), r;
  }
  getEdgeAnimationStyle() {
    var r;
    const t = super.getEdgeAnimationStyle(), e = (r = this.properties) === null || r === void 0 ? void 0 : r.runStatus;
    return e === "running" ? t.stroke = "#67b7ff" : e === "success" ? t.stroke = "#52c41a" : e === "fail" && (t.stroke = "#f5222d"), t;
  }
}, wy = {
  type: "base-edge",
  view: Kv,
  model: Zv
}, qv = class extends Ni {
  constructor() {
    super(), this.$hook = xu(this);
  }
  getEdge() {
    const r = super.getEdge(), t = this.props.model.isHovered, { isSilentMode: e } = this.props.graphModel.editConfigModel;
    return !e && t && (r.props.stroke = "#1890ff"), r;
  }
  getAppendWidth() {
    const r = this.$hook;
    return Ot("g", {}, super.getAppendWidth(), r.getActionShape());
  }
  getStartArrow() {
    return Ot("g", {});
  }
  getEndArrow() {
    return Ot("g", {});
  }
  toFront() {
  }
}, Jv = class extends yi {
  get isDisabled() {
    var r, t;
    return (r = (t = this.properties) === null || t === void 0 ? void 0 : t.disabled) !== null && r !== void 0 ? r : !1;
  }
  initEdgeData(r) {
    r.id || (r.id = ua()), super.initEdgeData(r);
  }
  getData() {
    return {
      id: this.id,
      type: this.type,
      sourceNodeId: this.sourceNodeId,
      targetNodeId: this.targetNodeId,
      sourceAnchorId: this.sourceAnchorId,
      targetAnchorId: this.targetAnchorId,
      pointsList: this.pointsList,
      properties: this.properties
    };
  }
  getEdgeStyle() {
    const r = super.getEdgeStyle();
    return r.stroke = "#afafaf", r.strokeWidth = 2, r;
  }
  getOutlineStyle() {
    const r = super.getOutlineStyle();
    return r.stroke = "none", r.hover && (r.hover.stroke = "none"), r;
  }
  getEdgeAnimationStyle() {
    var r;
    const t = super.getEdgeAnimationStyle(), e = (r = this.properties) === null || r === void 0 ? void 0 : r.runStatus;
    return e === "running" ? t.stroke = "#67b7ff" : e === "success" ? t.stroke = "#52c41a" : e === "fail" && (t.stroke = "#f5222d"), t;
  }
}, Sy = {
  type: "base-line-edge",
  view: qv,
  model: Jv
};
export {
  V as $,
  Ts as A,
  hs as B,
  ks as C,
  Cs as D,
  gi as E,
  Te as F,
  G,
  J as H,
  $e as I,
  ot as J,
  Xt as K,
  ln as L,
  As as M,
  tp as N,
  Ds as O,
  uu as P,
  Hi as Q,
  bf as R,
  Bs as S,
  Ah as T,
  dt as U,
  de as V,
  L as W,
  ie as X,
  A as Y,
  Ot as Z,
  $s as _,
  ua as a,
  Ys as b,
  my as c,
  gy as d,
  jv as f,
  hy as g,
  vy as h,
  Ey as i,
  Ps as j,
  Ns as k,
  xy as l,
  Rt as m,
  wy as n,
  _y as o,
  yy as p,
  S as q,
  Oy as r,
  ko as s,
  Sy as t,
  kv as u,
  Si as v,
  pu as w,
  Xs as x,
  Hs as y,
  ve as z
};
