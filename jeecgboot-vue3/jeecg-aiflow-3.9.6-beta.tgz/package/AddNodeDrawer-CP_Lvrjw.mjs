import { a as De } from "./objectSpread2-B0BetFB8.mjs";
import { t as D } from "./asyncToGenerator-BkhZtDh9.mjs";
import { i as _, t as He } from "./const-OjvoZKjM.mjs";
import { t as Me } from "./NodeIcon-I60YeJ6p.mjs";
import { Divider as Se, Space as Pe, Tooltip as Te } from "ant-design-vue/es";
import { Fragment as H, computed as a, createBlock as y, createCommentVNode as $e, createElementBlock as c, createElementVNode as O, createTextVNode as Ae, createVNode as F, defineComponent as Be, nextTick as w, normalizeClass as We, normalizeStyle as Ie, openBlock as u, reactive as j, ref as M, renderList as L, resolveComponent as Re, toDisplayString as q, unref as Ve, useCssVars as Ge, watch as J, withCtx as S, withModifiers as P } from "vue";
import { useDesign as ze } from "/@/hooks/web/useDesign";
import { sleep as Ee } from "/@/utils";
var Oe = { class: "airag-node-label" }, Fe = ["href"], K = 2, je = 12, Q = 10, Le = 9, qe = 24, Je = /* @__PURE__ */ Be({
  __name: "AddNodeDrawer",
  props: {
    visible: {
      type: Boolean,
      default: !1
    },
    payload: Object,
    triggerNodeId: String,
    isShow: Function,
    columnSize: {
      type: Number,
      default: 8
    },
    columnGap: {
      type: Number,
      default: 12
    },
    columnWidth: {
      type: Number,
      default: 160
    },
    nodeItemHeight: {
      type: Number,
      default: 38
    },
    nodeMarginTop: {
      type: Number,
      default: 6
    },
    nodePadding: {
      type: Number,
      default: 8
    }
  },
  emits: ["add"],
  setup(U, { emit: X }) {
    Ge((e) => ({
      v12371086: pe.value,
      v6848f3e0: fe.value,
      ce498c9e: me.value,
      v7d5c8bf0: ge.value,
      v4fabe448: ve.value,
      v2b079504: be.value,
      v5bdc7666: Ne.value,
      v08d8165a: xe.value,
      v9a4c2f88: Ce.value,
      v969f5710: he.value,
      v1b0db061: _e.value,
      v3281f7d2: we.value,
      v5ff69b4d: ye.value
    }));
    const l = U, Y = X, { prefixCls: Z } = ze("airag-add-node-drawer"), p = M(l.visible), f = M(!0), v = M([]), ee = a(() => Math.max(1, Number(l.columnSize) || 10)), T = a(() => Math.max(4, Number(l.columnGap) || 12)), $ = a(() => Math.max(120, Number(l.columnWidth) || 150)), A = a(() => Math.max(28, Number(l.nodeItemHeight) || 38)), B = a(() => Math.max(2, Number(l.nodeMarginTop) || 6)), te = a(() => Math.max(4, Number(l.nodePadding) || 8)), oe = typeof l.isShow == "function" ? l.isShow : _.isShow;
    J(() => l.visible, (e) => e ? ne() : ie()), J(() => l.triggerNodeId, ae);
    function ne() {
      return b.apply(this, arguments);
    }
    function b() {
      return b = D(function* () {
        var e, t;
        V(), yield w(), f.value = !1, I(), yield w(), !((e = l.payload) === null || e === void 0) && e.isDragend || (f.value = !0), W(), yield w(), !((t = l.payload) === null || t === void 0) && t.isDragend && (yield Ee(50), f.value = !0), p.value = !0;
      }), b.apply(this, arguments);
    }
    function ie() {
      return N.apply(this, arguments);
    }
    function N() {
      return N = D(function* () {
        p.value = !1;
      }), N.apply(this, arguments);
    }
    function ae(e, t) {
      !p.value || !e || e !== t && re();
    }
    function re() {
      return x.apply(this, arguments);
    }
    function x() {
      return x = D(function* () {
        V(), yield w(), W(), I();
      }), x.apply(this, arguments);
    }
    const m = j({
      top: 0,
      left: 0
    });
    function W(e) {
      if (e = R(e), !e) return;
      const { top: t, left: o, width: r, height: n } = e, i = {
        top: t + n / 2 - g.value / 2,
        left: o + r + 6
      };
      i.top = Math.max(i.top, 80);
      const s = window.innerHeight - g.value - 40;
      i.top = Math.min(i.top, s), m.top = i.top, m.left = i.left;
    }
    const h = j({
      top: 0,
      left: 0
    });
    function I(e) {
      if (e = R(e), !e) return;
      const { top: t, left: o, width: r, height: n } = e, i = {
        top: t + n / 2 - g.value / 2,
        left: o + r - G.value / 2
      };
      h.top = i.top, h.left = i.left;
    }
    function R(e) {
      return e || le();
    }
    function le() {
      const { payload: e = {} } = l, { event: t } = e;
      if (!t)
        return;
      const o = t.target;
      if (o && typeof o.getBoundingClientRect == "function")
        return o.getBoundingClientRect();
    }
    function V() {
      v.value = [];
      for (const e of _) if (_.isDivider(e)) v.value.push({
        divider: !0,
        label: _.getDividerLabel(e)
      });
      else if (oe(e)) {
        const t = He.get(e), o = t ? t.label : "未知";
        v.value.push({
          type: e,
          label: o,
          docs: t == null ? void 0 : t.docs
        });
      }
    }
    function de(e, t) {
      const o = [];
      let r = [], n = 0;
      for (const i of e) {
        if (i.divider) {
          n >= t && r.length > 0 && (o.push(C(r)), r = [], n = 0), r.push(i);
          continue;
        }
        n >= t && (o.push(C(r)), r = [], n = 0), r.push(i), n++;
      }
      return r.length > 0 && o.push(C(r)), o.filter((i) => i.length > 0);
    }
    function C(e) {
      let t = 0, o = e.length - 1;
      for (; t <= o && e[t].divider; ) t++;
      for (; o >= t && e[o].divider; ) o--;
      return e.slice(t, o + 1);
    }
    function se(e, t, o, r) {
      let n = 0, i = !1;
      for (const s of e) {
        if (s.divider) {
          n = n + (s.label ? qe : o), i = !1;
          continue;
        }
        i && (n = n + r), n = n + t, i = !0;
      }
      return n;
    }
    function ue(e, t, o, r) {
      if (!e.length) return 0;
      let n = 0;
      for (const i of e) {
        const s = se(i, t, o, r);
        s > n && (n = s);
      }
      return n + K + Q;
    }
    function ce(e, t, o) {
      return e <= 0 ? t : e * t + (e - 1) * o;
    }
    const k = a(() => de(v.value, ee.value)), g = a(() => ue(k.value, A.value, Le, B.value)), G = a(() => ce(k.value.length, $.value, T.value)), pe = a(() => G.value + "px"), fe = a(() => g.value + "px"), ve = a(() => `${je / 2}px ${Q / 2}px`), me = a(() => `${K / 2}px`), he = a(() => $.value + "px"), ge = a(() => T.value + "px"), _e = a(() => A.value + "px"), ye = a(() => B.value + "px"), we = a(() => te.value + "px"), be = a(() => h.top + "px"), Ne = a(() => h.left + "px"), xe = a(() => m.top + "px"), Ce = a(() => m.left + "px");
    function ke(e) {
      Y("add", e);
    }
    return (e, t) => {
      const o = Se, r = Re("Icon"), n = Te, i = Pe;
      return u(), c("div", {
        class: We([Ve(Z), { show: p.value }]),
        style: Ie({ transition: f.value ? "box-shadow 0.15s, opacity 0.3s, top 0.3s, left 0.3s, height 0.3s, transform 0.3s" : void 0 }),
        onClick: t[1] || (t[1] = P(() => {
        }, ["stop"]))
      }, [(u(!0), c(H, null, L(k.value, (s, z) => (u(), c("div", {
        key: z,
        class: "add-node-column"
      }, [(u(!0), c(H, null, L(s, (d, E) => (u(), c(H, { key: d.type ? `${d.type}-${E}` : `divider-${z}-${E}` }, [d.divider && !d.label ? (u(), y(o, {
        key: 0,
        class: "add-node-divider"
      })) : d.divider ? (u(), y(o, {
        key: 1,
        class: "add-node-divider add-node-divider-with-label",
        orientation: "left",
        plain: ""
      }, {
        default: S(() => [Ae(q(d.label), 1)]),
        _: 2
      }, 1024)) : (u(), y(i, {
        key: 2,
        class: "add-node-item",
        onClick: P((Qe) => ke(d.type), ["stop"])
      }, {
        default: S(() => [
          F(Me, { type: d.type }, null, 8, ["type"]),
          O("span", Oe, q(d.label), 1),
          d.docs ? (u(), y(n, {
            key: 0,
            title: "查看文档"
          }, {
            default: S(() => [O("a", {
              class: "airag-node-docs-btn",
              href: d.docs,
              target: "_blank",
              onClick: t[0] || (t[0] = P(() => {
              }, ["stop"]))
            }, [F(r, {
              icon: "material-symbols:menu-book-outline-rounded",
              color: "#666"
            })], 8, Fe)]),
            _: 2
          }, 1024)) : $e("", !0)
        ]),
        _: 2
      }, 1032, ["onClick"]))], 64))), 128))]))), 128))], 6);
    };
  }
}), it = /* @__PURE__ */ De({ default: () => Ke }), Ke = Je;
export {
  it as n,
  Ke as t
};
