import { t as c } from "./asyncToGenerator-BkhZtDh9.mjs";
import { unref as o } from "vue";
import { queryKnowledgeBathById as g } from "/@/views/super/airag/aiapp/AiApp.api";
function m(r, t) {
  return a.apply(this, arguments);
}
function a() {
  return a = c(function* (r, t) {
    const e = o(r), n = o(t);
    if (!e || e.length == 0) {
      t.value = [];
      return;
    }
    if (!n || n.length == 0) {
      t.value = yield s(e);
      return;
    }
    if (e.length !== n.length) {
      t.value = yield s(e);
      return;
    }
    const u = n.map((i) => i.id);
    if (e.filter((i) => !u.includes(i)).length > 0) {
      t.value = yield s(e);
      return;
    }
  }), a.apply(this, arguments);
}
function s(r) {
  return l.apply(this, arguments);
}
function l() {
  return l = c(function* (r) {
    if (!r || r.length == 0) return [];
    const t = yield g({ ids: r.join(",") }), e = t.success && Array.isArray(t.result) ? t.result : [], n = /* @__PURE__ */ new Map();
    return e.forEach((u) => {
      n.set(u.id, u);
    }), r.map((u) => {
      const i = n.get(u);
      return i || {
        id: u,
        name: "已失效",
        invalid: !0
      };
    });
  }), l.apply(this, arguments);
}
export {
  m as t
};
