import { n as c, t as o } from "./objectSpread2-B0BetFB8.mjs";
c();
function u(e, n = {}) {
  return o({
    field: e.field,
    label: e.name,
    component: "Input",
    required: e.required
  }, n);
}
function p(e) {
  return u(e, {
    component: "InputNumber",
    componentProps: { style: { width: "180px" } }
  });
}
function s(e) {
  return u(e, {
    slot: "picture",
    required: !1
  });
}
function a(e) {
  return u(e, {
    slot: "file",
    required: !1,
    componentProps: { accept: e.accept || "" }
  });
}
function f(e, n) {
  return u(e, {
    slot: n,
    required: !1
  });
}
function l(e) {
  if (!Array.isArray(e) || e.length === 0) return {
    schemas: [],
    fields: []
  };
  const n = [], t = [];
  return e.forEach((r) => {
    if (r.field !== "history") {
      if (r.type === "picture") {
        t.push(s(r));
        return;
      }
      if (r.type === "file") {
        t.push(a(r));
        return;
      }
      if (n.push({
        field: r.field,
        name: r.name,
        type: r.type,
        required: r.required
      }), r.type === "string" || r.type === "text") {
        t.push(u(r));
        return;
      }
      if (r.type === "number") {
        t.push(p(r));
        return;
      }
      t.push(f(r, "unknown"));
    }
  }), {
    schemas: t,
    fields: n
  };
}
export {
  l as t
};
