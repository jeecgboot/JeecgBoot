import { a as y } from "./objectSpread2-B0BetFB8.mjs";
import { t as g } from "./asyncToGenerator-BkhZtDh9.mjs";
import "./base-node-CKuyN1x8.mjs";
import { t as w } from "./NodeContainer-zpIyuhKY.mjs";
import { t as $ } from "./NodeKVS-CRVYjcYN.mjs";
import { t as h } from "./useNode-lPs0rKwe.mjs";
import { t as x } from "./data-BrtUPagO.mjs";
import { computed as o, createBlock as k, createVNode as K, defineComponent as T, guardReactiveProps as b, normalizeProps as A, openBlock as N, unref as n, watch as V, withCtx as L } from "vue";
var P = /* @__PURE__ */ T({
  __name: "KnowledgeWriteNode",
  props: {
    node: {
      type: Object,
      required: !0
    },
    graph: {
      type: Object,
      required: !0
    }
  },
  setup(a) {
    const { $properties: i, createStoreRef: u, getInputParamKVItem: p, getOutputParamKVItem: v } = h(a), l = u("knowledgeDataList");
    V(() => {
      var e;
      return (e = i.value) === null || e === void 0 || (e = e.options) === null || e === void 0 ? void 0 : e.knowIds;
    }, (function() {
      var e = g(function* (t) {
        yield x(t, l);
      });
      return function(t) {
        return e.apply(this, arguments);
      };
    })(), {
      immediate: !0,
      deep: !0
    });
    const d = o(() => {
      var e;
      return !((e = l.value) === null || e === void 0) && e.length ? l.value.map((t) => {
        const r = t == null ? void 0 : t.name;
        return r ? {
          text: r,
          type: t.invalid ? "invalid" : "default"
        } : null;
      }).filter((t) => !!t) : [];
    }), s = o(() => {
      var e, t;
      const r = (e = (t = i.value) === null || t === void 0 || (t = t.options) === null || t === void 0 ? void 0 : t.content) !== null && e !== void 0 ? e : "";
      return r && r.length > 60 ? `${r.slice(0, 60)}...` : r;
    }), c = o(() => {
      var e;
      return ((e = i.value) === null || e === void 0 || (e = e.options) === null || e === void 0 ? void 0 : e.writeType) || "text";
    }), m = o(() => {
      var e;
      const t = (e = i.value) === null || e === void 0 ? void 0 : e.options;
      if (!(t != null && t.waitForVectorize)) return "";
      const r = t.vectorizeFailStrategy === "error" ? "失败中断" : "失败忽略";
      return `开启，${t.waitTimeout || 300}秒超时（${r}）`;
    }), f = o(() => {
      var e;
      const t = (e = i.value) === null || e === void 0 || (e = e.options) === null || e === void 0 ? void 0 : e.fileSources;
      return !Array.isArray(t) || t.length === 0 ? "" : t.map((r) => r.name || r.field || "").filter(Boolean).join("，");
    }), _ = o(() => {
      const e = c.value === "file";
      return [
        p({
          label: "输入变量",
          emptyAction: "hidden",
          emptyTip: "尚未选择"
        }),
        {
          label: "知识库",
          value: "",
          valueList: d.value,
          emptyAction: "tip",
          emptyTip: "尚未选择"
        },
        {
          label: "写入方式",
          value: e ? "文件写入" : "文本写入",
          emptyAction: "tip"
        },
        {
          label: e ? "文件来源" : "写入内容",
          value: e ? f.value : s.value,
          emptyAction: "tip",
          emptyTip: e ? "尚未选择" : "尚未填写"
        },
        {
          label: "等待向量化",
          value: m.value,
          emptyAction: "hidden"
        },
        v({ label: "输出参数" })
      ];
    });
    return (e, t) => (N(), k(n(w), A(b(e.$props)), {
      default: L(() => [K(n($), { kvs: _.value }, null, 8, ["kvs"])]),
      _: 1
    }, 16));
  }
}), C = /* @__PURE__ */ y({ default: () => S }), S = P;
export {
  C as n,
  S as t
};
