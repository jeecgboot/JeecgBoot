import { a as $ } from "./objectSpread2-B0BetFB8.mjs";
import { t as F } from "./_plugin-vue_export-helper-Dj7HTbfw.mjs";
import { t as H } from "./asyncToGenerator-BkhZtDh9.mjs";
import { Card as U, Col as j, Input as A, Row as G, Tag as J } from "ant-design-vue/es";
import { Fragment as L, createBlock as C, createCommentVNode as S, createElementBlock as k, createElementVNode as a, createTextVNode as Q, createVNode as c, defineComponent as q, normalizeStyle as K, openBlock as d, ref as n, renderList as W, toDisplayString as v, unref as w, withCtx as i } from "vue";
import { Pagination as X, message as Y } from "ant-design-vue";
import Z from "/@/components/Modal/src/BasicModal.vue";
import { useModalInner as ee } from "/@/components/Modal";
import { defHttp as te } from "/@/utils/http/axios";
var ae = { class: "p-2" }, le = { class: "flex header" }, oe = { style: {
  display: "flex",
  width: "100%",
  "align-items": "center"
} }, se = { style: {
  display: "grid",
  "margin-left": "8px",
  "align-items": "center"
} }, re = { class: "checkbox-name ellipsis" }, ne = { class: "flex text-status" }, ie = { class: "tag-text" }, ue = { class: "tag-text" }, ce = { class: "text-desc mt-10" }, de = {
  key: 0,
  class: "use-select"
}, ve = {
  class: "ellipsis",
  style: { "max-width": "150px" }
}, pe = /* @__PURE__ */ q({
  __name: "SelectSourceModal",
  emits: ["register", "ok"],
  setup(fe, { emit: z }) {
    const I = z, [M, { setModalProps: b, closeModal: T }] = ee((e) => {
      var t;
      const r = typeof (e == null ? void 0 : e.dataSourceId) == "object" ? e == null || (t = e.dataSourceId) === null || t === void 0 ? void 0 : t.value : e == null ? void 0 : e.dataSourceId;
      r && (o.value = r), b({
        minHeight: 500,
        bodyStyle: { padding: "10px" }
      }), h();
    }), u = n([]), o = n(""), l = n(null), f = n(1), m = n(10), g = n(0), p = n(""), N = n([
      "10",
      "20",
      "30"
    ]);
    function V(e) {
      if (o.value === e.id) {
        o.value = "", l.value = null;
        return;
      }
      o.value = e.id, l.value = e;
    }
    function B() {
      o.value = "", l.value = null;
    }
    function O(e, t) {
      f.value = e, m.value = t, h();
    }
    function h() {
      return x.apply(this, arguments);
    }
    function x() {
      return x = H(function* () {
        let e = "";
        p.value && (e = "*" + p.value + "*");
        const t = {
          pageNo: f.value,
          pageSize: m.value,
          column: "createTime",
          order: "desc",
          name: e
        }, r = yield te.get({
          url: "/sys/dataSource/list",
          params: t
        });
        r ? (u.value = r.records || [], g.value = r.total || 0, o.value && (l.value = u.value.find((_) => _.id === o.value) || l.value)) : (u.value = [], g.value = 0);
      }), x.apply(this, arguments);
    }
    function P() {
      if (!l.value) {
        Y.warning("请选择一个数据源");
        return;
      }
      I("ok", [{
        id: l.value.id,
        name: l.value.name,
        code: l.value.code
      }]), T();
    }
    return (e, t) => {
      const r = A, _ = J, D = U, E = j, R = G;
      return d(), C(Z, {
        destroyOnClose: "",
        canFullscreen: !1,
        title: "选择数据源",
        width: "600px",
        onRegister: w(M),
        onOk: P
      }, {
        default: i(() => {
          var y;
          return [a("div", ae, [
            a("div", le, [c(r, {
              onPressEnter: h,
              class: "header-search",
              size: "small",
              value: p.value,
              "onUpdate:value": t[0] || (t[0] = (s) => p.value = s),
              placeholder: "请输入数据源名称，回车搜索"
            }, null, 8, ["value"])]),
            c(R, { span: 24 }, {
              default: i(() => [(d(!0), k(L, null, W(u.value, (s) => (d(), C(E, {
                span: 12,
                key: s.id,
                onClick: (me) => V(s)
              }, {
                default: i(() => [c(D, {
                  style: K(o.value === s.id ? { border: "1px solid #3370ff" } : {}),
                  hoverable: "",
                  class: "checkbox-card",
                  "body-style": { width: "100%" }
                }, {
                  default: i(() => [a("div", oe, [t[1] || (t[1] = a("div", { class: "source-icon" }, [a("svg", {
                    viewBox: "0 0 1024 1024",
                    xmlns: "http://www.w3.org/2000/svg",
                    width: "20",
                    height: "20"
                  }, [a("path", {
                    d: "M213.333333 533.333333c0 13.354667 19.669333 36.608 65.28 59.434667C337.664 622.293333 421.418667 640 512 640c90.581333 0 174.336-17.706667 233.386667-47.232 45.610667-22.826667 65.28-46.08 65.28-59.434667v-92.629333C740.266667 484.224 632.618667 512 512 512s-228.266667-27.818667-298.666667-71.296V533.333333z m597.333334 120.704C740.266667 697.557333 632.618667 725.333333 512 725.333333s-228.266667-27.818667-298.666667-71.296V746.666667c0 13.354667 19.669333 36.608 65.28 59.434666C337.664 835.626667 421.418667 853.333333 512 853.333333c90.581333 0 174.336-17.706667 233.386667-47.232 45.610667-22.826667 65.28-46.08 65.28-59.434666v-92.629334zM128 746.666667v-426.666667C128 213.973333 299.946667 128 512 128s384 85.973333 384 192v426.666667c0 106.026667-171.946667 192-384 192s-384-85.973333-384-192z m384-320c90.581333 0 174.336-17.706667 233.386667-47.232C790.954667 356.608 810.666667 333.354667 810.666667 320c0-13.354667-19.669333-36.608-65.28-59.434667C686.293333 231.04 602.581333 213.333333 512 213.333333c-90.581333 0-174.336 17.706667-233.386667 47.232C233.002667 283.392 213.333333 306.645333 213.333333 320c0 13.354667 19.669333 36.608 65.28 59.434667C337.664 408.96 421.418667 426.666667 512 426.666667z",
                    fill: "#ffffff"
                  })])], -1)), a("div", se, [a("span", re, v(s.name), 1), a("div", ne, [c(_, {
                    color: "#f2f3f8",
                    class: "tags-meadata"
                  }, {
                    default: i(() => [a("span", ie, v(s.dbType_dictText || "未知类型"), 1)]),
                    _: 2
                  }, 1024), c(_, {
                    color: "#f2f3f8",
                    class: "tags-meadata"
                  }, {
                    default: i(() => [a("span", ue, v(s.dbUsername || "未配置"), 1)]),
                    _: 2
                  }, 1024)])])]), a("div", ce, v(s.remark || "暂无描述"), 1)]),
                  _: 2
                }, 1032, ["style"])]),
                _: 2
              }, 1032, ["onClick"]))), 128))]),
              _: 1
            }),
            o.value ? (d(), k("div", de, [
              t[2] || (t[2] = Q(" 已选择 ", -1)),
              a("span", ve, v((y = l.value) === null || y === void 0 ? void 0 : y.name), 1),
              a("span", {
                style: {
                  "margin-left": "8px",
                  color: "#3d79fb",
                  cursor: "pointer"
                },
                onClick: B
              }, "清空")
            ])) : S("", !0),
            u.value.length > 0 ? (d(), C(w(X), {
              key: 1,
              current: f.value,
              "page-size": m.value,
              "page-size-options": N.value,
              total: g.value,
              showQuickJumper: !0,
              showSizeChanger: !0,
              onChange: O,
              class: "list-footer",
              size: "small"
            }, null, 8, [
              "current",
              "page-size",
              "page-size-options",
              "total"
            ])) : S("", !0)
          ])];
        }),
        _: 1
      }, 8, ["onRegister"]);
    };
  }
}), Me = /* @__PURE__ */ $({ default: () => _e }), _e = /* @__PURE__ */ F(pe, [["__scopeId", "data-v-44c26924"]]);
export {
  Me as n,
  _e as t
};
