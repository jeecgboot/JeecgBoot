import { a as w } from "./objectSpread2-B0BetFB8.mjs";
import { t as U } from "./_plugin-vue_export-helper-Dj7HTbfw.mjs";
import { t as q } from "./VarListEditor-A0nqHeND.mjs";
import { t as j } from "./VarListPicker-CrG8EHn2.mjs";
import { t as z } from "./useSettings-Cq_-E7Ut.mjs";
import "./Vars-Cgan49KR.mjs";
import { Input as N, InputNumber as O, Select as C, SelectOption as L } from "ant-design-vue/es";
import { createElementBlock as P, createElementVNode as t, createTextVNode as n, createVNode as r, defineComponent as k, isRef as o, openBlock as E, unref as l, withCtx as s } from "vue";
var I = { class: "brave-search-setting" }, R = { class: "setting-item" }, F = { class: "setting-item" }, T = { class: "setting-item" }, A = { class: "setting-item" }, M = { class: "setting-item" }, D = { class: "setting-item" }, G = /* @__PURE__ */ k({
  __name: "BraveSearchSetting",
  props: {
    type: {
      type: String,
      required: !0
    },
    node: {
      type: Object,
      required: !0
    },
    properties: {
      type: Object,
      required: !0
    },
    isSilentMode: {
      type: Boolean,
      required: !0
    },
    setProperties: {
      type: Function,
      required: !0
    }
  },
  setup(g) {
    const { inputParams: v, outputParams: p, prevVariables: _, createOptionRef: d, isReadOnly: u } = z(g), m = d("braveSearch.count"), f = d("braveSearch.country"), b = d("braveSearch.searchLang"), y = d("braveSearch.freshness"), x = { result: { tip: "Brave 搜索返回的完整结果数组（object[]）" } };
    return (J, e) => {
      const B = O, V = N, i = L, S = C;
      return E(), P("div", I, [
        t("div", R, [
          e[6] || (e[6] = t("div", { class: "label" }, "搜索关键词", -1)),
          r(l(j), {
            vars: l(v),
            "onUpdate:vars": e[0] || (e[0] = (a) => o(v) ? v.value = a : null),
            prevVariables: l(_),
            readonly: l(u)
          }, null, 8, [
            "vars",
            "prevVariables",
            "readonly"
          ]),
          e[7] || (e[7] = t("div", { class: "tip" }, "取输入变量的第一个作为 query 发送给 Brave Search", -1))
        ]),
        t("div", F, [e[8] || (e[8] = t("div", { class: "label" }, "结果数量", -1)), r(B, {
          value: l(m),
          "onUpdate:value": e[1] || (e[1] = (a) => o(m) ? m.value = a : null),
          min: 1,
          max: 10,
          disabled: l(u),
          style: { width: "100%" }
        }, null, 8, ["value", "disabled"])]),
        t("div", T, [e[9] || (e[9] = t("div", { class: "label" }, "国家/地区", -1)), r(V, {
          value: l(f),
          "onUpdate:value": e[2] || (e[2] = (a) => o(f) ? f.value = a : null),
          placeholder: "可选，两位国家代码，如 CN / US",
          disabled: l(u)
        }, null, 8, ["value", "disabled"])]),
        t("div", A, [e[14] || (e[14] = t("div", { class: "label" }, "搜索语言", -1)), r(S, {
          value: l(b),
          "onUpdate:value": e[3] || (e[3] = (a) => o(b) ? b.value = a : null),
          placeholder: "可选，推荐中文查询选 zh-hans",
          "allow-clear": "",
          disabled: l(u),
          style: { width: "100%" }
        }, {
          default: s(() => [
            r(i, { value: "zh-hans" }, {
              default: s(() => [...e[10] || (e[10] = [n("zh-hans（简体中文）", -1)])]),
              _: 1
            }),
            r(i, { value: "zh-hant" }, {
              default: s(() => [...e[11] || (e[11] = [n("zh-hant（繁体中文）", -1)])]),
              _: 1
            }),
            r(i, { value: "en" }, {
              default: s(() => [...e[12] || (e[12] = [n("en（英文）", -1)])]),
              _: 1
            }),
            r(i, { value: "ja" }, {
              default: s(() => [...e[13] || (e[13] = [n("ja（日文）", -1)])]),
              _: 1
            })
          ]),
          _: 1
        }, 8, ["value", "disabled"])]),
        t("div", M, [
          e[19] || (e[19] = t("div", { class: "label" }, "时效过滤", -1)),
          r(S, {
            value: l(y),
            "onUpdate:value": e[4] || (e[4] = (a) => o(y) ? y.value = a : null),
            placeholder: "可选，不限时间则留空",
            "allow-clear": "",
            disabled: l(u),
            style: { width: "100%" }
          }, {
            default: s(() => [
              r(i, { value: "pd" }, {
                default: s(() => [...e[15] || (e[15] = [n("过去 24 小时", -1)])]),
                _: 1
              }),
              r(i, { value: "pw" }, {
                default: s(() => [...e[16] || (e[16] = [n("过去一周", -1)])]),
                _: 1
              }),
              r(i, { value: "pm" }, {
                default: s(() => [...e[17] || (e[17] = [n("过去一月", -1)])]),
                _: 1
              }),
              r(i, { value: "py" }, {
                default: s(() => [...e[18] || (e[18] = [n("过去一年", -1)])]),
                _: 1
              })
            ]),
            _: 1
          }, 8, ["value", "disabled"]),
          e[20] || (e[20] = t("div", { class: "tip" }, '查询最新版本、近期新闻等时建议选"过去一月"或"过去一年"', -1))
        ]),
        t("div", D, [
          e[21] || (e[21] = t("div", { class: "label" }, "输出变量", -1)),
          r(l(q), {
            vars: l(p),
            "onUpdate:vars": e[5] || (e[5] = (a) => o(p) ? p.value = a : null),
            fixedVars: x,
            fieldBeforeText: "result.",
            readonly: l(u)
          }, null, 8, ["vars", "readonly"]),
          e[22] || (e[22] = t("div", { class: "tip" }, " result 为完整结果数组； result.title / result.url / result.description 会把对应字段按顺序抽成列表。 ", -1))
        ])
      ]);
    };
  }
}), ee = /* @__PURE__ */ w({ default: () => H }), H = /* @__PURE__ */ U(G, [["__scopeId", "data-v-205cf2df"]]);
export {
  ee as n,
  H as t
};
