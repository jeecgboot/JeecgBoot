import { a as E } from "./objectSpread2-B0BetFB8.mjs";
import { t as V } from "./_plugin-vue_export-helper-Dj7HTbfw.mjs";
import { t as x } from "./VarListEditor-A0nqHeND.mjs";
import { t as B } from "./VarListPicker-CrG8EHn2.mjs";
import { t as R } from "./useSettings-Cq_-E7Ut.mjs";
import "./Vars-Cgan49KR.mjs";
import { Input as h, RadioButton as k, RadioGroup as q } from "ant-design-vue/es";
import { createElementBlock as u, createElementVNode as a, createTextVNode as g, createVNode as r, defineComponent as J, isRef as o, openBlock as v, unref as t, withCtx as _ } from "vue";
var P = { class: "enhance-java-setting" }, O = { class: "setting-item" }, U = { class: "setting-item" }, j = { class: "setting-item" }, C = { class: "label" }, I = { key: 0 }, N = { key: 1 }, A = { class: "setting-item" }, L = /* @__PURE__ */ J({
  __name: "EnhanceJavaSetting",
  props: {
    type: {
      type: String,
      required: !0
    },
    node: {
      type: Object,
      required: !0
    },
    properties: {
      type: Object,
      required: !0
    },
    isSilentMode: {
      type: Boolean,
      required: !0
    },
    setProperties: {
      type: Function,
      required: !0
    }
  },
  setup(y) {
    const { inputParams: i, outputParams: d, prevVariables: b, createOptionRef: m, isReadOnly: l } = R(y), s = m("enhance.type"), p = m("enhance.path");
    return (w, e) => {
      const f = k, c = q, S = h;
      return v(), u("div", P, [
        a("div", O, [e[4] || (e[4] = a("div", { class: "label" }, "输入变量", -1)), r(t(B), {
          vars: t(i),
          "onUpdate:vars": e[0] || (e[0] = (n) => o(i) ? i.value = n : null),
          prevVariables: t(b),
          readonly: t(l)
        }, null, 8, [
          "vars",
          "prevVariables",
          "readonly"
        ])]),
        a("div", U, [e[7] || (e[7] = a("div", { class: "label" }, "增强类型", -1)), r(c, {
          value: t(s),
          "onUpdate:value": e[1] || (e[1] = (n) => o(s) ? s.value = n : null),
          "button-style": "solid",
          disabled: t(l)
        }, {
          default: _(() => [r(f, { value: "class" }, {
            default: _(() => [...e[5] || (e[5] = [g("类路径", -1)])]),
            _: 1
          }), r(f, { value: "spring" }, {
            default: _(() => [...e[6] || (e[6] = [g("Spring Bean", -1)])]),
            _: 1
          })]),
          _: 1
        }, 8, ["value", "disabled"])]),
        a("div", j, [
          a("div", C, [t(s) === "class" ? (v(), u("span", I, "类路径")) : (v(), u("span", N, "Spring Bean 名称"))]),
          r(S, {
            value: t(p),
            "onUpdate:value": e[2] || (e[2] = (n) => o(p) ? p.value = n : null),
            placeholder: "请输入" + (t(s) === "class" ? "类路径" : "Spring Bean 名称"),
            disabled: t(l)
          }, null, 8, [
            "value",
            "placeholder",
            "disabled"
          ]),
          e[8] || (e[8] = a("p", { class: "p-tip" }, [a("span", null, "需要实现 IAiRagEnhanceJava 接口")], -1))
        ]),
        a("div", A, [e[9] || (e[9] = a("div", { class: "label" }, "输出变量", -1)), r(t(x), {
          vars: t(d),
          "onUpdate:vars": e[3] || (e[3] = (n) => o(d) ? d.value = n : null),
          readonly: t(l)
        }, null, 8, ["vars", "readonly"])])
      ]);
    };
  }
}), X = /* @__PURE__ */ E({ default: () => T }), T = /* @__PURE__ */ V(L, [["__scopeId", "data-v-913d49e0"]]);
export {
  X as n,
  T as t
};
