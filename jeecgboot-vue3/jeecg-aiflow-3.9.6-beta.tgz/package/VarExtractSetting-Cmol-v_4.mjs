import { a as N } from "./objectSpread2-B0BetFB8.mjs";
import { t as T } from "./VarPicker-HOsUWkU-.mjs";
import { t as U } from "./VarListShow-Dg1oan43.mjs";
import { a as h, i as j, t as z } from "./VarDefineModal-z1TRO3AZ.mjs";
import { t as F } from "./useSettings-Cq_-E7Ut.mjs";
import "./Vars-Cgan49KR.mjs";
import { t as $ } from "./LLMModelSelect-BRPxeDUM.mjs";
import { List as G } from "ant-design-vue/es";
import { computed as m, createCommentVNode as H, createElementBlock as x, createElementVNode as r, createVNode as o, defineComponent as J, h as n, isRef as K, normalizeClass as Q, openBlock as b, ref as W, unref as l, watch as X } from "vue";
import { useMessage as Y } from "/@/hooks/web/useMessage";
import { useDesign as Z } from "/@/hooks/web/useDesign";
import { useModal as ee } from "/@/components/Modal";
import { Icon as I } from "/@/components/Icon";
import { cloneDeep as M, isEqual as te } from "lodash-es";
var re = { class: "setting-item" }, ae = { class: "setting-item" }, ne = { class: "setting-item" }, le = { key: 0 }, se = { class: "setting-item setting-output-params" }, ie = 10, oe = /* @__PURE__ */ J({
  __name: "VarExtractSetting",
  props: {
    type: {
      type: String,
      required: !0
    },
    node: {
      type: Object,
      required: !0
    },
    properties: {
      type: Object,
      required: !0
    },
    isSilentMode: {
      type: Boolean,
      required: !0
    },
    setProperties: {
      type: Function,
      required: !0
    }
  },
  setup(S) {
    const { createMessage: f } = Y(), O = S, { prefixCls: A } = Z("airag-var-extract-setting"), { inputParams: v, outputParams: c, prevVariables: C, createOptionRef: V, isReadOnly: a } = F(O), g = V("model"), p = V("variables"), [P, { openModal: _ }] = ee(), s = W(null), k = m(() => c.value.filter((t) => j.some((e) => e.field === t.field))), y = m({
      get() {
        return !Array.isArray(v.value) || v.value.length === 0 ? {
          nodeId: "",
          field: "",
          type: "string"
        } : v.value[0];
      },
      set(t) {
        v.value = [t];
      }
    }), q = m(() => C.value.filter((t) => t.type === "string")), u = m(() => Array.isArray(p.value) ? p.value : []);
    X(u, (t) => {
      const e = h(t);
      te(c.value, e) || (c.value = e);
    }, {
      deep: !0,
      immediate: !0
    });
    function E(t) {
      if (!a.value) {
        if (!(t != null && t.nodeId)) {
          y.value = {
            nodeId: "",
            field: "",
            type: "string"
          };
          return;
        }
        if (t.type && t.type !== "string") {
          f.warning("仅支持 string 类型的变量");
          return;
        }
        y.value = {
          nodeId: t.nodeId,
          field: t.field,
          type: "string",
          name: t.name
        };
      }
    }
    function w() {
      a.value || (s.value = null, _(!0, {}));
    }
    function L(t, e) {
      a.value || (s.value = e, _(!0, { record: t }));
    }
    function R(t) {
      if (a.value) return;
      const e = M(u.value);
      if (e.length <= 1) {
        f.warning("请至少保留一个提取变量");
        return;
      }
      e.splice(t, 1), p.value = e;
    }
    function D(t) {
      if (a.value) return;
      const e = M(u.value);
      if (e.some((i, d) => i.name === t.name && d !== s.value)) {
        f.warning("变量名称重复");
        return;
      }
      s.value === null || s.value === void 0 ? e.push(t) : e.splice(s.value, 1, t), p.value = e;
    }
    function B({ item: t, index: e }) {
      return n("div", {
        class: "var-item",
        onClick: () => {
          a.value || L(t, e);
        }
      }, [n("div", { class: "var-info" }, [n("div", { class: "var-name" }, [
        ...t.required ? [n("span", { class: "var-required" }, "*")] : [],
        n("span", {}, t.name),
        n("span", { style: { color: "#999999" } }, ` <${t.type}>`)
      ]), n("div", { class: "var-desc" }, t.description || "未填写描述")]), n("div", { class: "var-actions" }, [a.value ? null : n("a", {
        style: {},
        onClick: (i) => {
          i.preventDefault(), i.stopPropagation(), R(e);
        }
      }, [n(I, { icon: "ant-design:delete-outlined" })])])]);
    }
    return (t, e) => {
      const i = G;
      return b(), x("div", { class: Q([l(A)]) }, [
        r("div", re, [
          e[2] || (e[2] = r("div", { class: "label" }, "输入变量", -1)),
          o(l(T), {
            item: y.value,
            vars: q.value,
            allowedTypes: ["string"],
            readonly: l(a),
            onChange: e[0] || (e[0] = (d) => E(d))
          }, null, 8, [
            "item",
            "vars",
            "readonly"
          ]),
          e[3] || (e[3] = r("div", { class: "desc" }, "仅支持 string 类型的输入", -1))
        ]),
        r("div", ae, [e[4] || (e[4] = r("div", { class: "label" }, "模型", -1)), o($, {
          model: l(g),
          "onUpdate:model": e[1] || (e[1] = (d) => K(g) ? g.value = d : null),
          readonly: l(a)
        }, null, 8, ["model", "readonly"])]),
        r("div", ne, [
          e[6] || (e[6] = r("div", { class: "label setting-header" }, [r("span", null, "提取变量")], -1)),
          o(i, {
            "data-source": u.value,
            renderItem: B,
            "item-layout": "horizontal"
          }, null, 8, ["data-source"]),
          u.value.length < ie && !l(a) ? (b(), x("div", le, [r("a", { onClick: w }, [o(l(I), { icon: "ic:round-add" }), e[5] || (e[5] = r("span", null, "新增变量", -1))])])) : H("", !0)
        ]),
        r("div", se, [
          e[7] || (e[7] = r("div", { class: "label" }, "提取失败变量", -1)),
          e[8] || (e[8] = r("div", {
            class: "desc",
            style: { "margin-bottom": "8px" }
          }, [r("span", null, "以下变量仅在提取失败后可用")], -1)),
          o(l(U), { vars: k.value }, null, 8, ["vars"])
        ]),
        o(z, {
          onRegister: l(P),
          onOk: D
        }, null, 8, ["onRegister"])
      ], 2);
    };
  }
}), Oe = /* @__PURE__ */ N({ default: () => ue }), ue = oe;
export {
  Oe as n,
  ue as t
};
