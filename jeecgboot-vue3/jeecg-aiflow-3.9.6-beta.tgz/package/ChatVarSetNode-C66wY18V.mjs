import { a as u } from "./objectSpread2-B0BetFB8.mjs";
import "./base-node-CKuyN1x8.mjs";
import { t as s } from "./NodeContainer-zpIyuhKY.mjs";
import { t as d } from "./NodeKVS-CRVYjcYN.mjs";
import { t as v } from "./useNode-lPs0rKwe.mjs";
import { computed as m, createBlock as _, createVNode as c, defineComponent as f, guardReactiveProps as y, normalizeProps as h, openBlock as N, unref as r, withCtx as b } from "vue";
var C = /* @__PURE__ */ f({
  __name: "ChatVarSetNode",
  props: {
    node: {
      type: Object,
      required: !0
    },
    graph: {
      type: Object,
      required: !0
    }
  },
  setup(p) {
    const { containerProps: i, $properties: o } = v(p), l = m(() => {
      var e, t;
      const a = Array.isArray((e = o.value) === null || e === void 0 || (e = e.options) === null || e === void 0 ? void 0 : e.variables) ? (t = o.value) === null || t === void 0 || (t = t.options) === null || t === void 0 ? void 0 : t.variables : [];
      return a.length === 0 ? [{
        label: "赋值变量",
        value: "",
        emptyAction: "tip",
        emptyTip: "尚未配置"
      }] : [{
        label: "赋值变量",
        value: a.map((n) => n.name).filter(Boolean).join(", "),
        emptyAction: "tip",
        emptyTip: "尚未配置"
      }];
    });
    return (e, t) => (N(), _(r(s), h(y(r(i))), {
      default: b(() => [c(r(d), { kvs: l.value }, null, 8, ["kvs"])]),
      _: 1
    }, 16));
  }
}), j = /* @__PURE__ */ u({ default: () => V }), V = C;
export {
  j as n,
  V as t
};
