import { a as A } from "./objectSpread2-B0BetFB8.mjs";
import { t as N } from "./_plugin-vue_export-helper-Dj7HTbfw.mjs";
import { t as P } from "./rules-BcwBMgYM.mjs";
import { t as S } from "./VarPicker-HOsUWkU-.mjs";
import { Input as L } from "ant-design-vue/es";
import { Fragment as $, computed as D, createBlock as w, createCommentVNode as y, createElementBlock as s, createElementVNode as v, createVNode as h, defineComponent as q, openBlock as r, ref as O, renderList as U, resolveComponent as j, toDisplayString as V, unref as F } from "vue";
import { PlusOutlined as x } from "@ant-design/icons-vue";
var z = { class: "name" }, G = { key: 2 }, H = { class: "field" }, J = { key: 0 }, K = ["onClick"], M = {
  key: 0,
  class: "var-add",
  style: {
    width: "100%",
    "margin-bottom": "10px"
  }
}, Q = /* @__PURE__ */ q({
  __name: "VarListPicker",
  props: {
    vars: {
      type: Array,
      required: !0
    },
    node: {
      type: Object,
      required: !1
    },
    prevVariables: {
      type: Array,
      required: !0
    },
    readonly: {
      type: Boolean,
      default: !1
    },
    allowEditName: {
      type: Boolean,
      default: !0
    },
    allowEditValue: {
      type: Boolean,
      default: !1
    },
    allowDelete: {
      type: Boolean,
      default: !0
    },
    allowAdd: {
      type: Boolean,
      default: !0
    },
    allowedTypes: {
      type: Array,
      default: void 0
    },
    showTypeSelector: {
      type: Boolean,
      default: !1
    }
  },
  emits: ["update:vars"],
  setup(t, { emit: g }) {
    const C = t, I = g, d = D({
      get: () => [...C.vars],
      set: (e) => {
        I("update:vars", e);
      }
    });
    function B() {
      d.value = [...d.value, {
        field: "",
        name: "",
        nodeId: "",
        customValue: "",
        type: "string"
      }];
    }
    const u = O([]);
    function c(e, l, a) {
      u.value[e] || (u.value[e] = {
        name: "",
        field: ""
      }), u.value[e][l] = a;
    }
    function k(e, l, a) {
      if (a && e.name && (e.name = e.name.trim()), !e.name) c(l, "name", "请输入变量名");
      else {
        const p = P(e.name);
        p.passed ? (c(l, "name", ""), a && f()) : c(l, "name", p.message);
      }
    }
    function T(e, l, a) {
      a != null && a.nodeId ? (e.nodeId = a.nodeId, e.field = a.field, c(l, "field", "")) : (e.nodeId = "", e.field = ""), f();
    }
    function E(e, l) {
      e.nodeId = "", e.field = "", e.type = "string", e.customValue = l, f();
    }
    function b(e) {
      d.value = d.value.filter((l, a) => a !== e), delete u.value[e];
    }
    function f() {
      d.value = [...d.value];
    }
    return (e, l) => {
      const a = L, p = j("Icon");
      return r(), s("div", null, [(r(!0), s($, null, U(d.value, (o, n) => {
        var m, _;
        return r(), s("div", {
          key: n,
          class: "var-item"
        }, [
          v("div", z, [t.allowEditName ? (r(), w(a, {
            key: 0,
            value: o.name,
            "onUpdate:value": (i) => o.name = i,
            placeholder: "请输入变量名",
            readonly: t.readonly,
            onBlur: () => k(o, n, !0),
            onInput: () => k(o, n, !1)
          }, null, 8, [
            "value",
            "onUpdate:value",
            "readonly",
            "onBlur",
            "onInput"
          ])) : (r(), w(a, {
            key: 1,
            value: o.name + (o.nameText ? " / " + o.nameText : ""),
            disabled: ""
          }, null, 8, ["value"])), !((m = u.value[n]) === null || m === void 0) && m.name ? (r(), s("p", G, [v("span", null, V(u.value[n].name), 1)])) : y("", !0)]),
          v("div", H, [h(S, {
            item: o,
            vars: t.prevVariables,
            allowEditValue: t.allowEditValue,
            allowedTypes: t.allowedTypes,
            showTypeSelector: t.showTypeSelector,
            readonly: t.readonly,
            onChange: (i) => T(o, n, i),
            onChangeCustom: (i) => E(o, i),
            onChangeType: f
          }, null, 8, [
            "item",
            "vars",
            "allowEditValue",
            "allowedTypes",
            "showTypeSelector",
            "readonly",
            "onChange",
            "onChangeCustom"
          ]), !((_ = u.value[n]) === null || _ === void 0) && _.field ? (r(), s("p", J, [v("span", null, V(u.value[n].field), 1)])) : y("", !0)]),
          !t.readonly && t.allowDelete ? (r(), s("div", {
            key: 0,
            class: "action",
            onClick: (i) => b(n)
          }, [h(p, { icon: "ant-design:delete" })], 8, K)) : y("", !0)
        ]);
      }), 128)), !t.readonly && t.allowAdd ? (r(), s("div", M, [v("a", {
        type: "text",
        style: { "border-radius": "15px" },
        onClick: B
      }, [h(F(x)), l[0] || (l[0] = v("span", { style: { "margin-left": "6px" } }, "添加变量", -1))])])) : y("", !0)]);
    };
  }
}), te = /* @__PURE__ */ A({ default: () => R }), R = /* @__PURE__ */ N(Q, [["__scopeId", "data-v-967c36c4"]]);
export {
  te as n,
  R as t
};
