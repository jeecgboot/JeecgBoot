import { a as o } from "./objectSpread2-B0BetFB8.mjs";
import { t as r } from "./NodeIcon-Dt_fCcq_.mjs";
import { createBlock as a, openBlock as t } from "vue";
var s = /* @__PURE__ */ o({ default: () => e }), e = {
  __name: "ChatVarGetIcon",
  setup(c) {
    return (_, n) => (t(), a(r, {
      icon: "mdi:variable-box",
      color: "#4165d7"
    }));
  }
};
export {
  e as n,
  s as t
};
