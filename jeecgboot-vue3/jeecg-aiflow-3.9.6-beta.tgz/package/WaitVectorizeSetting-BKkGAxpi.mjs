import { a as w } from "./objectSpread2-B0BetFB8.mjs";
import { t as z } from "./_plugin-vue_export-helper-Dj7HTbfw.mjs";
import { InputNumber as b, Radio as V, RadioGroup as S, Switch as F } from "ant-design-vue/es";
import { Fragment as d, createCommentVNode as x, createElementBlock as u, createElementVNode as a, createTextVNode as s, createVNode as o, defineComponent as C, openBlock as m, withCtx as n } from "vue";
var k = { class: "setting-item" }, N = { class: "setting-item" }, T = { class: "setting-item" }, W = /* @__PURE__ */ C({
  __name: "WaitVectorizeSetting",
  props: {
    waitForVectorize: {
      type: Boolean,
      required: !0
    },
    waitTimeout: {
      type: Number,
      required: !0
    },
    vectorizeFailStrategy: {
      type: String,
      required: !0
    },
    readonly: {
      type: Boolean,
      default: !1
    }
  },
  emits: [
    "update:waitForVectorize",
    "update:waitTimeout",
    "update:vectorizeFailStrategy"
  ],
  setup(t, { emit: p }) {
    const r = p;
    function c(i) {
      r("update:waitForVectorize", i);
    }
    function v(i) {
      r("update:waitTimeout", i);
    }
    function _(i) {
      r("update:vectorizeFailStrategy", i);
    }
    return (i, e) => {
      const g = F, f = b, l = V, y = S;
      return m(), u(d, null, [a("div", k, [
        e[0] || (e[0] = a("div", { class: "label" }, "等待向量化完成", -1)),
        o(g, {
          checked: t.waitForVectorize,
          disabled: t.readonly,
          "onUpdate:checked": c
        }, null, 8, ["checked", "disabled"]),
        e[1] || (e[1] = a("span", { class: "wait-vectorize-tip" }, "开启后节点将阻塞，等待新增文档向量化完成再进入下一步", -1))
      ]), t.waitForVectorize ? (m(), u(d, { key: 0 }, [a("div", N, [e[2] || (e[2] = a("div", { class: "label" }, "超时时间（秒）", -1)), o(f, {
        value: t.waitTimeout,
        min: 30,
        max: 1800,
        disabled: t.readonly,
        style: { width: "100%" },
        "onUpdate:value": v
      }, null, 8, ["value", "disabled"])]), a("div", T, [e[5] || (e[5] = a("div", { class: "label" }, "向量化失败/超时后", -1)), o(y, {
        value: t.vectorizeFailStrategy,
        disabled: t.readonly,
        "onUpdate:value": _
      }, {
        default: n(() => [o(l, { value: "error" }, {
          default: n(() => [...e[3] || (e[3] = [s("报错并中断流程", -1)])]),
          _: 1
        }), o(l, { value: "ignore" }, {
          default: n(() => [...e[4] || (e[4] = [s("忽略并继续流程", -1)])]),
          _: 1
        })]),
        _: 1
      }, 8, ["value", "disabled"])])], 64)) : x("", !0)], 64);
    };
  }
}), R = /* @__PURE__ */ w({ default: () => B }), B = /* @__PURE__ */ z(W, [["__scopeId", "data-v-e6bac838"]]);
export {
  R as n,
  B as t
};
