import { a as d } from "./objectSpread2-B0BetFB8.mjs";
import { computed as u, createCommentVNode as n, createElementBlock as i, createElementVNode as l, defineComponent as v, normalizeStyle as p, openBlock as m, renderSlot as r, toDisplayString as o } from "vue";
var y = {
  key: 0,
  class: "node-key-value"
}, c = { class: "node-key-value-item" }, _ = { class: "node-key-value-item-value" }, f = /* @__PURE__ */ v({
  __name: "NodeKV",
  props: {
    label: {
      type: String,
      required: !0
    },
    value: {
      type: String,
      required: !1
    },
    labelWidth: {
      type: Number,
      required: !1
    }
  },
  setup(t) {
    const a = t, s = u(() => {
      const e = {};
      return a.labelWidth && (e.width = a.labelWidth + "px"), e;
    });
    return (e, h) => t.value || e.$slots.default ? (m(), i("div", y, [l("div", c, [l("div", {
      class: "node-key-value-item-key",
      style: p(s.value)
    }, [r(e.$slots, "label", {}, () => [l("span", null, o(t.label), 1)])], 4), l("div", _, [r(e.$slots, "default", {}, () => [l("span", null, o(t.value), 1)])])])])) : n("", !0);
  }
}), S = /* @__PURE__ */ d({ default: () => b }), b = f;
export {
  S as n,
  b as t
};
