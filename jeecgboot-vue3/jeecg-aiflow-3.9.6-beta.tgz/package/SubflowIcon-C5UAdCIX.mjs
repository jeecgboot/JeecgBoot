import { a as o } from "./objectSpread2-B0BetFB8.mjs";
import { t as e } from "./NodeIcon-Dt_fCcq_.mjs";
import { createBlock as t, defineComponent as r, openBlock as _ } from "vue";
var a = /* @__PURE__ */ r({
  __name: "SubflowIcon",
  setup(u) {
    return (c, f) => (_(), t(e, {
      icon: "hugeicons:flow",
      color: "#fd9d2f"
    }));
  }
}), d = /* @__PURE__ */ o({ default: () => n }), n = a;
export {
  d as n,
  n as t
};
