import { a as X } from "./objectSpread2-B0BetFB8.mjs";
import { t as Z } from "./_plugin-vue_export-helper-Dj7HTbfw.mjs";
import { Dropdown as ee, Empty as le, Input as ae, InputNumber as ne, InputSearch as te, Select as oe } from "ant-design-vue/es";
import { Fragment as re, Teleport as ue, computed as _, createBlock as $, createCommentVNode as ie, createElementBlock as x, createElementVNode as d, createSlots as E, createTextVNode as de, createVNode as I, defineComponent as ve, normalizeClass as P, openBlock as c, ref as y, renderList as se, toDisplayString as w, unref as pe, watch as D, withCtx as h, withModifiers as O } from "vue";
import ce from "/@/components/Icon";
var fe = { class: "var-picker" }, me = { class: "var-picker__trigger" }, _e = { class: "var-picker__icon danger" }, ye = { class: "var-picker__option-list" }, he = ["onClick"], ke = { class: "var-picker__option-title" }, ge = { class: "var-picker__option-desc" }, Ce = { class: "var-picker__option-type" }, $e = /* @__PURE__ */ ve({
  __name: "VarPicker",
  props: {
    item: {
      type: Object,
      required: !0
    },
    vars: {
      type: Array,
      required: !0
    },
    allowEditValue: {
      type: Boolean,
      default: !1
    },
    allowedTypes: {
      type: Array,
      default: void 0
    },
    showTypeSelector: {
      type: Boolean,
      default: !1
    },
    readonly: {
      type: Boolean,
      default: !1
    }
  },
  emits: [
    "update:value",
    "change",
    "changeCustom",
    "changeType"
  ],
  setup(k, { emit: K }) {
    const T = [{
      label: "str",
      value: "string"
    }, {
      label: "num",
      value: "number"
    }], a = k, u = K, g = y(), f = y(T[0].value), r = y(""), V = y(!1), C = y(""), v = y(null), s = y(!1), q = _(() => {
      var e;
      return !((e = a.allowedTypes) === null || e === void 0) && e.length ? a.allowedTypes.map((l) => ({
        label: l === "Image" ? "Image" : "String",
        value: l
      })) : T;
    }), m = _(() => a.allowEditValue === !0), b = _(() => v.value !== null || !m.value), F = _(() => {
      var e, l;
      return s.value ? "" : v.value ? S(v.value) : !((e = a.item) === null || e === void 0) && e.nodeId && (!((l = a.item) === null || l === void 0) && l.field) ? `${a.item.nodeId}.${a.item.field}` : "";
    }), R = _({
      get: () => {
        if (!r.value) return null;
        const e = Number(r.value);
        return Number.isNaN(e) ? null : e;
      },
      set: (e) => {
        if (b.value) {
          e == null && B();
          return;
        }
        if (!m.value) return;
        if (e == null) {
          r.value = "", u("changeCustom", ""), u("update:value", "");
          return;
        }
        const l = `${Math.trunc(Number(e))}`;
        r.value = l, v.value = null, s.value = !0, u("changeCustom", l), u("update:value", l);
      }
    }), N = _(() => m.value ? f.value === "number" ? "请输入整数或选择字段" : "请输入内容或选择字段" : "请选择字段"), A = _(() => {
      const e = C.value.trim().toLowerCase(), l = a.vars.filter((n) => U(n == null ? void 0 : n.type));
      return e ? l.filter((n) => {
        var t, o, p;
        return `${(t = n.nodeName) !== null && t !== void 0 ? t : ""} ${(o = n.name) !== null && o !== void 0 ? o : ""} ${(p = n.field) !== null && p !== void 0 ? p : ""}`.toLowerCase().includes(e);
      }) : l;
    });
    function U(e) {
      return !a.allowedTypes || a.allowedTypes.length === 0 ? !0 : e ? a.allowedTypes.some((l) => l.endsWith("[]") ? e === l : l === "array" ? e.endsWith("[]") : e === l) : !1;
    }
    D(() => {
      var e, l, n, t;
      return {
        nodeId: (e = a.item) === null || e === void 0 ? void 0 : e.nodeId,
        field: (l = a.item) === null || l === void 0 ? void 0 : l.field,
        customValue: (n = a.item) === null || n === void 0 ? void 0 : n.customValue,
        type: (t = a.item) === null || t === void 0 ? void 0 : t.type
      };
    }, () => L(), { immediate: !0 }), D(() => a.vars, () => {
      s.value || L();
    }, { deep: !0 });
    function L() {
      var e, l, n, t;
      if (typeof ((e = a.item) === null || e === void 0 ? void 0 : e.type) == "string" ? f.value = a.item.type : f.value = T[0].value, !((l = a.item) === null || l === void 0) && l.customValue) {
        r.value = a.item.customValue, s.value = !0, v.value = null;
        return;
      }
      if (!((n = a.item) === null || n === void 0) && n.nodeId && (!((t = a.item) === null || t === void 0) && t.field)) {
        const o = a.vars.find((p) => p.nodeId === a.item.nodeId && p.field === a.item.field);
        v.value = o != null ? o : null, r.value = M(o != null ? o : a.item), s.value = !1;
        return;
      }
      r.value = "", v.value = null, s.value = m.value;
    }
    function M(e) {
      var l, n, t, o;
      return e ? `${(l = (n = e.nodeName) !== null && n !== void 0 ? n : e.nodeId) !== null && l !== void 0 ? l : "-"} / ${(t = (o = e.name) !== null && o !== void 0 ? o : e.field) !== null && t !== void 0 ? t : "-"}` : "";
    }
    function W(e) {
      if (f.value !== "number") return e;
      const l = e.startsWith("-"), n = e.replace(/[^0-9]/g, "");
      return n ? l ? `-${n}` : n : "";
    }
    function j(e) {
      if (!m.value || b.value) return;
      const l = e.target;
      if (!l) return;
      const n = W(l.value);
      r.value = n, v.value = null, s.value = !0, V.value = !1, u("changeCustom", n), u("update:value", n);
    }
    function Y(e) {
      if (!b.value) return;
      const l = e.target;
      l && l.value === "" && B();
    }
    function z(e) {
      f.value = e, a.item && (a.item.type = e), u("changeType", e), s.value && (r.value = W(r.value), u("changeCustom", r.value));
    }
    function G(e) {
      a.readonly || (V.value = e, e || (C.value = ""));
    }
    function S(e) {
      return `${e.nodeId}.${e.field}`;
    }
    function H(e) {
      v.value = e, s.value = !1, r.value = M(e), u("changeCustom", ""), u("update:value", S(e)), u("change", e), e.type && z(e.type), V.value = !1, C.value = "";
    }
    function B() {
      v.value = null, r.value = "", s.value = m.value, u("changeCustom", ""), u("update:value", ""), u("change");
    }
    return (e, l) => {
      const n = oe, t = ae, o = ne, p = te, J = le, Q = ee;
      return c(), x("div", fe, [k.showTypeSelector && g.value ? (c(), $(ue, {
        key: 0,
        to: g.value
      }, [I(n, {
        class: "var-picker__type",
        value: f.value,
        options: q.value,
        dropdownStyle: { minWidth: "120px" },
        popupClassName: "var-picker__type-dropdown",
        disabled: k.readonly,
        onChange: z,
        onClick: l[0] || (l[0] = O(() => {
        }, ["stop"]))
      }, {
        option: h(({ value: i }) => [d("span", null, w(i), 1)]),
        _: 1
      }, 8, [
        "value",
        "options",
        "disabled"
      ])], 8, ["to"])) : ie("", !0), I(Q, {
        open: V.value,
        trigger: "click",
        placement: "bottomRight",
        overlayStyle: { pointerEvents: "none" },
        onOpenChange: G
      }, {
        overlay: h(() => [d("div", {
          class: "var-picker__overlay",
          onClick: l[3] || (l[3] = O(() => {
          }, ["stop"]))
        }, [I(p, {
          value: C.value,
          "onUpdate:value": l[2] || (l[2] = (i) => C.value = i),
          size: "small",
          allowClear: "",
          placeholder: "搜索节点/字段"
        }, null, 8, ["value"]), d("div", ye, [A.value.length ? (c(!0), x(re, { key: 0 }, se(A.value, (i) => (c(), x("div", {
          key: i.nodeId + "-" + i.field,
          class: P(["var-picker__option", F.value === S(i) ? "var-picker__option--active" : ""]),
          onClick: (Ve) => H(i)
        }, [d("div", ke, w(i.nodeName || "-") + " / " + w(i.name || "-"), 1), d("div", ge, [de(w(i.field) + " ", 1), d("span", Ce, w(i.type || "-"), 1)])], 10, he))), 128)) : (c(), $(J, {
          key: 1,
          description: "无匹配字段"
        }))])])]),
        default: h(() => [d("div", me, [b.value ? (c(), $(t, {
          key: "var-picker-readonly",
          class: P(["var-picker__input", "var-picker__input-readonly"]),
          value: r.value,
          readonly: "",
          placeholder: N.value
        }, E({ _: 2 }, [k.showTypeSelector ? {
          name: "addonBefore",
          fn: h(() => [d("div", {
            ref_key: "addonBeforeRef",
            ref: g
          }, null, 512)]),
          key: "0"
        } : void 0, m.value ? {
          name: "suffix",
          fn: h(() => [d("div", _e, [I(pe(ce), {
            icon: "ant-design:close-outlined",
            onClick: O(B, ["stop"])
          })])]),
          key: "1"
        } : void 0]), 1032, ["value", "placeholder"])) : f.value !== "number" ? (c(), $(t, {
          key: "var-picker-editable-string",
          class: P(["var-picker__input"]),
          value: r.value,
          placeholder: N.value,
          onInput: j,
          onChange: Y
        }, E({ _: 2 }, [k.showTypeSelector ? {
          name: "addonBefore",
          fn: h(() => [d("div", {
            ref_key: "addonBeforeRef",
            ref: g
          }, null, 512)]),
          key: "0"
        } : void 0]), 1032, ["value", "placeholder"])) : (c(), $(o, {
          key: "var-picker-editable-number",
          value: R.value,
          "onUpdate:value": l[1] || (l[1] = (i) => R.value = i),
          class: "var-picker__input var-picker__input-number",
          placeholder: N.value,
          precision: 0,
          step: 1,
          controls: !1
        }, E({ _: 2 }, [k.showTypeSelector ? {
          name: "addonBefore",
          fn: h(() => [d("div", {
            ref_key: "addonBeforeRef",
            ref: g
          }, null, 512)]),
          key: "0"
        } : void 0]), 1032, ["value", "placeholder"]))])]),
        _: 1
      }, 8, ["open"])]);
    };
  }
}), xe = /* @__PURE__ */ X({ default: () => we }), we = /* @__PURE__ */ Z($e, [["__scopeId", "data-v-71cec302"]]);
export {
  xe as n,
  we as t
};
