import { a as i } from "./objectSpread2-B0BetFB8.mjs";
import "./base-node-CKuyN1x8.mjs";
import { t as d } from "./NodeContainer-zpIyuhKY.mjs";
import { t as m } from "./NodeKVS-CRVYjcYN.mjs";
import { t as c } from "./useNode-lPs0rKwe.mjs";
import { computed as _, createBlock as v, createVNode as f, defineComponent as y, guardReactiveProps as h, normalizeProps as C, openBlock as N, unref as o, withCtx as g } from "vue";
var b = /* @__PURE__ */ y({
  __name: "ChatMemoryGetNode",
  props: {
    node: {
      type: Object,
      required: !0
    },
    graph: {
      type: Object,
      required: !0
    }
  },
  setup(r) {
    const { containerProps: a, $properties: n, getInputParamKVItem: p, getOutputParamKVItem: u } = c(r), l = _(() => {
      var e;
      const t = ((e = n.value) === null || e === void 0 || (e = e.options) === null || e === void 0 ? void 0 : e.content) || "", s = t.length > 60 ? t.substring(0, 60) + "..." : t;
      return [
        p({ label: "输入变量" }),
        {
          label: "检索内容",
          value: s,
          emptyAction: "tip",
          emptyTip: "尚未配置"
        },
        u({ label: "输出变量" })
      ];
    });
    return (e, t) => (N(), v(o(d), C(h(o(a))), {
      default: g(() => [f(o(m), { kvs: l.value }, null, 8, ["kvs"])]),
      _: 1
    }, 16));
  }
}), I = /* @__PURE__ */ i({ default: () => x }), x = b;
export {
  I as n,
  x as t
};
