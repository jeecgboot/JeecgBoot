import { a as v } from "./objectSpread2-B0BetFB8.mjs";
import "./base-node-CKuyN1x8.mjs";
import { t as _ } from "./NodeContainer-zpIyuhKY.mjs";
import { t as y } from "./NodeKVS-CRVYjcYN.mjs";
import { t as f } from "./useNode-lPs0rKwe.mjs";
import { computed as $, createBlock as N, createVNode as b, defineComponent as h, guardReactiveProps as A, normalizeProps as g, openBlock as x, unref as n, withCtx as L } from "vue";
var P = /* @__PURE__ */ h({
  __name: "LoopNode",
  props: {
    node: {
      type: Object,
      required: !0
    },
    graph: {
      type: Object,
      required: !0
    }
  },
  setup(l) {
    const { $properties: u, getInputParamKVItem: i, getOutputParamKVItem: s } = f(l), d = {
      counted: "次数循环",
      infinite: "无限循环",
      array: "迭代循环"
    }, m = $(() => {
      var e, o;
      const t = (e = (o = u.value) === null || o === void 0 ? void 0 : o.options) !== null && e !== void 0 ? e : {}, r = t.type, p = r === "counted" ? `循环 ${t.maxLoopTimes} 次` : d[r], a = [i({
        label: "输入变量",
        emptyAction: "hidden"
      }), {
        label: "循环模式",
        value: p != null ? p : "",
        emptyAction: "tip",
        emptyTip: "请选择循环模式"
      }], c = Array.isArray(t.loopParams) ? t.loopParams.length : 0;
      return a.push({
        label: "循环变量",
        value: `${c} 个`,
        emptyAction: "tip",
        emptyTip: "尚未配置循环变量"
      }, s({
        label: "输出变量",
        emptyAction: "hidden"
      })), a;
    });
    return (e, o) => (x(), N(n(_), g(A(e.$props)), {
      default: L(() => [b(n(y), { kvs: m.value }, null, 8, ["kvs"])]),
      _: 1
    }, 16));
  }
}), j = /* @__PURE__ */ v({ default: () => T }), T = P;
export {
  j as n,
  T as t
};
