import { a as V, n as x, t as c } from "./objectSpread2-B0BetFB8.mjs";
import { t as n } from "./NodeKV-DCNHOs9C.mjs";
import { Fragment as d, createBlock as s, createCommentVNode as h, createElementBlock as r, createElementVNode as k, defineComponent as A, normalizeClass as N, normalizeStyle as g, openBlock as l, ref as f, renderList as S, toDisplayString as u, watch as m, withCtx as v } from "vue";
x();
var K = { key: 0 }, L = { key: 0 }, w = {
  key: 1,
  style: { color: "#d69696" }
}, C = /* @__PURE__ */ A({
  __name: "NodeKVS",
  props: { kvs: {
    type: Array,
    required: !0
  } },
  setup(W) {
    const i = W, a = f(), _ = f([]);
    return m(() => i.kvs, () => {
      a.value = void 0, _.value = i.kvs.map((y) => {
        const t = c({}, y);
        t.emptyAction || (t.emptyAction = "hidden"), t.emptyTip || (t.emptyTip = "尚未选择");
        let e = t.width;
        return e || (e = t.label.length * 14.5), (!a.value || e > a.value) && (a.value = e), t;
      });
    }, {
      deep: !0,
      immediate: !0
    }), (y, t) => (l(!0), r(d, null, S(_.value, (e) => (l(), r(d, { key: e.label }, [e.valueList && e.valueList.length > 0 ? (l(), s(n, {
      key: 0,
      label: e.label,
      labelWidth: a.value
    }, {
      default: v(() => [(l(!0), r(d, null, S(e.valueList, (o, b) => {
        var p;
        return l(), r(d, { key: o.text + b }, [k("span", {
          class: N(["node-kv-value-item", { [`node-kv-value__${o.type}`]: !!o.type }]),
          style: g(c({}, o.style ? o.style : {}))
        }, u(o.text), 7), b < e.valueList.length - 1 ? (l(), r("span", K, u((p = e.separator) !== null && p !== void 0 ? p : ", "), 1)) : h("", !0)], 64);
      }), 128))]),
      _: 2
    }, 1032, ["label", "labelWidth"])) : e.emptyAction === "hidden" ? (l(), s(n, {
      key: 1,
      label: e.label,
      value: e.value,
      labelWidth: a.value
    }, null, 8, [
      "label",
      "value",
      "labelWidth"
    ])) : e.emptyAction === "show" ? (l(), s(n, {
      key: 2,
      label: e.label,
      value: e.value,
      labelWidth: a.value
    }, {
      default: v(() => [k("span", null, u(e.value), 1)]),
      _: 2
    }, 1032, [
      "label",
      "value",
      "labelWidth"
    ])) : e.emptyAction === "tip" ? (l(), s(n, {
      key: 3,
      label: e.label,
      labelWidth: a.value
    }, {
      default: v(() => [e.value ? (l(), r("span", L, u(e.value), 1)) : (l(), r("span", w, u(e.emptyTip), 1))]),
      _: 2
    }, 1032, ["label", "labelWidth"])) : h("", !0)], 64))), 128));
  }
}), E = /* @__PURE__ */ V({ default: () => B }), B = C;
export {
  E as n,
  B as t
};
