import { a as e } from "./objectSpread2-B0BetFB8.mjs";
import { t as o } from "./NodeIcon-Dt_fCcq_.mjs";
import { createBlock as r, defineComponent as t, openBlock as n } from "vue";
var _ = /* @__PURE__ */ t({
  __name: "KnowledgeIcon",
  setup(l) {
    return (c, p) => (n(), r(o, {
      icon: "garden:knowledge-base-26",
      color: "#4165d7"
    }));
  }
}), f = /* @__PURE__ */ e({ default: () => a }), a = _;
export {
  f as n,
  a as t
};
