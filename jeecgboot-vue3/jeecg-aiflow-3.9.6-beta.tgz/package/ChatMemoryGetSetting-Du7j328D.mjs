import { a as I } from "./objectSpread2-B0BetFB8.mjs";
import { t as q } from "./_plugin-vue_export-helper-Dj7HTbfw.mjs";
import { t as z } from "./VarTextarea-BzeLBgKt.mjs";
import { t as M } from "./VarListPicker-CrG8EHn2.mjs";
import { t as N } from "./VarListShow-Dg1oan43.mjs";
import { t as A } from "./useSettings-Cq_-E7Ut.mjs";
import "./Vars-Cgan49KR.mjs";
import { Alert as G, InputNumber as R, Popover as B, Slider as j, Space as E, Switch as L, Tooltip as F } from "ant-design-vue/es";
import { computed as p, createElementBlock as K, createElementVNode as o, createVNode as l, defineComponent as $, isRef as n, mergeProps as x, openBlock as D, unref as t, withCtx as u } from "vue";
import H from "/@/components/Icon";
var J = { class: "chat-memory-get-setting" }, Q = { class: "setting-item" }, W = { class: "setting-item" }, X = { class: "label-row" }, Y = { class: "setting-item" }, Z = { class: "setting-item" }, ee = { class: "label" }, te = { class: "setting-item" }, le = /* @__PURE__ */ $({
  __name: "ChatMemoryGetSetting",
  props: {
    type: {
      type: String,
      required: !0
    },
    node: {
      type: Object,
      required: !0
    },
    properties: {
      type: Object,
      required: !0
    },
    isSilentMode: {
      type: Boolean,
      required: !0
    },
    setProperties: {
      type: Function,
      required: !0
    }
  },
  setup(w) {
    const { inputParams: d, outputParams: S, prevVariables: V, inputVarsOptions: h, createOptionRef: v, isReadOnly: s } = A(w), m = v("content"), i = v("topNumber"), r = v("similarity"), k = p(() => ["string", "number"]), _ = p({
      get() {
        return r.value !== null;
      },
      set(f) {
        r.value = f ? 0.75 : null;
      }
    }), y = p(() => ({
      min: 0,
      max: 1,
      step: 0.01,
      disabled: s.value || !_.value
    })), C = p(() => s.value ? [] : ["click"]);
    return (f, e) => {
      const O = G, c = R, b = j, g = E, P = L, T = F, U = B;
      return D(), K("div", J, [
        l(O, {
          type: "info",
          "show-icon": "",
          message: "从AI应用的记忆库中检索相关记忆，需要在AI应用中关联该流程并配置记忆库",
          style: { "margin-bottom": "10px" }
        }),
        o("div", Q, [e[7] || (e[7] = o("div", { class: "label" }, "输入变量", -1)), l(t(M), {
          vars: t(d),
          "onUpdate:vars": e[0] || (e[0] = (a) => n(d) ? d.value = a : null),
          prevVariables: t(V),
          allowedTypes: k.value,
          readonly: t(s)
        }, null, 8, [
          "vars",
          "prevVariables",
          "allowedTypes",
          "readonly"
        ])]),
        o("div", W, [o("div", X, [e[10] || (e[10] = o("div", { class: "label" }, "检索内容", -1)), l(U, {
          trigger: C.value,
          placement: "bottomRight",
          open: t(s) ? !1 : void 0
        }, {
          content: u(() => [o("div", Y, [e[8] || (e[8] = o("div", { class: "label" }, "Top K", -1)), l(g, null, {
            default: u(() => [l(c, {
              value: t(i),
              "onUpdate:value": e[1] || (e[1] = (a) => n(i) ? i.value = a : null),
              min: 1,
              max: 10,
              size: "small",
              style: { width: "80px" },
              disabled: t(s)
            }, null, 8, ["value", "disabled"]), l(b, {
              value: t(i),
              "onUpdate:value": e[2] || (e[2] = (a) => n(i) ? i.value = a : null),
              min: 1,
              max: 10,
              size: "small",
              style: { width: "240px" },
              disabled: t(s)
            }, null, 8, ["value", "disabled"])]),
            _: 1
          })]), o("div", Z, [o("div", ee, [l(g, null, {
            default: u(() => [l(P, {
              checked: _.value,
              "onUpdate:checked": e[3] || (e[3] = (a) => _.value = a),
              size: "small",
              disabled: t(s)
            }, null, 8, ["checked", "disabled"]), e[9] || (e[9] = o("div", null, "Score 阈值", -1))]),
            _: 1
          })]), l(g, null, {
            default: u(() => [l(c, x({
              value: t(r),
              "onUpdate:value": e[4] || (e[4] = (a) => n(r) ? r.value = a : null)
            }, y.value, {
              size: "small",
              style: { width: "80px" }
            }), null, 16, ["value"]), l(b, x({
              value: t(r),
              "onUpdate:value": e[5] || (e[5] = (a) => n(r) ? r.value = a : null)
            }, y.value, {
              size: "small",
              style: { width: "240px" }
            }), null, 16, ["value"])]),
            _: 1
          })])]),
          default: u(() => [l(T, { title: "参数配置" }, {
            default: u(() => [l(t(H), {
              icon: "ant-design:setting",
              class: "pointer"
            })]),
            _: 1
          })]),
          _: 1
        }, 8, ["trigger", "open"])]), l(t(z), {
          value: t(m),
          "onUpdate:value": e[6] || (e[6] = (a) => n(m) ? m.value = a : null),
          varsOptions: t(h),
          placeholder: "请输入检索的关键词或语句，按下 / 可以选择变量",
          height: 100,
          readonly: t(s)
        }, null, 8, [
          "value",
          "varsOptions",
          "readonly"
        ])]),
        o("div", te, [e[11] || (e[11] = o("div", { class: "label" }, "输出变量", -1)), l(t(N), { vars: t(S) }, null, 8, ["vars"])])
      ]);
    };
  }
}), ge = /* @__PURE__ */ I({ default: () => ae }), ae = /* @__PURE__ */ q(le, [["__scopeId", "data-v-474ec5cf"]]);
export {
  ge as n,
  ae as t
};
