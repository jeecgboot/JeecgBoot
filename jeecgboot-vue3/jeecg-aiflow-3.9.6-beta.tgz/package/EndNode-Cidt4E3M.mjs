import { a as i } from "./objectSpread2-B0BetFB8.mjs";
import "./base-node-CKuyN1x8.mjs";
import { t as s } from "./NodeContainer-zpIyuhKY.mjs";
import { t as v } from "./NodeKVS-CRVYjcYN.mjs";
import { t as m } from "./useNode-lPs0rKwe.mjs";
import { computed as u, createBlock as c, createVNode as f, defineComponent as _, guardReactiveProps as y, normalizeProps as N, openBlock as x, unref as n, withCtx as b } from "vue";
var h = /* @__PURE__ */ _({
  __name: "EndNode",
  props: {
    node: {
      type: Object,
      required: !0
    },
    graph: {
      type: Object,
      required: !0
    }
  },
  setup(p) {
    const { $properties: r, getOutputParamKVItem: a } = m(p), d = u(() => {
      var t, e;
      return (t = (e = r.value) === null || e === void 0 || (e = e.options) === null || e === void 0 ? void 0 : e.outputType) !== null && t !== void 0 ? t : "default";
    }), l = u(() => {
      const t = d.value, e = [a({
        label: "输出变量",
        emptyAction: t === "text" ? "hidden" : "tip"
      }), {
        label: "输出格式",
        value: t === "text" ? "文本" : t === "card" ? "卡片" : "JSON"
      }];
      if (t === "text") {
        var o;
        e.push({
          label: "文本内容",
          value: (o = r.value) === null || o === void 0 || (o = o.options) === null || o === void 0 ? void 0 : o.outputContent,
          emptyTip: "尚未输入",
          emptyAction: "tip"
        });
      }
      return e;
    });
    return (t, e) => (x(), c(n(s), N(y(t.$props)), {
      default: b(() => [f(n(v), { kvs: l.value }, null, 8, ["kvs"])]),
      _: 1
    }, 16));
  }
}), A = /* @__PURE__ */ i({ default: () => k }), k = h;
export {
  A as n,
  k as t
};
