import { a as I } from "./objectSpread2-B0BetFB8.mjs";
import { t as p } from "./asyncToGenerator-BkhZtDh9.mjs";
import { d as h } from "./api-BJs6o08o.mjs";
import { t as N } from "./propStore-CR0aJ5bA.mjs";
import "./base-node-CKuyN1x8.mjs";
import { t as $ } from "./NodeContainer-zpIyuhKY.mjs";
import { t as k } from "./NodeKVS-CRVYjcYN.mjs";
import { t as x } from "./useNode-lPs0rKwe.mjs";
import { computed as f, createBlock as P, createVNode as T, defineComponent as q, guardReactiveProps as A, normalizeProps as B, openBlock as C, reactive as O, ref as R, unref as d, withCtx as V } from "vue";
import { useMessage as j } from "/@/hooks/web/useMessage";
var K = /* @__PURE__ */ q({
  __name: "SubflowNode",
  props: {
    node: {
      type: Object,
      required: !0
    },
    graph: {
      type: Object,
      required: !0
    }
  },
  setup(c) {
    const v = N(), { createMessage: m } = j(), l = c, { $properties: _, createStoreRef: b } = x(l), r = f(() => {
      var e;
      return (e = _.value) === null || e === void 0 || (e = e.options) === null || e === void 0 ? void 0 : e.subflowId;
    }), u = b("subflowInfo"), t = O({
      is: !1,
      tips: "",
      count: 0,
      id: ""
    }), w = f(() => t.is && t.id === r.value ? [{
      label: "子流程",
      value: "",
      emptyAction: "tip",
      emptyTip: t.tips
    }] : [{
      label: "子流程",
      value: r.value ? y() : "",
      emptyAction: "tip",
      emptyTip: "尚未选择"
    }]), n = R(!1);
    function y() {
      var e;
      if (n.value) return "加载中...";
      if (!u.value || u.value.id !== r.value)
        return i(), "";
      const o = (e = u.value) === null || e === void 0 ? void 0 : e.name;
      return o || "未命名";
    }
    function i() {
      return a.apply(this, arguments);
    }
    function a() {
      return a = p(function* () {
        return t.is && (t.is = !1, t.count = 0, t.tips = ""), yield S();
      }), a.apply(this, arguments);
    }
    function S() {
      return s.apply(this, arguments);
    }
    function s() {
      return s = p(function* () {
        if (!r.value) return "";
        if (t.count >= 3) {
          t.is = !0, t.id = r.value || "", t.tips = t.tips || "加载失败";
          return;
        }
        try {
          n.value = !0;
          const { success: e, result: o, message: g } = yield h(r.value);
          if (!e) throw new Error(g || "加载子流程信息失败");
          if ((o == null ? void 0 : o.endOutputType) === "card") {
            m.warning("卡片类型不支持作为子流程，已自动清空"), v.setProperties(l.node.id, { "options.subflowId": "" });
            return;
          }
          u.value = o;
        } catch (e) {
          t.count++, t.tips = (e == null ? void 0 : e.message) || "加载失败", t.count >= 3;
        } finally {
          n.value = !1;
        }
      }), s.apply(this, arguments);
    }
    return (e, o) => (C(), P(d($), B(A(e.$props)), {
      default: V(() => [T(d(k), { kvs: w.value }, null, 8, ["kvs"])]),
      _: 1
    }, 16));
  }
}), W = /* @__PURE__ */ I({ default: () => M }), M = K;
export {
  W as n,
  M as t
};
