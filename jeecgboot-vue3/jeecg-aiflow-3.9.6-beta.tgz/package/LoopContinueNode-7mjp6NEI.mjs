import { a as e } from "./objectSpread2-B0BetFB8.mjs";
import "./base-node-CKuyN1x8.mjs";
import { t as r } from "./NodeContainer-zpIyuhKY.mjs";
import { createBlock as t, defineComponent as p, guardReactiveProps as n, normalizeProps as a, openBlock as u, unref as _ } from "vue";
var i = /* @__PURE__ */ p({
  __name: "LoopContinueNode",
  props: {
    node: {},
    graph: {}
  },
  setup(d) {
    return (o, l) => (u(), t(_(r), a(n(o.$props)), null, 16));
  }
}), C = /* @__PURE__ */ e({ default: () => s }), s = i;
export {
  C as n,
  s as t
};
