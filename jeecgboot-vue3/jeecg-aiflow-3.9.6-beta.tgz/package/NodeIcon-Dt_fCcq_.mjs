import { a as i, n as u, t as d } from "./objectSpread2-B0BetFB8.mjs";
import { computed as r, createElementBlock as p, createVNode as f, defineComponent as m, normalizeClass as _, normalizeStyle as g, openBlock as v, renderSlot as y, resolveComponent as C, useCssVars as N } from "vue";
import { useDesign as S } from "/@/hooks/web/useDesign";
u();
var k = /* @__PURE__ */ m({
  __name: "NodeIcon",
  props: {
    icon: {
      type: String,
      required: !0
    },
    color: {
      type: String,
      default: "#66ccff"
    },
    rotate: {
      type: Number,
      default: 0
    },
    strokeWidth: {
      type: Number,
      default: 0
    },
    iconColor: {
      type: String,
      default: "#fff"
    },
    className: {
      type: String,
      default: ""
    }
  },
  setup(o) {
    N((t) => ({
      v43607186: o.iconColor,
      v7ed3db9e: s.value
    }));
    const e = o, { prefixCls: n } = S("airag-base-node-icon"), a = r(() => {
      const t = [n];
      return e.className && t.push(e.className), t;
    }), c = r(() => {
      const t = e.rotate > 0 ? { transform: `rotate(${e.rotate}deg)` } : {};
      return d({ backgroundColor: e.color }, t);
    }), s = r(() => e.strokeWidth > 0 ? e.strokeWidth + "px" : e.strokeWidth);
    return (t, h) => {
      const l = C("Icon");
      return v(), p("div", {
        class: _(a.value),
        style: g(c.value)
      }, [y(t.$slots, "icon", {}, () => [f(l, {
        icon: o.icon,
        color: o.iconColor
      }, null, 8, ["icon", "color"])])], 6);
    };
  }
}), j = /* @__PURE__ */ i({ default: () => b }), b = k;
export {
  j as n,
  b as t
};
