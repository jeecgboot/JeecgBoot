import { n as O, s as j, t as H } from "./objectSpread2-B0BetFB8.mjs";
import { t as u } from "./asyncToGenerator-BkhZtDh9.mjs";
import { t as W } from "./dayjs.min-DQ4QC875.mjs";
import { useMessage as A } from "/@/hooks/web/useMessage";
import { defHttp as n } from "/@/utils/http/axios";
var L = /* @__PURE__ */ j(W());
O();
var { createMessage: B } = A(), G = 36e5;
function V(e, s, o) {
  const i = (r, a) => [`%c${r}`, `color: ${a};`], g = () => i("[INFO]", "#2196F3"), D = () => i("[WARN]", "#FFC107"), m = () => i("[ERRO]", "#F44336"), E = i("[stream-run]", "#999999"), c = (r, ...a) => {
    const l = r(), t = [
      `${E[0]} ${l[0]}`,
      E[1],
      l[1]
    ], f = (0, L.default)().format("HH:mm:ss.SSS");
  };
  let p = "";
  function N() {
    return y.apply(this, arguments);
  }
  function y() {
    return y = u(function* () {
      const r = (yield n.post({
        url: "/airag/flow/debug",
        params: H({
          flow: e,
          inputParams: s,
          responseMode: "streaming"
        }, o),
        adapter: "fetch",
        responseType: "stream",
        timeout: G
      }, { isTransformResponse: !1 })).getReader(), a = new TextDecoder();
      for (p = ""; ; ) {
        const { done: l, value: t } = yield r.read();
        if (l) break;
        const f = a.decode(t, { stream: !0 });
        try {
          c(g, "收到 chunkText:", { chunkText: f }), q(f);
        } catch (h) {
        }
      }
    }), y.apply(this, arguments);
  }
  function q(r) {
    if (!r) {
      c(m, "chunkText 为空:", { chunkText: r });
      return;
    }
    p.length > 0 && (r = p + r, c(g, "合并解析失败的数据:", { chunkText: r }), p = "");
    let a = !1;
    const l = r.split(`
`).flatMap((t) => {
      if (t = t ? t.trim() : "", !t) return [];
      if (t.startsWith("data:") && (t = t.slice(5)), !t)
        return c(m, "chunk 为空:", {
          chunk: t,
          chunkText: r
        }), [];
      try {
        return [JSON.parse(t)];
      } catch (f) {
        a = !0, c(m, "chunk 解析失败:", {
          chunk: t,
          chunkText: r
        });
      }
      return [];
    });
    a && (p += r), l.forEach(C);
  }
  const _ = /* @__PURE__ */ new Map(), P = /* @__PURE__ */ new Set();
  function C(r) {
    var a, l;
    if (r.success == !1) {
      const h = _.get("FLOW_FINISHED");
      if (typeof h == "function") {
        h(r);
        return;
      }
    }
    const t = `${r.event}-${((a = r.data) === null || a === void 0 ? void 0 : a.id) || ((l = r.data) === null || l === void 0 ? void 0 : l.fromNodeId) || ""}`;
    P.has(t), P.add(t);
    const f = _.get(r.event);
    typeof f == "function" ? (c(g, ` ------ 处理 ${r.event} 事件:`, {
      key: t,
      data: r
    }), f(r.data, r)) : c(D, `${r.event} 事件对应的回调不存在:`, {
      key: t,
      data: r
    });
  }
  function d(r, a) {
    _.set(r, a);
  }
  return {
    run: N,
    onFlowStarted: (r) => d("FLOW_STARTED", r),
    onFlowFinished: (r) => d("FLOW_FINISHED", r),
    onNodeStarted: (r) => d("NODE_STARTED", r),
    onNodeFinished: (r) => d("NODE_FINISHED", r),
    onMessage: (r) => d("MESSAGE", r)
  };
}
function X(e) {
  return w.apply(this, arguments);
}
function w() {
  return w = u(function* (e) {
    return n.get({
      url: "/airag/flow/list",
      params: e
    });
  }), w.apply(this, arguments);
}
function Y(e, s) {
  return S.apply(this, arguments);
}
function S() {
  return S = u(function* (e, s) {
    var o;
    const i = (o = s == null ? void 0 : s.silent) !== null && o !== void 0 ? o : !1;
    return n.post({
      url: "/airag/flow/add",
      params: e
    }, { successMessageMode: i ? "none" : "success" });
  }), S.apply(this, arguments);
}
function Z(e) {
  return v.apply(this, arguments);
}
function v() {
  return v = u(function* (e) {
    return n.put({
      url: "/airag/flow/edit",
      params: e
    });
  }), v.apply(this, arguments);
}
function k(e) {
  return F.apply(this, arguments);
}
function F() {
  return F = u(function* (e, s = !1) {
    const o = s ? "取消发布" : "发布", i = yield n.put({
      url: "/airag/flow/edit",
      params: {
        id: e,
        status: s ? "enable" : "release"
      }
    }, {
      successMessageMode: "none",
      isTransformResponse: !1
    });
    return i.success ? (B.success(`${o}成功`), !0) : (B.warn(i.message || `${o}失败`), !1);
  }), F.apply(this, arguments);
}
function ee(e, s) {
  return x.apply(this, arguments);
}
function x() {
  return x = u(function* (e, s) {
    var o;
    const i = (o = s == null ? void 0 : s.silent) !== null && o !== void 0 ? o : !1;
    return n.put({
      url: "/airag/flow/design/save",
      params: {
        id: e.id,
        name: e.name,
        chain: e.chain,
        design: e.design
      }
    }, { successMessageMode: i ? "none" : "success" });
  }), x.apply(this, arguments);
}
function re(e) {
  return T.apply(this, arguments);
}
function T() {
  return T = u(function* (e) {
    return n.delete({
      url: "/airag/flow/delete",
      data: { id: e }
    }, { joinParamsToUrl: !0 });
  }), T.apply(this, arguments);
}
function te(e) {
  return I.apply(this, arguments);
}
function I() {
  return I = u(function* (e) {
    return n.delete({
      url: "/airag/flow/deleteBatch",
      data: { ids: e.join(",") }
    }, { joinParamsToUrl: !0 });
  }), I.apply(this, arguments);
}
function se(e) {
  return M.apply(this, arguments);
}
function M() {
  return M = u(function* (e) {
    return n.get({
      url: "/airag/flow/querySubflowById",
      params: { subflowId: e }
    });
  }), M.apply(this, arguments);
}
function ne(e) {
  return b.apply(this, arguments);
}
function b() {
  return b = u(function* (e) {
    return n.get({
      url: "/airag/flow/querySubflowById",
      params: { subflowId: e }
    }, {
      isTransformResponse: !1,
      errorMessageMode: "none"
    });
  }), b.apply(this, arguments);
}
function ae(e) {
  return $.apply(this, arguments);
}
function $() {
  return $ = u(function* (e) {
    return n.get({
      url: "/airag/flow/queryById",
      params: { id: e }
    });
  }), $.apply(this, arguments);
}
function oe(e, s) {
  return R.apply(this, arguments);
}
function R() {
  return R = u(function* (e, s) {
    return n.post({
      url: "/airag/flow/copyFlow",
      params: e
    }).then(() => {
      s();
    });
  }), R.apply(this, arguments);
}
function ue(e) {
  return n.get({
    url: "/airag/app/listDict",
    params: e
  });
}
function ie(e) {
  return n.post({
    url: "/airag/flow/code/generate",
    params: e,
    adapter: "fetch",
    responseType: "stream",
    timeout: 3e5
  }, { isTransformResponse: !1 });
}
export {
  re as a,
  ue as c,
  ne as d,
  k as f,
  te as i,
  ae as l,
  Z as m,
  oe as n,
  ie as o,
  ee as p,
  V as r,
  X as s,
  Y as t,
  se as u
};
