import { t as o } from "./NodeIcon-Dt_fCcq_.mjs";
import { createBlock as e, defineComponent as t, openBlock as r } from "vue";
var _ = /* @__PURE__ */ t({
  __name: "LoopBodyIcon",
  setup(a) {
    return (p, c) => (r(), e(o, {
      icon: "mdi:repeat-variant",
      color: "#5c93ff",
      "stroke-width": 0.5
    }));
  }
}), u = _;
export {
  u as default
};
