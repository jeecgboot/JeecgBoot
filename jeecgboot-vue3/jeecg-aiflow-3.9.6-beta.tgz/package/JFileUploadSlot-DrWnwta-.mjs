import { a as C } from "./objectSpread2-B0BetFB8.mjs";
import { t as w } from "./_plugin-vue_export-helper-Dj7HTbfw.mjs";
import { Upload as L } from "ant-design-vue/es";
import { computed as s, createCommentVNode as b, createElementBlock as d, createElementVNode as F, createVNode as u, defineComponent as j, openBlock as m, ref as B, resolveComponent as f, toDisplayString as H, watch as I, withCtx as v } from "vue";
import { useMessage as J } from "/@/hooks/web/useMessage";
import { getHeaders as N } from "/@/utils/common/compUtils";
var k = { class: "file-upload-slot" }, E = {
  key: 0,
  class: "accept-tip"
}, M = /* @__PURE__ */ j({
  __name: "JFileUploadSlot",
  props: {
    value: {
      type: String,
      default: ""
    },
    uploadUrl: {
      type: String,
      required: !0
    },
    accept: {
      type: [String, Array],
      default: () => []
    },
    useAuthHeaders: {
      type: Boolean,
      default: !0
    }
  },
  emits: ["update:value"],
  setup(i, { emit: _ }) {
    const a = i, g = _, { createMessage: p } = J(), h = s(() => a.useAuthHeaders ? N() : {}), n = B([]), o = s(() => !a.accept || Array.isArray(a.accept) && a.accept.length === 0 ? [] : (Array.isArray(a.accept) ? a.accept.flatMap((t) => t.split(",")) : a.accept.split(",")).map((t) => t.trim().replace(/^\./, "").toLowerCase()).filter(Boolean)), y = s(() => o.value.length === 0 ? "" : o.value.map((t) => `.${t}`).join(",")), c = s(() => o.value.join("、"));
    function S(t) {
      if (o.value.length === 0) return !0;
      const e = t.name, r = e.substring(e.lastIndexOf(".") + 1).toLowerCase();
      return o.value.includes(r) ? !0 : (p.warning(`不支持该文件格式，请上传 ${o.value.join("、")} 格式的文件`), !1);
    }
    function U(t) {
      const { file: e, fileList: r } = t;
      if (n.value = [...r], e.status === "error" || e.response && e.response.code === 500) {
        var l;
        p.error(((l = e.response) === null || l === void 0 ? void 0 : l.message) || `${e.name} 上传失败`);
        return;
      }
      (e.status === "done" || e.status === "removed") && x();
    }
    function x() {
      const t = n.value.filter((e) => e.status === "done" && e.response).map((e) => e.response.message).join(",");
      g("update:value", t);
    }
    return I(() => a.value, (t) => {
      t || (n.value = []);
    }), (t, e) => {
      const r = f("Icon"), l = f("a-button"), A = L;
      return m(), d("div", k, [u(A, {
        action: i.uploadUrl,
        accept: y.value,
        headers: h.value,
        "file-list": n.value,
        multiple: !0,
        "before-upload": S,
        onChange: U,
        onRemove: t.handleRemove
      }, {
        default: v(() => [u(l, null, {
          default: v(() => [u(r, { icon: "ant-design:upload-outlined" }), e[0] || (e[0] = F("span", { style: { "margin-left": "6px" } }, "点击上传文件", -1))]),
          _: 1
        })]),
        _: 1
      }, 8, [
        "action",
        "accept",
        "headers",
        "file-list",
        "onRemove"
      ]), c.value ? (m(), d("div", E, "支持格式：" + H(c.value), 1)) : b("", !0)]);
    };
  }
}), z = /* @__PURE__ */ C({ default: () => R }), R = /* @__PURE__ */ w(M, [["__scopeId", "data-v-995c1c19"]]);
export {
  z as n,
  R as t
};
