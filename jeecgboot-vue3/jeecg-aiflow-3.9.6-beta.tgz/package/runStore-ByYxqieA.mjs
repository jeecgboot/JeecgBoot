import { n as r, t as n } from "./objectSpread2-B0BetFB8.mjs";
import "/@/store";
import { defineStore as p } from "pinia";
r();
var f = p("airag-flow-run", {
  state: () => ({
    status: "",
    inputParams: {},
    outputTexts: /* @__PURE__ */ new Map(),
    outputParams: {},
    outputTypes: {},
    outputValues: {},
    nodeSteps: [],
    time: 0,
    timeText: "",
    beginTime: 0,
    resMessage: ""
  }),
  getters: {
    isRunning(t) {
      return t.status === "running";
    },
    isFinished(t) {
      return t.status === "finished" || t.status === "failed";
    },
    isFailed(t) {
      return t.status === "failed";
    },
    outputResult(t) {
      const s = [...t.outputTexts.values()];
      return this.isRunning ? s.join(`
`) : t.outputParams;
    }
  },
  actions: {
    initStatus() {
      this.time = 0, this.timeText = "", this.status = "", this.nodeSteps = [], this.inputParams = {}, this.outputTexts.clear(), this.outputParams = {}, this.outputTypes = {}, this.outputValues = {}, this.resMessage = "";
    },
    start(t) {
      this.initStatus(), this.status = "running", this.beginTime = Date.now(), this.inputParams = t;
    },
    finish(t, s, i, e = {}, u = {}) {
      const a = t ? this.nodeSteps.some((o) => o.status === "fail") : !0;
      this.status = a ? "failed" : "finished", this.time = Date.now() - this.beginTime, this.timeText = `${(this.time / 1e3).toFixed(3)}s`, this.outputParams = i, this.outputTypes = e, this.outputValues = u, this.resMessage = s;
    },
    end() {
      this.initStatus();
    },
    addStep(t) {
      this.nodeSteps.push(n(n({}, t), {}, {
        time: 0,
        timeText: "",
        beginTime: Date.now(),
        expansion: !1
      }));
    },
    updateStepStatus(t, s, i) {
      const e = [...this.nodeSteps].reverse().find((u) => u.node.id === t && u.status === "running");
      e && (e.status = s, e.outputParams = i, (s === "success" || s === "fail") && (e.time = Date.now() - e.beginTime, e.timeText = `${(e.time / 1e3).toFixed(3)}s`));
    },
    addOutputText(t, s) {
      var i;
      const e = (i = this.outputTexts.get(t)) !== null && i !== void 0 ? i : "";
      this.outputTexts.set(t, e + s);
    },
    getStep(t) {
      return this.nodeSteps.find((s) => s.node.id === t);
    }
  }
});
export {
  f as t
};
