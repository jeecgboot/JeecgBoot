import { a } from "./objectSpread2-B0BetFB8.mjs";
import { t as e } from "./NodeIcon-Dt_fCcq_.mjs";
import { createBlock as n, defineComponent as o, openBlock as t } from "vue";
var r = /* @__PURE__ */ o({
  __name: "EnhanceJavaIcon",
  setup(_) {
    return (p, u) => (t(), n(e, {
      icon: "ant-design:java-outlined",
      color: "#33c9ff",
      "stroke-width": 32
    }));
  }
}), v = /* @__PURE__ */ a({ default: () => c }), c = r;
export {
  v as n,
  c as t
};
