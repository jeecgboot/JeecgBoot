import { a as e } from "./objectSpread2-B0BetFB8.mjs";
import { t as r } from "./NodeIcon-Dt_fCcq_.mjs";
import { createBlock as o, defineComponent as t, openBlock as a } from "vue";
var s = /* @__PURE__ */ t({
  __name: "ClassifierIcon",
  setup(c) {
    return (i, l) => (a(), o(r, {
      icon: "mingcute:classify-3-fill",
      color: "#12c499"
    }));
  }
}), u = /* @__PURE__ */ e({ default: () => _ }), _ = s;
export {
  u as n,
  _ as t
};
