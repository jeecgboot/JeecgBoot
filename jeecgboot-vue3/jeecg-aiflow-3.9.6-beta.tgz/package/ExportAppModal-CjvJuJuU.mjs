import { a as y } from "./objectSpread2-B0BetFB8.mjs";
import { t as s } from "./asyncToGenerator-BkhZtDh9.mjs";
import { createElementBlock as w, createVNode as p, defineComponent as M, h as i, openBlock as A, ref as k, unref as c, withCtx as E } from "vue";
import { useMessage as F } from "/@/hooks/web/useMessage";
import R from "/@/components/Modal/src/BasicModal.vue";
import { useModalInner as b } from "/@/components/Modal";
import { useForm as B } from "/@/components/Form";
import { defHttp as C } from "/@/utils/http/axios";
import O from "/@/components/Form/src/BasicForm.vue";
var L = /* @__PURE__ */ M({
  __name: "ExportAppModal",
  setup(P) {
    const u = [{
      label: "是否导出敏感信息",
      field: "izExportAppKey",
      component: "Switch",
      componentProps: {
        checkedValue: 1,
        unCheckedValue: 0
      },
      defaultValue: 1,
      itemProps: { extra: i("div", [i("p", { style: {
        color: "#FFB02E",
        margin: 0
      } }, "开启此开关后会将AI模型配置中的API密钥将随文件一同导出。")]) }
    }], [m, { resetFields: d, validate: f }] = B({
      schemas: u,
      showActionButtonGroup: !1,
      layout: "vertical",
      wrapperCol: { span: 24 },
      labelCol: { span: 24 }
    }), o = k(), { createMessage: _ } = F(), [g, { setModalProps: l, closeModal: h }] = b((function() {
      var t = s(function* (e) {
        yield d(), l({ confirmLoading: !1 }), l({
          minHeight: 200,
          bodyStyle: { padding: "10px" }
        }), o.value = e || {};
      });
      return function(e) {
        return t.apply(this, arguments);
      };
    })());
    function x() {
      return r.apply(this, arguments);
    }
    function r() {
      return r = s(function* () {
        let t = yield f();
        C.get({
          url: "/airag/flow/exportFlow/" + o.value.id + "/" + t.izExportAppKey,
          timeout: 6e4
        }, { isTransformResponse: !1 }).then((e) => {
          if (e.success) {
            let a = document.createElement("a"), v = new Blob([e.result], { type: "application/octet-stream,charset=UTF-8" }), n = window.URL.createObjectURL(v);
            a.href = n, a.download = o.value.name + ".jeecgai", a.click(), window.URL.revokeObjectURL(n), h();
          } else _.error(e.message);
        });
      }), r.apply(this, arguments);
    }
    return (t, e) => (A(), w("div", null, [p(R, {
      destroyOnClose: "",
      onRegister: c(g),
      canFullscreen: !1,
      width: "400px",
      title: "导出应用",
      onOk: x
    }, {
      default: E(() => [p(O, { onRegister: c(m) }, null, 8, ["onRegister"])]),
      _: 1
    }, 8, ["onRegister"])]));
  }
}), N = /* @__PURE__ */ y({ default: () => U }), U = L;
export {
  N as n,
  U as t
};
