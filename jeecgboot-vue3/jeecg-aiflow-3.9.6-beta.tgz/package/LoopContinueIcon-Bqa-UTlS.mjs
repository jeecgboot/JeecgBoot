import { a as o } from "./objectSpread2-B0BetFB8.mjs";
import { t as e } from "./NodeIcon-Dt_fCcq_.mjs";
import { createBlock as t, defineComponent as r, openBlock as n } from "vue";
var p = /* @__PURE__ */ r({
  __name: "LoopContinueIcon",
  setup(a) {
    return (c, u) => (n(), t(e, {
      icon: "ph:caret-circle-double-right-bold",
      color: "#3D8BFF",
      "stroke-width": 0
    }));
  }
}), d = /* @__PURE__ */ o({ default: () => _ }), _ = p;
export {
  d as n,
  _ as t
};
