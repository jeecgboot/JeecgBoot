import { a as O } from "./objectSpread2-B0BetFB8.mjs";
import { t as R } from "./_plugin-vue_export-helper-Dj7HTbfw.mjs";
import { t as D } from "./VarPicker-HOsUWkU-.mjs";
import { t as j } from "./VarListShow-Dg1oan43.mjs";
import { t as F } from "./useSettings-Cq_-E7Ut.mjs";
import "./Vars-Cgan49KR.mjs";
import { t as T } from "./LLMModelSelect-BRPxeDUM.mjs";
import { Space as G, Textarea as J } from "ant-design-vue/es";
import { Fragment as z, computed as H, createBlock as K, createCommentVNode as Q, createElementBlock as B, createElementVNode as t, createVNode as _, defineComponent as W, isRef as X, openBlock as C, renderList as Y, resolveComponent as M, toDisplayString as Z, unref as a, withCtx as N } from "vue";
import { useMessage as ee } from "/@/hooks/web/useMessage";
import { cloneDeep as te } from "lodash-es";
var Ae = /* @__PURE__ */ O({
  getAnchorId: () => I,
  getAnchorIdByChooseIndex: () => re,
  getCaseList: () => oe
});
function oe(u) {
  var s, n;
  const g = [], l = (s = (n = u.properties) === null || n === void 0 ? void 0 : n.options) !== null && s !== void 0 ? s : {};
  return Array.isArray(l.categories) && g.push(...l.categories.map((E, b) => ({
    type: "CASE",
    label: `分类 ${b + 1}`,
    category: E.category || "-",
    value: E
  }))), l.else && g.push({
    type: "ELSE",
    label: "ELSE",
    value: l.else
  }), g;
}
function I(u, s, n) {
  return `${u}_${`case_${s === "ELSE" ? "else" : n}`}`;
}
function re(u, s) {
  return I(u, s === -1 ? "ELSE" : "CASE", s + 1);
}
var ae = { class: "classifier-setting" }, se = { class: "setting-item" }, ne = { class: "setting-item" }, le = { class: "setting-item" }, ie = { class: "case-item" }, de = { class: "case-header" }, ue = { class: "case-label" }, ce = { class: "setting-item" }, pe = /* @__PURE__ */ W({
  __name: "ClassifierSetting",
  props: {
    type: {
      type: String,
      required: !0
    },
    node: {
      type: Object,
      required: !0
    },
    properties: {
      type: Object,
      required: !0
    },
    isSilentMode: {
      type: Boolean,
      required: !0
    },
    setProperties: {
      type: Function,
      required: !0
    }
  },
  setup(u) {
    const { createMessage: s } = ee(), n = u, { lfRef: g, inputParams: l, outputParams: E, prevVariables: b, createOptionRef: V, isReadOnly: c } = F(n), A = V("model"), p = V("categories"), L = H({
      get() {
        return l.value[0] ? l.value[0] : {
          field: "",
          nodeId: ""
        };
      },
      set(o) {
        l.value = [o];
      }
    });
    function w(o) {
      o != null && o.nodeId ? L.value = {
        field: o.field,
        nodeId: o.nodeId
      } : L.value = {
        field: "",
        nodeId: ""
      };
    }
    function q() {
      c.value || (p.value = [...p.value, {
        category: "",
        next: ""
      }]);
    }
    function U(o) {
      var e;
      if (c.value) return;
      const { node: f } = n;
      if (p.value.length === 1) {
        s.warning("请至少保留一个分类");
        return;
      }
      if (!g.value) return;
      const i = g.value.graphModel, { $caseList: y } = f, { type: $ } = y[o], d = I(f.id, $, o + 1), v = i.getAnchorOutgoingEdge(d);
      !(v == null || (e = v[0]) === null || e === void 0) && e.id && i.deleteEdgeById(v[0].id);
      const m = [];
      for (let r = o + 1; r < y.length; r++) {
        var k;
        const { type: S } = y[r];
        if (S === "ELSE") continue;
        const P = I(f.id, S, r + 1), h = i.getAnchorOutgoingEdge(P);
        !(h == null || (k = h[0]) === null || k === void 0) && k.id && m.push({
          edge: h[0],
          newSourceAnchorId: I(f.id, "CASE", r)
        });
      }
      p.value.splice(o, 1), x(), m.length && setTimeout(() => {
        for (const r of m) {
          const S = {
            id: r.edge.id,
            type: r.edge.type,
            sourceNodeId: r.edge.sourceNodeId,
            targetNodeId: r.edge.targetNodeId,
            sourceAnchorId: r.newSourceAnchorId,
            targetAnchorId: r.edge.targetAnchorId
          };
          i.deleteEdgeById(r.edge.id), i.addEdge(S);
        }
        i.$J.repaintGraph();
      }, 10);
    }
    function x() {
      p.value = te(p.value);
    }
    return (o, e) => {
      const f = M("Icon"), i = G, y = J, $ = M("a-button");
      return C(), B("div", ae, [
        t("div", se, [e[3] || (e[3] = t("div", { class: "label" }, "输入变量", -1)), _(a(D), {
          vars: a(b),
          item: L.value,
          readonly: a(c),
          onChange: e[0] || (e[0] = (d) => w(d))
        }, null, 8, [
          "vars",
          "item",
          "readonly"
        ])]),
        t("div", ne, [e[4] || (e[4] = t("div", { class: "label" }, "模型", -1)), _(T, {
          model: a(A),
          "onUpdate:model": e[1] || (e[1] = (d) => X(A) ? A.value = d : null),
          readonly: a(c)
        }, null, 8, ["model", "readonly"])]),
        t("div", le, [
          e[6] || (e[6] = t("div", { class: "label" }, "分类", -1)),
          (C(!0), B(z, null, Y(a(p), (d, v) => (C(), B("div", ie, [t("div", de, [t("div", ue, [t("span", null, "分类 " + Z(v + 1), 1)]), a(c) ? Q("", !0) : (C(), K(i, {
            key: 0,
            class: "case-action"
          }, {
            default: N(() => [_(f, {
              class: "delete",
              icon: "ant-design:delete",
              onClick: (m) => U(v)
            }, null, 8, ["onClick"])]),
            _: 2
          }, 1024))]), _(y, {
            class: "case-input",
            value: d.category,
            "onUpdate:value": (m) => d.category = m,
            placeholder: "请输入你的分类主题内容",
            disabled: a(c),
            onBlur: e[2] || (e[2] = () => x())
          }, null, 8, [
            "value",
            "onUpdate:value",
            "disabled"
          ])]))), 256)),
          _($, {
            block: "",
            preIcon: "ant-design:plus",
            onClick: q,
            disabled: a(c)
          }, {
            default: N(() => [...e[5] || (e[5] = [t("span", null, "添加分类", -1)])]),
            _: 1
          }, 8, ["disabled"])
        ]),
        e[8] || (e[8] = t("div", { class: "setting-item" }, [t("div", { class: "label case-label" }, [t("div", { class: "c-type" }, "ELSE")]), t("div", { style: { color: "#aaaaaa" } }, [t("span", null, "当以上分类都不满足时，执行此分支")])], -1)),
        t("div", ce, [e[7] || (e[7] = t("div", { class: "label" }, "输出变量", -1)), _(a(j), { vars: a(E) }, null, 8, ["vars"])])
      ]);
    };
  }
}), Le = /* @__PURE__ */ O({ default: () => ve }), ve = /* @__PURE__ */ R(pe, [["__scopeId", "data-v-cc26cf6e"]]);
export {
  Ae as a,
  oe as i,
  Le as n,
  I as r,
  ve as t
};
