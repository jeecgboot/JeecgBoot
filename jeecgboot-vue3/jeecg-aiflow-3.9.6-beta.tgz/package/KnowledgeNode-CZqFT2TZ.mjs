import { a as g } from "./objectSpread2-B0BetFB8.mjs";
import { t as y } from "./asyncToGenerator-BkhZtDh9.mjs";
import "./base-node-CKuyN1x8.mjs";
import { i as N, t as w } from "./NodeContainer-zpIyuhKY.mjs";
import { t as k } from "./NodeKVS-CRVYjcYN.mjs";
import { t as P } from "./useNode-lPs0rKwe.mjs";
import { t as x } from "./data-BrtUPagO.mjs";
import { computed as n, createBlock as K, createVNode as h, defineComponent as T, guardReactiveProps as $, normalizeProps as L, openBlock as V, unref as p, watch as b, withCtx as A } from "vue";
var D = /* @__PURE__ */ T({
  __name: "KnowledgeNode",
  props: {
    node: {
      type: Object,
      required: !0
    },
    graph: {
      type: Object,
      required: !0
    }
  },
  setup(l) {
    const { $properties: d, createStoreRef: s, prevNodes: m, inputParams: u, getOutputParamKVItem: v } = P(l), a = s("knowledgeDataList");
    b(() => {
      var e;
      return (e = d.value) === null || e === void 0 || (e = e.options) === null || e === void 0 ? void 0 : e.knowIds;
    }, (function() {
      var e = y(function* (t) {
        x(t, a);
      });
      return function(t) {
        return e.apply(this, arguments);
      };
    })(), {
      immediate: !0,
      deep: !0
    });
    const f = n(() => {
      if (u.value.length === 0) return "";
      const e = u.value[0];
      if (!e.field || !e.nodeId) return "";
      const t = m.value.find((o) => o.id === e.nodeId);
      if (!t) return "";
      let r = t.properties.outputParams;
      t.type === N.START && (r = t.properties.inputParams);
      const i = r.find((o) => o.field === e.field);
      return i ? `${t.properties.text} / ${i.name}` : "";
    }), c = n(() => {
      var e;
      return !((e = a.value) === null || e === void 0) && e.length ? a.value.map((t) => {
        const r = (t == null ? void 0 : t.name) || "";
        return r ? {
          text: r,
          type: t.invalid ? "invalid" : "default"
        } : null;
      }).filter((t) => !!t) : [];
    }), _ = n(() => [
      {
        label: "查询变量",
        value: f.value,
        emptyAction: "tip",
        emptyTip: "尚未选择"
      },
      {
        label: "知识库",
        value: "",
        valueList: c.value,
        emptyAction: "tip",
        emptyTip: "尚未选择"
      },
      v()
    ]);
    return (e, t) => (V(), K(p(w), L($(e.$props)), {
      default: A(() => [h(p(k), { kvs: _.value }, null, 8, ["kvs"])]),
      _: 1
    }, 16));
  }
}), G = /* @__PURE__ */ g({ default: () => I }), I = D;
export {
  G as n,
  I as t
};
