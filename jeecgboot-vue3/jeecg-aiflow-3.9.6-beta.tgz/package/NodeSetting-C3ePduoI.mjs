import { a as f, n as h, t as S } from "./objectSpread2-B0BetFB8.mjs";
import { t as k } from "./asyncToGenerator-BkhZtDh9.mjs";
import { r as N } from "./const-OjvoZKjM.mjs";
import { Empty as x, Textarea as w } from "ant-design-vue/es";
import { Fragment as C, computed as q, createBlock as l, createCommentVNode as u, createElementBlock as a, createVNode as b, defineComponent as j, mergeProps as B, nextTick as O, normalizeClass as P, normalizeProps as T, openBlock as o, ref as d, unref as m, watch as V } from "vue";
import { useDesign as z } from "/@/hooks/web/useDesign";
h();
var E = {
  key: 1,
  style: { "margin-top": "100px" }
}, F = /* @__PURE__ */ j({
  __name: "NodeSetting",
  props: {
    type: {
      type: String,
      required: !0
    },
    node: {
      type: Object,
      required: !0
    },
    properties: {
      type: Object,
      required: !0
    },
    isSilentMode: {
      type: Boolean,
      required: !0
    },
    setProperties: {
      type: Function,
      required: !0
    }
  },
  setup(c) {
    const t = c, { prefixCls: _ } = z("airag-node-setting-container");
    let n = null;
    const i = d(!0), p = d(!1);
    V(() => {
      var e;
      return (e = t.node) === null || e === void 0 ? void 0 : e.id;
    }, k(function* () {
      p.value = !0, n = t.type ? N.get(t.type) : null, i.value = n == null, yield O(), p.value = !1;
    }), { immediate: !0 });
    const s = q({
      get: () => {
        if (!t.properties) return "";
        const e = S({}, t.properties);
        return delete e.width, delete e.height, JSON.stringify(e, null, 2);
      },
      set: (e) => {
        const r = JSON.parse(e);
        r.width = t.properties.width, r.height = t.properties.height, t.setProperties(r);
      }
    });
    return (e, r) => {
      const v = x, g = w;
      return o(), a(C, null, [p.value ? u("", !0) : (o(), a("div", {
        key: 0,
        class: P([m(_)])
      }, [i.value ? (o(), l(v, {
        key: 0,
        description: "暂无配置"
      })) : (o(), l(m(n), T(B({ key: 1 }, e.$props)), null, 16))], 2)), i.value ? (o(), a("div", E, [b(g, {
        value: s.value,
        "onUpdate:value": r[0] || (r[0] = (y) => s.value = y),
        style: {
          width: "100%",
          height: "30vh"
        }
      }, null, 8, ["value"])])) : u("", !0)], 64);
    };
  }
}), I = /* @__PURE__ */ f({ default: () => J }), J = F;
export {
  I as n,
  J as t
};
