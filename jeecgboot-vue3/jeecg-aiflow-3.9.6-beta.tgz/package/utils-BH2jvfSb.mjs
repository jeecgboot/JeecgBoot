import { a as ja, n as Uo, r as br, s as xr, t as cn } from "./objectSpread2-B0BetFB8.mjs";
import { i as Wa } from "./const-OjvoZKjM.mjs";
import { t as $a } from "./runStore-ByYxqieA.mjs";
import { n as Xa } from "./propStore-CR0aJ5bA.mjs";
import { $ as Pn, A as Ya, B as qi, C as _i, D as Vi, E as Ua, F as Vo, G as Qi, H as sr, I as lr, J as Va, K as qt, L as Lr, M as wr, N as Ka, O as Er, P as Ko, Q as qa, R as Ir, S as ii, T as Qa, U as Za, V as qo, W as oe, X as Ja, Y as ot, Z as I, _ as _r, a as es, b as ts, c as Qo, g as Zo, h as Jo, i as is, j as ni, k as ns, m as ea, o as rs, q as Fe, r as os, s as Qt, t as as, v as ss, w as ls, x as Cr, y as ds, z as us } from "./base-node-CKuyN1x8.mjs";
import { i as Zt, r as cs, t as hs } from "./NodeContainer-zpIyuhKY.mjs";
import { t as fs } from "./LoopIcon-CX6C90KP.mjs";
import { t as ps } from "./useNode-lPs0rKwe.mjs";
import { computed as vs, createBlock as gs, createElementVNode as ms, defineComponent as ys, mergeProps as bs, normalizeStyle as xs, onMounted as ws, openBlock as Es, ref as zn, unref as kr, watchEffect as _s, withCtx as Cs } from "vue";
import ta, { assign as Rn, cloneDeep as ft, concat as jn, filter as gi, findIndex as Ss, forEach as be, get as Ns, has as Yi, isArray as rn, isEmpty as ti, isEqual as _t, isFinite as Ts, isNil as ht, isObject as ia, map as Jt, merge as Hi, reduce as Ms, sortBy as As, uniqBy as Os } from "lodash-es";
var bt;
(function(o) {
  o.GROUP_ADD_NODE = "group:add-node", o.GROUP_REMOVE_NODE = "group:remove-node", o.GROUP_NOT_ALLOWED = "group:not-allowed";
})(bt || (bt = {}));
var Ui = "".concat(oe.NODE_DRAG, ",").concat(oe.NODE_DND_DRAG), dr = "".concat(oe.NODE_ADD, ",").concat(oe.NODE_DROP, ",").concat(oe.NODE_DND_ADD), Br = {
  width: 40,
  height: 40
}, Hr = {
  width: 40,
  height: 40
}, Fr = {
  width: 40,
  height: 40
}, Gr = {
  width: 100,
  height: 80
}, zr = {
  width: 100,
  height: 80
}, Ds = (function() {
  function o() {
    globalThis._ids = this, this._ids = /* @__PURE__ */ new Set();
  }
  return o.prototype.generateId = function() {
    return "xxxxxxx".replace(/[x]/g, function(n) {
      var e = Math.random() * 16 | 0;
      return (n === "x" ? e : e & 3 | 8).toString(16);
    });
  }, o.prototype.next = function() {
    for (var n = this.generateId(); this._ids.has(n); ) n = this.generateId();
    return this._ids.add(n), n;
  }, o;
})(), Ps = (globalThis == null ? void 0 : globalThis._ids) || new Ds();
function ri() {
  return Ps.next();
}
var na = /* @__PURE__ */ (function() {
  var o = function(n, e) {
    return o = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(i, t) {
      i.__proto__ = t;
    } || function(i, t) {
      for (var r in t) Object.prototype.hasOwnProperty.call(t, r) && (i[r] = t[r]);
    }, o(n, e);
  };
  return function(n, e) {
    if (typeof e != "function" && e !== null) throw new TypeError("Class extends value " + String(e) + " is not a constructor or null");
    o(n, e);
    function i() {
      this.constructor = n;
    }
    n.prototype = e === null ? Object.create(e) : (i.prototype = e.prototype, new i());
  };
})(), zu = (function(o) {
  na(n, o);
  function n(e, i) {
    return e.id || (e.id = "Event_".concat(ri())), e.text || (e.text = ""), e.text && typeof e.text == "string" && (e.text = {
      value: e.text,
      x: e.x,
      y: e.y + 40
    }), o.call(this, e, i) || this;
  }
  return n.prototype.setAttributes = function() {
    this.r = 18;
  }, n.prototype.getConnectedTargetRules = function() {
    var e = o.prototype.getConnectedTargetRules.call(this);
    return e.push({
      message: "起始节点不能作为边的终点",
      validate: function() {
        return !1;
      }
    }), e;
  }, n.extendKey = "StartEventModel", n;
})(ni), ju = (function(o) {
  na(n, o);
  function n() {
    return o !== null && o.apply(this, arguments) || this;
  }
  return n.extendKey = "StartEventNode", n;
})(ii), ra = /* @__PURE__ */ (function() {
  var o = function(n, e) {
    return o = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(i, t) {
      i.__proto__ = t;
    } || function(i, t) {
      for (var r in t) Object.prototype.hasOwnProperty.call(t, r) && (i[r] = t[r]);
    }, o(n, e);
  };
  return function(n, e) {
    if (typeof e != "function" && e !== null) throw new TypeError("Class extends value " + String(e) + " is not a constructor or null");
    o(n, e);
    function i() {
      this.constructor = n;
    }
    n.prototype = e === null ? Object.create(e) : (i.prototype = e.prototype, new i());
  };
})(), hn = function() {
  return hn = Object.assign || function(o) {
    for (var n, e = 1, i = arguments.length; e < i; e++) {
      n = arguments[e];
      for (var t in n) Object.prototype.hasOwnProperty.call(n, t) && (o[t] = n[t]);
    }
    return o;
  }, hn.apply(this, arguments);
}, Wu = (function(o) {
  ra(n, o);
  function n(e, i) {
    return e.id || (e.id = "Event_".concat(ri())), e.text || (e.text = ""), e.text && typeof e.text == "string" && (e.text = {
      value: e.text,
      x: e.x,
      y: e.y + 40
    }), o.call(this, e, i) || this;
  }
  return n.prototype.setAttributes = function() {
    this.r = 18;
  }, n.prototype.getConnectedSourceRules = function() {
    var e = o.prototype.getConnectedSourceRules.call(this);
    return e.push({
      message: "结束节点不能作为边的起点",
      validate: function() {
        return !1;
      }
    }), e;
  }, n.extendKey = "EndEventModel", n;
})(ni), $u = (function(o) {
  ra(n, o);
  function n() {
    return o !== null && o.apply(this, arguments) || this;
  }
  return n.prototype.getAnchorStyle = function() {
    return { visibility: "hidden" };
  }, n.prototype.getShape = function() {
    var e = this.props.model, i = e.getNodeStyle(), t = e, r = t.x, a = t.y, s = t.r, d = o.prototype.getShape.call(this);
    return I("g", {}, d, I("circle", hn(hn({}, i), {
      cx: r,
      cy: a,
      r: s - 5
    })));
  }, n.extendKey = "EndEventView", n;
})(ii), oa = /* @__PURE__ */ (function() {
  var o = function(n, e) {
    return o = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(i, t) {
      i.__proto__ = t;
    } || function(i, t) {
      for (var r in t) Object.prototype.hasOwnProperty.call(t, r) && (i[r] = t[r]);
    }, o(n, e);
  };
  return function(n, e) {
    if (typeof e != "function" && e !== null) throw new TypeError("Class extends value " + String(e) + " is not a constructor or null");
    o(n, e);
    function i() {
      this.constructor = n;
    }
    n.prototype = e === null ? Object.create(e) : (i.prototype = e.prototype, new i());
  };
})(), Xu = (function(o) {
  oa(n, o);
  function n(e, i) {
    return e.id || (e.id = "Flow_".concat(ri())), o.call(this, e, i) || this;
  }
  return n.extendKey = "SequenceFlowModel", n;
})(wr), Yu = (function(o) {
  oa(n, o);
  function n() {
    return o !== null && o.apply(this, arguments) || this;
  }
  return n.extendKey = "SequenceFlowEdge", n;
})(_r), aa = /* @__PURE__ */ (function() {
  var o = function(n, e) {
    return o = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(i, t) {
      i.__proto__ = t;
    } || function(i, t) {
      for (var r in t) Object.prototype.hasOwnProperty.call(t, r) && (i[r] = t[r]);
    }, o(n, e);
  };
  return function(n, e) {
    if (typeof e != "function" && e !== null) throw new TypeError("Class extends value " + String(e) + " is not a constructor or null");
    o(n, e);
    function i() {
      this.constructor = n;
    }
    n.prototype = e === null ? Object.create(e) : (i.prototype = e.prototype, new i());
  };
})(), Fi = function() {
  return Fi = Object.assign || function(o) {
    for (var n, e = 1, i = arguments.length; e < i; e++) {
      n = arguments[e];
      for (var t in n) Object.prototype.hasOwnProperty.call(n, t) && (o[t] = n[t]);
    }
    return o;
  }, Fi.apply(this, arguments);
}, Uu = (function(o) {
  aa(n, o);
  function n(e, i) {
    var t = this;
    return e.id || (e.id = "Gateway_".concat(ri())), e.text || (e.text = ""), e.text && typeof e.text == "string" && (e.text = {
      value: e.text,
      x: e.x,
      y: e.y + 40
    }), t = o.call(this, e, i) || this, t.points = [
      [25, 0],
      [50, 25],
      [25, 50],
      [0, 25]
    ], t;
  }
  return n.extendKey = "ExclusiveGatewayModel", n;
})(Er), Vu = (function(o) {
  aa(n, o);
  function n() {
    return o !== null && o.apply(this, arguments) || this;
  }
  return n.prototype.getShape = function() {
    var e = this.props.model, i = e, t = i.x, r = i.y, a = i.width, s = i.height, d = i.points, l = e.getNodeStyle();
    return I("g", { transform: "matrix(1 0 0 1 ".concat(t - a / 2, " ").concat(r - s / 2, ")") }, I("polygon", Fi(Fi({}, l), {
      x: t,
      y: r,
      points: d
    })), I("path", Fi({ d: "m 16,15 7.42857142857143,9.714285714285715 -7.42857142857143,9.714285714285715 3.428571428571429,0 5.714285714285715,-7.464228571428572 5.714285714285715,7.464228571428572 3.428571428571429,0 -7.42857142857143,-9.714285714285715 7.42857142857143,-9.714285714285715 -3.428571428571429,0 -5.714285714285715,7.464228571428572 -5.714285714285715,-7.464228571428572 -3.428571428571429,0 z" }, l)));
  }, n.extendKey = "ExclusiveGatewayNode", n;
})(Cr), sa = /* @__PURE__ */ (function() {
  var o = function(n, e) {
    return o = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(i, t) {
      i.__proto__ = t;
    } || function(i, t) {
      for (var r in t) Object.prototype.hasOwnProperty.call(t, r) && (i[r] = t[r]);
    }, o(n, e);
  };
  return function(n, e) {
    if (typeof e != "function" && e !== null) throw new TypeError("Class extends value " + String(e) + " is not a constructor or null");
    o(n, e);
    function i() {
      this.constructor = n;
    }
    n.prototype = e === null ? Object.create(e) : (i.prototype = e.prototype, new i());
  };
})(), ur = function() {
  return ur = Object.assign || function(o) {
    for (var n, e = 1, i = arguments.length; e < i; e++) {
      n = arguments[e];
      for (var t in n) Object.prototype.hasOwnProperty.call(n, t) && (o[t] = n[t]);
    }
    return o;
  }, ur.apply(this, arguments);
}, Ku = (function(o) {
  sa(n, o);
  function n(e, i) {
    return e.id || (e.id = "Activity_".concat(ri())), o.call(this, e, i) || this;
  }
  return n.extendKey = "ServiceTaskModel", n;
})(Vi), qu = (function(o) {
  sa(n, o);
  function n() {
    return o !== null && o.apply(this, arguments) || this;
  }
  return n.prototype.getLabelShape = function() {
    var e = this.props.model, i = e.x, t = e.y, r = e.width, a = e.height, s = e.getNodeStyle();
    return I("svg", {
      x: i - r / 2 + 5,
      y: t - a / 2 + 5,
      width: 30,
      height: 30,
      viewBox: "0 0 1274 1024"
    }, I("path", {
      fill: s.stroke,
      d: "M882.527918 434.149934c-2.234901-5.303796-7.311523-8.853645-13.059434-9.138124l-61.390185-3.009544c-6.635117-20.973684-15.521508-41.175795-26.513864-60.282968l42.051745-47.743374c4.308119-4.889357 4.955872-12.004405 1.602498-17.59268-46.384423-77.30362-103.969956-101.422947-106.400309-102.410438-5.332449-2.170432-11.432377-1.090844-15.693424 2.77009L654.674467 240.664222c-17.004279-8.654101-35.092239-15.756869-53.995775-21.210068l-3.26537-66.490344c-0.280386-5.747911-3.833305-10.824533-9.134031-13.059434-1.683339-0.709151-30.193673-12.391215-76.866668-12.051477-46.672996-0.339738-75.18333 11.342326-76.866668 12.051477-5.300726 2.234901-8.853645 7.311523-9.134031 13.059434l-3.26537 66.490344c-18.903535 5.453199-36.991496 12.555967-53.995775 21.210068l-48.450479-43.922349c-4.261047-3.860934-10.360975-4.940522-15.693424-2.77009-2.430352 0.98749-60.015885 25.106818-106.400309 102.410438-3.353374 5.588275-2.705622 12.703323 1.602498 17.59268l42.051745 47.743374c-10.992355 19.107173-19.878746 39.309284-26.513864 60.282968l-61.390185 3.009544c-5.747911 0.284479-10.824533 3.834328-13.059434 9.138124-1.01512 2.415003-24.687262 60.190871-2.822278 147.651828 1.583055 6.324032 7.072069 10.893094 13.57518 11.308557 5.892197 0.37146 11.751648 0.523933 17.419741 0.667196 14.498202 0.372483 28.193109 0.723477 40.908712 4.63353 4.212952 1.294482 6.435573 8.270361 9.349949 18.763342 1.287319 4.640694 2.617617 9.43693 4.484128 14.010085 1.794879 4.393054 3.75758 8.570189 5.66093 12.607132 1.302669 2.765997 2.529613 5.380544 3.689019 8.018627 2.986007 6.803963 2.682086 9.773598 2.578732 10.349719-3.061732 3.672646-6.391571 7.238868-9.91379 11.015891-1.810229 1.943258-3.680832 3.949962-5.523807 5.980201l-22.560832 24.8909c-3.865028 4.261047-4.940522 10.365068-2.774183 15.693424 0.991584 2.426259 25.102724 60.011792 102.414531 106.400309 5.588275 3.353374 12.703323 2.701528 17.591657-1.603521l23.476691-20.682042c2.346441-2.061962 4.64888-4.336772 6.875594-6.534833 9.05319-8.93858 14.018272-12.95608 17.73185-11.576663 3.305279 1.222851 6.907317 3.166109 10.720156 5.228071 3.325745 1.794879 6.764054 3.650133 10.465352 5.288446 6.016017 2.662643 12.120039 4.688789 18.019399 6.65149 6.827499 2.266623 13.279445 4.409426 18.819624 7.275707 1.518586 0.782829 1.926886 0.994654 2.358721 7.830339 0.726547 11.496845 1.25048 23.276123 1.753947 34.672684 0.264013 5.900384 0.528026 11.803837 0.815575 17.700127 0.284479 5.743818 3.833305 10.82044 9.138124 13.05534 1.654686 0.698918 29.371958 12.063757 74.869175 12.063757 0.328481 0 3.65832 0 3.986801 0 45.497217 0 73.214489-11.364839 74.869175-12.063757 5.304819-2.234901 8.853645-7.311523 9.138124-13.05534 0.287549-5.89629 0.551562-11.799744 0.815575-17.700127 0.503467-11.396561 1.027399-23.175839 1.753947-34.672684 0.431835-6.835685 0.840134-7.04751 2.358721-7.830339 5.54018-2.866281 11.992125-5.009084 18.819624-7.275707 5.89936-1.962701 12.003382-3.988848 18.019399-6.65149 3.701299-1.638313 7.139607-3.493567 10.465352-5.288446 3.812839-2.061962 7.414877-4.00522 10.720156-5.228071 3.713578-1.379417 8.67866 2.638083 17.73185 11.576663 2.226714 2.198062 4.529153 4.472871 6.875594 6.534833l23.476691 20.682042c4.888334 4.305049 12.003382 4.956895 17.591657 1.603521 77.311807-46.388517 101.422947-103.97405 102.414531-106.400309 2.166339-5.328355 1.090844-11.432377-2.774183-15.693424l-22.560832-24.8909c-1.842974-2.030239-3.713578-4.036943-5.523807-5.980201-3.52222-3.777023-6.852058-7.343245-9.91379-11.015891-0.103354-0.576121-0.407276-3.545756 2.578732-10.349719 1.159406-2.638083 2.38635-5.252631 3.689019-8.018627 1.90335-4.036943 3.866051-8.214079 5.66093-12.607132 1.866511-4.573155 3.196809-9.369392 4.484128-14.010085 2.914376-10.492982 5.136997-17.46886 9.349949-18.763342 12.715603-3.910053 26.41051-4.261047 40.908712-4.63353 5.668093-0.143263 11.527544-0.295735 17.419741-0.667196 6.503111-0.415462 11.992125-4.984524 13.57518-11.308557C907.21518 494.340805 883.543038 436.564937 882.527918 434.149934zM643.49894 643.761929c-35.280528 35.280528-82.191954 54.711066-132.086317 54.711066s-96.806813-19.430538-132.086317-54.711066c-35.280528-35.279504-54.711066-82.191954-54.711066-132.086317 0-49.894364 19.430538-96.80272 54.711066-132.082224 35.283598-35.284621 82.191954-54.711066 132.086317-54.711066s96.80579 19.426445 132.086317 54.711066c35.279504 35.279504 54.711066 82.187861 54.711066 132.082224C698.210006 561.569976 678.782537 608.482425 643.49894 643.761929z"
    }));
  }, n.prototype.getShape = function() {
    var e = this.props.model, i = e.x, t = e.y, r = e.width, a = e.height, s = e.radius, d = e.getNodeStyle();
    return I("g", {}, [I("rect", ur({
      x: i - r / 2,
      y: t - a / 2,
      rx: s,
      ry: s,
      width: r,
      height: a
    }, d)), this.getLabelShape()]);
  }, n.extendKey = "ServiceTaskNode", n;
})(_i), la = /* @__PURE__ */ (function() {
  var o = function(n, e) {
    return o = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(i, t) {
      i.__proto__ = t;
    } || function(i, t) {
      for (var r in t) Object.prototype.hasOwnProperty.call(t, r) && (i[r] = t[r]);
    }, o(n, e);
  };
  return function(n, e) {
    if (typeof e != "function" && e !== null) throw new TypeError("Class extends value " + String(e) + " is not a constructor or null");
    o(n, e);
    function i() {
      this.constructor = n;
    }
    n.prototype = e === null ? Object.create(e) : (i.prototype = e.prototype, new i());
  };
})(), fn = function() {
  return fn = Object.assign || function(o) {
    for (var n, e = 1, i = arguments.length; e < i; e++) {
      n = arguments[e];
      for (var t in n) Object.prototype.hasOwnProperty.call(n, t) && (o[t] = n[t]);
    }
    return o;
  }, fn.apply(this, arguments);
}, Qu = (function(o) {
  la(n, o);
  function n(e, i) {
    return e.id || (e.id = "Activity_".concat(ri())), o.call(this, e, i) || this;
  }
  return n.extendKey = "UserTaskModel", n;
})(Vi), Zu = (function(o) {
  la(n, o);
  function n() {
    return o !== null && o.apply(this, arguments) || this;
  }
  return n.prototype.getLabelShape = function() {
    var e = this.props.model, i = e.x, t = e.y, r = e.width, a = e.height, s = e.getNodeStyle();
    return I("svg", {
      x: i - r / 2 + 5,
      y: t - a / 2 + 5,
      width: 25,
      height: 25,
      viewBox: "0 0 1274 1024"
    }, I("path", {
      fill: s.stroke,
      d: "M655.807326 287.35973m-223.989415 0a218.879 218.879 0 1 0 447.978829 0 218.879 218.879 0 1 0-447.978829 0ZM1039.955839 895.482975c-0.490184-212.177424-172.287821-384.030443-384.148513-384.030443-211.862739 0-383.660376 171.85302-384.15056 384.030443L1039.955839 895.482975z"
    }));
  }, n.prototype.getShape = function() {
    var e = this.props.model, i = e.x, t = e.y, r = e.width, a = e.height, s = e.radius, d = e.getNodeStyle();
    return I("g", {}, [I("rect", fn(fn({}, d), {
      x: i - r / 2,
      y: t - a / 2,
      rx: s,
      ry: s,
      width: r,
      height: a
    })), this.getLabelShape()]);
  }, n.extendKey = "UserTaskNode", n;
})(_i), Rs = (function() {
  function o() {
    globalThis._ids = this, this._ids = /* @__PURE__ */ new Set();
  }
  return o.prototype.generateId = function() {
    return "xxxxxxx".replace(/[x]/g, function(n) {
      var e = Math.random() * 16 | 0;
      return (n === "x" ? e : e & 3 | 8).toString(16);
    });
  }, o.prototype.next = function() {
    for (var n = this.generateId(); this._ids.has(n); ) n = this.generateId();
    return this._ids.add(n), n;
  }, o;
})(), Ls = (globalThis == null ? void 0 : globalThis._ids) || new Rs();
function jr() {
  return Ls.next();
}
function da(o) {
  return Object.prototype.toString.call(o);
}
function Is(o) {
  return "  ".repeat(o);
}
function pn(o) {
  var n = o;
  return da(o) === "[object Object]" ? (n = {}, Object.keys(o).forEach(function(e) {
    var i = e;
    e.charAt(0) === "-" && (i = e.substring(1)), n[i] = pn(o[e]);
  })) : Array.isArray(o) && (n = [], o.forEach(function(e, i) {
    n[i] = pn(e);
  })), n;
}
function vn(o) {
  return o == null ? "" : o.toString().replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&apos;");
}
function ks(o) {
  var n = o;
  try {
    typeof n != "string" && (n = JSON.parse(o));
  } catch (e) {
    n = JSON.stringify(pn(o)).replace(/"/g, "'");
  }
  return vn(String(n));
}
var Ut = `	
`;
function on(o, n, e) {
  var i = Is(e);
  if (o !== 0 && o !== !1 && !o) return Ut + i + "<".concat(n, " />");
  var t = "";
  if (n === "#text") return Ut + i + vn(String(o));
  if (n === "#cdata-section") return Ut + i + "<![CDATA[" + o + "]]>";
  if (n === "#comment") return Ut + i + "<!--" + o + "-->";
  if ("".concat(n).charAt(0) === "-") return " " + n.substring(1) + '="' + ks(o) + '"';
  if (Array.isArray(o)) o.forEach(function(d) {
    t += on(d, n, e + 1);
  });
  else if (da(o) === "[object Object]") {
    var r = Object.keys(o), a = "", s = "";
    t += (e === 0 ? "" : Ut + i) + "<" + n, r.forEach(function(d) {
      d.charAt(0) === "-" ? a += on(o[d], d, e + 1) : s += on(o[d], d, e + 1);
    }), t += a + (s !== "" ? ">".concat(s).concat(Ut + i, "</").concat(n, ">") : " />");
  } else t += Ut + i + "<".concat(n, ">").concat(vn(String(o)), "</").concat(n, ">");
  return t;
}
function Bs(o) {
  var n = "";
  for (var e in o) n += on(o[e], e, 0);
  return n;
}
var st = function() {
};
st.ObjTree = function() {
  return this;
};
st.ObjTree.VERSION = "0.23";
st.ObjTree.prototype.xmlDecl = `<?xml version="1.0" encoding="UTF-8" ?>
`;
st.ObjTree.prototype.attr_prefix = "-";
st.ObjTree.prototype.parseXML = function(o) {
  var n;
  if (window.DOMParser) {
    var e = new DOMParser(), i = e.parseFromString(o, "application/xml");
    if (!i) return;
    n = i.documentElement;
  } else window.ActiveXObject && (e = new ActiveXObject("Microsoft.XMLDOM"), e.async = !1, e.loadXML(o), n = e.documentElement);
  if (n)
    return this.parseDOM(n);
};
st.ObjTree.prototype.parseHTTP = function(o, n, e) {
  var i = {};
  for (var t in n) i[t] = n[t];
  if (i.method || (typeof i.postBody == "undefined" && typeof i.postbody == "undefined" && typeof i.parameters == "undefined" ? i.method = "get" : i.method = "post"), e) {
    i.asynchronous = !0;
    var r = this, a = e, s = i.onComplete;
    i.onComplete = function(u) {
      var c;
      u && u.responseXML && u.responseXML.documentElement && (c = r.parseDOM(u.responseXML.documentElement)), a(c, u), s && s(u);
    };
  } else i.asynchronous = !1;
  var d;
  if (typeof HTTP != "undefined" && HTTP.Request) {
    i.uri = o;
    var l = new HTTP.Request(i);
    l && (d = l.transport);
  } else if (typeof Ajax != "undefined" && Ajax.Request) {
    var l = new Ajax.Request(o, i);
    l && (d = l.transport);
  }
  if (e) return d;
  if (d && d.responseXML && d.responseXML.documentElement) return this.parseDOM(d.responseXML.documentElement);
};
st.ObjTree.prototype.parseDOM = function(o) {
  if (o) {
    if (this.__force_array = {}, this.force_array) for (var n = 0; n < this.force_array.length; n++) this.__force_array[this.force_array[n]] = 1;
    var e = this.parseElement(o);
    if (this.__force_array[o.nodeName] && (e = [e]), o.nodeType != 11) {
      var i = {};
      i[o.nodeName] = e, e = i;
    }
    return e;
  }
};
st.ObjTree.prototype.parseElement = function(o) {
  if (o.nodeType != 7) {
    if (o.nodeType == 3 || o.nodeType == 4 || o.nodeType == 8)
      return o.nodeValue.match(/[^\x00-\x20]/) == null ? void 0 : o.nodeValue;
    var n = null, e = {};
    if (o.attributes && o.attributes.length) {
      n = {};
      for (var i = 0; i < o.attributes.length; i++) {
        var t = o.attributes[i].nodeName;
        if (typeof t == "string") {
          var r = o.attributes[i].nodeValue;
          try {
            r = JSON.parse(o.attributes[i].nodeValue.replace(/'/g, '"'));
          } catch (d) {
            r = o.attributes[i].nodeValue;
          }
          r && (t = this.attr_prefix + t, typeof e[t] == "undefined" && (e[t] = 0), e[t]++, this.addNode(n, t, e[t], r));
        }
      }
    }
    if (o.childNodes && o.childNodes.length) {
      var a = !0;
      n && (a = !1);
      for (var i = 0; i < o.childNodes.length && a; i++) {
        var s = o.childNodes[i].nodeType;
        s == 3 || s == 4 || s == 8 || (a = !1);
      }
      if (a) {
        n || (n = "");
        for (var i = 0; i < o.childNodes.length; i++) n += o.childNodes[i].nodeValue;
      } else {
        n || (n = {});
        for (var i = 0; i < o.childNodes.length; i++) {
          var t = o.childNodes[i].nodeName;
          if (typeof t == "string") {
            var r = this.parseElement(o.childNodes[i]);
            r && (typeof e[t] == "undefined" && (e[t] = 0), e[t]++, this.addNode(n, t, e[t], r));
          }
        }
      }
    } else n === null && (n = {});
    return n;
  }
};
st.ObjTree.prototype.addNode = function(o, n, e, i) {
  this.__force_array[n] ? (e == 1 && (o[n] = []), o[n][o[n].length] = i) : e == 1 ? o[n] = i : e == 2 ? o[n] = [o[n], i] : o[n][o[n].length] = i;
};
st.ObjTree.prototype.writeXML = function(o) {
  var n = this.hash_to_xml(null, o);
  return this.xmlDecl + n;
};
st.ObjTree.prototype.hash_to_xml = function(o, n) {
  var e = [], i = [];
  for (var t in n)
    if (n.hasOwnProperty(t)) {
      var r = n[t];
      t.charAt(0) != this.attr_prefix ? typeof r == "undefined" || r == null ? e[e.length] = "<" + t + " />" : typeof r == "object" && r.constructor == Array ? e[e.length] = this.array_to_xml(t, r) : typeof r == "object" ? e[e.length] = this.hash_to_xml(t, r) : e[e.length] = this.scalar_to_xml(t, r) : i[i.length] = " " + t.substring(1) + '="' + this.xml_escape(r) + '"';
    }
  var a = i.join(""), s = e.join("");
  return typeof o == "undefined" || o == null || (e.length > 0 ? s.match(/\n/) ? s = "<" + o + a + `>
` + s + "</" + o + `>
` : s = "<" + o + a + ">" + s + "</" + o + `>
` : s = "<" + o + a + ` />
`), s;
};
st.ObjTree.prototype.array_to_xml = function(o, n) {
  for (var e = [], i = 0; i < n.length; i++) {
    var t = n[i];
    typeof t == "undefined" || t == null ? e[e.length] = "<" + o + " />" : typeof t == "object" && t.constructor == Array ? e[e.length] = this.array_to_xml(o, t) : typeof t == "object" ? e[e.length] = this.hash_to_xml(o, t) : e[e.length] = this.scalar_to_xml(o, t);
  }
  return e.join("");
};
st.ObjTree.prototype.scalar_to_xml = function(o, n) {
  return o == "#text" ? this.xml_escape(n) : "<" + o + ">" + this.xml_escape(n) + "</" + o + `>
`;
};
st.ObjTree.prototype.xml_escape = vn;
var Hs = function(o) {
  return new st.ObjTree().parseXML(o);
}, Fs = /* @__PURE__ */ (function() {
  var o = function(n, e) {
    return o = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(i, t) {
      i.__proto__ = t;
    } || function(i, t) {
      for (var r in t) Object.prototype.hasOwnProperty.call(t, r) && (i[r] = t[r]);
    }, o(n, e);
  };
  return function(n, e) {
    if (typeof e != "function" && e !== null) throw new TypeError("Class extends value " + String(e) + " is not a constructor or null");
    o(n, e);
    function i() {
      this.constructor = n;
    }
    n.prototype = e === null ? Object.create(e) : (i.prototype = e.prototype, new i());
  };
})(), cr = function() {
  return cr = Object.assign || function(o) {
    for (var n, e = 1, i = arguments.length; e < i; e++) {
      n = arguments[e];
      for (var t in n) Object.prototype.hasOwnProperty.call(n, t) && (o[t] = n[t]);
    }
    return o;
  }, cr.apply(this, arguments);
}, Ln = function(o, n) {
  var e = typeof Symbol == "function" && o[Symbol.iterator];
  if (!e) return o;
  var i = e.call(o), t, r = [], a;
  try {
    for (; (n === void 0 || n-- > 0) && !(t = i.next()).done; ) r.push(t.value);
  } catch (s) {
    a = { error: s };
  } finally {
    try {
      t && !t.done && (e = i.return) && e.call(i);
    } finally {
      if (a) throw a.error;
    }
  }
  return r;
}, Rt;
(function(o) {
  o.START = "bpmn:startEvent", o.END = "bpmn:endEvent", o.GATEWAY = "bpmn:exclusiveGateway", o.USER = "bpmn:userTask", o.SYSTEM = "bpmn:serviceTask", o.FLOW = "bpmn:sequenceFlow";
})(Rt || (Rt = {}));
var ua = [
  "-name",
  "-id",
  "bpmn:incoming",
  "bpmn:outgoing",
  "-sourceRef",
  "-targetRef"
], Wr = [
  "properties",
  "startPoint",
  "endPoint",
  "pointsList"
], ca = function(o) {
  return String(o || "").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&amp;/g, "&").replace(/&quot;/g, '"').replace(/&apos;/g, "'");
};
function $r(o) {
  var n = o ? Wr.concat(o) : Wr;
  return function(e) {
    function i(t) {
      var r = {};
      return typeof t == "string" ? t : Array.isArray(t) ? t.map(function(a) {
        return i(a);
      }) : (Object.entries(t).forEach(function(a) {
        var s = Ln(a, 2), d = s[0], l = s[1];
        typeof l != "object" ? d.indexOf("-") === 0 || [
          "#text",
          "#cdata-section",
          "#comment"
        ].includes(d) ? r[d] = l : r["-".concat(d)] = l : n.includes(d) ? r["-".concat(d)] = i(l) : r[d] = i(l);
      }), r);
    }
    return i(e);
  };
}
function gn(o) {
  var n = {};
  return Object.entries(o).forEach(function(e) {
    var i = Ln(e, 2), t = i[0], r = i[1];
    t.indexOf("-") === 0 ? n[t.substring(1)] = pn(r) : typeof r == "string" ? n[t] = r : Object.prototype.toString.call(r) === "[object Object]" ? n[t] = gn(r) : Array.isArray(r) ? n[t] = r.map(function(a) {
      return gn(a);
    }) : n[t] = r;
  }), n;
}
function Gs(o, n, e) {
  var i = /* @__PURE__ */ new Map();
  n.nodes.forEach(function(r) {
    var a, s = { "-id": r.id };
    if (!((a = r.text) === null || a === void 0) && a.value && (s["-name"] = r.text.value), r.properties) {
      var d = $r(e)(r.properties);
      Object.assign(s, d);
    }
    i.set(r.id, s), o[r.type] ? Array.isArray(o[r.type]) ? o[r.type].push(s) : o[r.type] = [o[r.type], s] : o[r.type] = s;
  });
  var t = n.edges.map(function(r) {
    var a, s, d = i.get(r.targetNodeId);
    d["bpmn:incoming"] ? Array.isArray(d["bpmn:incoming"]) ? d["bpmn:incoming"].push(r.id) : d["bpmn:incoming"] = [d["bpmn:incoming"], r.id] : d["bpmn:incoming"] = r.id;
    var l = {
      "-id": r.id,
      "-sourceRef": r.sourceNodeId,
      "-targetRef": r.targetNodeId
    };
    if (!((a = r.text) === null || a === void 0) && a.value && (l["-name"] = (s = r.text) === null || s === void 0 ? void 0 : s.value), r.properties) {
      var u = $r(e)(r.properties);
      Object.assign(l, u);
    }
    return l;
  });
  n.edges.forEach(function(r) {
    var a = i.get(r.sourceNodeId);
    a["bpmn:outgoing"] ? Array.isArray(a["bpmn:outgoing"]) ? a["bpmn:outgoing"].push(r.id) : a["bpmn:outgoing"] = [a["bpmn:outgoing"], r.id] : a["bpmn:outgoing"] = r.id;
  }), o[Rt.FLOW] = t;
}
function zs(o, n) {
  o["bpmndi:BPMNEdge"] = n.edges.map(function(e) {
    var i, t = e.id, r = e.pointsList.map(function(s) {
      return {
        "-x": s.x,
        "-y": s.y
      };
    }), a = {
      "-id": "".concat(t, "_di"),
      "-bpmnElement": t,
      "di:waypoint": r
    };
    return !((i = e.text) === null || i === void 0) && i.value && (a["bpmndi:BPMNLabel"] = { "dc:Bounds": {
      "-x": e.text.x - e.text.value.length * 10 / 2,
      "-y": e.text.y - 7,
      "-width": e.text.value.length * 10,
      "-height": 14
    } }), a;
  }), o["bpmndi:BPMNShape"] = n.nodes.map(function(e) {
    var i, t = e.id, r = 100, a = 80, s = e.x, d = e.y, l = Wt.shapeConfigMap.get(e.type);
    l && (r = l.width, a = l.height), s -= r / 2, d -= a / 2;
    var u = {
      "-id": "".concat(t, "_di"),
      "-bpmnElement": t,
      "dc:Bounds": {
        "-x": s,
        "-y": d,
        "-width": r,
        "-height": a
      }
    };
    return !((i = e.text) === null || i === void 0) && i.value && (u["bpmndi:BPMNLabel"] = { "dc:Bounds": {
      "-x": e.text.x - e.text.value.length * 10 / 2,
      "-y": e.text.y - 7,
      "-width": e.text.value.length * 10,
      "-height": 14
    } }), u;
  });
}
function js(o) {
  var n = [], e = [], i = o["bpmn:definitions"];
  if (i) {
    var t = i["bpmn:process"], r = i["bpmndi:BPMNDiagram"], a = r == null ? void 0 : r["bpmndi:BPMNPlane"];
    if (!t || !a) return {
      nodes: n,
      edges: e
    };
    Object.keys(t).forEach(function(s) {
      if (s.indexOf("bpmn:") === 0) {
        var d = t[s];
        if (s === Rt.FLOW) {
          var l = a["bpmndi:BPMNEdge"];
          e = $s(d, (Array.isArray(l), l));
        } else {
          var u = a["bpmndi:BPMNShape"], c = (Array.isArray(u), u);
          n = n.concat(Ws(d, c, s));
        }
      }
    });
  }
  return {
    nodes: n,
    edges: e
  };
}
function Ws(o, n, e) {
  var i = [];
  if (Array.isArray(o)) o.forEach(function(a) {
    var s;
    Array.isArray(n) ? s = n.find(function(l) {
      return l["-bpmnElement"] === a["-id"];
    }) : s = n;
    var d = Xr(s, e, a);
    i.push(d);
  });
  else {
    var t = void 0;
    Array.isArray(n) ? t = n.find(function(a) {
      return a["-bpmnElement"] === o["-id"];
    }) : t = n;
    var r = Xr(t, e, o);
    i.push(r);
  }
  return i;
}
function Xr(o, n, e) {
  var i = Number(o["dc:Bounds"]["-x"]), t = Number(o["dc:Bounds"]["-y"]), r = ca(e["-name"]), a = Wt.shapeConfigMap.get(n);
  a && (i += a.width / 2, t += a.height / 2);
  var s;
  Object.entries(e).forEach(function(c) {
    var h = Ln(c, 2), f = h[0], p = h[1];
    ua.indexOf(f) === -1 && (s || (s = {}), s[f] = p);
  }), s && (s = gn(s));
  var d;
  if (r && (d = {
    x: i,
    y: t,
    value: r
  }, o["bpmndi:BPMNLabel"] && o["bpmndi:BPMNLabel"]["dc:Bounds"])) {
    var l = o["bpmndi:BPMNLabel"]["dc:Bounds"];
    d.x = Number(l["-x"]) + Number(l["-width"]) / 2, d.y = Number(l["-y"]) + Number(l["-height"]) / 2;
  }
  var u = {
    id: o["-bpmnElement"],
    type: n,
    x: i,
    y: t,
    properties: s
  };
  return d && (u.text = d), u;
}
function $s(o, n) {
  var e = [];
  if (Array.isArray(o)) o.forEach(function(t) {
    var r;
    Array.isArray(n) ? r = n.find(function(a) {
      return a["-bpmnElement"] === t["-id"];
    }) : r = n, e.push(Yr(r, t));
  });
  else {
    var i = void 0;
    Array.isArray(n) ? i = n.find(function(t) {
      return t["-bpmnElement"] === o["-id"];
    }) : i = n, e.push(Yr(i, o));
  }
  return e;
}
function Yr(o, n) {
  var e, i = n["-name"] ? ca("".concat(n["-name"])) : "";
  if (i) {
    var t = void 0;
    o["bpmndi:BPMNLabel"] && o["bpmndi:BPMNLabel"]["dc:Bounds"] && (t = o["bpmndi:BPMNLabel"]["dc:Bounds"]);
    var r = 0;
    if (i.split(`
`).forEach(function(c) {
      r < c.length && (r = c.length);
    }), t) e = {
      value: i,
      x: Number(t["-x"]) + r * 10 / 2,
      y: Number(t["-y"]) + 7
    };
    else {
      var a = o["di:waypoint"] || [], s = a[0], d = a[a.length - 1] || s;
      e = {
        value: i,
        x: (Number((s == null ? void 0 : s["-x"]) || 0) + Number((d == null ? void 0 : d["-x"]) || 0)) / 2,
        y: (Number((s == null ? void 0 : s["-y"]) || 0) + Number((d == null ? void 0 : d["-y"]) || 0)) / 2
      };
    }
  }
  var l;
  Object.entries(n).forEach(function(c) {
    var h = Ln(c, 2), f = h[0], p = h[1];
    ua.indexOf(f) === -1 && (l || (l = {}), l[f] = p);
  }), l && (l = gn(l));
  var u = {
    id: n["-id"],
    type: Rt.FLOW,
    pointsList: o["di:waypoint"].map(function(c) {
      return {
        x: Number(c["-x"]),
        y: Number(c["-y"])
      };
    }),
    sourceNodeId: n["-sourceRef"],
    targetNodeId: n["-targetRef"],
    properties: l
  };
  return e && (u.text = e), u;
}
var Wt = (function() {
  function o(n) {
    var e = n.lf, i = this;
    this.adapterOut = function(t, r) {
      var a = cr({}, i.processAttributes);
      Gs(a, t, r);
      var s = {
        "-id": "BPMNPlane_1",
        "-bpmnElement": a["-id"]
      };
      zs(s, t);
      var d = i.definitionAttributes;
      return d["bpmn:process"] = a, d["bpmndi:BPMNDiagram"] = {
        "-id": "BPMNDiagram_1",
        "bpmndi:BPMNPlane": s
      }, { "bpmn:definitions": d };
    }, this.adapterIn = function(t) {
      if (t) return js(t);
    }, e.adapterIn = function(t) {
      return i.adapterIn(t);
    }, e.adapterOut = function(t, r) {
      return i.adapterOut(t, r);
    }, this.processAttributes = {
      "-isExecutable": "true",
      "-id": "Process_".concat(jr())
    }, this.definitionAttributes = {
      "-id": "Definitions_".concat(jr()),
      "-xmlns:xsi": "http://www.w3.org/2001/XMLSchema-instance",
      "-xmlns:bpmn": "http://www.omg.org/spec/BPMN/20100524/MODEL",
      "-xmlns:bpmndi": "http://www.omg.org/spec/BPMN/20100524/DI",
      "-xmlns:dc": "http://www.omg.org/spec/DD/20100524/DC",
      "-xmlns:di": "http://www.omg.org/spec/DD/20100524/DI",
      "-targetNamespace": "http://logic-flow.org",
      "-exporter": "logicflow",
      "-exporterVersion": "1.2.0"
    };
  }
  return o.prototype.setCustomShape = function(n, e) {
    o.shapeConfigMap.set(n, e);
  }, o.pluginName = "bpmn-adapter", o.shapeConfigMap = /* @__PURE__ */ new Map(), o;
})();
Wt.shapeConfigMap.set(Rt.START, {
  width: Br.width,
  height: Br.height
});
Wt.shapeConfigMap.set(Rt.END, {
  width: Hr.width,
  height: Hr.height
});
Wt.shapeConfigMap.set(Rt.GATEWAY, {
  width: Fr.width,
  height: Fr.height
});
Wt.shapeConfigMap.set(Rt.SYSTEM, {
  width: Gr.width,
  height: Gr.height
});
Wt.shapeConfigMap.set(Rt.USER, {
  width: zr.width,
  height: zr.height
});
var Ju = (function(o) {
  Fs(n, o);
  function n(e) {
    var i = o.call(this, e) || this;
    i.adapterXmlIn = function(r) {
      var a = typeof r == "string" ? i.sanitizeNameAttributes(r) : r, s = Hs(a);
      return i.adapterIn(s);
    }, i.adapterXmlOut = function(r, a) {
      var s = i.adapterOut(r, a);
      return Bs(s);
    };
    var t = e.lf;
    return t.adapterIn = i.adapterXmlIn, t.adapterOut = i.adapterXmlOut, i;
  }
  return n.prototype.sanitizeNameAttributes = function(e) {
    return e.replace(/name="([^"]*)"/g, function(i, t) {
      var r = t.replace(/&(?!#?\w+;)/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
      return 'name="'.concat(r, '"');
    });
  }, n.pluginName = "bpmnXmlAdapter", n;
})(Wt);
function Ci() {
  this.targetRules.push({
    message: "分组外的节点不允许连接分组内的",
    validate: function(o, n) {
      var e = !!o.properties.parent, i = !!n.properties.parent;
      return !(!e && i);
    }
  });
}
var Xs = (function() {
  function o() {
    globalThis._ids = this, this._ids = /* @__PURE__ */ new Set();
  }
  return o.prototype.generateId = function() {
    return "xxxxxxx".replace(/[x]/g, function(n) {
      var e = Math.random() * 16 | 0;
      return (n === "x" ? e : e & 3 | 8).toString(16);
    });
  }, o.prototype.next = function() {
    for (var n = this.generateId(); this._ids.has(n); ) n = this.generateId();
    return this._ids.add(n), n;
  }, o;
})(), Ys = (globalThis == null ? void 0 : globalThis._ids) || new Xs();
function xt() {
  return Ys.next();
}
var Ur = /* @__PURE__ */ (function() {
  var o = function(n, e) {
    return o = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(i, t) {
      i.__proto__ = t;
    } || function(i, t) {
      for (var r in t) Object.prototype.hasOwnProperty.call(t, r) && (i[r] = t[r]);
    }, o(n, e);
  };
  return function(n, e) {
    if (typeof e != "function" && e !== null) throw new TypeError("Class extends value " + String(e) + " is not a constructor or null");
    o(n, e);
    function i() {
      this.constructor = n;
    }
    n.prototype = e === null ? Object.create(e) : (i.prototype = e.prototype, new i());
  };
})(), mi = function() {
  return mi = Object.assign || function(o) {
    for (var n, e = 1, i = arguments.length; e < i; e++) {
      n = arguments[e];
      for (var t in n) Object.prototype.hasOwnProperty.call(n, t) && (o[t] = n[t]);
    }
    return o;
  }, mi.apply(this, arguments);
}, Vr = function(o, n) {
  var e = typeof Symbol == "function" && o[Symbol.iterator];
  if (!e) return o;
  var i = e.call(o), t, r = [], a;
  try {
    for (; (n === void 0 || n-- > 0) && !(t = i.next()).done; ) r.push(t.value);
  } catch (s) {
    a = { error: s };
  } finally {
    try {
      t && !t.done && (e = i.return) && e.call(i);
    } finally {
      if (a) throw a.error;
    }
  }
  return r;
}, Us = function(o, n, e) {
  if (e || arguments.length === 2)
    for (var i = 0, t = n.length, r; i < t; i++) (r || !(i in n)) && (r || (r = Array.prototype.slice.call(n, 0, i)), r[i] = n[i]);
  return o.concat(r || Array.prototype.slice.call(n));
};
function Vs(o) {
  var n = Vr(o.useDefinition(), 1)[0];
  return {
    type: "bpmn:endEvent",
    view: (function(e) {
      Ur(i, e);
      function i() {
        return e !== null && e.apply(this, arguments) || this;
      }
      return i.prototype.getAnchorStyle = function() {
        return { visibility: "hidden" };
      }, i.prototype.getShape = function() {
        var t, r = this.props.model, a = r.getNodeStyle(), s = r, d = s.x, l = s.y, u = s.r, c = s.width, h = s.height, f = s.properties, p = e.prototype.getShape.call(this), v = f.definitionType, g = (((t = n.endEvent) === null || t === void 0 ? void 0 : t.get(v)) || {}).icon, b = Array.isArray(g) ? I.apply(void 0, Us(["g", { transform: "matrix(1 0 0 1 ".concat(d - c / 2, " ").concat(l - h / 2, ")") }], Vr(g), !1)) : I("path", {
          transform: "matrix(1 0 0 1 ".concat(d - c / 2, " ").concat(l - h / 2, ")"),
          d: g,
          style: "fill: black; stroke-linecap: round; stroke-linejoin: round; stroke: white; stroke-width: 1px;"
        });
        return I("g", {}, p, I("circle", mi(mi({}, a), {
          strokeWidth: 2,
          cx: d,
          cy: l,
          r: u - 2
        })), b);
      }, i;
    })(ii),
    model: (function(e) {
      Ur(i, e);
      function i(t, r) {
        var a = this, s, d, l;
        t.id || (t.id = "Event_".concat(xt())), t.text || (t.text = ""), t.text && typeof t.text == "string" && (t.text = {
          value: t.text,
          x: t.x,
          y: t.y + 40
        });
        var u = (((s = n.endEvent) === null || s === void 0 ? void 0 : s.get((d = t.properties) === null || d === void 0 ? void 0 : d.definitionType)) || {}).properties;
        return t.properties = mi(mi({}, u === void 0 ? {} : u), t.properties), (l = t.properties) !== null && l !== void 0 && l.definitionType && (t.properties.definitionId = "Definition_".concat(xt())), a = e.call(this, t, r) || this, Ci.call(a), a;
      }
      return i.prototype.setAttributes = function() {
        this.r = 18;
      }, i.prototype.getConnectedSourceRules = function() {
        var t = this, r = e.prototype.getConnectedSourceRules.call(this);
        return r.push({
          message: "结束节点不能作为边的起点",
          validate: function(a, s) {
            return a !== t;
          }
        }), r;
      }, i;
    })(ni)
  };
}
var Kr = /* @__PURE__ */ (function() {
  var o = function(n, e) {
    return o = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(i, t) {
      i.__proto__ = t;
    } || function(i, t) {
      for (var r in t) Object.prototype.hasOwnProperty.call(t, r) && (i[r] = t[r]);
    }, o(n, e);
  };
  return function(n, e) {
    if (typeof e != "function" && e !== null) throw new TypeError("Class extends value " + String(e) + " is not a constructor or null");
    o(n, e);
    function i() {
      this.constructor = n;
    }
    n.prototype = e === null ? Object.create(e) : (i.prototype = e.prototype, new i());
  };
})(), Bt = function() {
  return Bt = Object.assign || function(o) {
    for (var n, e = 1, i = arguments.length; e < i; e++) {
      n = arguments[e];
      for (var t in n) Object.prototype.hasOwnProperty.call(n, t) && (o[t] = n[t]);
    }
    return o;
  }, Bt.apply(this, arguments);
}, qr = function(o, n) {
  var e = typeof Symbol == "function" && o[Symbol.iterator];
  if (!e) return o;
  var i = e.call(o), t, r = [], a;
  try {
    for (; (n === void 0 || n-- > 0) && !(t = i.next()).done; ) r.push(t.value);
  } catch (s) {
    a = { error: s };
  } finally {
    try {
      t && !t.done && (e = i.return) && e.call(i);
    } finally {
      if (a) throw a.error;
    }
  }
  return r;
}, Ks = function(o, n, e) {
  if (e || arguments.length === 2)
    for (var i = 0, t = n.length, r; i < t; i++) (r || !(i in n)) && (r || (r = Array.prototype.slice.call(n, 0, i)), r[i] = n[i]);
  return o.concat(r || Array.prototype.slice.call(n));
};
function qs(o) {
  var n = qr(o.useDefinition(), 1)[0];
  return {
    type: "bpmn:intermediateCatchEvent",
    view: (function(e) {
      Kr(i, e);
      function i() {
        return e !== null && e.apply(this, arguments) || this;
      }
      return i.prototype.getAnchorStyle = function() {
        return { visibility: "hidden" };
      }, i.prototype.getShape = function() {
        var t, r = this.props.model, a = r.getNodeStyle(), s = r, d = s.x, l = s.y, u = s.r, c = s.width, h = s.height, f = s.properties.definitionType, p = (((t = n.intermediateCatchEvent) === null || t === void 0 ? void 0 : t.get(f)) || {}).icon, v = Array.isArray(p) ? I.apply(void 0, Ks(["g", { transform: "matrix(1 0 0 1 ".concat(d - c / 2, " ").concat(l - h / 2, ")") }], qr(p), !1)) : I("path", {
          transform: "matrix(1 0 0 1 ".concat(d - c / 2, " ").concat(l - h / 2, ")"),
          d: p
        });
        return I("g", {}, I("circle", Bt(Bt({}, a), {
          cx: d,
          cy: l,
          r: u,
          strokeWidth: 1.5
        })), I("circle", Bt(Bt({}, a), {
          cx: d,
          cy: l,
          r: u - 3,
          strokeWidth: 1.5
        })), v);
      }, i;
    })(ii),
    model: (function(e) {
      Kr(i, e);
      function i(t, r) {
        var a = this, s, d, l;
        t.id || (t.id = "Event_".concat(xt())), t.text || (t.text = ""), t.text && typeof t.text == "string" && (t.text = {
          value: t.text,
          x: t.x,
          y: t.y + 40
        });
        var u = (((s = n.intermediateCatchEvent) === null || s === void 0 ? void 0 : s.get((d = t.properties) === null || d === void 0 ? void 0 : d.definitionType)) || {}).properties;
        return t.properties = Bt(Bt({}, u === void 0 ? {} : u), t.properties), (l = t.properties) !== null && l !== void 0 && l.definitionType && (t.properties.definitionId = "Definition_".concat(xt())), a = e.call(this, t, r) || this, Ci.call(a), a;
      }
      return i.prototype.setAttributes = function() {
        this.r = 18;
      }, i;
    })(ni)
  };
}
var Qr = /* @__PURE__ */ (function() {
  var o = function(n, e) {
    return o = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(i, t) {
      i.__proto__ = t;
    } || function(i, t) {
      for (var r in t) Object.prototype.hasOwnProperty.call(t, r) && (i[r] = t[r]);
    }, o(n, e);
  };
  return function(n, e) {
    if (typeof e != "function" && e !== null) throw new TypeError("Class extends value " + String(e) + " is not a constructor or null");
    o(n, e);
    function i() {
      this.constructor = n;
    }
    n.prototype = e === null ? Object.create(e) : (i.prototype = e.prototype, new i());
  };
})(), yi = function() {
  return yi = Object.assign || function(o) {
    for (var n, e = 1, i = arguments.length; e < i; e++) {
      n = arguments[e];
      for (var t in n) Object.prototype.hasOwnProperty.call(n, t) && (o[t] = n[t]);
    }
    return o;
  }, yi.apply(this, arguments);
}, Zr = function(o, n) {
  var e = typeof Symbol == "function" && o[Symbol.iterator];
  if (!e) return o;
  var i = e.call(o), t, r = [], a;
  try {
    for (; (n === void 0 || n-- > 0) && !(t = i.next()).done; ) r.push(t.value);
  } catch (s) {
    a = { error: s };
  } finally {
    try {
      t && !t.done && (e = i.return) && e.call(i);
    } finally {
      if (a) throw a.error;
    }
  }
  return r;
}, Qs = function(o, n, e) {
  if (e || arguments.length === 2)
    for (var i = 0, t = n.length, r; i < t; i++) (r || !(i in n)) && (r || (r = Array.prototype.slice.call(n, 0, i)), r[i] = n[i]);
  return o.concat(r || Array.prototype.slice.call(n));
};
function Zs(o) {
  var n = Zr(o.useDefinition(), 1)[0];
  return {
    type: "bpmn:startEvent",
    view: (function(e) {
      Qr(i, e);
      function i() {
        return e !== null && e.apply(this, arguments) || this;
      }
      return i.prototype.getAnchorStyle = function() {
        return { visibility: "hidden" };
      }, i.prototype.getShape = function() {
        var t, r = this.props.model, a = r.getNodeStyle(), s = r, d = s.x, l = s.y, u = s.r, c = s.width, h = s.height, f = s.properties, p = f.definitionType, v = f.isInterrupting, g = (((t = n.startEvent) === null || t === void 0 ? void 0 : t.get(p)) || {}).icon, b = Array.isArray(g) ? I.apply(void 0, Qs(["g", { transform: "matrix(1 0 0 1 ".concat(d - c / 2, " ").concat(l - h / 2, ")") }], Zr(g), !1)) : I("path", {
          transform: "matrix(1 0 0 1 ".concat(d - c / 2, " ").concat(l - h / 2, ")"),
          d: g,
          style: "fill: white; stroke-linecap: round; stroke-linejoin: round; stroke: rgb(34, 36, 42); stroke-width: 1px;"
        });
        return I("g", {}, I("circle", yi(yi({}, a), {
          cx: d,
          cy: l,
          r: u,
          strokeDasharray: v ? "5,5" : "",
          strokeWidth: 2
        })), b);
      }, i;
    })(ii),
    model: (function(e) {
      Qr(i, e);
      function i(t, r) {
        var a, s, d;
        t.id || (t.id = "Event_".concat(xt())), t.text || (t.text = ""), t.text && typeof t.text == "string" && (t.text = {
          value: t.text,
          x: t.x,
          y: t.y + 40
        });
        var l = (((a = n.startEvent) === null || a === void 0 ? void 0 : a.get((s = t.properties) === null || s === void 0 ? void 0 : s.definitionType)) || {}).properties;
        return t.properties = yi(yi({}, l === void 0 ? {} : l), t.properties), (d = t.properties) !== null && d !== void 0 && d.definitionType && (t.properties.definitionId = "Definition_".concat(xt())), e.call(this, t, r) || this;
      }
      return i.prototype.setAttributes = function() {
        this.r = 18;
      }, i.prototype.getConnectedTargetRules = function() {
        var t = this, r = e.prototype.getConnectedTargetRules.call(this);
        return r.push({
          message: "起始节点不能作为边的终点",
          validate: function(a, s) {
            return s !== t;
          }
        }), r;
      }, i;
    })(ni)
  };
}
var Jr = /* @__PURE__ */ (function() {
  var o = function(n, e) {
    return o = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(i, t) {
      i.__proto__ = t;
    } || function(i, t) {
      for (var r in t) Object.prototype.hasOwnProperty.call(t, r) && (i[r] = t[r]);
    }, o(n, e);
  };
  return function(n, e) {
    if (typeof e != "function" && e !== null) throw new TypeError("Class extends value " + String(e) + " is not a constructor or null");
    o(n, e);
    function i() {
      this.constructor = n;
    }
    n.prototype = e === null ? Object.create(e) : (i.prototype = e.prototype, new i());
  };
})(), Ht = function() {
  return Ht = Object.assign || function(o) {
    for (var n, e = 1, i = arguments.length; e < i; e++) {
      n = arguments[e];
      for (var t in n) Object.prototype.hasOwnProperty.call(n, t) && (o[t] = n[t]);
    }
    return o;
  }, Ht.apply(this, arguments);
}, eo = function(o, n) {
  var e = typeof Symbol == "function" && o[Symbol.iterator];
  if (!e) return o;
  var i = e.call(o), t, r = [], a;
  try {
    for (; (n === void 0 || n-- > 0) && !(t = i.next()).done; ) r.push(t.value);
  } catch (s) {
    a = { error: s };
  } finally {
    try {
      t && !t.done && (e = i.return) && e.call(i);
    } finally {
      if (a) throw a.error;
    }
  }
  return r;
}, Js = function(o, n, e) {
  if (e || arguments.length === 2)
    for (var i = 0, t = n.length, r; i < t; i++) (r || !(i in n)) && (r || (r = Array.prototype.slice.call(n, 0, i)), r[i] = n[i]);
  return o.concat(r || Array.prototype.slice.call(n));
};
function el(o) {
  var n = eo(o.useDefinition(), 1)[0];
  return {
    type: "bpmn:boundaryEvent",
    view: (function(e) {
      Jr(i, e);
      function i() {
        return e !== null && e.apply(this, arguments) || this;
      }
      return i.prototype.getAnchorStyle = function() {
        return { visibility: "hidden" };
      }, i.prototype.getShape = function() {
        var t, r = this.props.model, a = r.getNodeStyle(), s = r, d = s.x, l = s.y, u = s.r, c = s.width, h = s.height, f = s.properties, p = f.definitionType, v = f.cancelActivity, g = (((t = n.boundaryEvent) === null || t === void 0 ? void 0 : t.get(p)) || {}).icon, b = Array.isArray(g) ? I.apply(void 0, Js(["g", { transform: "matrix(1 0 0 1 ".concat(d - c / 2, " ").concat(l - h / 2, ")") }], eo(g), !1)) : I("path", {
          transform: "matrix(1 0 0 1 ".concat(d - c / 2, " ").concat(l - h / 2, ")"),
          d: g
        });
        return I("g", {}, I("circle", Ht(Ht({}, a), {
          cx: d,
          cy: l,
          r: u,
          strokeDasharray: v ? "" : "5,5",
          strokeWidth: 1.5
        })), I("circle", Ht(Ht({}, a), {
          cx: d,
          cy: l,
          r: u - 3,
          strokeDasharray: v ? "" : "5,5",
          strokeWidth: 1.5
        })), b);
      }, i;
    })(ii),
    model: (function(e) {
      Jr(i, e);
      function i(t, r) {
        var a = this, s, d, l;
        t.id || (t.id = "Event_".concat(xt())), t.text || (t.text = ""), t.text && typeof t.text == "string" && (t.text = {
          value: t.text,
          x: t.x,
          y: t.y + 40
        });
        var u = (((s = n.boundaryEvent) === null || s === void 0 ? void 0 : s.get((d = t.properties) === null || d === void 0 ? void 0 : d.definitionType)) || {}).properties;
        return t.properties = Ht(Ht({
          attachedToRef: "",
          cancelActivity: !0
        }, u === void 0 ? {} : u), t.properties), (l = t.properties) !== null && l !== void 0 && l.definitionType && (t.properties.definitionId = "Definition_".concat(xt())), a = e.call(this, t, r) || this, Ci.call(a), a;
      }
      return i.prototype.initNodeData = function(t) {
        e.prototype.initNodeData.call(this, t), this.r = 20, this.autoToFront = !1, this.zIndex = 99999;
      }, i.prototype.setAttributes = function() {
        this.r = 18;
      }, i;
    })(ni)
  };
}
var to = /* @__PURE__ */ (function() {
  var o = function(n, e) {
    return o = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(i, t) {
      i.__proto__ = t;
    } || function(i, t) {
      for (var r in t) Object.prototype.hasOwnProperty.call(t, r) && (i[r] = t[r]);
    }, o(n, e);
  };
  return function(n, e) {
    if (typeof e != "function" && e !== null) throw new TypeError("Class extends value " + String(e) + " is not a constructor or null");
    o(n, e);
    function i() {
      this.constructor = n;
    }
    n.prototype = e === null ? Object.create(e) : (i.prototype = e.prototype, new i());
  };
})(), Ft = function() {
  return Ft = Object.assign || function(o) {
    for (var n, e = 1, i = arguments.length; e < i; e++) {
      n = arguments[e];
      for (var t in n) Object.prototype.hasOwnProperty.call(n, t) && (o[t] = n[t]);
    }
    return o;
  }, Ft.apply(this, arguments);
}, io = function(o, n) {
  var e = typeof Symbol == "function" && o[Symbol.iterator];
  if (!e) return o;
  var i = e.call(o), t, r = [], a;
  try {
    for (; (n === void 0 || n-- > 0) && !(t = i.next()).done; ) r.push(t.value);
  } catch (s) {
    a = { error: s };
  } finally {
    try {
      t && !t.done && (e = i.return) && e.call(i);
    } finally {
      if (a) throw a.error;
    }
  }
  return r;
}, tl = function(o, n, e) {
  if (e || arguments.length === 2)
    for (var i = 0, t = n.length, r; i < t; i++) (r || !(i in n)) && (r || (r = Array.prototype.slice.call(n, 0, i)), r[i] = n[i]);
  return o.concat(r || Array.prototype.slice.call(n));
};
function il(o) {
  var n = io(o.useDefinition(), 1)[0];
  return {
    type: "bpmn:intermediateThrowEvent",
    view: (function(e) {
      to(i, e);
      function i() {
        return e !== null && e.apply(this, arguments) || this;
      }
      return i.prototype.getAnchorStyle = function() {
        return { visibility: "hidden" };
      }, i.prototype.getShape = function() {
        var t, r = this.props.model, a = r.getNodeStyle(), s = r, d = s.x, l = s.y, u = s.r, c = s.width, h = s.height, f = s.properties.definitionType, p = (((t = n.intermediateThrowEvent) === null || t === void 0 ? void 0 : t.get(f)) || {}).icon, v = Array.isArray(p) ? I.apply(void 0, tl(["g", { transform: "matrix(1 0 0 1 ".concat(d - c / 2, " ").concat(l - h / 2, ")") }], io(p), !1)) : I("path", {
          transform: "matrix(1 0 0 1 ".concat(d - c / 2, " ").concat(l - h / 2, ")"),
          d: p,
          style: "fill: black"
        });
        return I("g", {}, I("circle", Ft(Ft({}, a), {
          cx: d,
          cy: l,
          r: u,
          strokeWidth: 1.5
        })), I("circle", Ft(Ft({}, a), {
          cx: d,
          cy: l,
          r: u - 3,
          strokeWidth: 1.5
        })), v);
      }, i;
    })(ii),
    model: (function(e) {
      to(i, e);
      function i(t, r) {
        var a = this, s, d, l;
        t.id || (t.id = "Event_".concat(xt())), t.text || (t.text = ""), t.text && typeof t.text == "string" && (t.text = {
          value: t.text,
          x: t.x,
          y: t.y + 40
        });
        var u = (((s = n.intermediateThrowEvent) === null || s === void 0 ? void 0 : s.get((d = t.properties) === null || d === void 0 ? void 0 : d.definitionType)) || {}).properties;
        return t.properties = Ft(Ft({}, u === void 0 ? {} : u), t.properties), (l = t.properties) !== null && l !== void 0 && l.definitionType && (t.properties.definitionId = "Definition_".concat(xt())), a = e.call(this, t, r) || this, Ci.call(a), a;
      }
      return i.prototype.setAttributes = function() {
        this.r = 18;
      }, i;
    })(ni)
  };
}
function nl(o) {
  o.register(Zs(o)), o.register(Vs(o)), o.register(qs(o)), o.register(il(o)), o.register(el(o));
}
var rl = [
  I("circle", {
    cx: 18,
    cy: 18,
    r: 11,
    style: "stroke-linecap: round;stroke-linejoin: round;stroke: rgb(34, 36, 42);stroke-width: 2px;fill: white"
  }),
  I("path", {
    d: "M 18,18 l 2.25,-7.5 m -2.25,7.5 l 5.25,1.5",
    style: "fill: none; stroke-linecap: round; stroke-linejoin: round; stroke: rgb(34, 36, 42); stroke-width: 2px;"
  }),
  I("path", {
    d: "M 18,18 m 0,7.5 l -0,2.25",
    transform: "rotate(0,18,18)",
    style: "fill: none; stroke-linecap: round; stroke-linejoin: round; stroke: rgb(34, 36, 42); stroke-width: 1px;"
  }),
  I("path", {
    d: "M 18,18 m 0,7.5 l -0,2.25",
    transform: "rotate(30,18,18)",
    style: "fill: none; stroke-linecap: round; stroke-linejoin: round; stroke: rgb(34, 36, 42); stroke-width: 1px;"
  }),
  I("path", {
    d: "M 18,18 m 0,7.5 l -0,2.25",
    transform: "rotate(60,18,18)",
    style: "fill: none; stroke-linecap: round; stroke-linejoin: round; stroke: rgb(34, 36, 42); stroke-width: 1px;"
  }),
  I("path", {
    d: "M 18,18 m 0,7.5 l -0,2.25",
    transform: "rotate(90,18,18)",
    style: "fill: none; stroke-linecap: round; stroke-linejoin: round; stroke: rgb(34, 36, 42); stroke-width: 1px;"
  }),
  I("path", {
    d: "M 18,18 m 0,7.5 l -0,2.25",
    transform: "rotate(120,18,18)",
    style: "fill: none; stroke-linecap: round; stroke-linejoin: round; stroke: rgb(34, 36, 42); stroke-width: 1px;"
  }),
  I("path", {
    d: "M 18,18 m 0,7.5 l -0,2.25",
    transform: "rotate(150,18,18)",
    style: "fill: none; stroke-linecap: round; stroke-linejoin: round; stroke: rgb(34, 36, 42); stroke-width: 1px;"
  }),
  I("path", {
    d: "M 18,18 m 0,7.5 l -0,2.25",
    transform: "rotate(180,18,18)",
    style: "fill: none; stroke-linecap: round; stroke-linejoin: round; stroke: rgb(34, 36, 42); stroke-width: 1px;"
  }),
  I("path", {
    d: "M 18,18 m 0,7.5 l -0,2.25",
    transform: "rotate(210,18,18)",
    style: "fill: none; stroke-linecap: round; stroke-linejoin: round; stroke: rgb(34, 36, 42); stroke-width: 1px;"
  }),
  I("path", {
    d: "M 18,18 m 0,7.5 l -0,2.25",
    transform: "rotate(240,18,18)",
    style: "fill: none; stroke-linecap: round; stroke-linejoin: round; stroke: rgb(34, 36, 42); stroke-width: 1px;"
  }),
  I("path", {
    d: "M 18,18 m 0,7.5 l -0,2.25",
    transform: "rotate(270,18,18)",
    style: "fill: none; stroke-linecap: round; stroke-linejoin: round; stroke: rgb(34, 36, 42); stroke-width: 1px;"
  }),
  I("path", {
    d: "M 18,18 m 0,7.5 l -0,2.25",
    transform: "rotate(300,18,18)",
    style: "fill: none; stroke-linecap: round; stroke-linejoin: round; stroke: rgb(34, 36, 42); stroke-width: 1px;"
  }),
  I("path", {
    d: "M 18,18 m 0,7.5 l -0,2.25",
    transform: "rotate(330,18,18)",
    style: "fill: none; stroke-linecap: round; stroke-linejoin: round; stroke: rgb(34, 36, 42); stroke-width: 1px;"
  })
], ec = [I("circle", {
  cx: 18,
  cy: 18,
  r: 10,
  style: "stroke-linecap: round; stroke-linejoin: round; stroke: rgb(34, 36, 42); stroke-width: 4px; fill: rgb(34, 36, 42);"
})], ol = "m 16,15 7.42857142857143,9.714285714285715 -7.42857142857143,9.714285714285715 3.428571428571429,0 5.714285714285715,-7.464228571428572 5.714285714285715,7.464228571428572 3.428571428571429,0 -7.42857142857143,-9.714285714285715 7.42857142857143,-9.714285714285715 -3.428571428571429,0 -5.714285714285715,7.464228571428572 -5.714285714285715,-7.464228571428572 -3.428571428571429,0 z", al = "m 23,10 0,12.5 -12.5,0 0,5 12.5,0 0,12.5 5,0 0,-12.5 12.5,0 0,-5 -12.5,0 0,-12.5 -5,0 z", sl = I("circle", {
  cx: 25,
  cy: 25,
  r: 13,
  style: "stroke-linecap: round; stroke-linejoin: round; stroke: rgb(34, 36, 42); stroke-width: 2.5px; fill: white;"
}), ll = "M882.527918 434.149934c-2.234901-5.303796-7.311523-8.853645-13.059434-9.138124l-61.390185-3.009544c-6.635117-20.973684-15.521508-41.175795-26.513864-60.282968l42.051745-47.743374c4.308119-4.889357 4.955872-12.004405 1.602498-17.59268-46.384423-77.30362-103.969956-101.422947-106.400309-102.410438-5.332449-2.170432-11.432377-1.090844-15.693424 2.77009L654.674467 240.664222c-17.004279-8.654101-35.092239-15.756869-53.995775-21.210068l-3.26537-66.490344c-0.280386-5.747911-3.833305-10.824533-9.134031-13.059434-1.683339-0.709151-30.193673-12.391215-76.866668-12.051477-46.672996-0.339738-75.18333 11.342326-76.866668 12.051477-5.300726 2.234901-8.853645 7.311523-9.134031 13.059434l-3.26537 66.490344c-18.903535 5.453199-36.991496 12.555967-53.995775 21.210068l-48.450479-43.922349c-4.261047-3.860934-10.360975-4.940522-15.693424-2.77009-2.430352 0.98749-60.015885 25.106818-106.400309 102.410438-3.353374 5.588275-2.705622 12.703323 1.602498 17.59268l42.051745 47.743374c-10.992355 19.107173-19.878746 39.309284-26.513864 60.282968l-61.390185 3.009544c-5.747911 0.284479-10.824533 3.834328-13.059434 9.138124-1.01512 2.415003-24.687262 60.190871-2.822278 147.651828 1.583055 6.324032 7.072069 10.893094 13.57518 11.308557 5.892197 0.37146 11.751648 0.523933 17.419741 0.667196 14.498202 0.372483 28.193109 0.723477 40.908712 4.63353 4.212952 1.294482 6.435573 8.270361 9.349949 18.763342 1.287319 4.640694 2.617617 9.43693 4.484128 14.010085 1.794879 4.393054 3.75758 8.570189 5.66093 12.607132 1.302669 2.765997 2.529613 5.380544 3.689019 8.018627 2.986007 6.803963 2.682086 9.773598 2.578732 10.349719-3.061732 3.672646-6.391571 7.238868-9.91379 11.015891-1.810229 1.943258-3.680832 3.949962-5.523807 5.980201l-22.560832 24.8909c-3.865028 4.261047-4.940522 10.365068-2.774183 15.693424 0.991584 2.426259 25.102724 60.011792 102.414531 106.400309 5.588275 3.353374 12.703323 2.701528 17.591657-1.603521l23.476691-20.682042c2.346441-2.061962 4.64888-4.336772 6.875594-6.534833 9.05319-8.93858 14.018272-12.95608 17.73185-11.576663 3.305279 1.222851 6.907317 3.166109 10.720156 5.228071 3.325745 1.794879 6.764054 3.650133 10.465352 5.288446 6.016017 2.662643 12.120039 4.688789 18.019399 6.65149 6.827499 2.266623 13.279445 4.409426 18.819624 7.275707 1.518586 0.782829 1.926886 0.994654 2.358721 7.830339 0.726547 11.496845 1.25048 23.276123 1.753947 34.672684 0.264013 5.900384 0.528026 11.803837 0.815575 17.700127 0.284479 5.743818 3.833305 10.82044 9.138124 13.05534 1.654686 0.698918 29.371958 12.063757 74.869175 12.063757 0.328481 0 3.65832 0 3.986801 0 45.497217 0 73.214489-11.364839 74.869175-12.063757 5.304819-2.234901 8.853645-7.311523 9.138124-13.05534 0.287549-5.89629 0.551562-11.799744 0.815575-17.700127 0.503467-11.396561 1.027399-23.175839 1.753947-34.672684 0.431835-6.835685 0.840134-7.04751 2.358721-7.830339 5.54018-2.866281 11.992125-5.009084 18.819624-7.275707 5.89936-1.962701 12.003382-3.988848 18.019399-6.65149 3.701299-1.638313 7.139607-3.493567 10.465352-5.288446 3.812839-2.061962 7.414877-4.00522 10.720156-5.228071 3.713578-1.379417 8.67866 2.638083 17.73185 11.576663 2.226714 2.198062 4.529153 4.472871 6.875594 6.534833l23.476691 20.682042c4.888334 4.305049 12.003382 4.956895 17.591657 1.603521 77.311807-46.388517 101.422947-103.97405 102.414531-106.400309 2.166339-5.328355 1.090844-11.432377-2.774183-15.693424l-22.560832-24.8909c-1.842974-2.030239-3.713578-4.036943-5.523807-5.980201-3.52222-3.777023-6.852058-7.343245-9.91379-11.015891-0.103354-0.576121-0.407276-3.545756 2.578732-10.349719 1.159406-2.638083 2.38635-5.252631 3.689019-8.018627 1.90335-4.036943 3.866051-8.214079 5.66093-12.607132 1.866511-4.573155 3.196809-9.369392 4.484128-14.010085 2.914376-10.492982 5.136997-17.46886 9.349949-18.763342 12.715603-3.910053 26.41051-4.261047 40.908712-4.63353 5.668093-0.143263 11.527544-0.295735 17.419741-0.667196 6.503111-0.415462 11.992125-4.984524 13.57518-11.308557C907.21518 494.340805 883.543038 436.564937 882.527918 434.149934zM643.49894 643.761929c-35.280528 35.280528-82.191954 54.711066-132.086317 54.711066s-96.806813-19.430538-132.086317-54.711066c-35.280528-35.279504-54.711066-82.191954-54.711066-132.086317 0-49.894364 19.430538-96.80272 54.711066-132.082224 35.283598-35.284621 82.191954-54.711066 132.086317-54.711066s96.80579 19.426445 132.086317 54.711066c35.279504 35.279504 54.711066 82.187861 54.711066 132.082224C698.210006 561.569976 678.782537 608.482425 643.49894 643.761929z", dl = "M655.807326 287.35973m-223.989415 0a218.879 218.879 0 1 0 447.978829 0 218.879 218.879 0 1 0-447.978829 0ZM1039.955839 895.482975c-0.490184-212.177424-172.287821-384.030443-384.148513-384.030443-211.862739 0-383.660376 171.85302-384.15056 384.030443L1039.955839 895.482975z", ul = "m44,60 m 3,2 l 0,10 m 3,-10 l 0,10 m 3,-10 l 0,10", cl = "m47,61 m 0,3 l 10,0 m -10,3 l 10,0 m -10,3 l 10,0", hl = "m 50,73 c 3.526979,0 6.386161,-2.829858 6.386161,-6.320661 0,-3.490806 -2.859182,-6.320661 -6.386161,-6.320661 -3.526978,0 -6.38616,2.829855 -6.38616,6.320661 0,1.745402 0.714797,3.325567 1.870463,4.469381 0.577834,0.571908 1.265885,1.034728 2.029916,1.35457 l -0.718163,-3.909793 m 0.718163,3.909793 -3.885211,0.802902", no = /* @__PURE__ */ (function() {
  var o = function(n, e) {
    return o = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(i, t) {
      i.__proto__ = t;
    } || function(i, t) {
      for (var r in t) Object.prototype.hasOwnProperty.call(t, r) && (i[r] = t[r]);
    }, o(n, e);
  };
  return function(n, e) {
    if (typeof e != "function" && e !== null) throw new TypeError("Class extends value " + String(e) + " is not a constructor or null");
    o(n, e);
    function i() {
      this.constructor = n;
    }
    n.prototype = e === null ? Object.create(e) : (i.prototype = e.prototype, new i());
  };
})(), Gt = function() {
  return Gt = Object.assign || function(o) {
    for (var n, e = 1, i = arguments.length; e < i; e++) {
      n = arguments[e];
      for (var t in n) Object.prototype.hasOwnProperty.call(n, t) && (o[t] = n[t]);
    }
    return o;
  }, Gt.apply(this, arguments);
};
function Wn(o, n, e) {
  return {
    type: o,
    view: (function(i) {
      no(t, i);
      function t() {
        return i !== null && i.apply(this, arguments) || this;
      }
      return t.prototype.getShape = function() {
        var r = this.props.model, a = r, s = a.x, d = a.y, l = a.width, u = a.height, c = a.points, h = r.getNodeStyle();
        return I("g", { transform: "matrix(1 0 0 1 ".concat(s - l / 2, " ").concat(d - u / 2, ")") }, I(Ko, Gt(Gt({}, h), {
          x: s,
          y: d,
          points: c
        })), typeof n == "string" ? I("path", Gt(Gt({ d: n }, h), {
          fill: "rgb(34, 36, 42)",
          strokeWidth: 1
        })) : n);
      }, t;
    })(Cr),
    model: (function(i) {
      no(t, i);
      function t(r, a) {
        var s = this;
        return r.id || (r.id = "Gateway_".concat(xt())), r.text || (r.text = ""), r.text && typeof r.text == "string" && (r.text = {
          value: r.text,
          x: r.x,
          y: r.y + 40
        }), r.properties = Gt(Gt({}, e || {}), r.properties), s = i.call(this, r, a) || this, s.points = [
          [25, 0],
          [50, 25],
          [25, 50],
          [0, 25]
        ], Ci.call(s), s;
      }
      return t;
    })(Er)
  };
}
function fl(o) {
  var n = Wn("bpmn:exclusiveGateway", ol), e = Wn("bpmn:parallelGateway", al), i = Wn("bpmn:inclusiveGateway", sl);
  o.register(n), o.register(i), o.register(e);
}
var ro = /* @__PURE__ */ (function() {
  var o = function(n, e) {
    return o = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(i, t) {
      i.__proto__ = t;
    } || function(i, t) {
      for (var r in t) Object.prototype.hasOwnProperty.call(t, r) && (i[r] = t[r]);
    }, o(n, e);
  };
  return function(n, e) {
    if (typeof e != "function" && e !== null) throw new TypeError("Class extends value " + String(e) + " is not a constructor or null");
    o(n, e);
    function i() {
      this.constructor = n;
    }
    n.prototype = e === null ? Object.create(e) : (i.prototype = e.prototype, new i());
  };
})(), bi = function() {
  return bi = Object.assign || function(o) {
    for (var n, e = 1, i = arguments.length; e < i; e++) {
      n = arguments[e];
      for (var t in n) Object.prototype.hasOwnProperty.call(n, t) && (o[t] = n[t]);
    }
    return o;
  }, bi.apply(this, arguments);
}, pl = function(o, n) {
  var e = typeof Symbol == "function" && o[Symbol.iterator];
  if (!e) return o;
  var i = e.call(o), t, r = [], a;
  try {
    for (; (n === void 0 || n-- > 0) && !(t = i.next()).done; ) r.push(t.value);
  } catch (s) {
    a = { error: s };
  } finally {
    try {
      t && !t.done && (e = i.return) && e.call(i);
    } finally {
      if (a) throw a.error;
    }
  }
  return r;
}, vl = function(o, n, e) {
  if (e || arguments.length === 2)
    for (var i = 0, t = n.length, r; i < t; i++) (r || !(i in n)) && (r || (r = Array.prototype.slice.call(n, 0, i)), r[i] = n[i]);
  return o.concat(r || Array.prototype.slice.call(n));
}, gl = {
  parallel: ul,
  sequential: cl,
  loop: hl
};
function oo(o, n, e) {
  return {
    type: o,
    view: (function(i) {
      ro(t, i);
      function t() {
        return i !== null && i.apply(this, arguments) || this;
      }
      return t.prototype.getLabelShape = function() {
        var r = this.props.model, a = r.x, s = r.y, d = r.width, l = r.height, u = r.getNodeStyle(), c = Array.isArray(n) ? I.apply(void 0, vl(["g", { transform: "matrix(1 0 0 1 ".concat(a - d / 2, " ").concat(s - l / 2, ")") }], pl(n), !1)) : I("path", {
          fill: u.stroke,
          d: n
        });
        return I("svg", {
          x: a - d / 2 + 5,
          y: s - l / 2 + 5,
          width: 25,
          height: 25,
          viewBox: "0 0 1274 1024"
        }, c);
      }, t.prototype.getShape = function() {
        var r = this.props.model, a = r.x, s = r.y, d = r.width, l = r.height, u = r.radius, c = r.properties, h = r.getNodeStyle();
        return I("g", {}, [
          I("rect", bi(bi({}, h), {
            x: a - d / 2,
            y: s - l / 2,
            rx: u,
            ry: u,
            width: d,
            height: l,
            opacity: 0.95
          })),
          this.getLabelShape(),
          I("g", { transform: "matrix(1 0 0 1 ".concat(a - d / 2, " ").concat(s - l / 2, ")") }, I("path", {
            fill: "white",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            stroke: "rgb(34, 36, 42)",
            strokeWidth: "2",
            d: gl[c.multiInstanceType] || ""
          }))
        ]);
      }, t;
    })(_i),
    model: (function(i) {
      ro(t, i);
      function t(r, a) {
        var s = this, d;
        r.id || (r.id = "Activity_".concat(xt()));
        var l = bi(bi({}, e || {}), r.properties);
        return r.properties = l, s = i.call(this, r, a) || this, (d = l == null ? void 0 : l.boundaryEvents) === null || d === void 0 || d.forEach(function(u) {
          s.addBoundaryEvent(u);
        }), s.deleteProperty("boundaryEvents"), Ci.call(s), s;
      }
      return t.prototype.initNodeData = function(r) {
        i.prototype.initNodeData.call(this, r), this.isTaskNode = !0, this.boundaryEvents = [];
      }, t.prototype.getNodeStyle = function() {
        var r = i.prototype.getNodeStyle.call(this);
        return this.properties.isBoundaryEventTouchingTask && (r.stroke = "#00acff", r.strokeWidth = 2), r;
      }, t.prototype.getOutlineStyle = function() {
        var r = i.prototype.getOutlineStyle.call(this);
        return r.stroke = "transparent", !r.hover && (r.hover = {}), r.hover.stroke = "transparent", r;
      }, t.prototype.setTouching = function(r) {
        this.setProperty("isBoundaryEventTouchingTask", r);
      }, t.prototype.addBoundaryEvent = function(r) {
        if (this.setTouching(!1), this.boundaryEvents.find(function(s) {
          return s === r;
        })) return !1;
        var a = this.graphModel.getNodeModelById(r);
        return a == null || a.setProperties({ attachedToRef: this.id }), this.boundaryEvents.push(r), !0;
      }, t.prototype.deleteBoundaryEvent = function(r) {
        this.boundaryEvents = this.boundaryEvents.filter(function(a) {
          return a !== r;
        });
      }, t;
    })(Vi)
  };
}
var ml = /* @__PURE__ */ (function() {
  var o = function(n, e) {
    return o = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(i, t) {
      i.__proto__ = t;
    } || function(i, t) {
      for (var r in t) Object.prototype.hasOwnProperty.call(t, r) && (i[r] = t[r]);
    }, o(n, e);
  };
  return function(n, e) {
    if (typeof e != "function" && e !== null) throw new TypeError("Class extends value " + String(e) + " is not a constructor or null");
    o(n, e);
    function i() {
      this.constructor = n;
    }
    n.prototype = e === null ? Object.create(e) : (i.prototype = e.prototype, new i());
  };
})(), ei = function() {
  return ei = Object.assign || function(o) {
    for (var n, e = 1, i = arguments.length; e < i; e++) {
      n = arguments[e];
      for (var t in n) Object.prototype.hasOwnProperty.call(n, t) && (o[t] = n[t]);
    }
    return o;
  }, ei.apply(this, arguments);
}, yl = function(o, n) {
  var e = typeof Symbol == "function" && o[Symbol.iterator];
  if (!e) return o;
  var i = e.call(o), t, r = [], a;
  try {
    for (; (n === void 0 || n-- > 0) && !(t = i.next()).done; ) r.push(t.value);
  } catch (s) {
    a = { error: s };
  } finally {
    try {
      t && !t.done && (e = i.return) && e.call(i);
    } finally {
      if (a) throw a.error;
    }
  }
  return r;
}, bl = qo, xl = (function(o) {
  ml(n, o);
  function n(e) {
    var i = o.call(this) || this;
    return i.updatePosition = function(t) {
      var r = t.deltaX, a = t.deltaY, s = i.nodeModel, d = s.x, l = s.y;
      i.nodeModel.x = d + r / 2, i.nodeModel.y = l + a / 2, i.nodeModel.moveText(r / 2, a / 2);
    }, i.getResize = function(t) {
      var r = t.index, a = t.deltaX, s = t.deltaY, d = t.width, l = t.height, u = t.PCTResizeInfo, c = t.pct, h = c === void 0 ? 1 : c, f = t.freezeWidth, p = f === void 0 ? !1 : f, v = t.freezeHeight, g = v === void 0 ? !1 : v, b = {
        width: d,
        height: l,
        deltaX: a,
        deltaY: s
      };
      if (u) {
        var _ = 4, D = 0, L = 0;
        switch (r) {
          case 0:
            L = (a * -1 - s) / _;
            break;
          case 1:
            L = (a - s) / _;
            break;
          case 2:
            L = (a + s) / _;
            break;
          case 3:
            L = (a * -1 + s) / _;
        }
        L !== 0 && (D = Math.round(L / u.ResizeBasis.basisHeight * 1e5) / 1e3), u.ResizePCT.widthPCT = Math.max(Math.min(u.ResizePCT.widthPCT + D, u.ScaleLimit.maxScaleLimit), u.ScaleLimit.minScaleLimit), u.ResizePCT.heightPCT = Math.max(Math.min(u.ResizePCT.heightPCT + D, u.ScaleLimit.maxScaleLimit), u.ScaleLimit.minScaleLimit);
        var W = Math.round(u.ResizePCT.widthPCT * u.ResizeBasis.basisWidth / 100), B = Math.round(u.ResizePCT.heightPCT * u.ResizeBasis.basisHeight / 100);
        switch (r) {
          case 0:
            a = d - W, s = l - B;
            break;
          case 1:
            a = W - d, s = l - B;
            break;
          case 2:
            a = W - d, s = B - l;
            break;
          case 3:
            a = d - W, s = B - l;
        }
        return b.width = W, b.height = B, b.deltaX = a / h, b.deltaY = s / h, b;
      }
      switch (r) {
        case 0:
          b.width = p ? d : d - a * h, b.height = g ? l : l - s * h;
          break;
        case 1:
          b.width = p ? d : d + a * h, b.height = g ? l : l - s * h;
          break;
        case 2:
          b.width = p ? d : d + a * h, b.height = g ? l : l + s * h;
          break;
        case 3:
          b.width = p ? d : d - a * h, b.height = g ? l : l + s * h;
      }
      return b;
    }, i.updateEdgePointByAnchors = function() {
      var t = i.nodeModel, r = t.id, a = t.anchors, s = i.getNodeEdges(r);
      s.sourceEdges.forEach(function(d) {
        var l = a.find(function(u) {
          return u.id === d.sourceAnchorId;
        });
        l && d.updateStartPoint({
          x: l.x,
          y: l.y
        });
      }), s.targetEdges.forEach(function(d) {
        var l = a.find(function(u) {
          return u.id === d.targetAnchorId;
        });
        l && d.updateEndPoint({
          x: l.x,
          y: l.y
        });
      });
    }, i.updateRect = function(t) {
      var r = t.deltaX, a = t.deltaY, s = i.nodeModel, d = s.x, l = s.y, u = s.width, c = s.height, h = s.radius, f = s.PCTResizeInfo, p = i.nodeModel, v = p.minWidth, g = p.minHeight, b = p.maxWidth, _ = p.maxHeight, D = i.index, L = v === b, W = g === _, B = i.getResize({
        index: D,
        deltaX: r,
        deltaY: a,
        width: u,
        height: c,
        PCTResizeInfo: f,
        pct: 1,
        freezeWidth: L,
        freezeHeight: W
      });
      if (B.width < v || B.width > b || B.height < g || B.height > _) {
        i.dragHandler.cancelDrag();
        return;
      }
      i.updatePosition({
        deltaX: L ? 0 : B.deltaX,
        deltaY: W ? 0 : B.deltaY
      }), i.nodeModel.width = B.width, i.nodeModel.height = B.height, i.nodeModel.setProperties({ nodeSize: {
        width: B.width,
        height: B.height
      } });
      var K = {
        x: d,
        y: l,
        width: u,
        height: c,
        radius: h
      }, Y = {
        x: i.nodeModel.x,
        y: i.nodeModel.y,
        width: i.nodeModel.width,
        height: i.nodeModel.height,
        radius: h
      };
      i.updateEdgePointByAnchors(), i.eventEmit({
        deltaX: r,
        deltaY: a,
        beforeNode: K,
        afterNode: Y
      });
    }, i.updateEllipse = function(t) {
      var r = t.deltaX, a = t.deltaY, s = i.nodeModel, d = s.rx, l = s.ry, u = s.x, c = s.y, h = s.PCTResizeInfo, f = i.index, p = i.nodeModel, v = p.minWidth, g = p.minHeight, b = p.maxWidth, _ = p.maxHeight, D = v === b, L = g === _, W = d, B = l, K = i.getResize({
        index: f,
        deltaX: r,
        deltaY: a,
        width: W,
        height: B,
        PCTResizeInfo: h,
        pct: 1 / 2,
        freezeWidth: D,
        freezeHeight: L
      });
      if (K.width < v / 2 || K.width > b / 2 || K.height < g / 2 || K.height > _ / 2) {
        i.dragHandler.cancelDrag();
        return;
      }
      i.updatePosition({
        deltaX: D ? 0 : K.deltaX,
        deltaY: L ? 0 : K.deltaY
      }), i.nodeModel.rx = K.width, i.nodeModel.ry = K.height, i.nodeModel.setProperties({ nodeSize: {
        rx: K.width,
        ry: K.height
      } });
      var Y = {
        x: u,
        y: c
      }, te = {
        rx: K.width,
        ry: K.height,
        x: i.nodeModel.x,
        y: i.nodeModel.y
      };
      i.updateEdgePointByAnchors(), i.eventEmit({
        deltaX: r,
        deltaY: a,
        beforeNode: ei(ei({}, Y), {
          rx: d,
          ry: l
        }),
        afterNode: te
      });
    }, i.updateDiamond = function(t) {
      var r = t.deltaX, a = t.deltaY, s = i.nodeModel, d = s.rx, l = s.ry, u = s.x, c = s.y, h = s.PCTResizeInfo, f = i.index, p = i.nodeModel, v = p.minWidth, g = p.minHeight, b = p.maxWidth, _ = p.maxHeight, D = v === b, L = g === _, W = d, B = l, K = i.getResize({
        index: f,
        deltaX: r,
        deltaY: a,
        width: W,
        height: B,
        PCTResizeInfo: h,
        pct: 1 / 2,
        freezeWidth: D,
        freezeHeight: L
      });
      if (K.width < v / 2 || K.width > b / 2 || K.height < g / 2 || K.height > _ / 2) {
        i.dragHandler.cancelDrag();
        return;
      }
      i.updatePosition({
        deltaX: D ? 0 : K.deltaX,
        deltaY: L ? 0 : K.deltaY
      }), i.nodeModel.rx = K.width, i.nodeModel.ry = K.height, i.nodeModel.setProperties({ nodeSize: {
        rx: K.width,
        ry: K.height
      } });
      var Y = {
        x: u,
        y: c,
        rx: d,
        ry: l
      }, te = {
        rx: K.width,
        ry: K.height,
        x: i.nodeModel.x,
        y: i.nodeModel.y
      };
      i.updateEdgePointByAnchors(), i.eventEmit({
        deltaX: r,
        deltaY: a,
        beforeNode: Y,
        afterNode: te
      });
    }, i.eventEmit = function(t) {
      var r = t.deltaX, a = t.deltaY, s = t.beforeNode, d = t.afterNode, l = i.nodeModel, u = l.id, c = l.modelType, h = l.type, f = ei({
        id: u,
        modelType: c,
        type: h
      }, s), p = ei({
        id: u,
        modelType: c,
        type: h
      }, d);
      i.graphModel.eventCenter.emit("node:resize", {
        preData: f,
        data: p,
        deltaX: r,
        deltaY: a,
        index: i.index,
        model: i.nodeModel
      });
    }, i.onDragging = function(t) {
      var r, a = t.deltaX, s = t.deltaY, d = i.graphModel.transformModel, l = i.nodeModel.modelType;
      r = yl(d.fixDeltaXY(a, s), 2), a = r[0], s = r[1], l === Qi.RECT_NODE || l === Qi.HTML_NODE ? i.updateRect({
        deltaX: a,
        deltaY: s
      }) : l === Qi.ELLIPSE_NODE ? i.updateEllipse({
        deltaX: a,
        deltaY: s
      }) : l === Qi.DIAMOND_NODE && i.updateDiamond({
        deltaX: a,
        deltaY: s
      });
    }, i.onDragEnd = function() {
      var t = i.graphModel.gridSize, r = t === void 0 ? 1 : t, a = r * Math.round(i.nodeModel.x / r), s = r * Math.round(i.nodeModel.y / r);
      i.nodeModel.moveTo(a, s), i.updateEdgePointByAnchors();
    }, i.index = e.index, i.nodeModel = e.model, i.graphModel = e.graphModel, i.dragHandler = new bl({
      onDragging: i.onDragging,
      onDragEnd: i.onDragEnd,
      step: 1
    }), i;
  }
  return n.prototype.getNodeEdges = function(e) {
    for (var i = this.graphModel.edges, t = [], r = [], a = 0; a < i.length; a++) {
      var s = i[a];
      s.sourceNodeId === e ? t.push(s) : i[a].targetNodeId === e && r.push(s);
    }
    return {
      sourceEdges: t,
      targetEdges: r
    };
  }, n.prototype.render = function() {
    var e = this.props, i = e.x, t = e.y, r = e.index, a = e.model.getControlPointStyle();
    return Fe("g", {
      className: "lf-resize-control-".concat(r),
      children: Fe(Vo, ei({
        className: "lf-node-control",
        x: i,
        y: t
      }, a, { onMouseDown: this.dragHandler.handleMouseDown }))
    });
  }, n;
})(Pn), wl = /* @__PURE__ */ (function() {
  var o = function(n, e) {
    return o = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(i, t) {
      i.__proto__ = t;
    } || function(i, t) {
      for (var r in t) Object.prototype.hasOwnProperty.call(t, r) && (i[r] = t[r]);
    }, o(n, e);
  };
  return function(n, e) {
    if (typeof e != "function" && e !== null) throw new TypeError("Class extends value " + String(e) + " is not a constructor or null");
    o(n, e);
    function i() {
      this.constructor = n;
    }
    n.prototype = e === null ? Object.create(e) : (i.prototype = e.prototype, new i());
  };
})(), mn = function() {
  return mn = Object.assign || function(o) {
    for (var n, e = 1, i = arguments.length; e < i; e++) {
      n = arguments[e];
      for (var t in n) Object.prototype.hasOwnProperty.call(n, t) && (o[t] = n[t]);
    }
    return o;
  }, mn.apply(this, arguments);
}, In = (function(o) {
  wl(n, o);
  function n() {
    var e = o.call(this) || this;
    return e.state = {}, e;
  }
  return n.prototype.getResizeControl = function() {
    var e = this.props, i = e.model, t = e.graphModel, r = i.x, a = i.y, s = i.width, d = i.height, l = {
      minX: r - s / 2,
      minY: a - d / 2,
      maxX: r + s / 2,
      maxY: a + d / 2
    }, u = l.minX, c = l.minY, h = l.maxX, f = l.maxY;
    return [
      {
        x: u,
        y: c
      },
      {
        x: h,
        y: c
      },
      {
        x: h,
        y: f
      },
      {
        x: u,
        y: f
      }
    ].map(function(p, v) {
      return Fe(xl, mn({ index: v }, p, {
        model: i,
        graphModel: t
      }));
    });
  }, n.prototype.getGroupSolid = function() {
    var e = this.props.model, i = e.x, t = e.y, r = e.width, a = e.height, s = e.getResizeOutlineStyle();
    return Fe(Vo, mn({}, s, {
      x: i,
      y: t,
      width: r,
      height: a
    }));
  }, n.prototype.render = function() {
    return Fe("g", {
      className: "lf-resize-control",
      children: [this.getGroupSolid(), this.getResizeControl()]
    });
  }, n;
})(Pn), ha = /* @__PURE__ */ (function() {
  var o = function(n, e) {
    return o = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(i, t) {
      i.__proto__ = t;
    } || function(i, t) {
      for (var r in t) Object.prototype.hasOwnProperty.call(t, r) && (i[r] = t[r]);
    }, o(n, e);
  };
  return function(n, e) {
    if (typeof e != "function" && e !== null) throw new TypeError("Class extends value " + String(e) + " is not a constructor or null");
    o(n, e);
    function i() {
      this.constructor = n;
    }
    n.prototype = e === null ? Object.create(e) : (i.prototype = e.prototype, new i());
  };
})(), tc = (function(o) {
  ha(n, o);
  function n(e, i) {
    var t = o.call(this, e, i) || this, r = e.properties.nodeSize;
    return r && (t.rx = r.rx, t.ry = r.ry), t;
  }
  return n.prototype.initNodeData = function(e) {
    o.prototype.initNodeData.call(this, e), this.minWidth = 30, this.minHeight = 30, this.maxWidth = 2e3, this.maxHeight = 2e3;
  }, n.prototype.getOutlineStyle = function() {
    var e = o.prototype.getOutlineStyle.call(this);
    return this.graphModel.editConfigModel.isSilentMode || (e.stroke = "none", e.hover && (e.hover.stroke = "none")), e;
  }, n.prototype.getResizeOutlineStyle = function() {
    return {
      fill: "none",
      stroke: "transparent",
      strokeWidth: 1,
      strokeDasharray: "3,3"
    };
  }, n.prototype.getControlPointStyle = function() {
    return {
      width: 7,
      height: 7,
      fill: "#FFFFFF",
      stroke: "#000000"
    };
  }, n.prototype.enableProportionResize = function(e) {
    if (e === void 0 && (e = !0), e) {
      var i = {
        widthPCT: 100,
        heightPCT: 100
      }, t = {
        basisWidth: this.rx,
        basisHeight: this.ry
      }, r = {
        maxScaleLimit: Math.min(this.maxWidth / (this.rx * 2) * 100, this.maxHeight / (this.ry * 2) * 100),
        minScaleLimit: Math.max(this.minWidth / (this.rx * 2) * 100, this.minHeight / (this.ry * 2) * 100)
      };
      this.PCTResizeInfo = {
        ResizePCT: i,
        ResizeBasis: t,
        ScaleLimit: r
      };
    } else delete this.PCTResizeInfo;
  }, n;
})(ns), ic = (function(o) {
  ha(n, o);
  function n() {
    return o !== null && o.apply(this, arguments) || this;
  }
  return n.prototype.getControlGroup = function() {
    var e = this.props, i = e.model, t = e.graphModel;
    return Fe(In, {
      model: i,
      graphModel: t
    });
  }, n.prototype.getResizeShape = function() {
    return o.prototype.getShape.call(this);
  }, n.prototype.getShape = function() {
    var e = this.props, i = e.model, t = e.graphModel.editConfigModel.isSilentMode;
    return Fe("g", { children: [this.getResizeShape(), i.isSelected && !t ? this.getControlGroup() : ""] });
  }, n;
})(ds), fa = /* @__PURE__ */ (function() {
  var o = function(n, e) {
    return o = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(i, t) {
      i.__proto__ = t;
    } || function(i, t) {
      for (var r in t) Object.prototype.hasOwnProperty.call(t, r) && (i[r] = t[r]);
    }, o(n, e);
  };
  return function(n, e) {
    if (typeof e != "function" && e !== null) throw new TypeError("Class extends value " + String(e) + " is not a constructor or null");
    o(n, e);
    function i() {
      this.constructor = n;
    }
    n.prototype = e === null ? Object.create(e) : (i.prototype = e.prototype, new i());
  };
})(), hr = function() {
  return hr = Object.assign || function(o) {
    for (var n, e = 1, i = arguments.length; e < i; e++) {
      n = arguments[e];
      for (var t in n) Object.prototype.hasOwnProperty.call(n, t) && (o[t] = n[t]);
    }
    return o;
  }, hr.apply(this, arguments);
}, nc = (function(o) {
  fa(n, o);
  function n(e, i) {
    var t = o.call(this, e, i) || this, r = e.properties.nodeSize;
    return r && (t.rx = r.rx, t.ry = r.ry), t;
  }
  return n.prototype.initNodeData = function(e) {
    o.prototype.initNodeData.call(this, e), this.minWidth = 30, this.minHeight = 30, this.maxWidth = 2e3, this.maxHeight = 2e3, this.gridSize = 1;
  }, n.prototype.getOutlineStyle = function() {
    var e = o.prototype.getOutlineStyle.call(this);
    return this.graphModel.editConfigModel.isSilentMode || (e.stroke = "none", e.hover && (e.hover.stroke = "none")), e;
  }, n.prototype.getResizeOutlineStyle = function() {
    return {
      fill: "none",
      stroke: "transparent",
      strokeWidth: 1,
      strokeDasharray: "3,3"
    };
  }, n.prototype.getControlPointStyle = function() {
    return {
      width: 7,
      height: 7,
      fill: "#FFFFFF",
      stroke: "#000000"
    };
  }, n.prototype.enableProportionResize = function(e) {
    if (e === void 0 && (e = !0), e) {
      var i = {
        widthPCT: 100,
        heightPCT: 100
      }, t = {
        basisWidth: this.rx,
        basisHeight: this.ry
      }, r = {
        maxScaleLimit: Math.min(this.maxWidth / (this.rx * 2) * 100, this.maxHeight / (this.ry * 2) * 100),
        minScaleLimit: Math.max(this.minWidth / (this.rx * 2) * 100, this.minHeight / (this.ry * 2) * 100)
      };
      this.PCTResizeInfo = {
        ResizePCT: i,
        ResizeBasis: t,
        ScaleLimit: r
      };
    } else delete this.PCTResizeInfo;
  }, n;
})(Ya), rc = (function(o) {
  fa(n, o);
  function n() {
    return o !== null && o.apply(this, arguments) || this;
  }
  return n.prototype.getControlGroup = function() {
    var e = this.props, i = e.model, t = e.graphModel;
    return Fe(In, {
      model: i,
      graphModel: t
    });
  }, n.prototype.getResizeShape = function() {
    var e = this.props.model, i = e.points, t = e.getNodeStyle();
    return Fe("g", { children: Fe(Ko, hr({}, t, { points: i })) });
  }, n.prototype.getShape = function() {
    var e = this.props, i = e.model.isSelected, t = e.graphModel.editConfigModel.isSilentMode;
    return Fe("g", { children: [this.getResizeShape(), i && !t ? this.getControlGroup() : ""] });
  }, n;
})(ts), pa = /* @__PURE__ */ (function() {
  var o = function(n, e) {
    return o = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(i, t) {
      i.__proto__ = t;
    } || function(i, t) {
      for (var r in t) Object.prototype.hasOwnProperty.call(t, r) && (i[r] = t[r]);
    }, o(n, e);
  };
  return function(n, e) {
    if (typeof e != "function" && e !== null) throw new TypeError("Class extends value " + String(e) + " is not a constructor or null");
    o(n, e);
    function i() {
      this.constructor = n;
    }
    n.prototype = e === null ? Object.create(e) : (i.prototype = e.prototype, new i());
  };
})(), oc = (function(o) {
  pa(n, o);
  function n(e, i) {
    var t = o.call(this, e, i) || this, r = e.properties.nodeSize;
    return r && (t.width = r.width, t.height = r.height), t;
  }
  return n.prototype.initNodeData = function(e) {
    o.prototype.initNodeData.call(this, e), this.minWidth = 30, this.minHeight = 30, this.maxWidth = 2e3, this.maxHeight = 2e3;
  }, n.prototype.getOutlineStyle = function() {
    var e = o.prototype.getOutlineStyle.call(this);
    return this.graphModel.editConfigModel.isSilentMode || (e.stroke = "none", e.hover && (e.hover.stroke = "none")), e;
  }, n.prototype.getResizeOutlineStyle = function() {
    return {
      fill: "none",
      stroke: "transparent",
      strokeWidth: 1,
      strokeDasharray: "3,3"
    };
  }, n.prototype.getControlPointStyle = function() {
    return {
      width: 7,
      height: 7,
      fill: "#FFFFFF",
      stroke: "#000000"
    };
  }, n.prototype.enableProportionResize = function(e) {
    if (e === void 0 && (e = !0), e) {
      var i = {
        widthPCT: 100,
        heightPCT: 100
      }, t = {
        basisWidth: this.width,
        basisHeight: this.height
      }, r = {
        maxScaleLimit: Math.min(this.maxWidth / this.width * 100, this.maxHeight / this.height * 100),
        minScaleLimit: Math.max(this.minWidth / this.width * 100, this.minHeight / this.height * 100)
      };
      this.PCTResizeInfo = {
        ResizePCT: i,
        ResizeBasis: t,
        ScaleLimit: r
      };
    } else delete this.PCTResizeInfo;
  }, n;
})(Ua), ac = (function(o) {
  pa(n, o);
  function n() {
    return o !== null && o.apply(this, arguments) || this;
  }
  return n.prototype.getControlGroup = function() {
    var e = this.props, i = e.model, t = e.graphModel;
    return Fe(In, {
      model: i,
      graphModel: t
    });
  }, n.prototype.getResizeShape = function() {
    return o.prototype.getShape.call(this);
  }, n.prototype.getShape = function() {
    var e = this.props, i = e.model.isSelected, t = e.graphModel.editConfigModel.isSilentMode;
    return Fe("g", { children: [this.getResizeShape(), i && !t ? this.getControlGroup() : ""] });
  }, n;
})(ss), va = /* @__PURE__ */ (function() {
  var o = function(n, e) {
    return o = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(i, t) {
      i.__proto__ = t;
    } || function(i, t) {
      for (var r in t) Object.prototype.hasOwnProperty.call(t, r) && (i[r] = t[r]);
    }, o(n, e);
  };
  return function(n, e) {
    if (typeof e != "function" && e !== null) throw new TypeError("Class extends value " + String(e) + " is not a constructor or null");
    o(n, e);
    function i() {
      this.constructor = n;
    }
    n.prototype = e === null ? Object.create(e) : (i.prototype = e.prototype, new i());
  };
})(), El = (function(o) {
  va(n, o);
  function n(e, i) {
    var t = o.call(this, e, i) || this, r = e.properties.nodeSize;
    return r && (t.width = r.width, t.height = r.height), t;
  }
  return n.prototype.initNodeData = function(e) {
    o.prototype.initNodeData.call(this, e), this.minWidth = 30, this.minHeight = 30, this.maxWidth = 2e3, this.maxHeight = 2e3;
  }, n.prototype.getOutlineStyle = function() {
    var e = o.prototype.getOutlineStyle.call(this);
    return this.graphModel.editConfigModel.isSilentMode || (e.stroke = "none", e.hover && (e.hover.stroke = "none")), e;
  }, n.prototype.getControlPointStyle = function() {
    return {
      width: 7,
      height: 7,
      fill: "#FFFFFF",
      stroke: "#000000"
    };
  }, n.prototype.enableProportionResize = function(e) {
    if (e === void 0 && (e = !0), e) {
      var i = {
        widthPCT: 100,
        heightPCT: 100
      }, t = {
        basisWidth: this.width,
        basisHeight: this.height
      }, r = {
        maxScaleLimit: Math.min(this.maxWidth / this.width * 100, this.maxHeight / this.height * 100),
        minScaleLimit: Math.max(this.minWidth / this.width * 100, this.minHeight / this.height * 100)
      };
      this.PCTResizeInfo = {
        ResizePCT: i,
        ResizeBasis: t,
        ScaleLimit: r
      };
    } else delete this.PCTResizeInfo;
  }, n;
})(Vi), _l = (function(o) {
  va(n, o);
  function n() {
    return o !== null && o.apply(this, arguments) || this;
  }
  return n.prototype.getControlGroup = function() {
    var e = this.props, i = e.model, t = e.graphModel;
    return Fe(In, {
      model: i,
      graphModel: t
    });
  }, n.prototype.getResizeShape = function() {
    return o.prototype.getShape.call(this);
  }, n.prototype.getShape = function() {
    return Fe("g", { children: this.getResizeShape() });
  }, n;
})(_i), ga = /* @__PURE__ */ (function() {
  var o = function(n, e) {
    return o = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(i, t) {
      i.__proto__ = t;
    } || function(i, t) {
      for (var r in t) Object.prototype.hasOwnProperty.call(t, r) && (i[r] = t[r]);
    }, o(n, e);
  };
  return function(n, e) {
    if (typeof e != "function" && e !== null) throw new TypeError("Class extends value " + String(e) + " is not a constructor or null");
    o(n, e);
    function i() {
      this.constructor = n;
    }
    n.prototype = e === null ? Object.create(e) : (i.prototype = e.prototype, new i());
  };
})(), yn = function() {
  return yn = Object.assign || function(o) {
    for (var n, e = 1, i = arguments.length; e < i; e++) {
      n = arguments[e];
      for (var t in n) Object.prototype.hasOwnProperty.call(n, t) && (o[t] = n[t]);
    }
    return o;
  }, yn.apply(this, arguments);
}, Vt = function(o, n) {
  var e = typeof Symbol == "function" && o[Symbol.iterator];
  if (!e) return o;
  var i = e.call(o), t, r = [], a;
  try {
    for (; (n === void 0 || n-- > 0) && !(t = i.next()).done; ) r.push(t.value);
  } catch (s) {
    a = { error: s };
  } finally {
    try {
      t && !t.done && (e = i.return) && e.call(i);
    } finally {
      if (a) throw a.error;
    }
  }
  return r;
}, Kt = function(o, n, e) {
  if (e || arguments.length === 2)
    for (var i = 0, t = n.length, r; i < t; i++) (r || !(i in n)) && (r || (r = Array.prototype.slice.call(n, 0, i)), r[i] = n[i]);
  return o.concat(r || Array.prototype.slice.call(n));
}, ao = 500, so = 300, Cl = -1e4, ma = (function(o) {
  ga(n, o);
  function n() {
    var e = o.apply(this, Kt([], Vt(arguments), !1)) || this;
    return e.isGroup = !0, e.isFolded = !1, e.unfoldedWidth = ao, e.unfoldedHeight = so, e.childrenLastFoldStatus = {}, e;
  }
  return n.prototype.initNodeData = function(e) {
    var i = this;
    o.prototype.initNodeData.call(this, e);
    var t = [];
    rn(e.children) && (t = e.children), this.children = new Set(t), this.width = ao, this.height = so, this.foldedWidth = 80, this.foldedHeight = 60, this.zIndex = Cl, this.radius = 0, this.text.editable = !1, this.text.draggable = !1, this.isRestrict = !1, this.resizable = !1, this.autoToFront = !1, this.foldable = !1, this.properties.isFolded === void 0 && (this.properties.isFolded = !1), this.isFolded = !!this.properties.isFolded, setTimeout(function() {
      i.isFolded && i.foldGroup(i.isFolded);
    });
  }, n.prototype.foldGroup = function(e) {
    var i = this;
    if (e !== this.isFolded) {
      this.setProperty("isFolded", e), this.isFolded = e, e ? (this.x = this.x - this.width / 2 + this.foldedWidth / 2, this.y = this.y - this.height / 2 + this.foldedHeight / 2, this.unfoldedWidth = this.width, this.unfoldedHeight = this.height, this.width = this.foldedWidth, this.height = this.foldedHeight) : (this.width = this.unfoldedWidth, this.height = this.unfoldedHeight, this.x = this.x + this.width / 2 - this.foldedWidth / 2, this.y = this.y + this.height / 2 - this.foldedHeight / 2);
      var t = Kt(Kt([], Vt(this.incoming.edges), !1), Vt(this.outgoing.edges), !1);
      this.children.forEach(function(r) {
        var a = i.graphModel.getElement(r);
        if (a) {
          var s = a.isFolded;
          if (a.isGroup && !a.isFolded && a.foldGroup(e), a.isGroup && !e) {
            var d = i.childrenLastFoldStatus[r];
            d !== void 0 && d !== a.isFolded && a.foldGroup(d);
          }
          i.childrenLastFoldStatus[r] = !!s, a.visible = !e;
          var l = a.incoming.edges, u = a.outgoing.edges;
          t = Kt(Kt(Kt([], Vt(t), !1), Vt(l), !1), Vt(u), !1);
        }
      }), this.foldEdge(e, t);
    }
  }, n.prototype.getAnchorStyle = function(e) {
    var i = o.prototype.getAnchorStyle.call(this, e);
    return i.stroke = "transparent", i.fill = "transparent", i.hover.fill = "transparent", i.hover.stroke = "transparent", i;
  }, n.prototype.foldEdge = function(e, i) {
    var t = this;
    i.forEach(function(r, a) {
      var s = r.id, d = r.sourceNodeId, l = r.targetNodeId, u = r.startPoint, c = r.endPoint, h = r.type, f = r.text, p = r.getProperties(), v = {
        id: "".concat(s, "__").concat(a),
        sourceNodeId: d,
        targetNodeId: l,
        startPoint: u,
        endPoint: c,
        type: h,
        properties: p,
        text: f == null ? void 0 : f.value
      };
      r.virtual && t.graphModel.deleteEdgeById(r.id);
      var g = t.graphModel.group.getNodeGroup(l);
      g || (g = t.graphModel.getNodeModelById(l));
      var b = t.graphModel.group.getNodeGroup(d);
      b || (b = t.graphModel.getNodeModelById(d)), e && r.visible !== !1 && (t.children.has(d) || t.id === d ? (v.startPoint = void 0, v.sourceNodeId = t.id) : (v.endPoint = void 0, v.targetNodeId = t.id), (g.id !== t.id || b.id !== t.id) && t.createVirtualEdge(v), r.visible = !1), !e && r.visible === !1 && (g && g.isGroup && g.isFolded ? (v.targetNodeId = g.id, v.endPoint = void 0, t.createVirtualEdge(v)) : b && b.isGroup && b.isFolded ? (v.sourceNodeId = b.id, v.startPoint = void 0, t.createVirtualEdge(v)) : r.visible = !0);
    });
  }, n.prototype.createVirtualEdge = function(e) {
    e.pointsList = void 0;
    var i = this.graphModel.addEdge(e);
    i.virtual = !0, i.text.editable = !1, i.isFoldedEdge = !0;
  }, n.prototype.isInRange = function(e) {
    var i = e.minX, t = e.minY, r = e.maxX, a = e.maxY;
    return i >= this.x - this.width / 2 && r <= this.x + this.width / 2 && t >= this.y - this.height / 2 && a <= this.y + this.height / 2;
  }, n.prototype.isAllowMoveTo = function(e) {
    var i = e.minX, t = e.minY, r = e.maxX, a = e.maxY;
    return {
      x: i >= this.x - this.width / 2 && r <= this.x + this.width / 2,
      y: t >= this.y - this.height / 2 && a <= this.y + this.height / 2
    };
  }, n.prototype.setAllowAppendChild = function(e) {
    this.setProperty("groupAddable", e);
  }, n.prototype.addChild = function(e) {
    this.children.add(e), this.graphModel.eventCenter.emit(bt.GROUP_ADD_NODE, { data: this.getData() });
  }, n.prototype.removeChild = function(e) {
    this.children.delete(e), this.graphModel.eventCenter.emit(bt.GROUP_REMOVE_NODE, { data: this.getData() });
  }, n.prototype.getAddableOutlineStyle = function() {
    return {
      stroke: "#FEB663",
      strokeWidth: 2,
      strokeDasharray: "4 4",
      fill: "transparent"
    };
  }, n.prototype.getData = function() {
    var e = this, i = o.prototype.getData.call(this);
    i.children = [], this.children.forEach(function(r) {
      var a = e.graphModel.getNodeModelById(r);
      a && !a.virtual && i.children.push(r);
    });
    var t = i.properties;
    return t == null || delete t.groupAddable, t == null || delete t.isFolded, i;
  }, n.prototype.getHistoryData = function() {
    var e = o.prototype.getData.call(this);
    e.children = Kt([], Vt(this.children), !1), e.isGroup = !0;
    var i = e.properties;
    return i == null || delete i.groupAddable, i != null && i.isFolded && (e.x = e.x + this.unfoldedWidth / 2 - this.foldedWidth / 2, e.y = e.y + this.unfoldedHeight / 2 - this.foldedHeight / 2), e;
  }, n.prototype.isAllowAppendIn = function(e) {
    return !0;
  }, n.prototype.toBack = function() {
    this.zIndex--;
  }, n;
})(El), ya = (function(o) {
  ga(n, o);
  function n() {
    return o !== null && o.apply(this, arguments) || this;
  }
  return n.prototype.getControlGroup = function() {
    var e = this.props.model, i = e.resizable, t = e.properties;
    return i && !t.isFolded ? o.prototype.getControlGroup.call(this) : null;
  }, n.prototype.getAddableShape = function() {
    var e = this.props.model, i = e.width, t = e.height, r = e.x, a = e.y, s = e.radius, d = e.properties, l = e.getAddableOutlineStyle;
    if (!d.groupAddable) return null;
    var u = this.props.model.getNodeStyle().strokeWidth, c = u === void 0 ? 0 : u, h = l(), f = i + c + 8, p = t + c + 8;
    return I("rect", yn(yn({}, h), {
      width: f,
      height: p,
      x: r - f / 2,
      y: a - p / 2,
      rx: s,
      ry: s
    }));
  }, n.prototype.getFoldIcon = function() {
    var e = this.props.model, i = e.x - e.width / 2 + 5, t = e.y - e.height / 2 + 5;
    if (!e.foldable) return null;
    var r = I("path", {
      fill: "none",
      stroke: "#818281",
      strokeWidth: 2,
      "pointer-events": "none",
      d: e.properties.isFolded ? "M ".concat(i + 3, ",").concat(t + 6, " ").concat(i + 11, ",").concat(t + 6, " M").concat(i + 7, ",").concat(t + 2, " ").concat(i + 7, ",").concat(t + 10) : "M ".concat(i + 3, ",").concat(t + 6, " ").concat(i + 11, ",").concat(t + 6, " ")
    });
    return I("g", {}, [I("rect", {
      height: 12,
      width: 14,
      rx: 2,
      ry: 2,
      strokeWidth: 1,
      fill: "#F4F5F6",
      stroke: "#CECECE",
      cursor: "pointer",
      x: e.x - e.width / 2 + 5,
      y: e.y - e.height / 2 + 5,
      onClick: function() {
        e.foldGroup(!e.properties.isFolded);
      }
    }), r]);
  }, n.prototype.getResizeShape = function() {
    return I("g", {}, [
      this.getAddableShape(),
      o.prototype.getResizeShape.call(this),
      this.getFoldIcon()
    ]);
  }, n;
})(_l), Sl = {
  type: "group",
  view: ya,
  model: ma
}, bn = function() {
  return bn = Object.assign || function(o) {
    for (var n, e = 1, i = arguments.length; e < i; e++) {
      n = arguments[e];
      for (var t in n) Object.prototype.hasOwnProperty.call(n, t) && (o[t] = n[t]);
    }
    return o;
  }, bn.apply(this, arguments);
}, Nl = function(o, n) {
  var e = {};
  for (var i in o) Object.prototype.hasOwnProperty.call(o, i) && n.indexOf(i) < 0 && (e[i] = o[i]);
  if (o != null && typeof Object.getOwnPropertySymbols == "function")
    for (var t = 0, i = Object.getOwnPropertySymbols(o); t < i.length; t++) n.indexOf(i[t]) < 0 && Object.prototype.propertyIsEnumerable.call(o, i[t]) && (e[i[t]] = o[i[t]]);
  return e;
}, $n = function(o, n) {
  var e = typeof Symbol == "function" && o[Symbol.iterator];
  if (!e) return o;
  var i = e.call(o), t, r = [], a;
  try {
    for (; (n === void 0 || n-- > 0) && !(t = i.next()).done; ) r.push(t.value);
  } catch (s) {
    a = { error: s };
  } finally {
    try {
      t && !t.done && (e = i.return) && e.call(i);
    } finally {
      if (a) throw a.error;
    }
  }
  return r;
}, Xn = function(o, n, e) {
  if (e || arguments.length === 2)
    for (var i = 0, t = n.length, r; i < t; i++) (r || !(i in n)) && (r || (r = Array.prototype.slice.call(n, 0, i)), r[i] = n[i]);
  return o.concat(r || Array.prototype.slice.call(n));
}, Tl = -1e3, Zi = -1e4, sc = (function() {
  function o(n) {
    var e = n.lf, i = this;
    this.topGroupZIndex = Zi, this.nodeGroupMap = /* @__PURE__ */ new Map(), this.graphRendered = function(t) {
      var r = t.data;
      r && r.nodes && (r.nodes.forEach(function(a) {
        a.children && a.children.forEach(function(s) {
          i.nodeGroupMap.set(s, a.id);
        });
      }), i.checkAndCorrectTopGroupZIndex(r.nodes));
    }, this.appendNodeToGroup = function(t) {
      var r = t.data, a = i.nodeGroupMap.get(r.id);
      if (a) {
        var s = i.lf.getNodeModelById(a);
        s.removeChild(r.id), i.nodeGroupMap.delete(r.id), s.setAllowAppendChild(!1);
      }
      var d = i.lf.getNodeModelById(r.id), l = d == null ? void 0 : d.getBounds();
      if (l && d) {
        var u = i.getGroup(l, r);
        if (d.isGroup && (r.children.forEach(function(c) {
          i.nodeGroupMap.set(c, r.id);
        }), i.checkAndCorrectTopGroupZIndex([r]), i.nodeSelected({
          data: r,
          isSelected: !1,
          isMultiple: !1
        })), !u) return;
        if (!u.isAllowAppendIn(r)) {
          i.lf.emit(bt.GROUP_NOT_ALLOWED, {
            group: u.getData(),
            node: r
          });
          return;
        }
        u.addChild(r.id), i.nodeGroupMap.set(r.id, u.id), u.setAllowAppendChild(!1);
      }
    }, this.deleteGroupChild = function(t) {
      var r = t.data;
      r.children && r.children.forEach(function(s) {
        i.nodeGroupMap.delete(s), i.lf.deleteNode(s);
      });
      var a = i.nodeGroupMap.get(r.id);
      a && (i.lf.getNodeModelById(a).removeChild(r.id), i.nodeGroupMap.delete(r.id));
    }, this.setActiveGroup = function(t) {
      var r = t.data, a = i.lf.getNodeModelById(r.id), s = a == null ? void 0 : a.getBounds();
      if (a && s) {
        var d = i.getGroup(s, r);
        if (i.activeGroup && i.activeGroup.setAllowAppendChild(!1), !d || a.isGroup && d.id === r.id || !d.isAllowAppendIn(r)) return;
        i.activeGroup = d, i.activeGroup.setAllowAppendChild(!0);
      }
    }, this.findNodeAndChildMaxZIndex = function(t) {
      var r = Zi;
      return t.isGroup && (r = Math.max(r, t.zIndex)), t.children && t.children.forEach(function(a) {
        typeof a == "object" && (a = a.id);
        var s = i.lf.getNodeModelById(a);
        if (s != null && s.isGroup) {
          var d = i.findNodeAndChildMaxZIndex(s);
          r = Math.max(d, r);
        }
      }), r;
    }, this.checkAndCorrectTopGroupZIndex = function(t) {
      var r = Zi;
      if (t.forEach(function(u) {
        var c = i.lf.getNodeModelById(u.id);
        if (c) {
          var h = i.findNodeAndChildMaxZIndex(c);
          h > r && (r = h);
        }
      }), !(i.topGroupZIndex >= r)) {
        for (var a = i.lf.graphModel.nodes.filter(function(u) {
          return u.isGroup;
        }), s = i.topGroupZIndex, d = 0; d < a.length; d++) {
          var l = a[d];
          l.zIndex > s && (s = l.zIndex);
        }
        i.topGroupZIndex = s;
      }
    }, this.nodeSelected = function(t) {
      var r = t.data, a = t.isMultiple, s = t.isSelected, d = i.lf.getNodeModelById(r.id);
      if (i.toFrontGroup(d), i.topGroupZIndex > Tl) {
        i.topGroupZIndex = Zi;
        for (var l = i.lf.graphModel.nodes.filter(function(v) {
          return v.isGroup;
        }).sort(function(v, g) {
          return v.zIndex - g.zIndex;
        }), u = 0, c = 0; c < l.length; c++) {
          var h = l[c];
          h.zIndex !== u && (i.topGroupZIndex++, u = h.zIndex), h.setZIndex(i.topGroupZIndex);
        }
      }
      if (a && s)
        if (d != null && d.isGroup) d.children.forEach(function(v) {
          var g = i.lf.graphModel.getElement(v);
          g == null || g.setSelected(!1);
        });
        else {
          var f = i.nodeGroupMap.get(r.id);
          if (f) {
            var p = i.lf.getNodeModelById(f);
            p != null && p.isSelected && (d == null || d.setSelected(!1));
          }
        }
    }, this.toFrontGroup = function(t) {
      !t || !t.isGroup || (i.topGroupZIndex++, t.setZIndex(i.topGroupZIndex), t.children && t.children.forEach(function(r) {
        var a = i.lf.getNodeModelById(r);
        i.toFrontGroup(a);
      }));
    }, e.register(Sl), this.lf = e, e.graphModel.addNodeMoveRules(function(t, r, a) {
      if (t.isGroup) {
        var s = i.getNodeAllChild(t);
        return e.graphModel.moveNodes(s, r, a, !0), !0;
      }
      var d = e.getNodeModelById(i.nodeGroupMap.get(t.id));
      if (d && d.isRestrict) {
        var l = t.getBounds(), u = l.minX, c = l.minY, h = l.maxX, f = l.maxY;
        return d.isAllowMoveTo({
          minX: u + r,
          minY: c + a,
          maxX: h + r,
          maxY: f + a
        });
      }
      return !0;
    }), e.graphModel.group = this, e.on(dr, this.appendNodeToGroup), e.on(oe.NODE_DELETE, this.deleteGroupChild), e.on(Ui, this.setActiveGroup), e.on(oe.NODE_CLICK, this.nodeSelected), e.on(oe.GRAPH_RENDERED, this.graphRendered), e.addElements = function(t, r) {
      var a = t.nodes, s = t.edges, d = {}, l = {
        nodes: [],
        edges: []
      }, u = [];
      return be(a, function(c) {
        var h = c.id, f = c.children, p = Nl(c, ["children"]), v = e.addNode(p);
        if (!v) return {
          nodes: [],
          edges: []
        };
        h && (d[h] = v.id), l.nodes.push(v);
        var g = i.createAllChildNodes(d, f, v, r).edgesArray;
        u.push.apply(u, Xn([], $n(g), !1));
      }), u.forEach(function(c) {
        i.createEdgeModel(c, d, r);
      }), be(s, function(c) {
        var h = i.createEdgeModel(c, d, 0);
        l.edges.push(h);
      }), l;
    };
  }
  return o.prototype.createAllChildNodes = function(n, e, i, t) {
    var r = this, a = this.lf, s = [], d = [], l = [];
    e == null || e.forEach(function(c) {
      var h = a.getNodeModelById(c);
      if (h) {
        var f = h.x, p = h.y, v = h.properties, g = h.type, b = h.rotate, _ = h.children, D = {
          x: f + t,
          y: p + t,
          properties: v,
          type: g,
          rotate: b
        }, L = oe.NODE_GROUP_COPY || "node:group-copy-add", W = a.addNode(D, L);
        if (i.addChild(W.id), n[c] = W.id, l.push(W), h.incoming.edges.forEach(function(te) {
          d.push(te);
        }), h.outgoing.edges.forEach(function(te) {
          d.push(te);
        }), _ instanceof Set) {
          var B = r.createAllChildNodes(n, _, W, t), K = B.nodesArray, Y = B.edgesArray;
          l.push.apply(l, Xn([], $n(K), !1)), s.push.apply(s, Xn([], $n(Y), !1));
        }
      }
    });
    var u = d.filter(function(c) {
      return n[c.sourceNodeId] && n[c.targetNodeId];
    }).map(function(c) {
      return c.getData();
    });
    return {
      nodesArray: l,
      edgesArray: s.concat(u)
    };
  }, o.prototype.createEdgeModel = function(n, e, i) {
    var t = this.lf, r = n.sourceNodeId, a = n.targetNodeId;
    e[r] && (r = e[r]), e[a] && (a = e[a]);
    var s = n.type, d = n.startPoint, l = n.endPoint, u = n.pointsList, c = n.text, h = {
      x: ((d == null ? void 0 : d.x) || 0) + i,
      y: ((d == null ? void 0 : d.y) || 0) + i
    }, f = {
      x: ((l == null ? void 0 : l.x) || 0) + i,
      y: ((l == null ? void 0 : l.y) || 0) + i
    }, p = [];
    u && u.length > 0 && (p = u.map(function(g) {
      return g.x += i, g.y += i, g;
    }));
    var v = {
      type: s,
      startPoint: h,
      endPoint: f,
      sourceNodeId: r,
      targetNodeId: a,
      pointsList: p
    };
    return ia(c) && !ti(c) && (v.text = bn(bn({}, c), {
      x: (c == null ? void 0 : c.x) + i,
      y: (c == null ? void 0 : c.y) + i
    })), t.graphModel.addEdge(v);
  }, o.prototype.getNodeAllChild = function(n) {
    var e = this, i = [];
    return n.children && n.children.forEach(function(t) {
      i.push(t);
      var r = e.lf.getNodeModelById(t);
      r != null && r.isGroup && (i = i.concat(e.getNodeAllChild(r)));
    }), i;
  }, o.prototype.getGroup = function(n, e) {
    var i = this.lf.graphModel.nodes.filter(function(a) {
      return a.isGroup && a.isInRange(n) && a.id !== e.id;
    });
    if (i.length !== 0) {
      if (i.length === 1) return i[0];
      for (var t = i[i.length - 1], r = i.length - 2; r >= 0; r--) i[r].zIndex > t.zIndex && (t = i[r]);
      return t;
    }
  }, o.prototype.getNodeGroup = function(n) {
    var e = this.nodeGroupMap.get(n);
    if (e) return this.lf.getNodeModelById(e);
  }, o.prototype.render = function() {
  }, o.prototype.destroy = function() {
  }, o.pluginName = "group", o;
})(), lo = /* @__PURE__ */ (function() {
  var o = function(n, e) {
    return o = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(i, t) {
      i.__proto__ = t;
    } || function(i, t) {
      for (var r in t) Object.prototype.hasOwnProperty.call(t, r) && (i[r] = t[r]);
    }, o(n, e);
  };
  return function(n, e) {
    if (typeof e != "function" && e !== null) throw new TypeError("Class extends value " + String(e) + " is not a constructor or null");
    o(n, e);
    function i() {
      this.constructor = n;
    }
    n.prototype = e === null ? Object.create(e) : (i.prototype = e.prototype, new i());
  };
})(), Gi = function() {
  return Gi = Object.assign || function(o) {
    for (var n, e = 1, i = arguments.length; e < i; e++) {
      n = arguments[e];
      for (var t in n) Object.prototype.hasOwnProperty.call(n, t) && (o[t] = n[t]);
    }
    return o;
  }, Gi.apply(this, arguments);
};
function Ml() {
  return {
    type: "bpmn:subProcess",
    view: (function(o) {
      lo(n, o);
      function n() {
        return o !== null && o.apply(this, arguments) || this;
      }
      return n.prototype.getFoldIcon = function() {
        var e = this.props.model, i = e, t = i.x, r = i.y, a = i.width, s = i.height, d = i.properties, l = i.foldable, u = e.x - e.width / 2 + 5, c = e.y - e.height / 2 + 5;
        if (!l) return null;
        var h = I("path", {
          fill: "none",
          stroke: "#818281",
          strokeWidth: 2,
          "pointer-events": "none",
          d: d.isFolded ? "M ".concat(u + 3, ",").concat(c + 6, " ").concat(u + 11, ",").concat(c + 6, " M").concat(u + 7, ",").concat(c + 2, " ").concat(u + 7, ",").concat(c + 10) : "M ".concat(u + 3, ",").concat(c + 6, " ").concat(u + 11, ",").concat(c + 6, " ")
        });
        return I("g", {}, [I("rect", {
          height: 12,
          width: 14,
          rx: 2,
          ry: 2,
          strokeWidth: 1,
          fill: "#F4F5F6",
          stroke: "#CECECE",
          cursor: "pointer",
          x: t - a / 2 + 5,
          y: r - s / 2 + 5,
          onClick: function(f) {
            var p, v;
            f.stopPropagation(), (v = (p = e).foldGroup) === null || v === void 0 || v.call(p, !d.isFolded);
          }
        }), h]);
      }, n.prototype.getResizeShape = function() {
        var e = this.props.model, i = e.x, t = e.y, r = e.width, a = e.height, s = e.getNodeStyle(), d = Gi(Gi({}, s), {
          x: i - r / 2,
          y: t - a / 2,
          width: r,
          height: a,
          stroke: "black",
          strokeWidth: 2,
          strokeDasharray: "0 0"
        });
        return I("g", {}, [I("rect", Gi({}, d)), this.getFoldIcon()]);
      }, n;
    })(ya),
    model: (function(o) {
      lo(n, o);
      function n() {
        return o !== null && o.apply(this, arguments) || this;
      }
      return n.prototype.initNodeData = function(e) {
        o.prototype.initNodeData.call(this, e), this.foldable = !0, this.resizable = !0, this.width = 400, this.height = 200, this.resetWidthHeight(), this.isTaskNode = !0, this.boundaryEvents = [];
      }, n.prototype.resetWidthHeight = function() {
        var e, i, t = (e = this.properties.iniProp) === null || e === void 0 ? void 0 : e.width, r = (i = this.properties.iniProp) === null || i === void 0 ? void 0 : i.height;
        t && (this.width = t), r && (this.height = r);
      }, n.prototype.getNodeStyle = function() {
        var e = o.prototype.getNodeStyle.call(this);
        return e.stroke = "#989891", e.strokeWidth = 1, e.strokeDasharray = "3 3", this.isSelected && (e.stroke = "rgb(124, 15, 255)"), this.properties.isBoundaryEventTouchingTask && (e.stroke = "#00acff", e.strokeWidth = 2), e;
      }, n.prototype.addChild = function(e) {
        var i = this.graphModel.getElement(e);
        i == null || i.setProperties({ parent: this.id }), o.prototype.addChild.call(this, e);
      }, n.prototype.getAnchorStyle = function() {
        var e = o.prototype.getAnchorStyle.call(this);
        return e.stroke = "#000", e.fill = "#fff", e.hover || (e.hover = {}), e.hover.stroke = "transparent", e;
      }, n.prototype.getOutlineStyle = function() {
        var e = o.prototype.getOutlineStyle.call(this);
        return e.stroke = "transparent", e.hover || (e.hover = {}), e.hover.stroke = "transparent", e;
      }, n.prototype.setTouching = function(e) {
        this.setProperty("isBoundaryEventTouchingTask", e);
      }, n.prototype.addBoundaryEvent = function(e) {
        if (this.setTouching(!1), this.boundaryEvents.find(function(t) {
          return t === e;
        })) return !1;
        var i = this.graphModel.getNodeModelById(e);
        return i == null || i.setProperties({ attachedToRef: this.id }), this.boundaryEvents.push(e), !0;
      }, n.prototype.deleteBoundaryEvent = function(e) {
        this.boundaryEvents = this.boundaryEvents.filter(function(i) {
          return i !== e;
        });
      }, n;
    })(ma)
  };
}
var uo = function(o) {
  var n = typeof Symbol == "function" && Symbol.iterator, e = n && o[n], i = 0;
  if (e) return e.call(o);
  if (o && typeof o.length == "number") return { next: function() {
    return o && i >= o.length && (o = void 0), {
      value: o && o[i++],
      done: !o
    };
  } };
  throw new TypeError(n ? "Object is not iterable." : "Symbol.iterator is not defined.");
};
function Al(o) {
  o.on("node:drag,node:dnd-drag", e), o.on("node:drop,node:dnd-add", n), o.graphModel.addNodeMoveRules(function(t, r, a) {
    if (t.isTaskNode) {
      var s = t.boundaryEvents;
      return o.graphModel.moveNodes(s, r, a, !0), !0;
    }
    return !0;
  });
  function n(t) {
    var r, a, s = t.data, d = s.type, l = s.id;
    if (d === "bpmn:boundaryEvent") {
      var u = o.graphModel.nodes;
      try {
        for (var c = uo(u), h = c.next(); !h.done; h = c.next()) {
          var f = h.value;
          if (f.isTaskNode) {
            var p = null;
            if ((p = i(f, s)) !== null) {
              var v = o.graphModel.getNodeModelById(l), g = o.graphModel.getNodeModelById(p), b = v.properties.attachedToRef;
              b && b !== p && o.graphModel.getNodeModelById(b).deleteBoundaryEvent(l), g.addBoundaryEvent(l);
              return;
            }
          }
        }
      } catch (_) {
        r = { error: _ };
      } finally {
        try {
          h && !h.done && (a = c.return) && a.call(c);
        } finally {
          if (r) throw r.error;
        }
      }
    }
  }
  function e(t) {
    var r, a, s = t.data;
    if (s.type === "bpmn:boundaryEvent") {
      var d = o.graphModel.nodes;
      try {
        for (var l = uo(d), u = l.next(); !u.done; u = l.next()) {
          var c = u.value;
          c.isTaskNode && (i(c, s) ? c.setTouching(!0) : c.setTouching(!1));
        }
      } catch (h) {
        r = { error: h };
      } finally {
        try {
          u && !u.done && (a = l.return) && a.call(l);
        } finally {
          if (r) throw r.error;
        }
      }
    }
  }
  function i(t, r) {
    var a = 5, s = t.x, d = t.y, l = t.width, u = t.height, c = t.id, h = {
      minX: s - l / 2,
      maxX: s + l / 2,
      minY: d - u / 2,
      maxY: d + u / 2
    }, f = r.x, p = r.y, v = {
      minX: h.minX - a,
      maxX: h.maxX + a,
      minY: h.minY - a,
      maxY: h.maxY + a
    }, g = {
      minX: h.minX + a,
      maxX: h.maxX - a,
      minY: h.minY + a,
      maxY: h.maxY - a
    };
    return f > v.minX && f < v.maxX && p > v.minY && p < v.maxY && !(f > g.minX && f < g.maxX && p > g.minY && p < g.maxY) ? c : null;
  }
}
function Ol(o) {
  var n = oo("bpmn:serviceTask", ll), e = oo("bpmn:userTask", dl);
  o.register(n), o.register(e), o.register(Ml()), Al(o);
}
var co = /* @__PURE__ */ (function() {
  var o = function(n, e) {
    return o = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(i, t) {
      i.__proto__ = t;
    } || function(i, t) {
      for (var r in t) Object.prototype.hasOwnProperty.call(t, r) && (i[r] = t[r]);
    }, o(n, e);
  };
  return function(n, e) {
    if (typeof e != "function" && e !== null) throw new TypeError("Class extends value " + String(e) + " is not a constructor or null");
    o(n, e);
    function i() {
      this.constructor = n;
    }
    n.prototype = e === null ? Object.create(e) : (i.prototype = e.prototype, new i());
  };
})(), zi = function() {
  return zi = Object.assign || function(o) {
    for (var n, e = 1, i = arguments.length; e < i; e++) {
      n = arguments[e];
      for (var t in n) Object.prototype.hasOwnProperty.call(n, t) && (o[t] = n[t]);
    }
    return o;
  }, zi.apply(this, arguments);
};
function Dl(o) {
  var n = (function(e) {
    co(i, e);
    function i(t, r) {
      return t.id || (t.id = "Flow_".concat(xt())), t.properties = zi(zi(zi({}, o || {}), t.properties), { isDefaultFlow: !1 }), e.call(this, t, r) || this;
    }
    return i.extendKey = "SequenceFlowModel", i;
  })(wr);
  return {
    type: "bpmn:sequenceFlow",
    view: (function(e) {
      co(i, e);
      function i() {
        return e !== null && e.apply(this, arguments) || this;
      }
      return i.prototype.getStartArrow = function() {
        return this.props.model.properties.isDefaultFlow ? I("path", {
          refX: 15,
          stroke: "#000000",
          strokeWidth: 2,
          d: "M 20 5 10 -5 z"
        }) : I("path", { d: "" });
      }, i.extendKey = "SequenceFlowEdge", i;
    })(_r),
    model: n
  };
}
var Pl = Dl();
function Rl(o) {
  o.register(Pl);
}
var Ll = function(o, n) {
  var e = typeof Symbol == "function" && o[Symbol.iterator];
  if (!e) return o;
  var i = e.call(o), t, r = [], a;
  try {
    for (; (n === void 0 || n-- > 0) && !(t = i.next()).done; ) r.push(t.value);
  } catch (s) {
    a = { error: s };
  } finally {
    try {
      t && !t.done && (e = i.return) && e.call(i);
    } finally {
      if (a) throw a.error;
    }
  }
  return r;
}, Il = [{
  nodes: [
    "startEvent",
    "intermediateCatchEvent",
    "boundaryEvent"
  ],
  definition: [{
    type: "bpmn:timerEventDefinition",
    icon: rl,
    properties: {
      definitionType: "bpmn:timerEventDefinition",
      timerValue: "",
      timerType: ""
    }
  }]
}];
function kl(o) {
  function n(e) {
    function i(t, r) {
      return t.forEach(function(a) {
        o != null && o[a] || (o[a] = /* @__PURE__ */ new Map());
        var s = o == null ? void 0 : o[a];
        r.forEach(function(d) {
          s.set(d.type, d);
        });
      }), o;
    }
    e.forEach(function(t) {
      i(t.nodes, t.definition);
    });
  }
  return function() {
    return [o, n];
  };
}
var lc = (function() {
  function o(n) {
    var e = n.lf;
    e.definition = {}, e.useDefinition = kl(e.definition);
    var i = Ll(e.useDefinition(), 2), t = i[0], r = i[1];
    r(Il), nl(e), fl(e), Rl(e), Ol(e), e.setDefaultEdgeType("bpmn:sequenceFlow");
  }
  return o.pluginName = "BpmnElementsPlugin", o;
})(), ho = {
  width: 40,
  height: 40
}, fo = {
  width: 40,
  height: 40
}, po = {
  width: 100,
  height: 80
}, xn = {
  width: 100,
  height: 80
}, vo = {
  width: 100,
  height: 80
}, go = {
  width: 100,
  height: 80
}, mo = {
  width: 100,
  height: 80
}, yo = {
  width: 100,
  height: 80
}, bo = {
  width: 100,
  height: 80
}, xo = {
  width: 100,
  height: 80
};
function ba(o) {
  return Object.prototype.toString.call(o);
}
function wo(o) {
  return "  ".repeat(o);
}
function wn(o) {
  return ba(o) === "[object Object]" ? Object.keys(o).reduce(function(n, e) {
    var i = e;
    return e.charAt(0) === "-" && (i = e.substring(1)), n[i] = wn(o[e]), n;
  }, {}) : Array.isArray(o) ? o.map(function(n) {
    return wn(n);
  }) : o;
}
function En(o) {
  return o == null ? "" : o.toString().replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&apos;");
}
function Bl(o) {
  var n = o;
  try {
    typeof n != "string" && (n = JSON.parse(o));
  } catch (e) {
    n = JSON.stringify(wn(o)).replace(/"/g, "'");
  }
  return En(String(n));
}
var Eo = `	
`;
function an(o, n, e) {
  var i = wo(e), t = "", r = Eo + i;
  if (n === "-json") return "";
  if (o !== 0 && o !== !1 && !o) return "".concat(r, "<").concat(n, " />");
  if (n === "#text") return r + En(String(o));
  if (n === "#cdata-section") return "".concat(r, "<![CDATA[").concat(o, "]]>");
  if (n === "#comment") return "".concat(r, "<!--").concat(o, "-->");
  if ("".concat(n).charAt(0) === "-") return " ".concat(n.substring(1), '="').concat(Bl(o), '"');
  if (Array.isArray(o)) t += o.map(function(l) {
    return an(l, n, e + 1);
  }).join("");
  else if (ba(o) === "[object Object]") {
    var a = Object.keys(o), s = "", d = o["-json"] ? Eo + wo(e + 1) + o["-json"] : "";
    t += "".concat(e === 0 ? "" : r, "<").concat(n), a.forEach(function(l) {
      l.charAt(0) === "-" ? s += an(o[l], l, e + 1) : d += an(o[l], l, e + 1);
    }), t += s + (d !== "" ? ">".concat(d).concat(r, "</").concat(n, ">") : " />");
  } else t += "".concat(r, "<").concat(n, ">").concat(En(String(o)), "</").concat(n, ">");
  return t;
}
function Hl(o) {
  var n = "";
  for (var e in o) n += an(o[e], e, 0);
  return n;
}
var lt = function() {
};
lt.ObjTree = function() {
  return this;
};
lt.ObjTree.VERSION = "0.23";
lt.ObjTree.prototype.xmlDecl = `<?xml version="1.0" encoding="UTF-8" ?>
`;
lt.ObjTree.prototype.attr_prefix = "-";
lt.ObjTree.prototype.parseXML = function(o) {
  var n;
  if (window.DOMParser) {
    var e = new DOMParser(), i = e.parseFromString(o, "application/xml");
    if (!i) return;
    n = i.documentElement;
  } else window.ActiveXObject && (e = new ActiveXObject("Microsoft.XMLDOM"), e.async = !1, e.loadXML(o), n = e.documentElement);
  if (n)
    return this.parseDOM(n);
};
lt.ObjTree.prototype.parseHTTP = function(o, n, e) {
  var i = {};
  for (var t in n) i[t] = n[t];
  if (i.method || (typeof i.postBody == "undefined" && typeof i.postbody == "undefined" && typeof i.parameters == "undefined" ? i.method = "get" : i.method = "post"), e) {
    i.asynchronous = !0;
    var r = this, a = e, s = i.onComplete;
    i.onComplete = function(u) {
      var c;
      u && u.responseXML && u.responseXML.documentElement && (c = r.parseDOM(u.responseXML.documentElement)), a(c, u), s && s(u);
    };
  } else i.asynchronous = !1;
  var d;
  if (typeof HTTP != "undefined" && HTTP.Request) {
    i.uri = o;
    var l = new HTTP.Request(i);
    l && (d = l.transport);
  } else if (typeof Ajax != "undefined" && Ajax.Request) {
    var l = new Ajax.Request(o, i);
    l && (d = l.transport);
  }
  if (e) return d;
  if (d && d.responseXML && d.responseXML.documentElement) return this.parseDOM(d.responseXML.documentElement);
};
lt.ObjTree.prototype.parseDOM = function(o) {
  if (o) {
    if (this.__force_array = {}, this.force_array) for (var n = 0; n < this.force_array.length; n++) this.__force_array[this.force_array[n]] = 1;
    var e = this.parseElement(o);
    if (this.__force_array[o.nodeName] && (e = [e]), o.nodeType !== 11) {
      var i = {};
      i[o.nodeName] = e, e = i;
    }
    return e;
  }
};
lt.ObjTree.prototype.parseElement = function(o) {
  if (o.nodeType !== 7) {
    if (o.nodeType === 3 || o.nodeType === 4 || o.nodeType === 8)
      return o.nodeValue.match(/[^\x00-\x20]/) == null ? void 0 : o.nodeValue;
    var n = null, e = {};
    if (o.attributes && o.attributes.length) {
      n = {};
      for (var i = 0; i < o.attributes.length; i++) {
        var t = o.attributes[i].nodeName;
        if (typeof t == "string") {
          var r = o.attributes[i].nodeValue;
          try {
            r = JSON.parse(o.attributes[i].nodeValue.replace(/'/g, '"'));
          } catch (d) {
            r = o.attributes[i].nodeValue;
          }
          r != null && (t = this.attr_prefix + t, typeof e[t] == "undefined" && (e[t] = 0), e[t]++, this.addNode(n, t, e[t], r));
        }
      }
    }
    if (o.childNodes && o.childNodes.length) {
      var a = !0;
      n && (a = !1);
      for (var i = 0; i < o.childNodes.length && a; i++) {
        var s = o.childNodes[i].nodeType;
        s === 3 || s === 4 || s === 8 || (a = !1);
      }
      if (a) {
        n || (n = "");
        for (var i = 0; i < o.childNodes.length; i++) n += o.childNodes[i].nodeValue;
      } else {
        n || (n = {});
        for (var i = 0; i < o.childNodes.length; i++) {
          var t = o.childNodes[i].nodeName;
          if (typeof t == "string") {
            var r = this.parseElement(o.childNodes[i]);
            r && (typeof e[t] == "undefined" && (e[t] = 0), e[t]++, this.addNode(n, t, e[t], r));
          }
        }
      }
    } else n === null && (n = {});
    return n;
  }
};
lt.ObjTree.prototype.addNode = function(o, n, e, i) {
  this.__force_array[n] ? (e === 1 && (o[n] = []), o[n][o[n].length] = i) : e === 1 ? o[n] = i : e === 2 ? o[n] = [o[n], i] : o[n][o[n].length] = i;
};
lt.ObjTree.prototype.writeXML = function(o) {
  var n = this.hash_to_xml(null, o);
  return this.xmlDecl + n;
};
lt.ObjTree.prototype.hash_to_xml = function(o, n) {
  var e = [], i = [];
  for (var t in n)
    if (Yi(n, t)) {
      var r = n[t];
      t.charAt(0) !== this.attr_prefix ? typeof r == "undefined" || r == null ? e[e.length] = "<".concat(t, " />") : typeof r == "object" && r.constructor === Array ? e[e.length] = this.array_to_xml(t, r) : typeof r == "object" ? e[e.length] = this.hash_to_xml(t, r) : e[e.length] = this.scalar_to_xml(t, r) : i[i.length] = " ".concat(t.substring(1), '="').concat(this.xml_escape(r), '"');
    }
  var a = i.join(""), s = e.join("");
  return typeof o == "undefined" || o == null || (e.length > 0 ? s.match(/\n/) ? s = "<".concat(o).concat(a, `>
`).concat(s, "</").concat(o, `>
`) : s = "<".concat(o).concat(a, ">").concat(s, "</").concat(o, `>
`) : s = "<".concat(o).concat(a, ` />
`)), s;
};
lt.ObjTree.prototype.array_to_xml = function(o, n) {
  for (var e = [], i = 0; i < n.length; i++) {
    var t = n[i];
    typeof t == "undefined" || t == null ? e[e.length] = "<".concat(o, " />") : typeof t == "object" && t.constructor === Array ? e[e.length] = this.array_to_xml(o, t) : typeof t == "object" ? e[e.length] = this.hash_to_xml(o, t) : e[e.length] = this.scalar_to_xml(o, t);
  }
  return e.join("");
};
lt.ObjTree.prototype.scalar_to_xml = function(o, n) {
  return o === "#text" ? this.xml_escape(n) : "<".concat(o, ">").concat(this.xml_escape(n), "</").concat(o, `>
`);
};
lt.ObjTree.prototype.xml_escape = En;
var Fl = function(o) {
  return new lt.ObjTree().parseXML(o);
}, Gl = /* @__PURE__ */ (function() {
  var o = function(n, e) {
    return o = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(i, t) {
      i.__proto__ = t;
    } || function(i, t) {
      for (var r in t) Object.prototype.hasOwnProperty.call(t, r) && (i[r] = t[r]);
    }, o(n, e);
  };
  return function(n, e) {
    if (typeof e != "function" && e !== null) throw new TypeError("Class extends value " + String(e) + " is not a constructor or null");
    o(n, e);
    function i() {
      this.constructor = n;
    }
    n.prototype = e === null ? Object.create(e) : (i.prototype = e.prototype, new i());
  };
})(), fr = function() {
  return fr = Object.assign || function(o) {
    for (var n, e = 1, i = arguments.length; e < i; e++) {
      n = arguments[e];
      for (var t in n) Object.prototype.hasOwnProperty.call(n, t) && (o[t] = n[t]);
    }
    return o;
  }, fr.apply(this, arguments);
}, _o = function(o, n) {
  var e = {};
  for (var i in o) Object.prototype.hasOwnProperty.call(o, i) && n.indexOf(i) < 0 && (e[i] = o[i]);
  if (o != null && typeof Object.getOwnPropertySymbols == "function")
    for (var t = 0, i = Object.getOwnPropertySymbols(o); t < i.length; t++) n.indexOf(i[t]) < 0 && Object.prototype.propertyIsEnumerable.call(o, i[t]) && (e[i[t]] = o[i[t]]);
  return e;
}, Sr = function(o) {
  var n = typeof Symbol == "function" && Symbol.iterator, e = n && o[n], i = 0;
  if (e) return e.call(o);
  if (o && typeof o.length == "number") return { next: function() {
    return o && i >= o.length && (o = void 0), {
      value: o && o[i++],
      done: !o
    };
  } };
  throw new TypeError(n ? "Object is not iterable." : "Symbol.iterator is not defined.");
}, Je = function(o, n) {
  var e = typeof Symbol == "function" && o[Symbol.iterator];
  if (!e) return o;
  var i = e.call(o), t, r = [], a;
  try {
    for (; (n === void 0 || n-- > 0) && !(t = i.next()).done; ) r.push(t.value);
  } catch (s) {
    a = { error: s };
  } finally {
    try {
      t && !t.done && (e = i.return) && e.call(i);
    } finally {
      if (a) throw a.error;
    }
  }
  return r;
}, Mt = function(o, n, e) {
  if (e || arguments.length === 2)
    for (var i = 0, t = n.length, r; i < t; i++) (r || !(i in n)) && (r || (r = Array.prototype.slice.call(n, 0, i)), r[i] = n[i]);
  return o.concat(r || Array.prototype.slice.call(n));
}, at;
(function(o) {
  o.START = "bpmn:startEvent", o.END = "bpmn:endEvent", o.INTERMEDIATE_CATCH = "bpmn:intermediateCatchEvent", o.INTERMEDIATE_THROW = "bpmn:intermediateThrowEvent", o.BOUNDARY = "bpmn:boundaryEvent", o.PARALLEL_GATEWAY = "bpmn:parallelGateway", o.INCLUSIVE_GATEWAY = "bpmn:inclusiveGateway", o.EXCLUSIVE_GATEWAY = "bpmn:exclusiveGateway", o.USER = "bpmn:userTask", o.SYSTEM = "bpmn:serviceTask", o.FLOW = "bpmn:sequenceFlow", o.SUBPROCESS = "bpmn:subProcess";
})(at || (at = {}));
var xa = [
  "-name",
  "-id",
  "bpmn:incoming",
  "bpmn:outgoing",
  "-sourceRef",
  "-targetRef",
  "-children"
], zl = [
  "properties",
  "startPoint",
  "endPoint",
  "pointsList"
], _n = {
  in: [],
  out: [
    "properties.panels",
    "properties.nodeSize",
    "properties.definitionId",
    "properties.timerValue",
    "properties.timerType",
    "properties.definitionType",
    "properties.parent",
    "properties.isBoundaryEventTouchingTask"
  ]
}, wa = function(o, n) {
  return Object.keys(n || {}).forEach(function(e) {
    if (o[e]) {
      var i = n[e], t = i.in, r = i.out;
      t && (o[e].in = t), r && (o[e].out = r);
    } else o[e] = n[e];
  }), o;
}, St = {
  "bpmn:startEvent": { out: function(o) {
    var n, e, i = o.properties;
    return ((e = (n = St[i.definitionType]) === null || n === void 0 ? void 0 : n.out) === null || e === void 0 ? void 0 : e.call(n, o)) || {};
  } },
  "bpmn:intermediateCatchEvent": { out: function(o) {
    var n, e, i = o.properties;
    return ((e = (n = St[i.definitionType]) === null || n === void 0 ? void 0 : n.out) === null || e === void 0 ? void 0 : e.call(n, o)) || {};
  } },
  "bpmn:intermediateThrowEvent": { out: function(o) {
    var n, e, i = o.properties;
    return ((e = (n = St[i.definitionType]) === null || n === void 0 ? void 0 : n.out) === null || e === void 0 ? void 0 : e.call(n, o)) || {};
  } },
  "bpmn:boundaryEvent": { out: function(o) {
    var n, e, i = o.properties;
    return ((e = (n = St[i.definitionType]) === null || n === void 0 ? void 0 : n.out) === null || e === void 0 ? void 0 : e.call(n, o)) || {};
  } },
  "bpmn:sequenceFlow": { out: function(o) {
    var n = o.properties, e = n.expressionType, i = n.condition;
    return i ? e === "cdata" ? { json: '<bpmn:conditionExpression xsi:type="bpmn2:tFormalExpression"><![CDATA[${'.concat(i, "}]]></bpmn:conditionExpression>") } : { json: '<bpmn:conditionExpression xsi:type="bpmn2:tFormalExpression">'.concat(i, "</bpmn:conditionExpression>") } : { json: "" };
  } },
  "bpmn:timerEventDefinition": {
    out: function(o) {
      var n = o.properties, e = n.timerType, i = n.timerValue, t = n.definitionId, r = function() {
        return "<bpmn:".concat(e, ' xsi:type="bpmn:tFormalExpression">').concat(i, "</bpmn:").concat(e, ">");
      };
      return { json: '<bpmn:timerEventDefinition id="'.concat(t, '"').concat(e && i ? ">".concat(r(), "</bpmn:timerEventDefinition>") : "/>") };
    },
    in: function(o, n) {
      var e, i, t, r, a = o, s = n["-id"], d = "", l = "";
      try {
        for (var u = Sr(Object.keys(n)), c = u.next(); !c.done; c = u.next()) {
          var h = c.value;
          h.includes("bpmn:") && (t = Je(h.split(":"), 2), d = t[1], l = (r = n[h]) === null || r === void 0 ? void 0 : r["#text"]);
        }
      } catch (f) {
        e = { error: f };
      } finally {
        try {
          c && !c.done && (i = u.return) && i.call(u);
        } finally {
          if (e) throw e.error;
        }
      }
      return {
        "-definitionId": s,
        "-definitionType": a,
        "-timerType": d,
        "-timerValue": l
      };
    }
  },
  "bpmn:conditionExpression": { in: function(o, n) {
    var e, i = "", t = "";
    return n["#cdata-section"] ? (t = "cdata", i = ((e = /^\$\{(.*)\}$/g.exec(n["#cdata-section"])) === null || e === void 0 ? void 0 : e[1]) || "") : n["#text"] && (t = "normal", i = n["#text"]), {
      "-condition": i,
      "-expressionType": t
    };
  } }
};
function jl(o) {
  var n = o != null ? o : {}, e = n.retainedAttrsFields, i = n.excludeFields, t = n.transformer, r = new Set(Mt(Mt([], Je(zl), !1), Je(e || []), !1)), a = {
    in: new Set(Mt(Mt([], Je(_n.in), !1), Je((i == null ? void 0 : i.in) || []), !1)),
    out: new Set(Mt(Mt([], Je(_n.out), !1), Je((i == null ? void 0 : i.out) || []), !1))
  };
  return St = wa(St, t), function(s) {
    var d = s.nodes, l = s.edges;
    function u(c, h) {
      var f, p;
      if ((c == null ? void 0 : c.flag) !== 1) {
        var v;
        if ((v = St[c.type]) && v.out) {
          var g = v.out(c), b = Object.keys(g);
          b.length > 0 && b.forEach(function(te) {
            c[te] = g[te];
          });
        }
        c != null && c.children && (c.children = c.children.map(function(te) {
          return d.find(function(se) {
            return se.id === te;
          }) || l.find(function(se) {
            return se.id === te;
          }) || {};
        }));
        var _ = {};
        if (typeof c == "string") return c;
        if (Array.isArray(c)) return c.map(function(te) {
          return u(te, "");
        }).filter(function(te) {
          return te != null;
        });
        try {
          for (var D = Sr(Object.entries(c)), L = D.next(); !L.done; L = D.next()) {
            var W = Je(L.value, 2), B = W[0], K = W[1];
            if ((K == null ? void 0 : K.flag) === 1) return;
            var Y = [h, B].filter(function(te) {
              return te;
            }).join(".");
            a.out.has(Y) || (typeof K != "object" ? B.indexOf("-") === 0 || [
              "#text",
              "#cdata-section",
              "#comment"
            ].includes(B) ? _[B] = K : _["-".concat(B)] = K : r.has(Y) ? _["-".concat(B)] = u(K, Y) : _[B] = u(K, Y));
          }
        } catch (te) {
          f = { error: te };
        } finally {
          try {
            L && !L.done && (p = D.return) && p.call(D);
          } finally {
            if (f) throw f.error;
          }
        }
        return _;
      }
    }
    return u(s, "");
  };
}
function Cn(o) {
  var n, e, i = {};
  try {
    for (var t = Sr(Object.entries(o)), r = t.next(); !r.done; r = t.next()) {
      var a = Je(r.value, 2), s = a[0], d = a[1];
      s.indexOf("-") === 0 ? i[s.substring(1)] = wn(d) : typeof d == "string" ? i[s] = d : Object.prototype.toString.call(d) === "[object Object]" ? i[s] = Cn(d) : Array.isArray(d) ? i[s] = d.map(function(l) {
        return Cn(l);
      }) : i[s] = d;
    }
  } catch (l) {
    n = { error: l };
  } finally {
    try {
      r && !r.done && (e = t.return) && e.call(t);
    } finally {
      if (n) throw n.error;
    }
  }
  return i;
}
function Wl(o, n, e) {
  var i, t = /* @__PURE__ */ new Map(), r = jl(e)(n);
  r.nodes.forEach(function(s) {
    var d = s["-id"], l = s["-type"], u = s.text, c = s.children, h = _o(s, [
      "-id",
      "-type",
      "text",
      "children"
    ]), f = { "-id": d };
    u != null && u["-value"] && (f["-name"] = u["-value"]), h["-json"] && (f["-json"] = h["-json"]), h["-properties"] && Object.assign(f, h["-properties"]), c && (f.children = c), o[l] || (o[l] = []), o[l].push(f), t.set(d, f);
  });
  var a = r.edges.map(function(s) {
    var d = s["-id"], l = s["-sourceNodeId"], u = s["-targetNodeId"], c = s.text, h = _o(s, [
      "-id",
      "-sourceNodeId",
      "-targetNodeId",
      "text"
    ]), f = t.get(u);
    f["bpmn:incoming"] || (f["bpmn:incoming"] = []), f["bpmn:incoming"].push(d);
    var p = {
      "-id": d,
      "-sourceRef": l,
      "-targetRef": u
    };
    return c != null && c["-value"] && (p["-name"] = c["-value"]), h["-json"] && (p["-json"] = h["-json"]), h["-properties"] && Object.assign(p, h["-properties"]), p;
  });
  return n.edges.forEach(function(s) {
    var d = s.sourceNodeId, l = s.id, u = t.get(d);
    u["bpmn:outgoing"] || (u["bpmn:outgoing"] = []), u["bpmn:outgoing"].push(l);
  }), (i = o["bpmn:subProcess"]) === null || i === void 0 || i.forEach(function(s) {
    var d = {
      "bpmn:incoming": /* @__PURE__ */ new Set(),
      "bpmn:outgoing": /* @__PURE__ */ new Set()
    }, l = [];
    s.children.forEach(function(p) {
      var v, g = t.get(p["-id"]);
      ["bpmn:incoming", "bpmn:outgoing"].forEach(function(_) {
        g[_] && g[_].forEach(function(D) {
          d[_].add(D);
        });
      });
      var b = (v = o[p["-type"]]) === null || v === void 0 ? void 0 : v.findIndex(function(_) {
        return _["-id"] === p["-id"];
      });
      b >= 0 && o[p["-type"]].splice(b, 1), t.delete(p["-id"]), s[p["-type"]] || (s[p["-type"]] = []), s[p["-type"]].push(g);
    });
    var u = d["bpmn:incoming"];
    d["bpmn:outgoing"].forEach(function(p) {
      u.has(p) && l.push(p);
    });
    for (var c = function(p) {
      var v = a.findIndex(function(g) {
        return g["-id"] === l[p];
      });
      v >= 0 ? (s["bpmn:sequenceFlow"] || (s["bpmn:sequenceFlow"] = []), s["bpmn:sequenceFlow"].push(a[v]), a.splice(v, 1)) : p++, h = p;
    }, h, f = 0; f < l.length; )
      c(f), f = h;
    delete s.children;
  }), o[at.FLOW] = a, o;
}
function $l(o, n) {
  o["bpmndi:BPMNEdge"] = n.edges.map(function(e) {
    var i, t = e.id, r = e.pointsList.map(function(s) {
      return {
        "-x": s.x,
        "-y": s.y
      };
    }), a = {
      "-id": "".concat(t, "_di"),
      "-bpmnElement": t,
      "di:waypoint": r
    };
    return !((i = e.text) === null || i === void 0) && i.value && (a["bpmndi:BPMNLabel"] = { "dc:Bounds": {
      "-x": e.text.x - e.text.value.length * 10 / 2,
      "-y": e.text.y - 7,
      "-width": e.text.value.length * 10,
      "-height": 14
    } }), a;
  }), o["bpmndi:BPMNShape"] = n.nodes.map(function(e) {
    var i, t = e.id, r = 100, a = 80, s = e.x, d = e.y, l = pt.shapeConfigMap.get(e.type);
    l && (r = l.width, a = l.height), s -= r / 2, d -= a / 2;
    var u = {
      "-id": "".concat(t, "_di"),
      "-bpmnElement": t,
      "dc:Bounds": {
        "-x": s,
        "-y": d,
        "-width": r,
        "-height": a
      }
    };
    return !((i = e.text) === null || i === void 0) && i.value && (u["bpmndi:BPMNLabel"] = { "dc:Bounds": {
      "-x": e.text.x - e.text.value.length * 10 / 2,
      "-y": e.text.y - 7,
      "-width": e.text.value.length * 10,
      "-height": 14
    } }), u;
  });
}
var Xl = ["bpmn:incoming", "bpmn:outgoing"];
function Yl(o, n) {
  var e = [], i = [], t = /* @__PURE__ */ new Map(), r = n != null ? n : {}, a = r.transformer, s = r.excludeFields, d = {
    in: new Set(Mt(Mt([], Je(_n.in), !1), Je((s == null ? void 0 : s.in) || []), !1)),
    out: new Set(Mt(Mt([], Je(_n.out), !1), Je((s == null ? void 0 : s.out) || []), !1))
  };
  St = wa(St, a);
  var l = o["bpmn:definitions"];
  if (l) {
    var u = l["bpmn:process"];
    (function(h, f) {
      f.forEach(function(p) {
        try {
          Object.keys(h).forEach(function(v) {
            try {
              p(v);
            } catch (g) {
            }
          });
        } catch (v) {
        }
      });
    })(u, [
      function(h) {
        function f(v) {
          v["-children"] || (v["-children"] = []), Object.keys(v).forEach(function(g) {
            var b;
            g.indexOf("bpmn:") === 0 && !Xl.includes(g) && (u[g] || (u[g] = []), !Array.isArray(u[g]) && (u[g] = [u[g]]), Array.isArray(v[g]) ? (b = u[g]).push.apply(b, Mt([], Je(v[g]), !1)) : u[g].push(v[g]), Array.isArray(v[g]) ? v[g].forEach(function(_) {
              !g.includes("Flow") && v["-children"].push(_["-id"]);
            }) : !g.includes("Flow") && v["-children"].push(v[g]["-id"]), delete v[g]);
          });
        }
        if (h === "bpmn:subProcess") {
          var p = u[h];
          Array.isArray(p) ? p.forEach(function(v) {
            h === "bpmn:subProcess" && f(v);
          }) : f(p);
        }
      },
      function(h) {
        var f = function(v) {
          Object.keys(v).forEach(function(g) {
            var b, _;
            if (g.includes("bpmn:")) {
              var D = {};
              St[g] && St[g].in ? (D = (_ = (b = St[g]).in) === null || _ === void 0 ? void 0 : _.call(b, g, ta.cloneDeep(v[g])), delete v[g]) : p(v[g]);
              var L = void 0;
              (L = Reflect.ownKeys(D)).length > 0 && L.forEach(function(W) {
                Reflect.set(v, W, D[W]);
              });
            }
          });
        };
        function p(v) {
          t.set(v["-id"], v), Array.isArray(v) ? v.forEach(function(g) {
            p(g);
          }) : typeof v == "object" && f(v);
        }
        p(u[h]);
      },
      function(h) {
        if (h.indexOf("bpmn:") === 0) {
          var f = u[h];
          if (h === "bpmn:sequenceFlow") {
            var p = l["bpmndi:BPMNDiagram"]["bpmndi:BPMNPlane"]["bpmndi:BPMNEdge"];
            i = Vl(f, p);
          } else {
            var v = l["bpmndi:BPMNDiagram"]["bpmndi:BPMNPlane"]["bpmndi:BPMNShape"];
            if (h === "bpmn:boundaryEvent") {
              var g = u[h], b = function(_) {
                var D = _["-attachedToRef"], L = t.get(D);
                L["-boundaryEvents"] || (L["-boundaryEvents"] = []), L["-boundaryEvents"].push(_["-id"]);
              };
              Array.isArray(g) ? g.forEach(function(_) {
                b(_);
              }) : b(g);
            }
            e = e.concat(Ul(f, v, h));
          }
        }
      }
    ]);
  }
  var c = function(h, f, p) {
    Object.keys(h).forEach(function(v) {
      var g = p ? "".concat(p, ".").concat(v) : v;
      f.has(g) ? delete h[v] : typeof h[v] == "object" && c(h[v], f, g);
    });
  };
  return e.forEach(function(h) {
    var f, p;
    if (!((f = n == null ? void 0 : n.mapping) === null || f === void 0) && f.in) {
      var v = (p = n == null ? void 0 : n.mapping) === null || p === void 0 ? void 0 : p.in, g = h.type;
      v[g] && (h.type = v[g]);
    }
    c(h, d.in, "");
  }), i.forEach(function(h) {
    var f, p;
    if (!((f = n == null ? void 0 : n.mapping) === null || f === void 0) && f.in) {
      var v = (p = n == null ? void 0 : n.mapping) === null || p === void 0 ? void 0 : p.in, g = h.type;
      v[g] && (h.type = v[g]);
    }
    c(h, d.in, "");
  }), {
    nodes: e,
    edges: i
  };
}
function Ul(o, n, e) {
  var i = [];
  if (Array.isArray(o)) o.forEach(function(a) {
    var s;
    Array.isArray(n) ? s = n.find(function(l) {
      return l["-bpmnElement"] === a["-id"];
    }) : s = n;
    var d = Co(s, e, a);
    i.push(d);
  });
  else {
    var t = void 0;
    Array.isArray(n) ? t = n.find(function(a) {
      return a["-bpmnElement"] === o["-id"];
    }) : t = n;
    var r = Co(t, e, o);
    i.push(r);
  }
  return i;
}
function Co(o, n, e) {
  var i = Number(o["dc:Bounds"]["-x"]), t = Number(o["dc:Bounds"]["-y"]), r = e["-children"], a = e["-name"], s = pt.shapeConfigMap.get(n);
  s && (i += s.width / 2, t += s.height / 2);
  var d = {};
  Object.entries(e).forEach(function(h) {
    var f = Je(h, 2), p = f[0], v = f[1];
    xa.includes(p) || (d[p] = v);
  }), d = Cn(d);
  var l;
  if (a && (l = {
    x: i,
    y: t,
    value: a
  }, o["bpmndi:BPMNLabel"] && o["bpmndi:BPMNLabel"]["dc:Bounds"])) {
    var u = o["bpmndi:BPMNLabel"]["dc:Bounds"];
    l.x = Number(u["-x"]) + Number(u["-width"]) / 2, l.y = Number(u["-y"]) + Number(u["-height"]) / 2;
  }
  var c = {
    id: o["-bpmnElement"],
    type: n,
    x: i,
    y: t,
    properties: d
  };
  return r && (c.children = r), l && (c.text = l), c;
}
function Vl(o, n) {
  var e = [];
  if (Array.isArray(o)) o.forEach(function(t) {
    var r;
    Array.isArray(n) ? r = n.find(function(a) {
      return a["-bpmnElement"] === t["-id"];
    }) : r = n, e.push(So(r, t));
  });
  else {
    var i = void 0;
    Array.isArray(n) ? i = n.find(function(t) {
      return t["-bpmnElement"] === o["-id"];
    }) : i = n, e.push(So(i, o));
  }
  return e;
}
function So(o, n) {
  var e, i = n["-name"] ? "".concat(n["-name"]) : "";
  if (i) {
    var t = o["bpmndi:BPMNLabel"]["dc:Bounds"], r = 0;
    i.split(`
`).forEach(function(l) {
      r < l.length && (r = l.length);
    }), e = {
      value: i,
      x: Number(t["-x"]) + r * 10 / 2,
      y: Number(t["-y"]) + 7
    };
  }
  var a = {};
  Object.entries(n).forEach(function(l) {
    var u = Je(l, 2), c = u[0], h = u[1];
    xa.includes(c) || (a[c] = h);
  }), a = Cn(a);
  var s = o["di:waypoint"].map(function(l) {
    return {
      x: Number(l["-x"]),
      y: Number(l["-y"])
    };
  }), d = {
    id: n["-id"],
    type: at.FLOW,
    pointsList: s,
    sourceNodeId: n["-sourceRef"],
    targetNodeId: n["-targetRef"],
    properties: a
  };
  return e && (d.text = e), d;
}
var pt = (function() {
  function o(n) {
    var e = n.lf, i = this;
    this.adapterOut = function(t, r) {
      var a, s, d = fr({}, i.processAttributes);
      Wl(d, t, r);
      var l = {
        "-id": "BPMNPlane_1",
        "-bpmnElement": d["-id"]
      };
      $l(l, t);
      var u = i.definitionAttributes;
      u["bpmn:process"] = d, u["bpmndi:BPMNDiagram"] = {
        "-id": "BPMNDiagram_1",
        "bpmndi:BPMNPlane": l
      };
      var c = { "bpmn:definitions": u };
      if (!((a = r == null ? void 0 : r.mapping) === null || a === void 0) && a.out) {
        var h = (s = r == null ? void 0 : r.mapping) === null || s === void 0 ? void 0 : s.out, f = function(p) {
          Array.isArray(p) && p.forEach(function(v) {
            return f(v);
          }), typeof p == "object" && Object.keys(p).forEach(function(v) {
            var g;
            (g = h[v]) ? (p[g] = ta.cloneDeep(p[v]), delete p[v], f(p[g])) : f(p[v]);
          });
        };
        f(c);
      }
      return c;
    }, this.adapterIn = function(t, r) {
      if (t) return Yl(t, r);
    }, e.adapterIn = this.adapterIn, e.adapterOut = this.adapterOut, this.processAttributes = {
      "-isExecutable": "true",
      "-id": "Process"
    }, this.definitionAttributes = {
      "-id": "Definitions",
      "-xmlns:xsi": "http://www.w3.org/2001/XMLSchema-instance",
      "-xmlns:bpmn": "http://www.omg.org/spec/BPMN/20100524/MODEL",
      "-xmlns:bpmndi": "http://www.omg.org/spec/BPMN/20100524/DI",
      "-xmlns:dc": "http://www.omg.org/spec/DD/20100524/DC",
      "-xmlns:di": "http://www.omg.org/spec/DD/20100524/DI",
      "-targetNamespace": "http://logic-flow.org",
      "-exporter": "logicflow",
      "-exporterVersion": "1.2.10"
    };
  }
  return o.prototype.setCustomShape = function(n, e) {
    o.shapeConfigMap.set(n, e);
  }, o.pluginName = "bpmn-adapter", o.shapeConfigMap = /* @__PURE__ */ new Map(), o;
})();
pt.shapeConfigMap.set(at.START, {
  width: ho.width,
  height: ho.height
});
pt.shapeConfigMap.set(at.END, {
  width: fo.width,
  height: fo.height
});
pt.shapeConfigMap.set(at.INTERMEDIATE_CATCH, {
  width: xn.width,
  height: xn.height
});
pt.shapeConfigMap.set(at.INTERMEDIATE_THROW, {
  width: xn.width,
  height: xn.height
});
pt.shapeConfigMap.set(at.BOUNDARY, {
  width: po.width,
  height: po.height
});
pt.shapeConfigMap.set(at.PARALLEL_GATEWAY, {
  width: vo.width,
  height: vo.height
});
pt.shapeConfigMap.set(at.INCLUSIVE_GATEWAY, {
  width: go.width,
  height: go.height
});
pt.shapeConfigMap.set(at.EXCLUSIVE_GATEWAY, {
  width: mo.width,
  height: mo.height
});
pt.shapeConfigMap.set(at.SYSTEM, {
  width: yo.width,
  height: yo.height
});
pt.shapeConfigMap.set(at.USER, {
  width: bo.width,
  height: bo.height
});
pt.shapeConfigMap.set(at.SUBPROCESS, {
  width: xo.width,
  height: xo.height
});
var dc = (function(o) {
  Gl(n, o);
  function n(e) {
    var i = o.call(this, e) || this;
    i.adapterXmlIn = function(a) {
      var s = Fl(a);
      return i.adapterIn(s, i.props);
    }, i.adapterXmlOut = function(a) {
      var s = i.adapterOut(a, i.props);
      return Hl(s);
    };
    var t = e.lf, r = e.props;
    return t.adapterIn = i.adapterXmlIn, t.adapterOut = i.adapterXmlOut, i.props = r, i;
  }
  return n.pluginName = "BPMNAdapter", n;
})(pt), wi = function() {
  return wi = Object.assign || function(o) {
    for (var n, e = 1, i = arguments.length; e < i; e++) {
      n = arguments[e];
      for (var t in n) Object.prototype.hasOwnProperty.call(n, t) && (o[t] = n[t]);
    }
    return o;
  }, wi.apply(this, arguments);
}, Kl = function(o, n) {
  var e = typeof Symbol == "function" && o[Symbol.iterator];
  if (!e) return o;
  var i = e.call(o), t, r = [], a;
  try {
    for (; (n === void 0 || n-- > 0) && !(t = i.next()).done; ) r.push(t.value);
  } catch (s) {
    a = { error: s };
  } finally {
    try {
      t && !t.done && (e = i.return) && e.call(i);
    } finally {
      if (a) throw a.error;
    }
  }
  return r;
}, vi = {
  SEQUENCE_FLOW: 1,
  START_EVENT: 2,
  END_EVENT: 3,
  USER_TASK: 4,
  EXCLUSIVE_GATEWAY: 6
}, Ea = {
  1: "bpmn:sequenceFlow",
  2: "bpmn:startEvent",
  3: "bpmn:endEvent",
  4: "bpmn:userTask",
  6: "bpmn:exclusiveGateway"
};
function _a(o) {
  switch (o) {
    case "bpmn:sequenceFlow":
      return vi.SEQUENCE_FLOW;
    case "bpmn:startEvent":
      return vi.START_EVENT;
    case "bpmn:endEvent":
      return vi.END_EVENT;
    case "bpmn:userTask":
      return vi.USER_TASK;
    case "bpmn:exclusiveGateway":
      return vi.EXCLUSIVE_GATEWAY;
    default:
      return o;
  }
}
function ql(o) {
  var n = o.id, e = o.type, i = o.x, t = o.y, r = o.text, a = r === void 0 ? "" : r, s = o.properties;
  return {
    incoming: [],
    outgoing: [],
    dockers: [],
    type: _a(e),
    properties: wi(wi({}, s), {
      name: a && a.value || "",
      x: i,
      y: t,
      text: a
    }),
    key: n
  };
}
function Ql(o) {
  var n = o.id, e = o.type, i = o.sourceNodeId, t = o.targetNodeId, r = o.startPoint, a = o.endPoint, s = o.pointsList, d = o.text, l = d === void 0 ? "" : d, u = o.properties;
  return {
    incoming: [i],
    outgoing: [t],
    type: _a(e),
    dockers: [],
    properties: wi(wi({}, u), {
      name: l && l.value || "",
      text: l,
      startPoint: JSON.stringify(r),
      endPoint: JSON.stringify(a),
      pointsList: JSON.stringify(s)
    }),
    key: n
  };
}
function Zl(o) {
  var n = /* @__PURE__ */ new Map(), e = { flowElementList: [] };
  return o.nodes.forEach(function(i) {
    var t = ql(i);
    e.flowElementList.push(t), n.set(i.id, t);
  }), o.edges.forEach(function(i) {
    var t = Ql(i);
    n.get(i.sourceNodeId).outgoing.push(t.key), n.get(i.targetNodeId).incoming.push(t.key), e.flowElementList.push(t);
  }), e;
}
function Jl(o) {
  var n = o.incoming, e = o.outgoing, i = o.properties, t = o.key, r = o.type, a = i.text, s = i.name, d = i.startPoint, l = i.endPoint, u = i.pointsList, c = {
    id: t,
    type: Ea[r],
    sourceNodeId: n[0],
    targetNodeId: e[0],
    text: a || s,
    properties: {}
  };
  d && (c.startPoint = JSON.parse(d)), l && (c.endPoint = JSON.parse(l)), u && (c.pointsList = JSON.parse(u));
  var h = [
    "startPoint",
    "endPoint",
    "pointsList",
    "text"
  ];
  return Object.keys(o.properties).forEach(function(f) {
    h.indexOf(f) === -1 && (c.properties[f] = o.properties[f]);
  }), c;
}
function ed(o) {
  var n = o.properties, e = o.key, i = o.type, t = o.bounds, r = n.x, a = n.y, s = n.text;
  if (r === void 0) {
    var d = Kl(t, 2), l = d[0], u = l.x, c = l.y, h = d[1], f = h.x, p = h.y;
    r = (u + f) / 2, a = (c + p) / 2;
  }
  var v = {
    id: e,
    type: Ea[i],
    x: r,
    y: a,
    text: s,
    properties: {}
  }, g = [
    "x",
    "y",
    "text"
  ];
  return Object.keys(o.properties).forEach(function(b) {
    g.indexOf(b) === -1 && (v.properties[b] = o.properties[b]);
  }), v;
}
function td(o) {
  var n = {
    nodes: [],
    edges: []
  }, e = o.flowElementList;
  return e && e.length > 0 && e.forEach(function(i) {
    if (i.type === vi.SEQUENCE_FLOW) {
      var t = Jl(i);
      n.edges.push(t);
    } else {
      var r = ed(i);
      n.nodes.push(r);
    }
  }), n;
}
var uc = (function() {
  function o(n) {
    var e = n.lf;
    e.adapterIn = this.adapterIn, e.adapterOut = this.adapterOut;
  }
  return o.prototype.adapterOut = function(n) {
    if (n) return Zl(n);
  }, o.prototype.adapterIn = function(n) {
    if (n) return td(n);
  }, o.pluginName = "turboAdapter", o;
})(), id = function(o) {
  var n = typeof Symbol == "function" && Symbol.iterator, e = n && o[n], i = 0;
  if (e) return e.call(o);
  if (o && typeof o.length == "number") return { next: function() {
    return o && i >= o.length && (o = void 0), {
      value: o && o[i++],
      done: !o
    };
  } };
  throw new TypeError(n ? "Object is not iterable." : "Symbol.iterator is not defined.");
};
function No(o, n) {
  var e = o.minX, i = o.minY, t = o.maxX, r = o.maxY, a = n.x, s = n.y, d = n.width, l = n.height;
  return e >= a - d / 2 && t <= a + d / 2 && i >= s - l / 2 && r <= s + l / 2;
}
function nd(o, n, e, i) {
  var t = o.minX, r = o.minY, a = o.maxX, s = o.maxY, d = n.x, l = n.y, u = n.width, c = n.height, h = t + u / 2, f = r + c / 2, p = a - u / 2, v = s - c / 2;
  return {
    x: d + e >= h && d + e <= p,
    y: l + i >= f && l + i <= v
  };
}
function Ca(o, n) {
  var e, i;
  if (!o.children || o.children.size === 0) return null;
  var t = 1 / 0, r = 1 / 0, a = -1 / 0, s = -1 / 0, d = !1;
  try {
    for (var l = id(Array.from(o.children)), u = l.next(); !u.done; u = l.next()) {
      var c = u.value, h = n(c);
      if (h) {
        d = !0;
        var f = h.getBounds();
        t = Math.min(t, f.minX), r = Math.min(r, f.minY), a = Math.max(a, f.maxX), s = Math.max(s, f.maxY);
      }
    }
  } catch (p) {
    e = { error: p };
  } finally {
    try {
      u && !u.done && (i = l.return) && i.call(l);
    } finally {
      if (e) throw e.error;
    }
  }
  return d ? {
    minX: t,
    minY: r,
    maxX: a,
    maxY: s
  } : null;
}
function Sa(o, n) {
  return o.minX <= n.minX && o.minY <= n.minY && o.maxX >= n.maxX && o.maxY >= n.maxY;
}
var Yn = "0,0,0,0", To = "center";
function Na(o) {
  var n = o.x, e = o.y, i = o.width, t = o.height;
  return {
    bandLeft: n - i / 2,
    bandTop: e - t / 2 + 10,
    bandWidth: i,
    bandHeight: t - 10
  };
}
function rd(o) {
  var n = o.x, e = o.width, i = o.height, t = o.textAlign, r = o.pad, a = Na({
    x: n,
    y: o.y,
    width: e,
    height: i
  }), s = a.bandLeft, d = a.bandTop, l = a.bandWidth, u = s + r.left, c = s + l - r.right, h = d + r.top, f = u + Math.max(0, c - u) / 2;
  return t === "left" ? {
    x: u,
    y: h
  } : t === "right" ? {
    x: c,
    y: h
  } : {
    x: f,
    y: h
  };
}
function Ta(o) {
  var n = Na(o), e = n.bandLeft, i = n.bandTop, t = n.bandWidth, r = n.bandHeight, a = o.overflowMode, s = o.fontSize, d = o.pad;
  return {
    foX: e,
    foY: i,
    foWidth: t,
    foHeight: a === "ellipsis" ? d.top + s + 2 + d.bottom : r
  };
}
function ji(o) {
  if (o == null || o === "") return {
    top: 0,
    right: 0,
    bottom: 0,
    left: 0
  };
  if (typeof o == "number") {
    var n = Math.max(0, o);
    return {
      top: n,
      right: n,
      bottom: n,
      left: n
    };
  }
  var e = String(o).split(/[\s,]+/).filter(Boolean).map(function(i) {
    return parseFloat(i.replace(/px$/i, "")) || 0;
  });
  if (e.length === 1) {
    var n = e[0];
    return {
      top: n,
      right: n,
      bottom: n,
      left: n
    };
  }
  return e.length === 2 ? {
    top: e[0],
    right: e[1],
    bottom: e[0],
    left: e[1]
  } : e.length === 3 ? {
    top: e[0],
    right: e[1],
    bottom: e[2],
    left: e[1]
  } : {
    top: e[0],
    right: e[1],
    bottom: e[2],
    left: e[3]
  };
}
function od(o) {
  return o === "left" ? "start" : o === "right" ? "end" : "middle";
}
function ad(o) {
  return o === "autoWrap" || o === "ellipsis";
}
function Ma(o) {
  var n = ji(o);
  return "".concat(n.top, "px ").concat(n.right, "px ").concat(n.bottom, "px ").concat(n.left, "px");
}
var sd = /* @__PURE__ */ (function() {
  var o = function(n, e) {
    return o = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(i, t) {
      i.__proto__ = t;
    } || function(i, t) {
      for (var r in t) Object.prototype.hasOwnProperty.call(t, r) && (i[r] = t[r]);
    }, o(n, e);
  };
  return function(n, e) {
    if (typeof e != "function" && e !== null) throw new TypeError("Class extends value " + String(e) + " is not a constructor or null");
    o(n, e);
    function i() {
      this.constructor = n;
    }
    n.prototype = e === null ? Object.create(e) : (i.prototype = e.prototype, new i());
  };
})(), Ct = function() {
  return Ct = Object.assign || function(o) {
    for (var n, e = 1, i = arguments.length; e < i; e++) {
      n = arguments[e];
      for (var t in n) Object.prototype.hasOwnProperty.call(n, t) && (o[t] = n[t]);
    }
    return o;
  }, Ct.apply(this, arguments);
}, Un = function(o, n, e, i) {
  var t = arguments.length, r = t < 3 ? n : i === null ? i = Object.getOwnPropertyDescriptor(n, e) : i, a;
  if (typeof Reflect == "object" && typeof Reflect.decorate == "function") r = Reflect.decorate(o, n, e, i);
  else for (var s = o.length - 1; s >= 0; s--) (a = o[s]) && (r = (t < 3 ? a(r) : t > 3 ? a(n, e, r) : a(n, e)) || r);
  return t > 3 && r && Object.defineProperty(n, e, r), r;
}, di = function(o, n) {
  var e = typeof Symbol == "function" && o[Symbol.iterator];
  if (!e) return o;
  var i = e.call(o), t, r = [], a;
  try {
    for (; (n === void 0 || n-- > 0) && !(t = i.next()).done; ) r.push(t.value);
  } catch (s) {
    a = { error: s };
  } finally {
    try {
      t && !t.done && (e = i.return) && e.call(i);
    } finally {
      if (a) throw a.error;
    }
  }
  return r;
}, Oi = function(o, n, e) {
  if (e || arguments.length === 2)
    for (var i = 0, t = n.length, r; i < t; i++) (r || !(i in n)) && (r || (r = Array.prototype.slice.call(n, 0, i)), r[i] = n[i]);
  return o.concat(r || Array.prototype.slice.call(n));
}, ld = 400, dd = 230, ud = 80, cd = 60, hd = -1e4, Nr = (function(o) {
  sd(n, o);
  function n(e, i) {
    var t = o.call(this, e, i) || this;
    return t.isGroup = !0, t.isRestrict = !1, t.autoResize = !1, t.collapsible = !0, t.staticTextPosition = !0, t.isCollapsed = !1, t.groupAddable = !1, t.transformWithContainer = !1, t.childrenLastCollapseStateDict = /* @__PURE__ */ new Map(), t.childrenLastCollapseStateDict = /* @__PURE__ */ new Map(), t.initNodeData(e), t.setAttributes(), t;
  }
  return n.prototype.initNodeData = function(e) {
    var i;
    o.prototype.initNodeData.call(this, e);
    var t = (i = e.properties) !== null && i !== void 0 ? i : {}, r = t.children, a = t.width, s = t.height, d = t.collapsedWidth, l = t.collapsedHeight, u = t.collapsible, c = t.isCollapsed, h = t.zIndex, f = t.isRestrict, p = t.autoResize, v = t.autoToFront, g = t.transformWithContainer;
    this.children = r ? new Set(r) : /* @__PURE__ */ new Set(), this.zIndex = h != null ? h : hd, this.isCollapsed = c != null ? c : !1, this.setProperties({ isCollapsed: c != null ? c : !1 });
    var b = a != null ? a : ld, _ = s != null ? s : dd;
    this.width = b, this.height = _, this.expandWidth = b, this.expandHeight = _, this.collapsedWidth = d != null ? d : ud, this.collapsedHeight = l != null ? l : cd, this.isRestrict = f != null ? f : !1, this.transformWithContainer = g != null ? g : !1, this.autoResize = p != null ? p : !1, this.collapsible = u != null ? u : !0, this.autoToFront = v != null ? v : !1, this.setTextPosition(), this.text.draggable = !1;
  }, n.prototype.setAttributes = function() {
    o.prototype.setAttributes.call(this), this.setTextPosition();
  }, n.prototype.getTextStyle = function() {
    var e, i, t, r, a, s, d = o.prototype.getTextStyle.call(this), l = (r = (t = (i = (e = this.properties) === null || e === void 0 ? void 0 : e.textStyle) === null || i === void 0 ? void 0 : i.wrapPadding) !== null && t !== void 0 ? t : d.wrapPadding) !== null && r !== void 0 ? r : Yn, u = ji(l), c = Ct(Ct({ textAlign: To }, d), { wrapPadding: Ma(l) }), h = (a = c.overflowMode) !== null && a !== void 0 ? a : "default", f = Number((s = c.fontSize) !== null && s !== void 0 ? s : 12);
    return h === "ellipsis" && (c.textHeight = u.top + f + 2 + u.bottom), c.textAnchor = od(c.textAlign), c.dominantBaseline = "hanging", ft(c);
  }, n.prototype.setProperties = function(e) {
    o.prototype.setProperties.call(this, e);
  }, n.prototype.getData = function() {
    var e = this, i = o.prototype.getData.call(this), t = [];
    return be(Array.from(this.children), function(r) {
      var a = e.graphModel.getNodeModelById(r);
      a && !a.virtual && t.push(r);
    }), i.children = t, i.properties && (i.properties.children = t, i.properties.isCollapsed = this.isCollapsed), i;
  }, n.prototype.getNodesInGroup = function(e) {
    var i = [];
    return e.isGroup && be(Array.from(e.children), function(t) {
      i.push(t);
    }), i;
  }, n.prototype.getMoveDistance = function(e, i, t) {
    t === void 0 && (t = !1);
    var r = di(o.prototype.getMoveDistance.call(this, e, i, t), 2), a = r[0], s = r[1], d = this.getNodesInGroup(this);
    return this.graphModel.moveNodes(d, e, i, t), [a, s];
  }, n.prototype.getHistoryData = function() {
    var e = o.prototype.getHistoryData.call(this);
    e.children = Array.from(this.children), e.isGroup = !0;
    var i = this, t = i.x, r = i.y, a = i.collapsedWidth, s = i.collapsedHeight, d = i.expandWidth, l = i.expandHeight;
    return i.isCollapsed && (e.x = t + d / 2 - a / 2, e.y = r + l / 2 - s / 2, e.text && (e.text.x = e.text.x + d / 2 - a / 2, e.text.y = e.text.y + l / 2 - s / 2)), e;
  }, n.prototype.toggleCollapse = function(e) {
    var i = this, t = this.graphModel, r = !!e;
    this.isCollapsed = r, this.setProperties({ isCollapsed: r }), t.eventCenter.emit("dynamicGroup:collapse", {
      collapse: r,
      nodeModel: this
    }), r ? this.collapse() : this.expand();
    var a = Oi(Oi([], di(this.incoming.edges), !1), di(this.outgoing.edges), !1), s = Array.from(this.children);
    be(s, function(d) {
      var l, u, c = i.graphModel.elementsModelMap.get(d);
      if (c) {
        var h = c.isCollapsed;
        if (c.isGroup) {
          var f = c;
          if (f.isCollapsed || f.toggleCollapse(e), !e) {
            var p = (l = i.childrenLastCollapseStateDict) === null || l === void 0 ? void 0 : l.get(d);
            p !== void 0 && p !== c.isCollapsed && f.toggleCollapse(p);
          }
        }
        if ((u = i.childrenLastCollapseStateDict) === null || u === void 0 || u.set(d, !!h), c.visible = !e, c.BaseType === Za.NODE) {
          var v = c.incoming.edges, g = c.outgoing.edges;
          a = Oi(Oi(Oi([], di(a), !1), di(v), !1), di(g), !1);
        }
      }
    }), this.collapseEdge(r, a);
  }, n.prototype.getTitleHtmlRect = function() {
    var e, i, t, r, a, s = this.getTextStyle(), d = ji((t = (i = (e = this.properties) === null || e === void 0 ? void 0 : e.textStyle) === null || i === void 0 ? void 0 : i.wrapPadding) !== null && t !== void 0 ? t : Yn), l = ((r = s.overflowMode) !== null && r !== void 0 ? r : "default") === "ellipsis" ? "ellipsis" : "autoWrap";
    return Ta({
      x: this.x,
      y: this.y,
      width: this.width,
      height: this.height,
      overflowMode: l,
      fontSize: Number((a = s.fontSize) !== null && a !== void 0 ? a : 12),
      pad: d
    });
  }, n.prototype.updateExpandedSize = function(e, i) {
    this.expandWidth = e, this.expandHeight = i, this.setProperties({
      width: e,
      height: i
    });
  }, n.prototype.setTextPosition = function() {
    var e, i, t, r, a = this, s = a.x, d = a.y, l = a.width, u = a.height, c = a.text;
    if (c) {
      if (this.isCollapsed) {
        (c.x !== s || c.y !== d) && (this.text = Ct(Ct({}, c), {
          x: s,
          y: d
        }));
        return;
      }
      var h = this.getTextStyle(), f = ji((t = (i = (e = this.properties) === null || e === void 0 ? void 0 : e.textStyle) === null || i === void 0 ? void 0 : i.wrapPadding) !== null && t !== void 0 ? t : Yn), p = (r = h.textAlign) !== null && r !== void 0 ? r : To, v = rd({
        x: s,
        y: d,
        width: l,
        height: u,
        textAlign: p,
        pad: f
      }), g = v.x, b = v.y;
      (g !== c.x || b !== c.y) && (this.text = Ct(Ct({}, c), {
        x: g,
        y: b
      }));
    }
  }, n.prototype.collapse = function() {
    var e = this, i = e.x, t = e.y, r = e.width, a = e.height, s = e.collapsedWidth, d = e.collapsedHeight;
    this.x = i - r / 2 + s / 2, this.y = t - a / 2 + d / 2, this.expandWidth = r, this.expandHeight = a, this.width = s, this.height = d, this.setTextPosition();
  }, n.prototype.expand = function() {
    var e = this, i = e.x, t = e.y, r = e.expandWidth, a = e.expandHeight, s = e.collapsedWidth, d = e.collapsedHeight;
    this.width = r, this.height = a, this.x = i + this.width / 2 - s / 2, this.y = t + this.height / 2 - d / 2, this.setTextPosition();
  }, n.prototype.createVirtualEdge = function(e, i) {
    e.pointsList = void 0;
    var t = this.graphModel.addEdge(e);
    t.virtual = !0, t.text.editable = !1, t.isCollapsedEdge = !0;
    var r = this.graphModel.dynamicGroup;
    return r == null || r.registerCollapsedVirtualEdge(t.id, this.id, i), t;
  }, n.prototype.collapseEdge = function(e, i) {
    var t = this, r = this.graphModel;
    be(i, function(a, s) {
      var d, l = a.getData(), u = l.targetNodeId, c = l.sourceNodeId, h = Ct(Ct({}, l), {
        id: "".concat(l.id, "__").concat(s),
        text: (d = l.text) === null || d === void 0 ? void 0 : d.value
      });
      if (a.virtual) {
        var f = r.dynamicGroup;
        f == null || f.unregisterCollapsedVirtualEdge(a.id), r.deleteEdgeById(a.id);
        return;
      }
      var p = r.dynamicGroup.getGroupByNodeId(u);
      p || (p = r.getNodeModelById(u));
      var v = r.dynamicGroup.getGroupByNodeId(c);
      if (v || (v = r.getNodeModelById(c)), e && a.visible && (t.children.has(c) || t.id === c ? (h.startPoint = void 0, h.sourceNodeId = t.id, delete h.sourceAnchorId) : (h.endPoint = void 0, h.targetNodeId = t.id, delete h.targetAnchorId), (p.id !== t.id || v.id !== t.id) && t.createVirtualEdge(h, a.id), a.visible = !1), !e && !a.visible) {
        if (!r.getEdgeModelById(a.id)) return;
        p && p.isGroup && p.isCollapsed ? (h.targetNodeId = p.id, h.endPoint = void 0, delete h.targetAnchorId, t.createVirtualEdge(h, a.id)) : v && v.isGroup && v.isCollapsed ? (h.sourceNodeId = v.id, h.startPoint = void 0, delete h.sourceAnchorId, t.createVirtualEdge(h, a.id)) : a.visible = !0;
      }
    });
  }, n.prototype.isAllowAppendIn = function(e) {
    return !0;
  }, n.prototype.setAllowAppendChild = function(e) {
    this.groupAddable = e;
  }, n.prototype.addChild = function(e) {
    this.children.add(e);
    var i = this.getData();
    this.graphModel.eventCenter.emit(bt.GROUP_ADD_NODE, {
      data: i,
      childId: e
    });
  }, n.prototype.removeChild = function(e) {
    this.children.delete(e);
    var i = this.getData();
    this.graphModel.eventCenter.emit(bt.GROUP_REMOVE_NODE, { data: i });
  }, n.prototype.toBack = function() {
    this.zIndex--;
  }, n.prototype.isManualEdgeConnectAllowed = function() {
    var e, i = ((e = this.properties) !== null && e !== void 0 ? e : {}).allowEdgeConnect;
    if (i !== void 0) return i;
    var t = this.graphModel.dynamicGroup;
    return !(t != null && t.disallowEdgeConnectToGroup);
  }, n.prototype.getConnectedTargetRules = function() {
    var e = this, i = o.prototype.getConnectedTargetRules.call(this);
    return i.push({
      message: "分组节点不允许作为边的终点",
      validate: function() {
        return e.isManualEdgeConnectAllowed();
      }
    }), i;
  }, n.prototype.getConnectedSourceRules = function() {
    var e = this, i = o.prototype.getConnectedSourceRules.call(this);
    return i.push({
      message: "分组节点不允许作为边的起点",
      validate: function() {
        return e.isManualEdgeConnectAllowed();
      }
    }), i;
  }, n.prototype.getDefaultAnchor = function() {
    var e = o.prototype.getDefaultAnchor.call(this);
    return this.isManualEdgeConnectAllowed() ? e : e.map(function(i) {
      return Ct(Ct({}, i), { edgeAddable: !1 });
    });
  }, n.prototype.getAnchorStyle = function() {
    var e = o.prototype.getAnchorStyle.call(this);
    return e.stroke = "transparent", e.fill = "transparent", e.hover && (e.hover.fill = "transparent", e.hover.stroke = "transparent"), e;
  }, n.prototype.getAddableOutlineStyle = function() {
    var e, i = this.graphModel.dynamicGroup, t = (e = i == null ? void 0 : i.sensorOutline) !== null && e !== void 0 ? e : {}, r = t.stroke, a = t.strokeWidth;
    return {
      stroke: r != null ? r : Mo.stroke,
      strokeWidth: a != null ? a : Mo.strokeWidth,
      strokeDasharray: "4 4",
      fill: "transparent"
    };
  }, Un([ot], n.prototype, "isCollapsed", void 0), Un([ot], n.prototype, "groupAddable", void 0), Un([ot], n.prototype, "transformWithContainer", void 0), n;
})(Vi), Mo = {
  stroke: "#feb663",
  strokeWidth: 2
}, Re = {
  defaultWidth: 120,
  defaultHeight: 120,
  titleSize: 60,
  poolMinSize: 20
}, Ce = {
  defaultWidth: 120,
  defaultHeight: 120,
  titleSize: 20,
  iconSize: 20,
  iconSpacing: 15
}, fd = /* @__PURE__ */ (function() {
  var o = function(n, e) {
    return o = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(i, t) {
      i.__proto__ = t;
    } || function(i, t) {
      for (var r in t) Object.prototype.hasOwnProperty.call(t, r) && (i[r] = t[r]);
    }, o(n, e);
  };
  return function(n, e) {
    if (typeof e != "function" && e !== null) throw new TypeError("Class extends value " + String(e) + " is not a constructor or null");
    o(n, e);
    function i() {
      this.constructor = n;
    }
    n.prototype = e === null ? Object.create(e) : (i.prototype = e.prototype, new i());
  };
})(), Dt = function() {
  return Dt = Object.assign || function(o) {
    for (var n, e = 1, i = arguments.length; e < i; e++) {
      n = arguments[e];
      for (var t in n) Object.prototype.hasOwnProperty.call(n, t) && (o[t] = n[t]);
    }
    return o;
  }, Dt.apply(this, arguments);
}, pd = function(o, n, e, i) {
  var t = arguments.length, r = t < 3 ? n : i === null ? i = Object.getOwnPropertyDescriptor(n, e) : i, a;
  if (typeof Reflect == "object" && typeof Reflect.decorate == "function") r = Reflect.decorate(o, n, e, i);
  else for (var s = o.length - 1; s >= 0; s--) (a = o[s]) && (r = (t < 3 ? a(r) : t > 3 ? a(n, e, r) : a(n, e)) || r);
  return t > 3 && r && Object.defineProperty(n, e, r), r;
}, vd = (function(o) {
  fd(n, o);
  function n(e, i) {
    var t = o.call(this, e, i) || this;
    return t.titleSize = Re.titleSize, t.poolConfig = Re, t.isPool = !0, t._defaultLaneCreated = !1, t;
  }
  return Object.defineProperty(n.prototype, "isHorizontal", {
    get: function() {
      var e;
      return ((e = this.properties) === null || e === void 0 ? void 0 : e.direction) === "horizontal";
    },
    enumerable: !1,
    configurable: !0
  }), n.prototype.initNodeData = function(e) {
    var i, t;
    o.prototype.initNodeData.call(this, e), e.properties && (this.width = ((i = e.properties) === null || i === void 0 ? void 0 : i.width) || Re.defaultWidth, this.height = ((t = e.properties) === null || t === void 0 ? void 0 : t.height) || Re.defaultHeight), this.autoResize = !1, this.isRestrict = !0, this.transformWithContainer = !0, this.resizable = !1, this.rotatable = !1, this.autoToFront = !1, this.text.editable = !0, this.updateTextPosition(), this.addEventListeners(), this.resizePool();
  }, n.prototype.addEventListeners = function() {
    var e = this;
    this.graphModel.eventCenter.on("node:resize", function(i) {
      var t = i.data, r = i.index;
      if (e.children.has(t.id)) {
        var a = e.graphModel.getNodeModelById(t.id);
        if (!a || !a.type || a.type !== "lane") return;
        var s = e.getLanes(), d = void 0, l = void 0, u = 0, c = 0;
        if (e.isHorizontal) {
          var h = s.reduce(function(D, L) {
            return D + L.height;
          }, 0);
          d = a.width + Re.titleSize, l = h;
        } else {
          var f = s.reduce(function(D, L) {
            return D + L.width;
          }, 0);
          l = a.height + Re.titleSize, d = f;
        }
        var p = typeof r == "number" ? r : 2, v = p === 0 || p === 3, g = p === 0 || p === 1, b = v ? -1 : 1, _ = g ? -1 : 1;
        u = b * (d - e.width), c = _ * (l - e.height), e.width = d, e.height = l, e.move(u / 2, c / 2);
      }
      e.resizeChildren(), e.updateTextPosition();
    });
  }, n.prototype.getNodesInGroup = function(e) {
    var i = this, t = [];
    return e.isGroup && be(Array.from(e.children), function(r) {
      var a = i.graphModel.getNodeModelById(r);
      a && !a.isDragging && t.push(r);
    }), t;
  }, n.prototype.updateTextPosition = function() {
    this.isHorizontal ? (this.text.x = this.x - this.width / 2 + Re.titleSize / 2, this.text.y = this.y) : (this.text.x = this.x, this.text.y = this.y - this.height / 2 + Re.titleSize / 2);
  }, n.prototype.resizePool = function() {
    var e = this.getLanes();
    if (e.length !== 0) {
      var i = 0, t = 0;
      this.isHorizontal ? (be(e, function(r) {
        var a = r.width, s = r.height;
        i = Math.max(i, a), t += s;
      }), this.width = i + Re.titleSize, this.height = t) : (be(e, function(r) {
        var a = r.width, s = r.height;
        i += a, t = Math.max(t, s);
      }), this.width = i, this.height = t + Re.titleSize), this.updateTextPosition();
    }
  }, n.prototype.resizeChildrenWithNewLane = function(e, i) {
    var t = this, r, a = this.getLanes();
    if (!(!(e && i) || ti(a))) {
      var s = [], d = a.find(function(_) {
        return _.id === i;
      });
      if (s = a.filter(function(_) {
        return _.id !== i;
      }).slice().sort(function(_, D) {
        return t.isHorizontal ? _.y - D.y : _.x - D.x;
      }), d) {
        var l = (r = d.properties) === null || r === void 0 ? void 0 : r.referenceLaneId, u = l ? s.findIndex(function(_) {
          return _.id === l;
        }) : 0, c = ["above", "left"].includes(e) ? Math.max(u, 0) : Math.min(u + 1, s.length);
        s.splice(c, 0, d);
      }
      if (this.isHorizontal) {
        var h = this.width - Re.titleSize, f = s.reduce(function(_, D) {
          return _ + D.height;
        }, 0), p = this.y - f / 2;
        s.forEach(function(_, D) {
          var L = p + _.height / 2;
          _.text = Dt(Dt({}, _.text), {
            x: _.x - h / 2 + Ce.titleSize / 2,
            y: _.y
          }), t.moveLane(_, _.x, L), D < s.length - 1 && (p += _.height);
        }), this.height = f;
      } else {
        var v = this.height - Re.titleSize, g = s.reduce(function(_, D) {
          return _ + D.width;
        }, 0), b = this.x - g / 2;
        s.forEach(function(_, D) {
          var L = b + _.width / 2;
          _.text = Dt(Dt({}, _.text), {
            x: _.x,
            y: _.y - v / 2 + Ce.titleSize / 2
          }), t.moveLane(_, L, _.y), D < s.length - 1 && (b += _.width);
        }), this.width = g;
      }
      this.updateTextPosition();
    }
  }, n.prototype.moveLane = function(e, i, t) {
    var r = this, a = [];
    e.children && e.children.size > 0 && e.children.forEach(function(s) {
      var d = r.graphModel.getNodeModelById(s);
      d && !d.isDragging && String(d.type) !== "lane" && a.push({
        id: s,
        dx: d.x - e.x,
        dy: d.y - e.y
      });
    }), e.moveTo(i, t, !0), a.forEach(function(s) {
      var d = s.id, l = s.dx, u = s.dy, c = r.graphModel.getNodeModelById(d);
      if (c) {
        var h = c.x, f = c.y, p = e.x + l, v = e.y + u;
        c.moveTo(p, v);
        var g = c.incoming.edges, b = c.outgoing.edges;
        g.forEach(function(_) {
          _.moveEndPoint(p - h, v - f);
        }), b.forEach(function(_) {
          _.moveStartPoint(p - h, v - f);
        });
      }
    });
  }, n.prototype.resizeChildren = function() {
    var e = this, i = this.getLanes();
    if (i.length !== 0)
      if (this.isHorizontal) {
        this.height = i.reduce(function(a, s) {
          return a + s.height;
        }, 0);
        var t = i.slice().sort(function(a, s) {
          return a.y - s.y;
        });
        i.forEach(function(a) {
          a.width = e.width - Re.titleSize;
          var s = t.findIndex(function(l) {
            return l.id === a.id;
          }), d = t.reduce(function(l, u, c) {
            return c < s && u.id !== a.id ? l + u.height : l;
          }, e.y - e.height / 2);
          a.moveTo(e.x - e.width / 2 + Re.titleSize + a.width / 2, d + a.height / 2, !0);
        });
      } else {
        this.width = i.reduce(function(a, s) {
          return a + s.width;
        }, 0);
        var r = ft(i).sort(function(a, s) {
          return a.x - s.x;
        });
        i.forEach(function(a) {
          a.height = e.height - Re.titleSize;
          var s = r.findIndex(function(l) {
            return l.id === a.id;
          }), d = r.reduce(function(l, u, c) {
            return c < s && u.id !== a.id ? l + u.width : l;
          }, e.x - e.width / 2);
          a.moveTo(d + a.width / 2, e.y - e.height / 2 + Re.titleSize + a.height / 2, !0);
        });
      }
  }, n.prototype.getLanes = function() {
    var e = this, i = [];
    return Array.from(this.children).forEach(function(t) {
      var r = e.graphModel.getNodeModelById(t);
      r && String(r.type) === "lane" && i.push(r);
    }), i;
  }, n.prototype.addLane = function(e, i) {
    var t, r, a, s, d = this.getLanes();
    if (d.length === 0) return this.createDefaultLane(i);
    var l = this.x, u = this.y, c = d.find(function(_) {
      return _.id === (i == null ? void 0 : i.id);
    }), h = c || d[0], f = (t = h == null ? void 0 : h.width) !== null && t !== void 0 ? t : this.width, p = (r = h == null ? void 0 : h.height) !== null && r !== void 0 ? r : this.height;
    this.isHorizontal && ["above", "below"].includes(e) && c && (u = e === "above" ? c.y - c.height / 2 - p / 2 : c.y + c.height / 2 + p / 2, l = c.x), !this.isHorizontal && ["left", "right"].includes(e) && c && (l = e === "left" ? c.x - c.width / 2 - f / 2 : c.x + c.width / 2 + f / 2, u = c.y);
    var v = ft(i);
    v && (delete v.id, delete v.children, (a = v.properties) === null || a === void 0 || delete a.parent, (s = v.properties) === null || s === void 0 || delete s.children);
    var g = Hi(v, {
      type: "lane",
      x: l,
      y: u,
      width: f,
      height: p,
      text: "新泳道",
      properties: {
        parent: this.id,
        position: e,
        referenceLaneId: c == null ? void 0 : c.id
      },
      zIndex: this.zIndex
    }, this.properties.laneConfig), b = this.graphModel.addNode(g);
    return this.setZIndex(this.zIndex - 1), this.addChild(b.id), this.resizeChildrenWithNewLane(e, b.id), b;
  }, n.prototype.setZIndex = function(e) {
    this.zIndex = Math.min(e, -100);
  }, n.prototype.addChildAbove = function(e) {
    return this.addLane("above", e);
  }, n.prototype.addChildBelow = function(e) {
    return this.addLane("below", e);
  }, n.prototype.addChildLeft = function(e) {
    return this.addLane("left", e);
  }, n.prototype.addChildRight = function(e) {
    return this.addLane("right", e);
  }, n.prototype.createDefaultLane = function(e) {
    var i = null;
    if (this.isHorizontal) {
      var t = this.width - Re.titleSize, r = this.height;
      i = this.graphModel.addNode(Hi({
        type: "lane",
        x: this.x - this.width / 2 + Re.titleSize + t / 2,
        y: this.y,
        width: t,
        height: r,
        text: {
          x: this.x - this.width / 2 + Re.titleSize / 2,
          y: this.y,
          value: "泳道1"
        },
        properties: {
          parent: this.id,
          isHorizontal: this.isHorizontal
        },
        zIndex: this.zIndex
      }, e));
    } else {
      var t = this.width, r = this.height - Re.titleSize;
      i = this.graphModel.addNode(Hi({
        type: "lane",
        x: this.x,
        y: this.y - this.height / 2 + Re.titleSize + (this.height - Re.titleSize) / 2,
        width: t,
        height: r,
        text: {
          x: this.x,
          y: this.y - this.height / 2 + Re.titleSize / 2,
          value: "泳道1"
        },
        properties: { parent: this.id },
        zIndex: this.zIndex
      }, e));
    }
    return this.setZIndex(this.zIndex - 1), this.addChild(i.id), this.resizeChildren(), this.updateTextPosition(), i;
  }, n.prototype.deleteChild = function(e) {
    var i = this.getLanes();
    i.length <= 1 || i.find(function(t) {
      return t.id === e;
    }) && (this.removeChild(e), this.graphModel.deleteNode(e), this.resizePool(), this.resizeChildren());
  }, n.prototype.getNodeStyle = function() {
    var e = o.prototype.getNodeStyle.call(this);
    return e.strokeWidth = 2, e;
  }, n.prototype.getTextStyle = function() {
    var e = o.prototype.getTextStyle.call(this);
    return e.overflowMode = "ellipsis", e.strokeWidth = 2, e.textWidth = this.isHorizontal ? this.height : this.width, e.textHeight = this.isHorizontal ? this.width : this.height, this.isHorizontal && (e.transform = "rotate(-90deg)", e.textAlign = "center"), e;
  }, n.prototype.getData = function() {
    var e = o.prototype.getData.call(this);
    return Dt(Dt({}, e), { properties: Dt(Dt({}, e.properties), {
      width: this.width,
      height: this.height
    }) });
  }, pd([Va], n.prototype, "isHorizontal", null), n;
})(Nr), pr = /* @__PURE__ */ xr(Qa()), gd = /* @__PURE__ */ (function() {
  var o = function(n, e) {
    return o = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(i, t) {
      i.__proto__ = t;
    } || function(i, t) {
      for (var r in t) Object.prototype.hasOwnProperty.call(t, r) && (i[r] = t[r]);
    }, o(n, e);
  };
  return function(n, e) {
    if (typeof e != "function" && e !== null) throw new TypeError("Class extends value " + String(e) + " is not a constructor or null");
    o(n, e);
    function i() {
      this.constructor = n;
    }
    n.prototype = e === null ? Object.create(e) : (i.prototype = e.prototype, new i());
  };
})(), md = (function(o) {
  gd(n, o);
  function n() {
    return o !== null && o.apply(this, arguments) || this;
  }
  return n.prototype.getShape = function() {
    var e, i = this.props.model, t = i.text.value, r = i.getTextStyle(), a = (e = r.overflowMode) !== null && e !== void 0 ? e : "default";
    return ad(a) ? this.renderTitleHtmlText(t, r) : o.prototype.getShape.call(this);
  }, n.prototype.renderTitleHtmlText = function(e, i) {
    var t, r = this.props, a = r.model, s = r.graphModel, d = a.text, l = d.editable, u = d.draggable, c = s.editConfigModel, h = i.overflowMode, f = Number((t = i.fontSize) !== null && t !== void 0 ? t : 12), p = i.wrapPadding, v = ji(p), g = Ma(p), b = Ta({
      x: a.x,
      y: a.y,
      width: a.width,
      height: a.height,
      overflowMode: h,
      fontSize: f,
      pad: v
    }), _ = b.foX, D = b.foY, L = b.foWidth, W = b.foHeight, B = h === "ellipsis", K = String(e).split(/\r\n|\r|\n/g), Y = c.nodeTextDraggable || u;
    return Fe("g", {
      className: (0, pr.default)({
        "lf-element-text": l,
        "lf-text-draggable": !l && Y,
        "lf-text-disabled": !l && !Y
      }),
      children: Fe("foreignObject", {
        width: L,
        height: W,
        x: _,
        y: D,
        style: {
          overflow: "visible",
          textAlign: "left"
        },
        children: Fe("div", {
          className: "lf-node-text-auto-wrap lf-dg-title-html",
          style: {
            boxSizing: "border-box",
            display: "flex",
            alignItems: "flex-start",
            justifyContent: "stretch",
            width: L,
            height: W,
            padding: g
          },
          children: Fe("div", {
            className: B ? "lf-node-text-ellipsis-content" : "lf-node-text-auto-wrap-content",
            title: B ? K.join("") : "",
            style: {
              textAlign: i.textAlign,
              fontSize: f,
              lineHeight: i.lineHeight,
              fontFamily: i.fontFamily,
              color: i.fill,
              width: "100%"
            },
            children: K.map(function(te, se) {
              return Fe("div", {
                className: "lf-node-text--auto-wrap-inner",
                children: te
              }, se);
            })
          })
        })
      })
    });
  }, n;
})(ls);
function yd(o, n, e) {
  var i = o.x, t = o.y, r = o.width, a = o.height, s = n.x, d = n.y, l = n.width, u = n.height, c = e.x, h = e.y, f = (c - i) / r, p = (h - t) / a;
  return {
    x: s + f * l,
    y: d + p * u
  };
}
function Aa(o, n, e) {
  var i = n.x, t = n.y, r = o.x, a = o.y, s = r - i, d = a - t, l = s * Math.cos(e) - d * Math.sin(e), u = s * Math.sin(e) + d * Math.cos(e);
  return {
    x: l + i,
    y: u + t
  };
}
var bd = /* @__PURE__ */ (function() {
  var o = function(n, e) {
    return o = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(i, t) {
      i.__proto__ = t;
    } || function(i, t) {
      for (var r in t) Object.prototype.hasOwnProperty.call(t, r) && (i[r] = t[r]);
    }, o(n, e);
  };
  return function(n, e) {
    if (typeof e != "function" && e !== null) throw new TypeError("Class extends value " + String(e) + " is not a constructor or null");
    o(n, e);
    function i() {
      this.constructor = n;
    }
    n.prototype = e === null ? Object.create(e) : (i.prototype = e.prototype, new i());
  };
})(), Sn = function() {
  return Sn = Object.assign || function(o) {
    for (var n, e = 1, i = arguments.length; e < i; e++) {
      n = arguments[e];
      for (var t in n) Object.prototype.hasOwnProperty.call(n, t) && (o[t] = n[t]);
    }
    return o;
  }, Sn.apply(this, arguments);
}, xd = function(o, n) {
  var e = typeof Symbol == "function" && o[Symbol.iterator];
  if (!e) return o;
  var i = e.call(o), t, r = [], a;
  try {
    for (; (n === void 0 || n-- > 0) && !(t = i.next()).done; ) r.push(t.value);
  } catch (s) {
    a = { error: s };
  } finally {
    try {
      t && !t.done && (e = i.return) && e.call(i);
    } finally {
      if (a) throw a.error;
    }
  }
  return r;
}, wd = function(o, n, e) {
  if (e || arguments.length === 2)
    for (var i = 0, t = n.length, r; i < t; i++) (r || !(i in n)) && (r || (r = Array.prototype.slice.call(n, 0, i)), r[i] = n[i]);
  return o.concat(r || Array.prototype.slice.call(n));
}, Tr = (function(o) {
  bd(n, o);
  function n() {
    var e = o.apply(this, wd([], xd(arguments), !1)) || this;
    return e.childrenPositionMap = /* @__PURE__ */ new Map(), e.onNodeRotate = function(i) {
      var t = i.model, r = e.props, a = r.model, s = r.graphModel, d = a.transformWithContainer, l = a.isRestrict, u = e.childrenPositionMap;
      if (!(!d || l) && t.id === a.id) {
        var c = {
          x: a.x,
          y: a.y
        };
        be(Array.from(a.children), function(h) {
          var f = s.getNodeModelById(h);
          if (f) {
            var p = {
              x: f.x,
              y: f.y
            };
            u.has(f.id) ? p = u.get(f.id) : u.set(f.id, p);
            var v = t.rotate * (180 / Math.PI);
            v < 0 && (v += 360);
            var g = v * (Math.PI / 180), b = Aa(p, c, g);
            f.moveTo(b.x, b.y), f.rotate = t.rotate;
          }
        });
      }
    }, e.onNodeResize = function(i) {
      var t = i.deltaX, r = i.deltaY, a = i.index, s = i.model, d = i.preData, l = e.props, u = l.model, c = l.graphModel, h = u.transformWithContainer, f = u.isRestrict;
      if (!(!h || f) && s.id === u.id) {
        var p = d.properties || {}, v = p.width, g = p.height;
        be(Array.from(u.children), function(b) {
          var _ = c.getNodeModelById(b);
          if (_) {
            var D = _.width / v * t, L = _.height / g * r;
            Ka({
              deltaX: D,
              deltaY: L,
              index: a,
              nodeModel: _,
              graphModel: c,
              cancelCallback: function() {
              }
            });
          }
        });
      }
    }, e.onNodeMouseMove = function() {
    }, e.graphRendered = function() {
      var i = e.props.model;
      i.isCollapsed && i.toggleCollapse(!0);
    }, e;
  }
  return n.prototype.componentDidMount = function() {
    o.prototype.componentDidMount.call(this);
    var e = this.props.graphModel.eventCenter;
    e.on(oe.NODE_ROTATE, this.onNodeRotate), e.on(oe.NODE_RESIZE, this.onNodeResize), e.on(oe.NODE_MOUSEMOVE, this.onNodeMouseMove), e.on(oe.GRAPH_RENDERED, this.graphRendered);
  }, n.prototype.componentWillUnmount = function() {
    o.prototype.componentWillUnmount.call(this);
    var e = this.props.graphModel.eventCenter;
    e.off(oe.NODE_ROTATE, this.onNodeRotate), e.off(oe.NODE_RESIZE, this.onNodeResize), e.off(oe.NODE_MOUSEMOVE, this.onNodeMouseMove), e.off(oe.GRAPH_RENDERED, this.graphRendered);
  }, n.prototype.getNodesInGroup = function(e, i) {
    var t = this, r = [];
    return e.isGroup && be(Array.from(e.children), function(a) {
      r.push(a);
      var s = i.getNodeModelById(a);
      s != null && s.isGroup && (r = r.concat(t.getNodesInGroup(s, i)));
    }), r;
  }, n.prototype.getResizeControl = function() {
    var e = this.props.model, i = e.resizable, t = e.isCollapsed;
    return i && !t ? o.prototype.getResizeControl.call(this) : null;
  }, n.prototype.getAppendAreaShape = function() {
    var e = this.props.model, i = e.width, t = e.height, r = e.x, a = e.y, s = e.radius;
    if (!e.groupAddable) return null;
    var d = e.getNodeStyle().strokeWidth, l = d === void 0 ? 0 : d, u = e.getAddableOutlineStyle(), c = i + l + 8, h = t + l + 8;
    return I("rect", Sn(Sn({}, u), {
      width: c,
      height: h,
      x: r - c / 2,
      y: a - h / 2,
      rx: s,
      ry: s
    }));
  }, n.prototype.getCollapseIcon = function(e, i) {
    return "M ".concat(e + 3, ",").concat(i + 6, " ").concat(e + 11, ",").concat(i + 6, " M").concat(e + 7, ",").concat(i + 2, " ").concat(e + 7, ",").concat(i + 10);
  }, n.prototype.getExpandIcon = function(e, i) {
    return "M ".concat(e + 3, ",").concat(i + 6, " ").concat(e + 11, ",").concat(i + 6, " ");
  }, n.prototype.getOperateIcon = function() {
    var e = this.props.model, i = e.x, t = e.y, r = e.width, a = e.height, s = i - r / 2 + 10, d = t - a / 2 + 10;
    if (!e.collapsible) return null;
    var l = e != null && e.isCollapsed ? this.getCollapseIcon(s, d) : this.getExpandIcon(s, d), u = I("path", {
      fill: "none",
      stroke: "#818281",
      strokeWidth: 2,
      "pointer-events": "none",
      d: l
    });
    return I("g", {}, [I("rect", {
      height: 12,
      width: 14,
      rx: 2,
      ry: 2,
      strokeWidth: 1,
      fill: "#f4f5f6",
      stroke: "#cecece",
      cursor: "pointer",
      x: s,
      y: d,
      onPointerDown: function(c) {
        c.stopPropagation();
      },
      onClick: function(c) {
        c.stopPropagation(), e.toggleCollapse(!e.isCollapsed);
      },
      onDblClick: function(c) {
        c.stopPropagation();
      }
    }), u]);
  }, n.prototype.getText = function() {
    var e, i = this.props, t = i.model, r = i.graphModel, a = r.editConfigModel;
    if (a.nodeTextMode !== qt.TEXT || t.state === sr.TEXT_EDIT) return null;
    var s = null;
    if (t.text) {
      var d = !1;
      a.nodeTextDraggable && t.text.draggable && (d = !0), s = I(md, {
        editable: a.nodeTextEdit && ((e = t.text.editable) !== null && e !== void 0 ? e : !0),
        model: t,
        graphModel: r,
        draggable: d
      });
    }
    var l = this.getOperateIcon();
    return !s && !l ? null : I("g", {}, s, l);
  }, n.prototype.getShape = function() {
    return I("g", {}, [this.getAppendAreaShape(), o.prototype.getShape.call(this)]);
  }, n;
})(_i), Ed = /* @__PURE__ */ (function() {
  var o = function(n, e) {
    return o = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(i, t) {
      i.__proto__ = t;
    } || function(i, t) {
      for (var r in t) Object.prototype.hasOwnProperty.call(t, r) && (i[r] = t[r]);
    }, o(n, e);
  };
  return function(n, e) {
    if (typeof e != "function" && e !== null) throw new TypeError("Class extends value " + String(e) + " is not a constructor or null");
    o(n, e);
    function i() {
      this.constructor = n;
    }
    n.prototype = e === null ? Object.create(e) : (i.prototype = e.prototype, new i());
  };
})(), Pt = function() {
  return Pt = Object.assign || function(o) {
    for (var n, e = 1, i = arguments.length; e < i; e++) {
      n = arguments[e];
      for (var t in n) Object.prototype.hasOwnProperty.call(n, t) && (o[t] = n[t]);
    }
    return o;
  }, Pt.apply(this, arguments);
}, _d = (function(o) {
  Ed(n, o);
  function n() {
    return o !== null && o.apply(this, arguments) || this;
  }
  return n.prototype.componentDidMount = function() {
    var e, i, t, r = this.props, a = r.graphModel, s = r.model, d = a.nodes.findIndex(function(u) {
      return u.id === s.id;
    }), l = a.nodes.filter(function(u) {
      return String(u.type) === "pool";
    }).length;
    s.setZIndex(-((l - d) * 100)), !(!((i = (e = s.properties) === null || e === void 0 ? void 0 : e.children) === null || i === void 0) && i.length) && !s._defaultLaneCreated && !s.virtual && (s.createDefaultLane((t = s.properties) === null || t === void 0 ? void 0 : t.laneConfig), s._defaultLaneCreated = !0);
  }, n.prototype.getShape = function() {
    var e = this.props.model, i = e.x, t = e.y, r = e.width, a = e.height, s = e.properties, d = s.textStyle, l = d === void 0 ? {} : d, u = s.style, c = u === void 0 ? {} : u, h = e.isHorizontal, f = e.getNodeStyle(), p = {
      fill: "#ffffff",
      stroke: "#000000",
      strokeWidth: 1
    }, v = i - r / 2, g = t - a / 2, b = Pt(Pt(Pt(Pt({}, p), f), {
      x: v,
      y: g,
      width: h ? Re.titleSize : r,
      height: h ? a : Re.titleSize
    }), h && l), _ = Pt(Pt(Pt(Pt({}, p), f), {
      x: h ? v + Re.titleSize : v,
      y: h ? g : g + Re.titleSize,
      width: h ? r - Re.titleSize : r,
      height: h ? a : a - Re.titleSize
    }), h && c);
    return I("g", {}, [I("rect", b), I("rect", _)]);
  }, n.prototype.getResizeControl = function() {
    var e = this.props.model, i = e.resizable, t = e.isCollapsed;
    return i && !t ? o.prototype.getResizeControl.call(this) : null;
  }, n;
})(Tr), Nn = function() {
  return Nn = Object.assign || function(o) {
    for (var n, e = 1, i = arguments.length; e < i; e++) {
      n = arguments[e];
      for (var t in n) Object.prototype.hasOwnProperty.call(n, t) && (o[t] = n[t]);
    }
    return o;
  }, Nn.apply(this, arguments);
}, ui = function(o, n) {
  var e = typeof Symbol == "function" && o[Symbol.iterator];
  if (!e) return o;
  var i = e.call(o), t, r = [], a;
  try {
    for (; (n === void 0 || n-- > 0) && !(t = i.next()).done; ) r.push(t.value);
  } catch (s) {
    a = { error: s };
  } finally {
    try {
      t && !t.done && (e = i.return) && e.call(i);
    } finally {
      if (a) throw a.error;
    }
  }
  return r;
}, ci = function(o, n, e) {
  if (e || arguments.length === 2)
    for (var i = 0, t = n.length, r; i < t; i++) (r || !(i in n)) && (r || (r = Array.prototype.slice.call(n, 0, i)), r[i] = n[i]);
  return o.concat(r || Array.prototype.slice.call(n));
}, Mr = {
  type: "dynamic-group",
  view: Tr,
  model: Nr
}, Cd = -1e3, Di = -1e4, cc = (function() {
  function o(n) {
    var e = n.lf, i = n.options, t = this;
    this.disallowEdgeConnectToGroup = !1, this.cascadeDeleteChildren = !0, this.topGroupZIndex = Di, this.activeGroups = /* @__PURE__ */ new Set(), this.nodeGroupMap = /* @__PURE__ */ new Map(), this.collapsedVirtualEdges = /* @__PURE__ */ new Map(), this.collapsedRealEdgeToGroup = /* @__PURE__ */ new Map(), this.onEdgeDelete = function(r) {
      var a = r.data, s = t.collapsedVirtualEdges.get(a.id);
      if (s) {
        t.collapsedVirtualEdges.delete(a.id), t.collapsedRealEdgeToGroup.delete(s.realEdgeId), t.lf.getEdgeModelById(s.realEdgeId) && t.lf.deleteEdge(s.realEdgeId);
        return;
      }
      t.collapsedRealEdgeToGroup.get(a.id) && t.collapsedRealEdgeToGroup.delete(a.id);
      var d = [];
      t.collapsedVirtualEdges.forEach(function(l, u) {
        l.realEdgeId === a.id && d.push(u);
      }), d.forEach(function(l) {
        t.collapsedVirtualEdges.delete(l), t.lf.getEdgeModelById(l) && t.lf.deleteEdge(l);
      });
    }, this.onSelectionDrop = function() {
      t.clearDragTargetHighlight(), t.lf.graphModel.getSelectElements().nodes.forEach(function(r) {
        t.addNodeToGroup(r);
      });
    }, this.onNodeAdd = function(r) {
      var a = r.data;
      t.syncGroupChildren(a);
    }, this.onNodeDndAdd = function(r) {
      var a = r.data;
      t.syncGroupChildren(a), t.addNodeToGroup(a), t.clearDragTargetHighlight();
    }, this.onNodeDrop = function(r) {
      var a = r.data;
      t.clearDragTargetHighlight(), t.addNodeToGroup(a);
    }, this.onNodeMouseUp = function() {
      t.clearDragTargetHighlight();
    }, this.detachNodeFromGroup = function(r, a) {
      var s = t.lf.getNodeModelById(r);
      s && (s.removeChild(a), t.nodeGroupMap.delete(a), s.setAllowAppendChild(!1));
    }, this.releaseGroupMembers = function(r) {
      r.isCollapsed && r.toggleCollapse(!1), be(Array.from(r.children), function(a) {
        t.detachNodeFromGroup(r.id, a);
      });
    }, this.removeChildFromOtherGroups = function(r, a) {
      var s = t.nodeGroupMap.get(r);
      if (s && s !== a) {
        var d = t.lf.getNodeModelById(s);
        d == null || d.removeChild(r);
      }
      be(t.lf.graphModel.nodes, function(l) {
        var u;
        if (!(!l.isGroup || l.id === a)) {
          var c = l;
          !((u = c.children) === null || u === void 0) && u.has(r) && c.removeChild(r);
        }
      });
    }, this.setNodeGroup = function(r, a) {
      t.removeChildFromOtherGroups(a, r), t.nodeGroupMap.set(a, r);
    }, this.syncGroupChildren = function(r) {
      var a = t.lf.getNodeModelById(r.id);
      if (a != null && a.isGroup) {
        var s = a;
        be(Array.from(s.children), function(d) {
          t.setNodeGroup(r.id, d);
        }), t.calibrateTopGroupZIndex([r]), t.onNodeSelect({
          data: r,
          isSelected: !1,
          isMultiple: !1
        });
      }
    }, this.addNodeToGroup = function(r) {
      var a = t.lf.getNodeModelById(r.id), s = a == null ? void 0 : a.getBounds();
      if (!(!a || !s)) {
        var d = t.nodeGroupMap.get(r.id), l = t.getGroupByBounds(s, r);
        if (!(d && (l == null ? void 0 : l.id) === d)) {
          if (!l) {
            d && t.detachNodeFromGroup(d, r.id);
            return;
          }
          if (!d) {
            l.isAllowAppendIn(r) ? l.addChild(r.id) : t.lf.emit(bt.GROUP_NOT_ALLOWED, {
              group: l.getData(),
              node: r
            });
            return;
          }
          if (l.isAllowAppendIn(r))
            t.detachNodeFromGroup(d, r.id), l.addChild(r.id);
          else {
            var u = t.lf.getNodeModelById(d);
            if (u && No(s, u)) return;
            t.detachNodeFromGroup(d, r.id), t.lf.emit(bt.GROUP_NOT_ALLOWED, {
              group: l.getData(),
              node: r
            });
          }
        }
      }
    }, this.onGroupAddNode = function(r) {
      var a = r.data, s = r.childId;
      t.setNodeGroup(a.id, s);
    }, this.removeNodeFromGroup = function(r) {
      var a = r.data, s = r.model;
      if (s.isGroup && a.children) {
        var d = s;
        t.cascadeDeleteChildren ? be(Array.from(d.children), function(c) {
          t.nodeGroupMap.delete(c), t.lf.deleteNode(c);
        }) : d.children.size > 0 && t.releaseGroupMembers(d);
      }
      var l = t.nodeGroupMap.get(a.id);
      if (l) {
        var u = t.lf.getNodeModelById(l);
        u && u.removeChild(a.id), t.nodeGroupMap.delete(a.id);
      }
    }, this.onSelectionDrag = function() {
      var r = t.lf.graphModel.getSelectElements().nodes, a = /* @__PURE__ */ new Set();
      r.forEach(function(s) {
        var d = t.getTargetGroupForNode(s);
        d && a.add(d);
      }), t.activeGroups.forEach(function(s) {
        a.has(s) || s.setAllowAppendChild(!1);
      }), a.forEach(function(s) {
        t.activeGroups.has(s) || s.setAllowAppendChild(!0);
      }), t.activeGroups = a;
    }, this.onNodeDrag = function(r) {
      var a = r.data;
      t.setActiveGroup(a);
    }, this.setActiveGroup = function(r) {
      var a = t.getTargetGroupForNode(r), s = /* @__PURE__ */ new Set();
      a && s.add(a), t.activeGroups.forEach(function(d) {
        s.has(d) || d.setAllowAppendChild(!1);
      }), s.forEach(function(d) {
        t.activeGroups.has(d) || d.setAllowAppendChild(!0);
      }), t.activeGroups = s;
    }, this.onNodeSelect = function(r) {
      var a = r.data, s = r.isMultiple, d = r.isSelected, l = t.lf.getNodeModelById(a.id);
      if (t.sendNodeToFront(l), t.topGroupZIndex > Cd) {
        var u = t.lf.graphModel.nodes;
        t.topGroupZIndex = Di;
        var c = As(gi(u, function(g) {
          return !!g.isGroup;
        }), "zIndex"), h = 0;
        be(c, function(g) {
          g.zIndex !== h && (t.topGroupZIndex++, h = g.zIndex), g.setZIndex(t.topGroupZIndex);
        });
      }
      if (s && d)
        if (l != null && l.isGroup) {
          var f = l.children;
          be(Array.from(f), function(g) {
            var b = t.lf.getNodeModelById(g);
            b == null || b.setSelected(!1);
          });
        } else {
          var p = t.nodeGroupMap.get(a.id);
          if (p) {
            var v = t.lf.getNodeModelById(p);
            v != null && v.isSelected && (l == null || l.setSelected(!1));
          }
        }
    }, this.onNodeMove = function(r) {
      var a = r.data.id, s = t.nodeGroupMap.get(a);
      if (s) {
        var d = t.lf.getNodeModelById(s);
        if (!(!d || !d.isRestrict || !d.autoResize)) {
          var l = t.lf.getNodeModelById(a);
          if (l) {
            var u = l.getBounds(), c = u.minX, h = u.minY, f = u.maxX, p = u.maxY, v = !1, g = d.getBounds(), b = Object.assign({}, g);
            if (c < b.minX && (b.minX = c, v = !0), h < b.minY && (b.minY = h, v = !0), f > b.maxX && (b.maxX = f, v = !0), p > b.maxY && (b.maxY = p, v = !0), !!v) {
              var _ = b.minX + (b.maxX - b.minX) / 2, D = b.minY + (b.maxY - b.minY) / 2, L = b.maxX - b.minX, W = b.maxY - b.minY;
              d.moveTo(_, D), d.width = L, d.height = W, d.updateExpandedSize(L, W), d.setTextPosition();
            }
          }
        }
      }
    }, this.onNodeResize = function(r) {
      var a = r.model;
      a != null && a.isGroup && !a.isCollapsed && a.setTextPosition();
    }, this.onGraphRendered = function(r) {
      var a = r.data;
      t.nodeGroupMap.clear(), t.collapsedVirtualEdges.clear(), t.collapsedRealEdgeToGroup.clear(), t.activeGroups.clear(), t.topGroupZIndex = Di, be(a.nodes, function(s) {
        s.children && be(s.children, function(d) {
          t.nodeGroupMap.set(d, s.id);
        });
      }), t.calibrateTopGroupZIndex(a.nodes);
    }, e.register(Mr), this.lf = e, Rn(this, i), this.init();
  }
  return o.prototype.getGroupByNodeId = function(n) {
    var e = this.nodeGroupMap.get(n);
    if (e) return this.lf.getNodeModelById(e);
  }, o.prototype.registerCollapsedVirtualEdge = function(n, e, i) {
    this.collapsedVirtualEdges.set(n, {
      groupId: e,
      realEdgeId: i
    }), this.collapsedRealEdgeToGroup.set(i, e);
  }, o.prototype.unregisterCollapsedVirtualEdge = function(n) {
    var e = this.collapsedVirtualEdges.get(n);
    e && (this.collapsedVirtualEdges.delete(n), this.collapsedRealEdgeToGroup.get(e.realEdgeId) === e.groupId && this.collapsedRealEdgeToGroup.delete(e.realEdgeId));
  }, o.prototype.getGroupByBounds = function(n, e) {
    var i = this.lf.graphModel.nodes, t = gi(i, function(d) {
      return !!d.isGroup && No(n, d) && d.id !== e.id;
    }), r = t.length;
    if (r <= 1) return t[0];
    for (var a = t[r - 1], s = r - 2; s >= 0; s--) t[s].zIndex > a.zIndex && (a = t[s]);
    return a;
  }, o.prototype.sendNodeToFront = function(n) {
    var e = this;
    if (!(!n || !n.isGroup) && (this.topGroupZIndex++, n.setZIndex(this.topGroupZIndex), n.children)) {
      var i = n.children;
      be(Array.from(i), function(t) {
        var r = e.lf.getNodeModelById(t);
        e.sendNodeToFront(r);
      });
    }
  }, o.prototype.getMaxZIndex = function(n) {
    var e = this, i = Di;
    if (n.isGroup && (i = Math.max(i, n.zIndex)), n.children) {
      var t = n.children;
      be(Array.from(t), function(r) {
        var a = e.lf.getNodeModelById(r);
        if (a != null && a.isGroup) {
          var s = e.getMaxZIndex(a);
          i = Math.max(i, s);
        }
      });
    }
    return i;
  }, o.prototype.calibrateTopGroupZIndex = function(n) {
    var e = this, i = Di;
    if (be(n, function(s) {
      var d = e.lf.getNodeModelById(s.id);
      if (d) {
        var l = e.getMaxZIndex(d);
        l > i && (i = l);
      }
    }), !(this.topGroupZIndex >= i)) {
      var t = this.lf.graphModel.nodes, r = gi(t, function(s) {
        return !!s.isGroup;
      }), a = this.topGroupZIndex;
      be(r, function(s) {
        s.zIndex > a && (a = s.zIndex);
      }), this.topGroupZIndex = a;
    }
  }, o.prototype.clearDragTargetHighlight = function() {
    this.activeGroups.forEach(function(n) {
      n.setAllowAppendChild(!1);
    }), this.activeGroups.clear();
  }, o.prototype.getTargetGroupForNode = function(n) {
    var e = this.lf.getNodeModelById(n.id), i = e == null ? void 0 : e.getBounds();
    if (!(!e || !i)) {
      var t = this.getGroupByBounds(i, n);
      if (t && !(e.isGroup && t.id === n.id) && t.isAllowAppendIn(n))
        return t;
    }
  }, o.prototype.removeChildrenInGroupNodeData = function(n) {
    var e, i = ft(n);
    return delete i.children, !((e = i.properties) === null || e === void 0) && e.children && delete i.properties.children, i;
  }, o.prototype.initGroupChildNodes = function(n, e, i, t) {
    var r = this, a = [], s = [], d = [];
    be(Array.from(e), function(c) {
      var h = r.lf.getNodeModelById(c);
      if (h) {
        var f = h.children, p = h.getData(), v = oe.NODE_GROUP_COPY || "node:group-copy-add", g = Zo(r.removeChildrenInGroupNodeData(p), t), b = r.lf.addNode(g, v);
        if (i.addChild(b.id), n[c] = b.id, a.push(b), d.push.apply(d, ci([], ui(ci(ci([], ui(b.incoming.edges), !1), ui(b.outgoing.edges), !1)), !1)), f instanceof Set) {
          var _ = r.initGroupChildNodes(n, f, b, t), D = _.childNodes, L = _.edgesData;
          a.push.apply(a, ci([], ui(D), !1)), s.push.apply(s, ci([], ui(L), !1));
        }
      }
    });
    var l = gi(d, function(c) {
      return Yi(n, c.sourceNodeId) && Yi(n, c.targetNodeId);
    }), u = Jt(l, function(c) {
      return c.getData();
    });
    return {
      childNodes: a,
      edgesData: s.concat(u)
    };
  }, o.prototype.createEdge = function(n, e, i) {
    var t, r, a = n.sourceNodeId, s = n.targetNodeId, d = (t = e[a]) !== null && t !== void 0 ? t : a, l = (r = e[s]) !== null && r !== void 0 ? r : s, u = ft(n);
    return n.id && typeof n.text == "object" && n.text !== null && (u = Jo(n, i)), this.lf.graphModel.addEdge(Nn(Nn({}, u), {
      sourceNodeId: d,
      targetNodeId: l
    }));
  }, o.prototype.checkGroupBoundsWithChildren = function(n, e, i, t, r) {
    var a = this, s = Ca(n, function(c) {
      return a.lf.getNodeModelById(c);
    });
    if (!s) return !0;
    var d = n.x + e / 2, l = n.y + i / 2, u = {
      minX: d - t / 2,
      minY: l - r / 2,
      maxX: d + t / 2,
      maxY: l + r / 2
    };
    return Sa(u, s);
  }, o.prototype.init = function() {
    var n = this, e = this.lf, i = e.graphModel;
    i.addNodeMoveRules(function(t, r, a) {
      if (t.isGroup) return !0;
      var s = n.nodeGroupMap.get(t.id), d = n.lf.getNodeModelById(s);
      if (d && d.isRestrict) {
        if (d.autoResize) return !0;
        var l = d.getBounds();
        return nd(l, t, r, a);
      }
      return !0;
    }), i.addNodeResizeRules(function(t, r, a, s, d) {
      return t.isGroup ? n.checkGroupBoundsWithChildren(t, r, a, s, d) : !0;
    }), i.dynamicGroup = this, this.originDeleteNode = e.deleteNode.bind(e), e.deleteNode = function(t) {
      var r = e.getNodeModelById(t);
      if (!n.cascadeDeleteChildren && (r != null && r.isGroup)) {
        var a = r;
        a.children.size > 0 && n.releaseGroupMembers(a);
      }
      return n.originDeleteNode(t);
    }, e.on(oe.NODE_ADD, this.onNodeAdd), e.on(oe.NODE_DND_ADD, this.onNodeDndAdd), e.on(oe.NODE_DROP, this.onNodeDrop), e.on(oe.NODE_MOUSEUP, this.onNodeMouseUp), e.on(oe.SELECTION_DROP, this.onSelectionDrop), e.on(oe.NODE_DELETE, this.removeNodeFromGroup), e.on(oe.EDGE_DELETE, this.onEdgeDelete), e.on(Ui, this.onNodeDrag), e.on(oe.SELECTION_DRAG, this.onSelectionDrag), e.on(oe.NODE_CLICK, this.onNodeSelect), e.on(oe.NODE_MOUSEMOVE, this.onNodeMove), e.on(oe.NODE_RESIZE, this.onNodeResize), e.on(oe.GRAPH_RENDERED, this.onGraphRendered), e.on(bt.GROUP_ADD_NODE, this.onGroupAddNode), e.addElements = function(t, r) {
      var a = t.nodes, s = t.edges;
      r === void 0 && (r = 0);
      var d = {}, l = {
        nodes: [],
        edges: []
      }, u = [];
      return be(a, function(c) {
        var h, f, p = c.id, v = (f = (h = c.properties) === null || h === void 0 ? void 0 : h.children) !== null && f !== void 0 ? f : c.children, g = e.addNode(n.removeChildrenInGroupNodeData(c));
        if (p && (d[p] = g.id), l.nodes.push(g), g.isGroup) {
          var b = n.initGroupChildNodes(d, v, g, r).edgesData;
          u.push.apply(u, ci([], ui(b), !1));
        }
      }), be(u, function(c) {
        n.createEdge(c, d, r);
      }), be(s, function(c) {
        l.edges.push(n.createEdge(c, d, r));
      }), l;
    }, this.render();
  }, o.prototype.render = function() {
  }, o.prototype.destroy = function() {
    this.lf.off(oe.NODE_ADD, this.onNodeAdd), this.lf.off(oe.NODE_DND_ADD, this.onNodeDndAdd), this.lf.off(oe.NODE_DROP, this.onNodeDrop), this.lf.off(oe.NODE_MOUSEUP, this.onNodeMouseUp), this.lf.off(oe.SELECTION_DROP, this.onSelectionDrop), this.lf.off(oe.NODE_DELETE, this.removeNodeFromGroup), this.lf.off(oe.EDGE_DELETE, this.onEdgeDelete), this.lf.off(Ui, this.onNodeDrag), this.lf.off(oe.SELECTION_DRAG, this.onSelectionDrag), this.lf.off(oe.NODE_CLICK, this.onNodeSelect), this.lf.off(oe.NODE_MOUSEMOVE, this.onNodeMove), this.lf.off(oe.NODE_RESIZE, this.onNodeResize), this.lf.off(oe.GRAPH_RENDERED, this.onGraphRendered), this.lf.off(bt.GROUP_ADD_NODE, this.onGroupAddNode), this.originDeleteNode && (this.lf.deleteNode = this.originDeleteNode);
  }, o.pluginName = "dynamicGroup", o;
})(), Sd = /* @__PURE__ */ (function() {
  var o = function(n, e) {
    return o = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(i, t) {
      i.__proto__ = t;
    } || function(i, t) {
      for (var r in t) Object.prototype.hasOwnProperty.call(t, r) && (i[r] = t[r]);
    }, o(n, e);
  };
  return function(n, e) {
    if (typeof e != "function" && e !== null) throw new TypeError("Class extends value " + String(e) + " is not a constructor or null");
    o(n, e);
    function i() {
      this.constructor = n;
    }
    n.prototype = e === null ? Object.create(e) : (i.prototype = e.prototype, new i());
  };
})(), zt = function() {
  return zt = Object.assign || function(o) {
    for (var n, e = 1, i = arguments.length; e < i; e++) {
      n = arguments[e];
      for (var t in n) Object.prototype.hasOwnProperty.call(n, t) && (o[t] = n[t]);
    }
    return o;
  }, zt.apply(this, arguments);
}, Nd = function(o, n) {
  var e = typeof Symbol == "function" && o[Symbol.iterator];
  if (!e) return o;
  var i = e.call(o), t, r = [], a;
  try {
    for (; (n === void 0 || n-- > 0) && !(t = i.next()).done; ) r.push(t.value);
  } catch (s) {
    a = { error: s };
  } finally {
    try {
      t && !t.done && (e = i.return) && e.call(i);
    } finally {
      if (a) throw a.error;
    }
  }
  return r;
}, Td = function(o, n, e) {
  if (e || arguments.length === 2)
    for (var i = 0, t = n.length, r; i < t; i++) (r || !(i in n)) && (r || (r = Array.prototype.slice.call(n, 0, i)), r[i] = n[i]);
  return o.concat(r || Array.prototype.slice.call(n));
}, Md = (function(o) {
  Sd(n, o);
  function n() {
    var e = o.apply(this, Td([], Nd(arguments), !1)) || this;
    return e.isLane = !0, e.defaultZIndex = -1, e;
  }
  return n.prototype.initNodeData = function(e) {
    var i;
    o.prototype.initNodeData.call(this, e), this.width = e.width || Ce.defaultWidth, this.height = e.height || Ce.defaultHeight, this.draggable = !0, this.resizable = !0, this.rotatable = !1, this.defaultZIndex = e.zIndex || -1, this.setZIndex(this.defaultZIndex), this.autoToFront = !0, this.text.editable = !0, this.style.stroke = "#000", this.style.strokeWidth = 1, this.properties = zt(zt({}, this.properties), {
      processRef: "",
      panels: ["processRef"],
      direction: ((i = e.properties) === null || i === void 0 ? void 0 : i.direction) || "vertical"
    }), this.collapsedWidth = this.width, this.collapsedHeight = this.height, this.expandWidth = this.width, this.expandHeight = this.height;
  }, n.prototype.setAttributes = function() {
    o.prototype.setAttributes.call(this), this.updateTextPosition();
  }, n.prototype.setZIndex = function(e) {
    this.zIndex = Math.min(e, this.defaultZIndex) || this.defaultZIndex;
  }, n.prototype.toggleCollapse = function() {
    this.isCollapsed = !1, this.setProperties({ isCollapsed: !1 });
  }, n.prototype.getPoolId = function() {
    var e = this;
    try {
      if (!this.graphModel)
        return null;
      var i = this.graphModel.nodes.find(function(t) {
        return t.children && t.children.has(e.id);
      });
      return (i == null ? void 0 : i.id) || null;
    } catch (t) {
      return null;
    }
  }, n.prototype.getPoolModel = function() {
    try {
      var e = this.getPoolId();
      return !e || !this.graphModel ? null : this.graphModel.getNodeModelById(e) || null;
    } catch (i) {
      return null;
    }
  }, n.prototype.changeAttribute = function(e) {
    var i = e.width, t = e.height, r = e.x, a = e.y;
    i && (this.width = i), t && (this.height = t), r && (this.x = r), a && (this.y = a);
  }, n.prototype.getData = function() {
    var e = o.prototype.getData.call(this);
    return zt(zt({}, e), { properties: zt(zt({}, e.properties), {
      width: this.width,
      height: this.height,
      processRef: this.properties.processRef,
      direction: this.properties.direction
    }) });
  }, n.prototype.isAllowAppendIn = function(e) {
    return String(e.type) !== "lane";
  }, n.prototype.getNodesInGroup = function(e) {
    var i = this, t = [], r = e.properties.parent;
    return e.isDragging && r && t.push(r), be(Array.from(e.children), function(a) {
      var s = i.graphModel.getNodeModelById(a);
      s && !s.isDragging && String(s.type) !== "lane" && t.push(a);
    }), t;
  }, n.prototype.getNodeStyle = function() {
    var e = o.prototype.getNodeStyle.call(this);
    return e.strokeWidth = 2, e;
  }, n.prototype.getTextStyle = function() {
    var e = this.properties.isHorizontal, i = e === void 0 ? !1 : e, t = o.prototype.getTextStyle.call(this);
    return t.overflowMode = "ellipsis", t.strokeWidth = 2, t.textWidth = i ? this.height : this.width, t.textHeight = i ? this.width : this.height, i && (t.transform = "rotate(-90deg)", t.textAlign = "center"), t;
  }, n.prototype.getSubNodes = function() {
    var e = this, i = [];
    return Array.from(this.children).forEach(function(t) {
      var r = e.graphModel.getNodeModelById(t);
      r && i.push(r);
    }), i;
  }, n.prototype.updateTextPosition = function() {
    this.properties.isHorizontal ? (this.text.x = this.x - this.width / 2 + Ce.titleSize / 2, this.text.y = this.y) : (this.text.x = this.x, this.text.y = this.y - this.height / 2 + Ce.titleSize / 2);
  }, n;
})(Nr), Ad = /* @__PURE__ */ (function() {
  var o = function(n, e) {
    return o = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(i, t) {
      i.__proto__ = t;
    } || function(i, t) {
      for (var r in t) Object.prototype.hasOwnProperty.call(t, r) && (i[r] = t[r]);
    }, o(n, e);
  };
  return function(n, e) {
    if (typeof e != "function" && e !== null) throw new TypeError("Class extends value " + String(e) + " is not a constructor or null");
    o(n, e);
    function i() {
      this.constructor = n;
    }
    n.prototype = e === null ? Object.create(e) : (i.prototype = e.prototype, new i());
  };
})(), He = function() {
  return He = Object.assign || function(o) {
    for (var n, e = 1, i = arguments.length; e < i; e++) {
      n = arguments[e];
      for (var t in n) Object.prototype.hasOwnProperty.call(n, t) && (o[t] = n[t]);
    }
    return o;
  }, He.apply(this, arguments);
}, Od = function(o, n) {
  var e = typeof Symbol == "function" && o[Symbol.iterator];
  if (!e) return o;
  var i = e.call(o), t, r = [], a;
  try {
    for (; (n === void 0 || n-- > 0) && !(t = i.next()).done; ) r.push(t.value);
  } catch (s) {
    a = { error: s };
  } finally {
    try {
      t && !t.done && (e = i.return) && e.call(i);
    } finally {
      if (a) throw a.error;
    }
  }
  return r;
}, Dd = function(o, n, e) {
  if (e || arguments.length === 2)
    for (var i = 0, t = n.length, r; i < t; i++) (r || !(i in n)) && (r || (r = Array.prototype.slice.call(n, 0, i)), r[i] = n[i]);
  return o.concat(r || Array.prototype.slice.call(n));
}, Pd = (function(o) {
  Ad(n, o);
  function n() {
    return o !== null && o.apply(this, arguments) || this;
  }
  return n.prototype.getAppendAreaShape = function() {
    var e = this.props.model, i = e.width, t = e.height, r = e.x, a = e.y, s = e.radius;
    if (!e.groupAddable) return null;
    var d = e.getNodeStyle().strokeWidth, l = d === void 0 ? 0 : d, u = e.getAddableOutlineStyle(), c = i + l + 8, h = t + l + 8;
    return I("rect", He(He({}, u), {
      width: c,
      height: h,
      x: r - c / 2,
      y: a - h / 2,
      rx: s,
      ry: s
    }));
  }, n.prototype.getShape = function() {
    var e = this.props.model, i = e.x, t = e.y, r = e.width, a = e.height, s = e.properties, d = s.textStyle, l = d === void 0 ? {} : d, u = s.isHorizontal, c = e.getNodeStyle(), h = {
      fill: "#ffffff",
      stroke: "#000000",
      strokeWidth: 1
    }, f = i - r / 2, p = t - a / 2, v = He({
      x: i - r / 2,
      y: t - a / 2,
      width: r,
      height: a,
      stroke: "#000000",
      strokeWidth: 2,
      fill: "transparent"
    }, c), g = this.getOperateIcons(), b = He(He(He(He({}, h), c), {
      x: u ? f + Ce.titleSize : f,
      y: u ? p : p + Ce.titleSize,
      width: u ? r - Ce.titleSize : r,
      height: u ? a : Ce.titleSize
    }), u ? l : {});
    return I("g", {}, Dd([
      this.getAppendAreaShape(),
      I("rect", b),
      I("rect", He({}, v))
    ], Od(g), !1));
  }, n.prototype.getOperateIcons = function() {
    var e = this.props.model;
    if (!e.isSelected) return [];
    var i = e.getPoolModel();
    if (!i) return [];
    var t = i.isHorizontal, r = e.getData();
    return [
      this.addBeforeLaneIcon(t, function() {
        var a, s;
        return t ? (a = i.addChildAbove) === null || a === void 0 ? void 0 : a.call(i, r) : (s = i.addChildRight) === null || s === void 0 ? void 0 : s.call(i, r);
      }),
      this.addAfterLaneIcon(t, function() {
        var a, s;
        return t ? (a = i.addChildBelow) === null || a === void 0 ? void 0 : a.call(i, r) : (s = i.addChildLeft) === null || s === void 0 ? void 0 : s.call(i, r);
      }),
      this.deleteLaneIcon(function() {
        var a;
        return (a = i.deleteChild) === null || a === void 0 ? void 0 : a.call(i, r.id);
      })
    ];
  }, n.prototype.addBeforeLaneIcon = function(e, i) {
    var t = this.props.model, r = t.x, a = t.y, s = t.width, d = t.height, l = r + s / 2 + Ce.iconSpacing, u = a - d / 2, c = {
      width: Ce.iconSize / 2,
      height: Ce.iconSize,
      strokeWidth: 1,
      fill: "#fff",
      stroke: "#000",
      x: l,
      y: u
    }, h = [I("rect", He(He({}, c), {
      x: l + Ce.iconSize / 2,
      strokeDasharray: "2 2"
    })), I("rect", c)];
    return e && (h = [I("rect", He(He({}, c), {
      width: Ce.iconSize,
      height: Ce.iconSize / 2,
      strokeDasharray: "2 2"
    })), I("rect", He(He({}, c), {
      width: Ce.iconSize,
      height: Ce.iconSize / 2,
      y: u + Ce.iconSize / 2
    }))]), I("g", {
      cursor: "pointer",
      onClick: i
    }, h);
  }, n.prototype.addAfterLaneIcon = function(e, i) {
    var t = this.props.model, r = t.x, a = t.y, s = t.width, d = t.height, l = r + s / 2 + Ce.iconSpacing, u = a - d / 2 + Ce.iconSize + Ce.iconSpacing, c = {
      width: Ce.iconSize / 2,
      height: Ce.iconSize,
      strokeWidth: 1,
      fill: "#fff",
      stroke: "#000",
      x: l,
      y: u
    }, h = [I("rect", He(He({}, c), { x: l + Ce.iconSize / 2 })), I("rect", He(He({}, c), { strokeDasharray: "2 2" }))];
    return e && (h = [I("rect", He(He({}, c), {
      width: Ce.iconSize,
      height: Ce.iconSize / 2
    })), I("rect", He(He({}, c), {
      width: Ce.iconSize,
      height: Ce.iconSize / 2,
      y: u + Ce.iconSize / 2,
      strokeDasharray: "2 2"
    }))]), I("g", {
      cursor: "pointer",
      onClick: i
    }, h);
  }, n.prototype.deleteLaneIcon = function(e) {
    var i = this.props.model, t = i.x, r = i.y, a = i.width, s = i.height, d = t + a / 2 + Ce.iconSpacing, l = r - s / 2 + (Ce.iconSize + Ce.iconSpacing) * 3;
    return I("g", {
      cursor: "pointer",
      onClick: e,
      width: Ce.iconSize,
      height: Ce.iconSize,
      transform: "translate(".concat(d, ", ").concat(l, ")")
    }, [I("rect", {
      width: Ce.iconSize,
      height: Ce.iconSize,
      fill: "transparent"
    }), I("path", {
      transform: "translate(2, 1) scale(".concat(Ce.iconSize / 18, ")"),
      fill: "#000",
      d: "M1.6361705,0.07275847000000002L1.6362224,0.07267305000000002L5.1435161,2.2034403L6.3516493,1.28341734Q7.2009554,0.63665058,8.0902505,1.22722644L10.1215935,2.5762291Q11.006711,3.1640306,10.745867,4.1940317L10.4062386,5.5351257L13.625054,7.5778356L13.625001,7.5779204Q13.678322,7.6117587,13.721552,7.6577945Q13.764784,7.7038307,13.795207,7.7591715Q13.82563,7.8145118,13.841336,7.87568Q13.857041,7.9368477,13.857041,8Q13.85704,8.0492353,13.847435,8.0975251Q13.83783,8.145814900000001,13.818987,8.191302799999999Q13.800144,8.2367907,13.772791,8.2777286Q13.745438,8.318666499999999,13.710623,8.3534818Q13.675808,8.3882966,13.63487,8.4156504Q13.593931,8.4430046,13.548444,8.461846399999999Q13.502956,8.4806881,13.454666,8.4902935Q13.406377,8.4998994,13.357141,8.499899899999999Q13.211908,8.499899899999999,13.089283,8.4220805L13.08923,8.4221654L4.9074116,3.229857L1.1170242400000001,0.92732695L1.1170761599999999,0.92724147Q1.06204063,0.8938076500000001,1.0172748,0.84751782Q0.97250897,0.80122799,0.9409355500000001,0.74510445Q0.9093622,0.68898091,0.89304277,0.626688Q0.87672335,0.564395107,0.87672332,0.5Q0.8767232899999999,0.450764146,0.88632876,0.402474351Q0.8959341599999999,0.35418455,0.91477591,0.30869657Q0.93361765,0.26320857,0.9609716500000001,0.22227046Q0.9883256,0.18133234999999998,1.02314061,0.14651734Q1.05795562,0.11170232000000002,1.0988937,0.08434838Q1.13983184,0.056994409999999995,1.18531984,0.038152660000000005Q1.2308077800000001,0.019310890000000025,1.27909762,0.009705450000000004Q1.32738745,0.00010001999999997846,1.3766233300000001,0.00009998999999999425Q1.516567,0.00009998999999999425,1.6361705,0.07275847000000002ZM9.5175018,4.9711194L9.7764683,3.9485345Q9.8634167,3.6052005,9.5683784,3.4092672L7.537035,2.0602646Q7.240603,1.8634058,6.9575009,2.0789949L6.0496349,2.7703574L9.5175018,4.9711194ZM11.227273,14.5L11.227273,9.7307692L11.227173,9.7307692Q11.227173,9.6815329,11.217567,9.6332426Q11.207962,9.5849533,11.189119,9.539465Q11.170278,9.4939766,11.142924,9.4530392Q11.11557,9.4121017,11.080755,9.3772869Q11.04594,9.3424721,11.005002,9.3151178Q10.964064,9.2877636,10.918575,9.2689209Q10.873087,9.2500801,10.824797,9.2404747Q10.776508,9.2308693,10.727273,9.2308693Q10.678036,9.2308693,10.629745,9.2404747Q10.581455,9.2500801,10.535968,9.2689209Q10.4904804,9.2877636,10.449542,9.3151178Q10.4086046,9.3424721,10.3737898,9.377286Q10.338975,9.4121008,10.3116207,9.4530382Q10.2842674,9.4939766,10.2654257,9.539465Q10.2465839,9.5849533,10.2369785,9.6332426Q10.2273731,9.6815329,10.2273731,9.7307692L10.2272739,9.7307692L10.2272739,14.5Q10.2272739,15,9.727273,15L7.7207794,15L7.7207789,8.2500091L7.7206788,8.2500091Q7.7206783,8.2007728,7.7110729,8.152483Q7.7014675,8.104193200000001,7.6826253,8.0587053Q7.6637836,8.013217000000001,7.6364298,7.9722791Q7.6090755,7.9313412,7.5742612,7.8965263Q7.5394459,7.861711,7.4985075,7.8343568Q7.4575696,7.807003,7.4120817,7.7881613Q7.3665934,7.7693195,7.3183041,7.7597141Q7.2700143,7.7501092,7.2207789,7.7501092Q7.1715426,7.7501092,7.1232524,7.7597141Q7.0749626,7.7693195,7.0294747,7.7881613Q6.9839869,7.807003,6.943049,7.8343573Q6.9021111,7.861711,6.8672962,7.8965263Q6.8324809,7.9313412,6.8051271,7.9722791Q6.7777729,8.013217000000001,6.7589312,8.0587053Q6.7400894,8.1041937,6.7304845,8.1524839Q6.7208786,8.2007732,6.7208791,8.2500095L6.7207789,8.2500091L6.7207794,15L4.2142854,15L4.2142854,6.2692308L4.2141855,6.2692308Q4.2141852,6.2199945,4.204579799999999,6.1717048Q4.1949743999999995,6.123415,4.1761324,6.0779266Q4.1572905,6.0324383,4.1299367,5.9915004Q4.1025827,5.9505625,4.0677679,5.9157476Q4.0329528,5.8809328,3.9920146,5.8535786Q3.9510765,5.8262248,3.9055884,5.8073831Q3.8601003,5.7885418,3.811811,5.7789364Q3.7635212,5.769331,3.7142854,5.769331Q3.6650493,5.769331,3.6167595,5.7789364Q3.5684695,5.7885418,3.5229816,5.8073831Q3.4774938,5.8262248,3.4365554,5.8535786Q3.3956175,5.8809328,3.3608027,5.9157476Q3.3259873,5.9505625,3.2986333,5.9915004Q3.2712793,6.0324383,3.2524376,6.0779266Q3.2335958,6.123415,3.2239904,6.1717048Q3.214385,6.2199945,3.2143853,6.2692308L3.2142854,6.2692308L3.2142854,15L1.5000002,15Q1.0000001200000002,15,1.0000001200000002,14.5L1,5.4150848Q1,5.0384622,1.3766233300000001,5.0384622L1.3766233300000001,5.0383615Q1.42585915,5.0383615,1.47414887,5.0287557Q1.5224386,5.0191503,1.5679266,5.0003085Q1.6134146,4.9814663,1.6543528,4.954113Q1.695291,4.9267588,1.730106,4.8919439Q1.7649209,4.8571291,1.792275,4.8161907Q1.8196288,4.7752523,1.8384706,4.7297645Q1.8573124,4.6842766,1.8669178,4.6359868Q1.8765233,4.587697,1.8765234,4.5384617Q1.8765233,4.4892254000000005,1.8669178,4.4409355999999995Q1.8573124,4.3926458,1.8384707,4.3471577Q1.819629,4.3016696,1.792275,4.2607315Q1.7649209,4.2197936,1.730106,4.1849787Q1.695291,4.1501637,1.6543529,4.1228096Q1.6134148,4.0954556,1.5679268,4.0766139Q1.5224388,4.0577724,1.4741489300000001,4.048166999999999Q1.42585915,4.0385615999999995,1.3766233300000001,4.0385615999999995L1.3766233300000001,4.0384617Q0.8064074800000001,4.0384617,0.403203636,4.4416654Q0,4.8448691,0,5.4150848L9.000000000813912e-8,14.5Q2.9999999984209325e-8,15.121321,0.439339694,15.56066Q0.8786805,16.000002000000002,1.5000002,16.000002000000002L9.727273,16.000002000000002Q10.3485928,16.000002000000002,10.787933,15.56066Q11.227273,15.121321,11.227273,14.5Z"
    })]);
  }, n;
})(Tr);
function Rd(o, n) {
  var e = o.minX, i = o.minY, t = o.maxX, r = o.maxY, a = n.x, s = n.y, d = n.width, l = n.height;
  return e >= a - d / 2 && t <= a + d / 2 && i >= s - l / 2 && r <= s + l / 2;
}
function Ld(o, n, e, i) {
  var t = o.minX, r = o.minY, a = o.maxX, s = o.maxY, d = n.x, l = n.y, u = n.width, c = n.height, h = t + u / 2, f = r + c / 2, p = a - u / 2, v = s - c / 2;
  return {
    x: d + e >= h && d + e <= p,
    y: l + i >= f && l + i <= v
  };
}
var jt = function() {
  return jt = Object.assign || function(o) {
    for (var n, e = 1, i = arguments.length; e < i; e++) {
      n = arguments[e];
      for (var t in n) Object.prototype.hasOwnProperty.call(n, t) && (o[t] = n[t]);
    }
    return o;
  }, jt.apply(this, arguments);
}, hi = function(o, n) {
  var e = typeof Symbol == "function" && o[Symbol.iterator];
  if (!e) return o;
  var i = e.call(o), t, r = [], a;
  try {
    for (; (n === void 0 || n-- > 0) && !(t = i.next()).done; ) r.push(t.value);
  } catch (s) {
    a = { error: s };
  } finally {
    try {
      t && !t.done && (e = i.return) && e.call(i);
    } finally {
      if (a) throw a.error;
    }
  }
  return r;
}, fi = function(o, n, e) {
  if (e || arguments.length === 2)
    for (var i = 0, t = n.length, r; i < t; i++) (r || !(i in n)) && (r || (r = Array.prototype.slice.call(n, 0, i)), r[i] = n[i]);
  return o.concat(r || Array.prototype.slice.call(n));
}, Id = {
  type: "pool",
  view: _d,
  model: vd
}, kd = {
  type: "lane",
  view: Pd,
  model: Md
}, hc = (function() {
  function o(n) {
    var e = n.lf, i = n.options, t = this;
    this.activeGroups = /* @__PURE__ */ new Set(), this.nodeLaneMap = /* @__PURE__ */ new Map(), this.onSelectionDrop = function() {
      t.lf.graphModel.getSelectElements().nodes.forEach(function(r) {
        t.addNodeToGroup(r);
      });
    }, this.onNodeAddOrDrop = function(r) {
      var a = r.data;
      t.addNodeToGroup(a);
    }, this.addNodeToGroup = function(r) {
      var a = t.nodeLaneMap.get(r.id);
      if (a) {
        var s = t.lf.getNodeModelById(a);
        s.removeChild(r.id), t.nodeLaneMap.delete(r.id), s.setAllowAppendChild(!1);
      }
      var d = t.lf.getNodeModelById(r.id), l = d == null ? void 0 : d.getBounds();
      if (d && l) {
        if (d.isGroup) {
          var u = d;
          be(Array.from(u.children), function(f) {
            t.nodeLaneMap.set(f, r.id);
          });
        }
        var s = t.getLaneByBounds(l, r);
        if (s)
          if (s.isAllowAppendIn(r)) {
            s.addChild(r.id), s.setAllowAppendChild(!1);
            var c = t.lf.getNodeModelById(r.id);
            c == null || c.setProperties(jt(jt({}, c.properties), { parent: s.id }));
          } else t.lf.emit("lane:not-allowed", {
            lane: s.getData(),
            node: r
          });
      }
    }, this.onGroupAddNode = function(r) {
      var a = r.data, s = r.childId;
      t.nodeLaneMap.set(s, a.id);
    }, this.removeNodeFromGroup = function(r) {
      var a = r.data;
      r.model.isGroup && a.children && be(Array.from(a.children), function(c) {
        t.nodeLaneMap.delete(c), t.lf.deleteNode(c);
      });
      var s = t.nodeLaneMap.get(a.id);
      if (s) {
        var d = t.lf.getNodeModelById(s);
        d && d.removeChild(a.id), t.nodeLaneMap.delete(a.id);
        var l = t.lf.getNodeModelById(a.id), u = jt(jt({}, l == null ? void 0 : l.properties), {
          parent: void 0,
          relativeDistanceX: void 0,
          relativeDistanceY: void 0
        });
        l == null || l.setProperties(u);
      }
    }, this.onSelectionDrag = function() {
      var r = t.lf.graphModel.getSelectElements().nodes, a = /* @__PURE__ */ new Set();
      r.forEach(function(s) {
        var d = t.getTargetLaneForNode(s);
        d && a.add(d);
      }), t.activeGroups.forEach(function(s) {
        a.has(s) || s.setAllowAppendChild(!1);
      }), a.forEach(function(s) {
        t.activeGroups.has(s) || s.setAllowAppendChild(!0);
      }), t.activeGroups = a;
    }, this.onNodeDrag = function(r) {
      var a = r.data;
      t.setActiveGroup(a);
    }, this.setActiveGroup = function(r) {
      var a = t.getTargetLaneForNode(r), s = /* @__PURE__ */ new Set();
      a && s.add(a), t.activeGroups.forEach(function(d) {
        s.has(d) || d.setAllowAppendChild(!1);
      }), s.forEach(function(d) {
        t.activeGroups.has(d) || d.setAllowAppendChild(!0);
      }), t.activeGroups = s;
    }, this.onNodeDrop = function() {
      t.clearDragTargetHighlight();
    }, this.onNodeMouseUp = function() {
      t.clearDragTargetHighlight();
    }, this.onNodeSelect = function(r) {
      var a = r.data, s = r.isMultiple, d = r.isSelected, l = t.lf.getNodeModelById(a.id);
      if (s && d)
        if (l != null && l.isGroup) {
          var u = l.children;
          be(Array.from(u), function(f) {
            var p = t.lf.getNodeModelById(f);
            p == null || p.setSelected(!1);
          });
        } else {
          var c = t.nodeLaneMap.get(a.id);
          if (c) {
            var h = t.lf.getNodeModelById(c);
            h != null && h.isSelected && (l == null || l.setSelected(!1));
          }
        }
    }, this.onNodeMove = function(r) {
      var a = r.data.id, s = t.nodeLaneMap.get(a);
      if (s) {
        var d = t.lf.getNodeModelById(s);
        if (!(!d || !d.isRestrict || !d.autoResize)) {
          var l = t.lf.getNodeModelById(a);
          if (l) {
            var u = l.getBounds(), c = u.minX, h = u.minY, f = u.maxX, p = u.maxY, v = !1, g = d.getBounds(), b = Object.assign({}, g);
            if (c < b.minX && (b.minX = c, v = !0), h < b.minY && (b.minY = h, v = !0), f > b.maxX && (b.maxX = f, v = !0), p > b.maxY && (b.maxY = p, v = !0), !!v) {
              var _ = b.minX + (b.maxX - b.minX) / 2, D = b.minY + (b.maxY - b.minY) / 2, L = b.maxX - b.minX, W = b.maxY - b.minY;
              d.moveTo(_, D), d.width = L, d.height = W, d.updateExpandedSize(L, W), d.setTextPosition();
            }
          }
        }
      }
    }, this.onGraphRendered = function(r) {
      var a = r.data;
      be(a.nodes, function(s) {
        s.children && be(s.children, function(d) {
          t.nodeLaneMap.set(d, s.id);
        });
      });
    }, e.register(Id), e.register(kd), this.lf = e, Rn(this, i), this.init();
  }
  return o.prototype.getLaneByNodeId = function(n) {
    var e = this.nodeLaneMap.get(n);
    if (e) return this.lf.getNodeModelById(e);
  }, o.prototype.getLaneByBounds = function(n, e) {
    var i = this.lf.graphModel.nodes, t = gi(i, function(d) {
      return !!d.isGroup && Rd(n, d) && d.id !== e.id;
    }), r = t.length;
    if (r <= 1) return t[0];
    for (var a = t[r - 1], s = r - 2; s >= 0; s--) t[s].zIndex > a.zIndex && (a = t[s]);
    return a;
  }, o.prototype.getTargetLaneForNode = function(n) {
    var e = this.lf.getNodeModelById(n.id), i = e == null ? void 0 : e.getBounds();
    if (!(!e || !i)) {
      var t = this.getLaneByBounds(i, n);
      if (t && !(e.isGroup && t.id === n.id) && t.isAllowAppendIn(n))
        return t;
    }
  }, o.prototype.clearDragTargetHighlight = function() {
    this.activeGroups.forEach(function(n) {
      n.setAllowAppendChild(!1);
    }), this.activeGroups.clear();
  }, o.prototype.removeChildrenInGroupNodeData = function(n) {
    var e, i = ft(n);
    return delete i.children, !((e = i.properties) === null || e === void 0) && e.children && delete i.properties.children, i;
  }, o.prototype.initGroupChildNodes = function(n, e, i, t) {
    var r = this, a = [], s = [], d = [];
    be(Array.from(e), function(c) {
      var h = r.lf.getNodeModelById(c);
      if (h) {
        var f = h.children, p = h.getData(), v = oe.NODE_GROUP_COPY || "node:group-copy-add", g = Zo(r.removeChildrenInGroupNodeData(p), t), b = r.lf.addNode(g, v);
        if (i.addChild(b.id), n[c] = b.id, a.push(b), d.push.apply(d, fi([], hi(fi(fi([], hi(b.incoming.edges), !1), hi(b.outgoing.edges), !1)), !1)), f instanceof Set) {
          var _ = r.initGroupChildNodes(n, f, b, t), D = _.childNodes, L = _.edgesData;
          a.push.apply(a, fi([], hi(D), !1)), s.push.apply(s, fi([], hi(L), !1));
        }
      }
    });
    var l = gi(d, function(c) {
      return Yi(n, c.sourceNodeId) && Yi(n, c.targetNodeId);
    }), u = Jt(l, function(c) {
      return c.getData();
    });
    return {
      childNodes: a,
      edgesData: s.concat(u)
    };
  }, o.prototype.createEdge = function(n, e, i) {
    var t, r, a = n.sourceNodeId, s = n.targetNodeId, d = (t = e[a]) !== null && t !== void 0 ? t : a, l = (r = e[s]) !== null && r !== void 0 ? r : s, u = ft(n);
    return n.id && typeof n.text == "object" && n.text !== null && (u = Jo(n, i)), this.lf.graphModel.addEdge(jt(jt({}, u), {
      sourceNodeId: d,
      targetNodeId: l
    }));
  }, o.prototype.checkGroupBoundsWithChildren = function(n, e, i, t, r) {
    var a = this, s = Ca(n, function(c) {
      return a.lf.getNodeModelById(c);
    });
    if (!s) return !0;
    var d = n.x + e / 2, l = n.y + i / 2, u = {
      minX: d - t / 2,
      minY: l - r / 2,
      maxX: d + t / 2,
      maxY: l + r / 2
    };
    return Sa(u, s);
  }, o.prototype.init = function() {
    var n = this, e = this.lf, i = e.graphModel;
    i.addNodeMoveRules(function(t, r, a) {
      if (t.isGroup) return !0;
      var s = n.nodeLaneMap.get(t.id), d = n.lf.getNodeModelById(s);
      if (d && d.isRestrict) {
        if (d.autoResize) return !0;
        var l = d.getBounds();
        return Ld(l, t, r, a);
      }
      return !0;
    }), i.addNodeResizeRules(function(t, r, a, s, d) {
      return t.isGroup ? n.checkGroupBoundsWithChildren(t, r, a, s, d) : !0;
    }), i.dynamicGroup = this, e.on(dr, this.onNodeAddOrDrop), e.on(oe.SELECTION_DROP, this.onSelectionDrop), e.on(oe.NODE_DELETE, this.removeNodeFromGroup), e.on(Ui, this.onNodeDrag), e.on(oe.SELECTION_DRAG, this.onSelectionDrag), e.on(oe.NODE_DROP, this.onNodeDrop), e.on(oe.NODE_MOUSEUP, this.onNodeMouseUp), e.on(oe.NODE_CLICK, this.onNodeSelect), e.on(oe.NODE_MOUSEMOVE, this.onNodeMove), e.on(oe.GRAPH_RENDERED, this.onGraphRendered), e.on(bt.GROUP_ADD_NODE, this.onGroupAddNode), e.addElements = function(t, r) {
      var a = t.nodes, s = t.edges;
      r === void 0 && (r = 40);
      var d = {}, l = {
        nodes: [],
        edges: []
      }, u = [];
      return be(a, function(c) {
        var h, f, p = c.id, v = (f = (h = c.properties) === null || h === void 0 ? void 0 : h.children) !== null && f !== void 0 ? f : c.children, g = e.addNode(n.removeChildrenInGroupNodeData(c));
        if (p && (d[p] = g.id), l.nodes.push(g), g.isGroup) {
          var b = n.initGroupChildNodes(d, v, g, r).edgesData;
          u.push.apply(u, fi([], hi(b), !1));
        }
      }), be(u, function(c) {
        n.createEdge(c, d, r);
      }), be(s, function(c) {
        l.edges.push(n.createEdge(c, d, r));
      }), l;
    }, this.render();
  }, o.prototype.render = function() {
  }, o.prototype.destroy = function() {
    this.lf.off(dr, this.onNodeAddOrDrop), this.lf.off(oe.SELECTION_DROP, this.onSelectionDrop), this.lf.off(oe.NODE_DELETE, this.removeNodeFromGroup), this.lf.off(Ui, this.onNodeDrag), this.lf.off(oe.SELECTION_DRAG, this.onSelectionDrag), this.lf.off(oe.NODE_DROP, this.onNodeDrop), this.lf.off(oe.NODE_MOUSEUP, this.onNodeMouseUp), this.lf.off(oe.NODE_CLICK, this.onNodeSelect), this.lf.off(oe.NODE_MOUSEMOVE, this.onNodeMove), this.lf.off(oe.GRAPH_RENDERED, this.onGraphRendered), this.lf.off(bt.GROUP_ADD_NODE, this.onGroupAddNode);
  }, o.pluginName = "PoolElements", o;
})(), Ei;
(function(o) {
  o.HORIZONTAL = "horizontal", o.VERTICAL = "vertical";
})(Ei || (Ei = {}));
var Bd = function(o, n, e, i) {
  return i === void 0 && (i = 0), Fd(o, n, e) <= i;
};
function Ao(o) {
  return o * o;
}
function Vn(o, n) {
  return Ao(o.x - n.x) + Ao(o.y - n.y);
}
var Hd = function(o, n, e) {
  var i = Vn(n, e);
  if (i === 0) return Vn(o, n);
  var t = ((o.x - n.x) * (e.x - n.x) + (o.y - n.y) * (e.y - n.y)) / i;
  return t = Math.max(0, Math.min(1, t)), Vn(o, {
    x: n.x + t * (e.x - n.x),
    y: n.y + t * (e.y - n.y)
  });
}, Fd = function(o, n, e) {
  return Math.sqrt(Hd(o, n, e));
}, Gd = function(o) {
  var n = o.x, e = o.y, i = o.width, t = o.height;
  return {
    minX: n - i / 2,
    minY: e - t / 2,
    maxX: n + i / 2,
    maxY: e + t / 2,
    x: n,
    y: e,
    width: i,
    height: t,
    centerX: n,
    centerY: e
  };
}, zd = function(o, n) {
  var e;
  return o.x === n.x ? e = Ei.VERTICAL : o.y === n.y && (e = Ei.HORIZONTAL), e;
}, jd = function(o, n, e) {
  var i = Gd(o), t = zd(n, e), r = Math.max(n.x, e.x), a = Math.min(n.x, e.x), s = Math.max(n.y, e.y), d = Math.min(n.y, e.y), l = o.x, u = o.y, c = o.width, h = o.height;
  if (t === Ei.HORIZONTAL) {
    if (r >= i.maxX && a <= i.minX) return {
      startCrossPoint: {
        x: n.x > e.x ? l + c / 2 : l - c / 2,
        y: n.y
      },
      endCrossPoint: {
        x: n.x > e.x ? l - c / 2 : l + c / 2,
        y: n.y
      }
    };
  } else if (t === Ei.VERTICAL && s >= i.maxY && d <= i.minY)
    return {
      startCrossPoint: {
        x: n.x,
        y: n.y > e.y ? u + h / 2 : u - h / 2
      },
      endCrossPoint: {
        x: n.x,
        y: n.y > e.y ? u - h / 2 : u + h / 2
      }
    };
}, Wd = function(o, n, e) {
  e === void 0 && (e = 0);
  for (var i = o.x, t = o.y, r = n.pointsList, a = 0; a < r.length - 1; a++) if (Bd({
    x: i,
    y: t
  }, r[a], r[a + 1], e)) {
    var s = jd(o, r[a], r[a + 1]);
    if (s) return {
      crossIndex: a + 1,
      crossPoints: s
    };
  }
  return {
    crossIndex: -1,
    crossPoints: {
      startCrossPoint: {
        x: 0,
        y: 0
      },
      endCrossPoint: {
        x: 0,
        y: 0
      }
    }
  };
}, fc = (function() {
  function o(n) {
    var e = n.lf;
    this._lf = e, this.deviation = 20, this.dndAdd = !0, this.dropAdd = !0, this.eventHandler();
  }
  return o.prototype.eventHandler = function() {
    var n = this;
    this.dndAdd && this._lf.on("node:dnd-add", function(e) {
      var i = e.data;
      n.insetNode(i);
    }), this.dropAdd && this._lf.on("node:drop", function(e) {
      for (var i = e.data, t = n._lf.graphModel.edges, r = i.id, a = !0, s = 0; s < t.length; s++) if (t[s].sourceNodeId === r || t[s].targetNodeId === r) {
        a = !1;
        break;
      }
      a && n.insetNode(i);
    });
  }, o.prototype.checkRuleBeforeInsetNode = function(n, e, i, t, r) {
    var a = this._lf.getNodeModelById(n), s = this._lf.getNodeModelById(e), d = a.getAnchorInfo(i), l = s.getAnchorInfo(t), u = a.isAllowConnectedAsSource(r, d, l), c = s.isAllowConnectedAsTarget(r, d, l), h = Lr(u), f = h.isAllPass, p = h.msg, v = Lr(c), g = v.isAllPass, b = v.msg;
    return {
      isPass: f && g,
      sourceMsg: p,
      targetMsg: b
    };
  }, o.prototype.insetNode = function(n) {
    var e = this, i = this._lf.graphModel.edges, t = this._lf.getNodeModelById(n.id), r = t == null ? void 0 : t.getDefaultAnchor();
    if (!r || r.length === 0) {
      this._lf.graphModel.eventCenter.emit(oe.CONNECTION_NOT_ALLOWED, {
        data: n,
        msg: "自定义类型节点不显示锚点，也不允许其他节点连接到此节点"
      });
      return;
    }
    if (t)
      for (var a = 0; a < i.length; a++) {
        var s = Wd(t, i[a], this.deviation), d = s.crossIndex, l = s.crossPoints;
        if (d >= 0) {
          var u = i[a], c = u.sourceNodeId, h = u.targetNodeId, f = u.id, p = u.type, v = u.pointsList, g = u.sourceAnchorId, b = u.targetAnchorId, _ = ft(v[0]);
          this._lf.deleteEdge(f);
          var D = this.checkRuleBeforeInsetNode(c, h, g, b, n), L = Ir(l.startCrossPoint, t).anchor;
          this._lf.addEdge({
            type: p,
            sourceNodeId: c,
            targetNodeId: n.id,
            startPoint: _,
            endPoint: L
          });
          var W = Ir(l.endCrossPoint, t).anchor;
          if (this._lf.addEdge({
            type: p,
            sourceNodeId: n.id,
            targetNodeId: h,
            startPoint: ft(W),
            endPoint: ft(v[v.length - 1])
          }), D.isPass)
            break;
          this._lf.graphModel.eventCenter.emit(oe.CONNECTION_NOT_ALLOWED, {
            data: n,
            msg: D.targetMsg || D.sourceMsg
          }), setTimeout(function() {
            e._lf.undo();
          }, 200);
          break;
        }
      }
  }, o.pluginName = "insertNodeInPolyline", o;
})(), $d = /* @__PURE__ */ (function() {
  var o = function(n, e) {
    return o = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(i, t) {
      i.__proto__ = t;
    } || function(i, t) {
      for (var r in t) Object.prototype.hasOwnProperty.call(t, r) && (i[r] = t[r]);
    }, o(n, e);
  };
  return function(n, e) {
    if (typeof e != "function" && e !== null) throw new TypeError("Class extends value " + String(e) + " is not a constructor or null");
    o(n, e);
    function i() {
      this.constructor = n;
    }
    n.prototype = e === null ? Object.create(e) : (i.prototype = e.prototype, new i());
  };
})(), Wi = function() {
  return Wi = Object.assign || function(o) {
    for (var n, e = 1, i = arguments.length; e < i; e++) {
      n = arguments[e];
      for (var t in n) Object.prototype.hasOwnProperty.call(n, t) && (o[t] = n[t]);
    }
    return o;
  }, Wi.apply(this, arguments);
}, Xd = function(o, n, e, i) {
  var t = arguments.length, r = t < 3 ? n : i === null ? i = Object.getOwnPropertyDescriptor(n, e) : i, a;
  if (typeof Reflect == "object" && typeof Reflect.decorate == "function") r = Reflect.decorate(o, n, e, i);
  else for (var s = o.length - 1; s >= 0; s--) (a = o[s]) && (r = (t < 3 ? a(r) : t > 3 ? a(n, e, r) : a(n, e)) || r);
  return t > 3 && r && Object.defineProperty(n, e, r), r;
}, Yd = function(o, n) {
  var e = typeof Symbol == "function" && o[Symbol.iterator];
  if (!e) return o;
  var i = e.call(o), t, r = [], a;
  try {
    for (; (n === void 0 || n-- > 0) && !(t = i.next()).done; ) r.push(t.value);
  } catch (s) {
    a = { error: s };
  } finally {
    try {
      t && !t.done && (e = i.return) && e.call(i);
    } finally {
      if (a) throw a.error;
    }
  }
  return r;
}, Ud = (function(o) {
  $d(n, o);
  function n(e) {
    var i = o.call(this, e) || this;
    i.textRef = qa(), i.setHoverOn = function() {
      var d = i.props.element;
      d.isDragging || i.state.isHovered || (i.setState({ isHovered: !0 }), d.setHovered(!0));
    }, i.setHoverOff = function() {
      var d = i.props.element;
      i.state.isHovered && (i.setState({ isHovered: !1 }), d.setHovered(!1));
    }, i.handleMouseDown = function(d) {
      var l, u = i.props, c = u.label, h = u.graphModel.editConfigModel.nodeTextDraggable;
      ((l = c.draggable) !== null && l !== void 0 ? l : h) && !i.state.isDragging && !i.state.isEditing && i.stepDrag.handleMouseDown(d);
    }, i.handleMouseUp = function(d) {
      i.state.isDragging && i.stepDrag.handleMouseUp(d);
    }, i.handleDragging = function(d) {
      var l = d.deltaX, u = d.deltaY;
      i.state.isDragging || i.setState({ isDragging: !0 });
      var c = i.props, h = c.label, f = c.graphModel, p = f.transformModel, v = Yd(p.fixDeltaXY(l, u), 2), g = v[0], b = v[1];
      i.setElementModelLabelInfo({
        x: h.x + g,
        y: h.y + b
      }), f.eventCenter.emit("label:drag", {
        data: h.getData(),
        model: h
      });
    }, i.handleDragEnd = function() {
      i.setState({ isDragging: !1 });
    }, i.handleClick = function(d) {
      var l = i.props, u = l.label, c = l.element, h = l.graphModel;
      c.setSelected(!i.state.isSelected), i.setState({ isSelected: !i.state.isSelected }), i.setElementModelLabelInfo({ isSelected: !0 }), h.eventCenter.emit("label:click", {
        data: u.getData(),
        e: d,
        model: c
      });
    }, i.handleDbClick = function(d) {
      var l = i.props, u = l.label, c = l.element;
      if (l.graphModel.eventCenter.emit("label:dblclick", {
        data: u.getData(),
        e: d,
        model: c
      }), !u.editable) {
        c.setSelected(!0);
        return;
      }
      if (c.setSelected(), c.setElementState(sr.TEXT_EDIT), i.setState({ isEditing: !0 }), i.textRef.current) {
        i.textRef.current.contentEditable = "true", i.textRef.current.focus();
        var h = document.createRange(), f = window.getSelection();
        h.selectNodeContents(i.textRef.current), h.collapse(!1), f == null || f.removeAllRanges(), f == null || f.addRange(h);
      }
    }, i.handleBlur = function(d) {
      var l = i.props, u = l.label, c = l.element;
      l.graphModel.eventCenter.emit("label:blur", {
        e: d,
        model: c,
        data: u.getData(),
        element: i.textRef.current
      }), i.setState({
        isDragging: !1,
        isHovered: !1,
        isSelected: !1
      });
    }, i.handleInput = function(d) {
      var l = i.props, u = l.label;
      l.graphModel.eventCenter.emit("label:input", {
        e: d,
        data: u.getData()
      });
    }, i.reCalcLabelSize = function() {
    };
    var t = e.label, r = e.graphModel, a = r.gridSize, s = r.eventCenter;
    return i.stepDrag = new qo({
      onDragging: i.handleDragging,
      onDragEnd: i.handleDragEnd,
      step: a,
      eventType: "LABEL",
      model: t,
      eventCenter: s
    }), i.state = {
      isEditing: !1,
      isHovered: !1,
      isDragging: !1,
      isSelected: !1
    }, i;
  }
  return n.prototype.setElementModelLabelInfo = function(e) {
    var i = this.props, t = i.label, r = i.element, a = i.graphModel, s = r.properties._label, d = Ss(s, function(c) {
      return c.id === t.id;
    }), l = s[d];
    s[d] = Wi(Wi({}, l), e);
    var u = a.getElement(r.id);
    u == null || u.setProperty("_label", s);
  }, n.prototype.componentDidMount = function() {
    var e = this, i = this.props, t = i.label, r = i.element;
    i.graphModel.eventCenter.on("blank:click,node:click,edge:click,label:click", function(a) {
      var s, d, l, u, c = a.data;
      if (((c == null ? void 0 : c.type) !== "label" || c.type === "label" && c.id !== t.id || e.state.isSelected) && e.setState({ isSelected: !1 }), ((c == null ? void 0 : c.type) !== "label" || c.type == "label" && c.id !== t.id) && e.state.isEditing) {
        e.setState({ isEditing: !1 });
        var h = (d = (s = e.textRef.current) === null || s === void 0 ? void 0 : s.innerText) !== null && d !== void 0 ? d : "", f = (u = (l = e.textRef.current) === null || l === void 0 ? void 0 : l.innerHTML) !== null && u !== void 0 ? u : "";
        e.setElementModelLabelInfo({
          value: h,
          content: f,
          isSelected: !1
        }), r.setElementState(sr.DEFAULT);
      }
      ((c == null ? void 0 : c.type) !== "label" || c.type == "label" && c.id !== t.id) && e.textRef.current && (e.textRef.current.contentEditable = "false");
    });
  }, n.prototype.componentDidUpdate = function() {
  }, n.prototype.componentWillUnmount = function() {
    this.props.graphModel.eventCenter.off("blank:click,node:click,edge:click");
  }, n.prototype.render = function() {
    var e, i = this.props, t = i.label, r = i.element, a = i.graphModel, s = this.state, d = s.isDragging, l = s.isHovered, u = s.isSelected, c = s.isEditing, h = a.transformModel.getTransformStyle().transform, f = t.id, p = t.x, v = t.y, g = t.zIndex, b = t.vertical, _ = t.style, D = t.rotate, L = t.content, W = t.labelWidth, B = t.textOverflowMode, K = W != null ? W : r.BaseType === "node" ? r.width - 20 : 80, Y = {
      left: "".concat(p - K / 2, "px"),
      top: "".concat(v - 10, "px"),
      width: "".concat(K, "px"),
      height: "20px",
      zIndex: g != null ? g : 1,
      transform: D ? "".concat(h, " rotate(").concat(D, "deg)") : "".concat(h, " rotate(").concat(b ? -0.25 : 0, "turn)")
    };
    return Fe("div", {
      id: "element-container-".concat(f),
      className: (0, pr.default)("lf-label-editor-container"),
      style: Y,
      onPointerDown: this.handleMouseDown,
      onPointerUp: this.handleMouseUp,
      onClick: this.handleClick,
      onDblClick: this.handleDbClick,
      onBlur: this.handleBlur,
      onMouseEnter: this.setHoverOn,
      onMouseOver: this.setHoverOn,
      onMouseLeave: this.setHoverOff,
      children: Fe("div", {
        ref: this.textRef,
        id: "editor-container-".concat(f),
        className: (0, pr.default)("lf-label-editor", (e = {
          "lf-label-editor-dragging": d,
          "lf-label-editor-editing": c,
          "lf-label-editor-hover": !c && (l || u)
        }, e["lf-label-editor-".concat(B)] = !c, e)),
        onInput: this.handleInput,
        style: Wi({
          maxWidth: "".concat(K, "px"),
          boxSizing: "border-box",
          display: "inline-block",
          background: c || r.BaseType === "edge" ? "#fff" : "transparent"
        }, _),
        dangerouslySetInnerHTML: { __html: L }
      })
    });
  }, n = Xd([ea], n), n;
})(Pn), Et = function(o, n, e, i) {
  var t = arguments.length, r = t < 3 ? n : i === null ? i = Object.getOwnPropertyDescriptor(n, e) : i, a;
  if (typeof Reflect == "object" && typeof Reflect.decorate == "function") r = Reflect.decorate(o, n, e, i);
  else for (var s = o.length - 1; s >= 0; s--) (a = o[s]) && (r = (t < 3 ? a(r) : t > 3 ? a(n, e, r) : a(n, e)) || r);
  return t > 3 && r && Object.defineProperty(n, e, r), r;
}, Vd = lr, Kd = (function() {
  function o(n, e, i) {
    var t;
    this.type = "label", this.content = "", this.value = "", this.style = {}, this.vertical = !1, this.editable = !0, this.draggable = !0, this.textOverflowMode = "default", this.element = e, this.graphModel = i, this.id = (t = n.id) !== null && t !== void 0 ? t : Vd(), this.initLabelData(n);
  }
  return o.prototype.initLabelData = function(n) {
    Rn(this, n);
  }, o.prototype.getData = function() {
    return {
      id: this.id,
      x: this.x,
      y: this.y,
      type: "label",
      content: this.content,
      value: this.value,
      rotate: this.rotate,
      style: Ja(this.style),
      draggable: this.draggable,
      editable: this.editable,
      labelWidth: this.labelWidth,
      textOverflowMode: this.textOverflowMode,
      vertical: this.vertical
    };
  }, Et([ot], o.prototype, "x", void 0), Et([ot], o.prototype, "y", void 0), Et([ot], o.prototype, "content", void 0), Et([ot], o.prototype, "value", void 0), Et([ot], o.prototype, "rotate", void 0), Et([ot], o.prototype, "style", void 0), Et([ot], o.prototype, "zIndex", void 0), Et([ot], o.prototype, "vertical", void 0), Et([ot], o.prototype, "editable", void 0), Et([ot], o.prototype, "draggable", void 0), Et([ot], o.prototype, "labelWidth", void 0), Et([ot], o.prototype, "textOverflowMode", void 0), o;
})(), qd = /* @__PURE__ */ br(((o, n) => {
  "classList" in document.createElement("_") || (function(e) {
    "use strict";
    if ("Element" in e) {
      var i = "classList", t = "prototype", r = e.Element[t], a = Object, s = String[t].trim || function() {
        return this.replace(/^\s+|\s+$/g, "");
      }, d = Array[t].indexOf || function(v) {
        for (var g = 0, b = this.length; g < b; g++) if (g in this && this[g] === v) return g;
        return -1;
      }, l = function(v, g) {
        this.name = v, this.code = DOMException[v], this.message = g;
      }, u = function(v, g) {
        if (g === "") throw new l("SYNTAX_ERR", "An invalid or illegal string was specified");
        if (/\s/.test(g)) throw new l("INVALID_CHARACTER_ERR", "String contains an invalid character");
        return d.call(v, g);
      }, c = function(v) {
        for (var g = s.call(v.getAttribute("class") || ""), b = g ? g.split(/\s+/) : [], _ = 0, D = b.length; _ < D; _++) this.push(b[_]);
        this._updateClassName = function() {
          v.setAttribute("class", this.toString());
        };
      }, h = c[t] = [], f = function() {
        return new c(this);
      };
      if (l[t] = Error[t], h.item = function(v) {
        return this[v] || null;
      }, h.contains = function(v) {
        return v += "", u(this, v) !== -1;
      }, h.add = function() {
        var v = arguments, g = 0, b = v.length, _, D = !1;
        do
          _ = v[g] + "", u(this, _) === -1 && (this.push(_), D = !0);
        while (++g < b);
        D && this._updateClassName();
      }, h.remove = function() {
        var v = arguments, g = 0, b = v.length, _, D = !1, L;
        do
          for (_ = v[g] + "", L = u(this, _); L !== -1; )
            this.splice(L, 1), D = !0, L = u(this, _);
        while (++g < b);
        D && this._updateClassName();
      }, h.toggle = function(v, g) {
        v += "";
        var b = this.contains(v), _ = b ? g !== !0 && "remove" : g !== !1 && "add";
        return _ && this[_](v), g === !0 || g === !1 ? g : !b;
      }, h.toString = function() {
        return this.join(" ");
      }, a.defineProperty) {
        var p = {
          get: f,
          enumerable: !0,
          configurable: !0
        };
        try {
          a.defineProperty(r, i, p);
        } catch (v) {
          v.number === -2146823252 && (p.enumerable = !1, a.defineProperty(r, i, p));
        }
      } else a[t].__defineGetter__ && r.__defineGetter__(i, f);
    }
  })(self), (function(e) {
    "use strict";
    if (e.URL = e.URL || e.webkitURL, e.Blob && e.URL) try {
      new Blob();
      return;
    } catch (r) {
    }
    var i = e.BlobBuilder || e.WebKitBlobBuilder || e.MozBlobBuilder || (function(r) {
      var a = function(Y) {
        return Object.prototype.toString.call(Y).match(/^\[object\s(.*)\]$/)[1];
      }, s = function() {
        this.data = [];
      }, d = function(te, se, Le) {
        this.data = te, this.size = te.length, this.type = se, this.encoding = Le;
      }, l = s.prototype, u = d.prototype, c = r.FileReaderSync, h = function(Y) {
        this.code = this[this.name = Y];
      }, f = "NOT_FOUND_ERR SECURITY_ERR ABORT_ERR NOT_READABLE_ERR ENCODING_ERR NO_MODIFICATION_ALLOWED_ERR INVALID_STATE_ERR SYNTAX_ERR".split(" "), p = f.length, v = r.URL || r.webkitURL || r, g = v.createObjectURL, b = v.revokeObjectURL, _ = v, D = r.btoa, L = r.atob, W = r.ArrayBuffer, B = r.Uint8Array, K = /^[\w-]+:\/*\[?[\w\.:-]+\]?(?::[0-9]+)?/;
      for (d.fake = u.fake = !0; p--; ) h.prototype[f[p]] = p + 1;
      return v.createObjectURL || (_ = r.URL = function(Y) {
        var te = document.createElementNS("http://www.w3.org/1999/xhtml", "a"), se;
        return te.href = Y, "origin" in te || (te.protocol.toLowerCase() === "data:" ? te.origin = null : (se = Y.match(K), te.origin = se && se[1])), te;
      }), _.createObjectURL = function(Y) {
        var te = Y.type, se;
        if (te === null && (te = "application/octet-stream"), Y instanceof d)
          return se = "data:" + te, Y.encoding === "base64" ? se + ";base64," + Y.data : Y.encoding === "URI" ? se + "," + decodeURIComponent(Y.data) : D ? se + ";base64," + D(Y.data) : se + "," + encodeURIComponent(Y.data);
        if (g) return g.call(v, Y);
      }, _.revokeObjectURL = function(Y) {
        Y.substring(0, 5) !== "data:" && b && b.call(v, Y);
      }, l.append = function(Y) {
        var te = this.data;
        if (B && (Y instanceof W || Y instanceof B)) {
          for (var se = "", Le = new B(Y), ze = 0, xe = Le.length; ze < xe; ze++) se += String.fromCharCode(Le[ze]);
          te.push(se);
        } else if (a(Y) === "Blob" || a(Y) === "File")
          if (c) {
            var w = new c();
            te.push(w.readAsBinaryString(Y));
          } else throw new h("NOT_READABLE_ERR");
        else Y instanceof d ? Y.encoding === "base64" && L ? te.push(L(Y.data)) : Y.encoding === "URI" ? te.push(decodeURIComponent(Y.data)) : Y.encoding === "raw" && te.push(Y.data) : (typeof Y != "string" && (Y += ""), te.push(unescape(encodeURIComponent(Y))));
      }, l.getBlob = function(Y) {
        return arguments.length || (Y = null), new d(this.data.join(""), Y, "raw");
      }, l.toString = function() {
        return "[object BlobBuilder]";
      }, u.slice = function(Y, te, se) {
        var Le = arguments.length;
        return Le < 3 && (se = null), new d(this.data.slice(Y, Le > 1 ? te : this.data.length), se, this.encoding);
      }, u.toString = function() {
        return "[object Blob]";
      }, u.close = function() {
        this.size = 0, delete this.data;
      }, s;
    })(e);
    e.Blob = function(r, a) {
      var s = a && a.type || "", d = new i();
      if (r) for (var l = 0, u = r.length; l < u; l++) Uint8Array && r[l] instanceof Uint8Array ? d.append(r[l].buffer) : d.append(r[l]);
      var c = d.getBlob(s);
      return !c.slice && c.webkitSlice && (c.slice = c.webkitSlice), c;
    };
    var t = Object.getPrototypeOf || function(r) {
      return r.__proto__;
    };
    e.Blob.prototype = t(new e.Blob());
  })(typeof self != "undefined" && self || typeof window != "undefined" && window || o.content || o), (function(e, i) {
    "use strict";
    !(typeof n == "object" && typeof process != "undefined" && process && process.versions && process.versions.electron) && typeof n == "object" ? n.exports = i : typeof define == "function" && define.amd ? define(function() {
      return i;
    }) : e.MediumEditor = i;
  })(o, (function() {
    "use strict";
    function e(i, t) {
      "use strict";
      return this.init(i, t);
    }
    return e.extensions = {}, (function(i) {
      "use strict";
      function t(l, u) {
        var c, h = Array.prototype.slice.call(arguments, 2);
        u = u || {};
        for (var f = 0; f < h.length; f++) {
          var p = h[f];
          if (p)
            for (c in p) p.hasOwnProperty(c) && typeof p[c] != "undefined" && (l || u.hasOwnProperty(c) === !1) && (u[c] = p[c]);
        }
        return u;
      }
      var r = !1;
      try {
        var a = document.createElement("div"), s = document.createTextNode(" ");
        a.appendChild(s), r = a.contains(s);
      } catch (l) {
      }
      var d = {
        isIE: navigator.appName === "Microsoft Internet Explorer" || navigator.appName === "Netscape" && (/* @__PURE__ */ new RegExp("Trident/.*rv:([0-9]{1,}[.0-9]{0,})")).exec(navigator.userAgent) !== null,
        isEdge: /Edge\/\d+/.exec(navigator.userAgent) !== null,
        isFF: navigator.userAgent.toLowerCase().indexOf("firefox") > -1,
        isMac: i.navigator.platform.toUpperCase().indexOf("MAC") >= 0,
        keyCode: {
          BACKSPACE: 8,
          TAB: 9,
          ENTER: 13,
          ESCAPE: 27,
          SPACE: 32,
          DELETE: 46,
          K: 75,
          M: 77,
          V: 86
        },
        isMetaCtrlKey: function(l) {
          return !!(d.isMac && l.metaKey || !d.isMac && l.ctrlKey);
        },
        isKey: function(l, u) {
          var c = d.getKeyCode(l);
          return Array.isArray(u) === !1 ? c === u : u.indexOf(c) !== -1;
        },
        getKeyCode: function(l) {
          var u = l.which;
          return u === null && (u = l.charCode !== null ? l.charCode : l.keyCode), u;
        },
        blockContainerElementNames: [
          "p",
          "h1",
          "h2",
          "h3",
          "h4",
          "h5",
          "h6",
          "blockquote",
          "pre",
          "ul",
          "li",
          "ol",
          "address",
          "article",
          "aside",
          "audio",
          "canvas",
          "dd",
          "dl",
          "dt",
          "fieldset",
          "figcaption",
          "figure",
          "footer",
          "form",
          "header",
          "hgroup",
          "main",
          "nav",
          "noscript",
          "output",
          "section",
          "video",
          "table",
          "thead",
          "tbody",
          "tfoot",
          "tr",
          "th",
          "td"
        ],
        emptyElementNames: [
          "br",
          "col",
          "colgroup",
          "hr",
          "img",
          "input",
          "source",
          "wbr"
        ],
        extend: function() {
          var u = [!0].concat(Array.prototype.slice.call(arguments));
          return t.apply(this, u);
        },
        defaults: function() {
          var u = [!1].concat(Array.prototype.slice.call(arguments));
          return t.apply(this, u);
        },
        createLink: function(l, u, c, h) {
          var f = l.createElement("a");
          return d.moveTextRangeIntoElement(u[0], u[u.length - 1], f), f.setAttribute("href", c), h && (h === "_blank" && f.setAttribute("rel", "noopener noreferrer"), f.setAttribute("target", h)), f;
        },
        findOrCreateMatchingTextNodes: function(l, u, c) {
          for (var h = l.createTreeWalker(u, NodeFilter.SHOW_ALL, null, !1), f = [], p = 0, v = !1, g = null, b = null; (g = h.nextNode()) !== null; ) if (!(g.nodeType > 3))
            if (g.nodeType === 3) {
              if (!v && c.start < p + g.nodeValue.length && (v = !0, b = d.splitStartNodeIfNeeded(g, c.start, p)), v && d.splitEndNodeIfNeeded(g, b, c.end, p), v && p === c.end) break;
              if (v && p > c.end + 1) throw new Error("PerformLinking overshot the target!");
              v && f.push(b || g), p += g.nodeValue.length, b !== null && (p += b.nodeValue.length, h.nextNode()), b = null;
            } else g.tagName.toLowerCase() === "img" && (!v && c.start <= p && (v = !0), v && f.push(g));
          return f;
        },
        splitStartNodeIfNeeded: function(l, u, c) {
          return u !== c ? l.splitText(u - c) : null;
        },
        splitEndNodeIfNeeded: function(l, u, c, h) {
          var f = h + l.nodeValue.length + (u ? u.nodeValue.length : 0) - 1, p = c - h - (u ? l.nodeValue.length : 0);
          f >= c && h !== f && p !== 0 && (u || l).splitText(p);
        },
        splitByBlockElements: function(l) {
          if (l.nodeType !== 3 && l.nodeType !== 1) return [];
          var u = [], c = e.util.blockContainerElementNames.join(",");
          if (l.nodeType === 3 || l.querySelectorAll(c).length === 0) return [l];
          for (var h = 0; h < l.childNodes.length; h++) {
            var f = l.childNodes[h];
            f.nodeType === 3 ? u.push(f) : f.nodeType === 1 && (f.querySelectorAll(c).length === 0 ? u.push(f) : u = u.concat(e.util.splitByBlockElements(f)));
          }
          return u;
        },
        findAdjacentTextNodeWithContent: function(u, c, h) {
          var f = !1, p, v = h.createNodeIterator(u, NodeFilter.SHOW_TEXT, null, !1);
          for (p = v.nextNode(); p; ) {
            if (p === c) f = !0;
            else if (f && p.nodeType === 3 && p.nodeValue && p.nodeValue.trim().length > 0)
              break;
            p = v.nextNode();
          }
          return p;
        },
        findPreviousSibling: function(l) {
          if (!l || d.isMediumEditorElement(l)) return !1;
          for (var u = l.previousSibling; !u && !d.isMediumEditorElement(l.parentNode); )
            l = l.parentNode, u = l.previousSibling;
          return u;
        },
        isDescendant: function(u, c, h) {
          if (!u || !c) return !1;
          if (u === c) return !!h;
          if (u.nodeType !== 1) return !1;
          if (r || c.nodeType !== 3) return u.contains(c);
          for (var f = c.parentNode; f !== null; ) {
            if (f === u) return !0;
            f = f.parentNode;
          }
          return !1;
        },
        isElement: function(u) {
          return !!(u && u.nodeType === 1);
        },
        throttle: function(l, u) {
          var c = 50, h, f, p, v = null, g = 0, b = function() {
            g = Date.now(), v = null, p = l.apply(h, f), v || (h = f = null);
          };
          return !u && u !== 0 && (u = c), function() {
            var _ = Date.now(), D = u - (_ - g);
            return h = this, f = arguments, D <= 0 || D > u ? (v && (clearTimeout(v), v = null), g = _, p = l.apply(h, f), v || (h = f = null)) : v || (v = setTimeout(b, D)), p;
          };
        },
        traverseUp: function(l, u) {
          if (!l) return !1;
          do {
            if (l.nodeType === 1) {
              if (u(l)) return l;
              if (d.isMediumEditorElement(l)) return !1;
            }
            l = l.parentNode;
          } while (l);
          return !1;
        },
        htmlEntities: function(l) {
          return String(l).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
        },
        insertHTMLCommand: function(l, u) {
          var c, h, f, p, v, g, b, _ = !1, D = [
            "insertHTML",
            !1,
            u
          ];
          if (!e.util.isEdge && l.queryCommandSupported("insertHTML")) try {
            return l.execCommand.apply(l, D);
          } catch (L) {
          }
          if (c = l.getSelection(), c.rangeCount) {
            if (h = c.getRangeAt(0), b = h.commonAncestorContainer, d.isMediumEditorElement(b) && !b.firstChild) h.selectNode(b.appendChild(l.createTextNode("")));
            else if (b.nodeType === 3 && h.startOffset === 0 && h.endOffset === b.nodeValue.length || b.nodeType !== 3 && b.innerHTML === h.toString()) {
              for (; !d.isMediumEditorElement(b) && b.parentNode && b.parentNode.childNodes.length === 1 && !d.isMediumEditorElement(b.parentNode); ) b = b.parentNode;
              h.selectNode(b);
            }
            for (h.deleteContents(), f = l.createElement("div"), f.innerHTML = u, p = l.createDocumentFragment(); f.firstChild; )
              v = f.firstChild, g = p.appendChild(v);
            h.insertNode(p), g && (h = h.cloneRange(), h.setStartAfter(g), h.collapse(!0), e.selection.selectRange(l, h)), _ = !0;
          }
          return l.execCommand.callListeners && l.execCommand.callListeners(D, _), _;
        },
        execFormatBlock: function(l, u) {
          var c = d.getTopBlockContainer(e.selection.getSelectionStart(l)), h;
          if (u === "blockquote") {
            if (c && (h = Array.prototype.slice.call(c.childNodes), h.some(function(f) {
              return d.isBlockContainer(f);
            })))
              return l.execCommand("outdent", !1, null);
            if (d.isIE) return l.execCommand("indent", !1, u);
          }
          if (c && u === c.nodeName.toLowerCase() && (u = "p"), d.isIE && (u = "<" + u + ">"), c && c.nodeName.toLowerCase() === "blockquote") {
            if (d.isIE && u === "<p>") return l.execCommand("outdent", !1, u);
            if ((d.isFF || d.isEdge) && u === "p")
              return h = Array.prototype.slice.call(c.childNodes), h.some(function(f) {
                return !d.isBlockContainer(f);
              }) && l.execCommand("formatBlock", !1, u), l.execCommand("outdent", !1, u);
          }
          return l.execCommand("formatBlock", !1, u);
        },
        setTargetBlank: function(l, u) {
          var c, h = u || !1;
          if (l.nodeName.toLowerCase() === "a")
            l.target = "_blank", l.rel = "noopener noreferrer";
          else
            for (l = l.getElementsByTagName("a"), c = 0; c < l.length; c += 1) (h === !1 || h === l[c].attributes.href.value) && (l[c].target = "_blank", l[c].rel = "noopener noreferrer");
        },
        removeTargetBlank: function(l, u) {
          var c;
          if (l.nodeName.toLowerCase() === "a")
            l.removeAttribute("target"), l.removeAttribute("rel");
          else
            for (l = l.getElementsByTagName("a"), c = 0; c < l.length; c += 1) u === l[c].attributes.href.value && (l[c].removeAttribute("target"), l[c].removeAttribute("rel"));
        },
        addClassToAnchors: function(l, u) {
          var c = u.split(" "), h, f;
          if (l.nodeName.toLowerCase() === "a") for (f = 0; f < c.length; f += 1) l.classList.add(c[f]);
          else {
            var p = l.getElementsByTagName("a");
            if (p.length === 0) {
              var v = d.getClosestTag(l, "a");
              l = v ? [v] : [];
            } else l = p;
            for (h = 0; h < l.length; h += 1) for (f = 0; f < c.length; f += 1) l[h].classList.add(c[f]);
          }
        },
        isListItem: function(l) {
          if (!l) return !1;
          if (l.nodeName.toLowerCase() === "li") return !0;
          for (var u = l.parentNode, c = u.nodeName.toLowerCase(); c === "li" || !d.isBlockContainer(u) && c !== "div"; ) {
            if (c === "li") return !0;
            if (u = u.parentNode, u) c = u.nodeName.toLowerCase();
            else return !1;
          }
          return !1;
        },
        cleanListDOM: function(l, u) {
          if (u.nodeName.toLowerCase() === "li") {
            var c = u.parentElement;
            c.parentElement.nodeName.toLowerCase() === "p" && (d.unwrap(c.parentElement, l), e.selection.moveCursor(l, u.firstChild, u.firstChild.textContent.length));
          }
        },
        splitOffDOMTree: function(l, u, c) {
          for (var h = u, f = null, p = !c; h !== l; ) {
            var v = h.parentNode, g = v.cloneNode(!1), b = p ? h : v.firstChild, _;
            for (f && (p ? g.appendChild(f) : _ = f), f = g; b; ) {
              var D = b.nextSibling;
              b === h ? (b.hasChildNodes() ? b = b.cloneNode(!1) : b.parentNode.removeChild(b), b.textContent && f.appendChild(b), b = p ? D : null) : (b.parentNode.removeChild(b), (b.hasChildNodes() || b.textContent) && f.appendChild(b), b = D);
            }
            _ && f.appendChild(_), h = v;
          }
          return f;
        },
        moveTextRangeIntoElement: function(l, u, c) {
          if (!l || !u) return !1;
          var h = d.findCommonRoot(l, u);
          if (!h) return !1;
          if (u === l) {
            var f = l.parentNode, p = l.nextSibling;
            return f.removeChild(l), c.appendChild(l), p ? f.insertBefore(c, p) : f.appendChild(c), c.hasChildNodes();
          }
          for (var v = [], g, b, _, D = 0; D < h.childNodes.length; D++)
            if (_ = h.childNodes[D], !g)
              d.isDescendant(_, l, !0) && (g = _);
            else if (d.isDescendant(_, u, !0)) {
              b = _;
              break;
            } else v.push(_);
          var L = b.nextSibling, W = h.ownerDocument.createDocumentFragment();
          return g === l ? (g.parentNode.removeChild(g), W.appendChild(g)) : W.appendChild(d.splitOffDOMTree(g, l)), v.forEach(function(B) {
            B.parentNode.removeChild(B), W.appendChild(B);
          }), b === u ? (b.parentNode.removeChild(b), W.appendChild(b)) : W.appendChild(d.splitOffDOMTree(b, u, !0)), c.appendChild(W), b.parentNode === h ? h.insertBefore(c, b) : L ? h.insertBefore(c, L) : h.appendChild(c), c.hasChildNodes();
        },
        depthOfNode: function(l) {
          for (var u = 0, c = l; c.parentNode !== null; )
            c = c.parentNode, u++;
          return u;
        },
        findCommonRoot: function(l, u) {
          for (var c = d.depthOfNode(l), h = d.depthOfNode(u), f = l, p = u; c !== h; ) c > h ? (f = f.parentNode, c -= 1) : (p = p.parentNode, h -= 1);
          for (; f !== p; )
            f = f.parentNode, p = p.parentNode;
          return f;
        },
        isElementAtBeginningOfBlock: function(l) {
          for (var u, c; !d.isBlockContainer(l) && !d.isMediumEditorElement(l); ) {
            for (c = l; c = c.previousSibling; )
              if (u = c.nodeType === 3 ? c.nodeValue : c.textContent, u.length > 0) return !1;
            l = l.parentNode;
          }
          return !0;
        },
        isMediumEditorElement: function(l) {
          return l && l.getAttribute && !!l.getAttribute("data-medium-editor-element");
        },
        getContainerEditorElement: function(l) {
          return d.traverseUp(l, function(u) {
            return d.isMediumEditorElement(u);
          });
        },
        isBlockContainer: function(l) {
          return l && l.nodeType !== 3 && d.blockContainerElementNames.indexOf(l.nodeName.toLowerCase()) !== -1;
        },
        getClosestBlockContainer: function(l) {
          return d.traverseUp(l, function(u) {
            return d.isBlockContainer(u) || d.isMediumEditorElement(u);
          });
        },
        getTopBlockContainer: function(l) {
          var u = d.isBlockContainer(l) ? l : !1;
          return d.traverseUp(l, function(c) {
            return d.isBlockContainer(c) && (u = c), !u && d.isMediumEditorElement(c) ? (u = c, !0) : !1;
          }), u;
        },
        getFirstSelectableLeafNode: function(l) {
          for (; l && l.firstChild; ) l = l.firstChild;
          if (l = d.traverseUp(l, function(c) {
            return d.emptyElementNames.indexOf(c.nodeName.toLowerCase()) === -1;
          }), l.nodeName.toLowerCase() === "table") {
            var u = l.querySelector("th, td");
            u && (l = u);
          }
          return l;
        },
        getFirstTextNode: function(l) {
          return d.warn("getFirstTextNode is deprecated and will be removed in version 6.0.0"), d._getFirstTextNode(l);
        },
        _getFirstTextNode: function(l) {
          if (l.nodeType === 3) return l;
          for (var u = 0; u < l.childNodes.length; u++) {
            var c = d._getFirstTextNode(l.childNodes[u]);
            if (c !== null) return c;
          }
          return null;
        },
        ensureUrlHasProtocol: function(l) {
          return l.indexOf("://") === -1 ? "http://" + l : l;
        },
        warn: function() {
          i.console !== void 0 && typeof i.console.warn == "function" && i.console.warn.apply(i.console, arguments);
        },
        deprecated: function(l, u, c) {
          var h = l + " is deprecated, please use " + u + " instead.";
          c && (h += " Will be removed in " + c), d.warn(h);
        },
        deprecatedMethod: function(l, u, c, h) {
          d.deprecated(l, u, h), typeof this[u] == "function" && this[u].apply(this, c);
        },
        cleanupAttrs: function(l, u) {
          u.forEach(function(c) {
            l.removeAttribute(c);
          });
        },
        cleanupTags: function(l, u) {
          u.indexOf(l.nodeName.toLowerCase()) !== -1 && l.parentNode.removeChild(l);
        },
        unwrapTags: function(l, u) {
          u.indexOf(l.nodeName.toLowerCase()) !== -1 && e.util.unwrap(l, document);
        },
        getClosestTag: function(l, u) {
          return d.traverseUp(l, function(c) {
            return c.nodeName.toLowerCase() === u.toLowerCase();
          });
        },
        unwrap: function(l, u) {
          for (var c = u.createDocumentFragment(), h = Array.prototype.slice.call(l.childNodes), f = 0; f < h.length; f++) c.appendChild(h[f]);
          c.childNodes.length ? l.parentNode.replaceChild(c, l) : l.parentNode.removeChild(l);
        },
        guid: function() {
          function l() {
            return Math.floor((1 + Math.random()) * 65536).toString(16).substring(1);
          }
          return l() + l() + "-" + l() + "-" + l() + "-" + l() + "-" + l() + l() + l();
        }
      };
      e.util = d;
    })(window), (function() {
      "use strict";
      var i = function(t) {
        e.util.extend(this, t);
      };
      i.extend = function(t) {
        var r = this, a;
        t && t.hasOwnProperty("constructor") ? a = t.constructor : a = function() {
          return r.apply(this, arguments);
        }, e.util.extend(a, r);
        var s = function() {
          this.constructor = a;
        };
        return s.prototype = r.prototype, a.prototype = new s(), t && e.util.extend(a.prototype, t), a;
      }, i.prototype = {
        init: function() {
        },
        base: void 0,
        name: void 0,
        checkState: void 0,
        destroy: void 0,
        queryCommandState: void 0,
        isActive: void 0,
        isAlreadyApplied: void 0,
        setActive: void 0,
        setInactive: void 0,
        getInteractionElements: void 0,
        window: void 0,
        document: void 0,
        getEditorElements: function() {
          return this.base.elements;
        },
        getEditorId: function() {
          return this.base.id;
        },
        getEditorOption: function(t) {
          return this.base.options[t];
        }
      }, [
        "execAction",
        "on",
        "off",
        "subscribe",
        "trigger"
      ].forEach(function(t) {
        i.prototype[t] = function() {
          return this.base[t].apply(this.base, arguments);
        };
      }), e.Extension = i;
    })(), (function() {
      "use strict";
      function i(t) {
        return e.util.isBlockContainer(t) ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_SKIP;
      }
      e.selection = {
        findMatchingSelectionParent: function(t, r) {
          var a = r.getSelection(), s, d;
          return a.rangeCount === 0 ? !1 : (s = a.getRangeAt(0), d = s.commonAncestorContainer, e.util.traverseUp(d, t));
        },
        getSelectionElement: function(t) {
          return this.findMatchingSelectionParent(function(r) {
            return e.util.isMediumEditorElement(r);
          }, t);
        },
        exportSelection: function(t, r) {
          if (!t) return null;
          var a = null, s = r.getSelection();
          if (s.rangeCount > 0) {
            var d = s.getRangeAt(0), l = d.cloneRange(), u;
            l.selectNodeContents(t), l.setEnd(d.startContainer, d.startOffset), u = l.toString().length, a = {
              start: u,
              end: u + d.toString().length
            }, this.doesRangeStartWithImages(d, r) && (a.startsWithImage = !0);
            var c = this.getTrailingImageCount(t, a, d.endContainer, d.endOffset);
            if (c && (a.trailingImageCount = c), u !== 0) {
              var h = this.getIndexRelativeToAdjacentEmptyBlocks(r, t, d.startContainer, d.startOffset);
              h !== -1 && (a.emptyBlocksIndex = h);
            }
          }
          return a;
        },
        importSelection: function(t, r, a, s) {
          if (!(!t || !r)) {
            var d = a.createRange();
            d.setStart(r, 0), d.collapse(!0);
            var l = r, u = [], c = 0, h = !1, f = !1, p = 0, v = !1, g, b = !1, _ = null;
            for ((s || t.startsWithImage || typeof t.emptyBlocksIndex != "undefined") && (b = !0); !v && l; ) {
              if (l.nodeType > 3) {
                l = u.pop();
                continue;
              }
              if (l.nodeType === 3 && !f)
                g = c + l.length, !h && t.start >= c && t.start <= g && (b || t.start < g ? (d.setStart(l, t.start - c), h = !0) : _ = l), h && t.end >= c && t.end <= g && (t.trailingImageCount ? f = !0 : (d.setEnd(l, t.end - c), v = !0)), c = g;
              else {
                if (t.trailingImageCount && f && (l.nodeName.toLowerCase() === "img" && p++, p === t.trailingImageCount)) {
                  for (var D = 0; l.parentNode.childNodes[D] !== l; ) D++;
                  d.setEnd(l.parentNode, D + 1), v = !0;
                }
                if (!v && l.nodeType === 1)
                  for (var L = l.childNodes.length - 1; L >= 0; )
                    u.push(l.childNodes[L]), L -= 1;
              }
              v || (l = u.pop());
            }
            !h && _ && (d.setStart(_, _.length), d.setEnd(_, _.length)), typeof t.emptyBlocksIndex != "undefined" && (d = this.importSelectionMoveCursorPastBlocks(a, r, t.emptyBlocksIndex, d)), s && (d = this.importSelectionMoveCursorPastAnchor(t, d)), this.selectRange(a, d);
          }
        },
        importSelectionMoveCursorPastAnchor: function(t, r) {
          var a = function(c) {
            return c.nodeName.toLowerCase() === "a";
          };
          if (t.start === t.end && r.startContainer.nodeType === 3 && r.startOffset === r.startContainer.nodeValue.length && e.util.traverseUp(r.startContainer, a)) {
            for (var s = r.startContainer, d = r.startContainer.parentNode; d !== null && d.nodeName.toLowerCase() !== "a"; ) d.childNodes[d.childNodes.length - 1] !== s ? d = null : (s = d, d = d.parentNode);
            if (d !== null && d.nodeName.toLowerCase() === "a") {
              for (var l = null, u = 0; l === null && u < d.parentNode.childNodes.length; u++) d.parentNode.childNodes[u] === d && (l = u);
              r.setStart(d.parentNode, l + 1), r.collapse(!0);
            }
          }
          return r;
        },
        importSelectionMoveCursorPastBlocks: function(t, r, a, s) {
          var d = t.createTreeWalker(r, NodeFilter.SHOW_ELEMENT, i, !1), l = s.startContainer, u, c, h = 0;
          for (a = a || 1, l.nodeType === 3 && e.util.isBlockContainer(l.previousSibling) ? u = l.previousSibling : u = e.util.getClosestBlockContainer(l); d.nextNode(); ) if (!c)
            u === d.currentNode && (c = d.currentNode);
          else if (c = d.currentNode, h++, h === a || c.textContent.length > 0) break;
          return c || (c = u), s.setStart(e.util.getFirstSelectableLeafNode(c), 0), s;
        },
        getIndexRelativeToAdjacentEmptyBlocks: function(t, r, a, s) {
          if (a.textContent.length > 0 && s > 0) return -1;
          var d = a;
          if (d.nodeType !== 3 && (d = a.childNodes[s]), d) {
            if (!e.util.isElementAtBeginningOfBlock(d)) return -1;
            var l = e.util.findPreviousSibling(d);
            if (l) {
              if (l.nodeValue) return -1;
            } else return -1;
          }
          for (var u = e.util.getClosestBlockContainer(a), c = t.createTreeWalker(r, NodeFilter.SHOW_ELEMENT, i, !1), h = 0; c.nextNode(); ) {
            var f = c.currentNode.textContent === "";
            if ((f || h > 0) && (h += 1), c.currentNode === u) return h;
            f || (h = 0);
          }
          return h;
        },
        doesRangeStartWithImages: function(t, r) {
          if (t.startOffset !== 0 || t.startContainer.nodeType !== 1) return !1;
          if (t.startContainer.nodeName.toLowerCase() === "img") return !0;
          var a = t.startContainer.querySelector("img");
          if (!a) return !1;
          for (var s = r.createTreeWalker(t.startContainer, NodeFilter.SHOW_ALL, null, !1); s.nextNode(); ) {
            var d = s.currentNode;
            if (d === a) break;
            if (d.nodeValue) return !1;
          }
          return !0;
        },
        getTrailingImageCount: function(t, r, a, s) {
          if (s === 0 || a.nodeType !== 1 || a.nodeName.toLowerCase() !== "img" && !a.querySelector("img")) return 0;
          for (var d = a.childNodes[s - 1]; d.hasChildNodes(); ) d = d.lastChild;
          for (var l = t, u = [], c = 0, h = !1, f = !1, p = !1, v, g = 0; !p && l; ) {
            if (l.nodeType > 3) {
              l = u.pop();
              continue;
            }
            if (l.nodeType === 3 && !f)
              g = 0, v = c + l.length, !h && r.start >= c && r.start <= v && (h = !0), h && r.end >= c && r.end <= v && (f = !0), c = v;
            else if (l.nodeName.toLowerCase() === "img" && g++, l === d) p = !0;
            else if (l.nodeType === 1)
              for (var b = l.childNodes.length - 1; b >= 0; )
                u.push(l.childNodes[b]), b -= 1;
            p || (l = u.pop());
          }
          return g;
        },
        selectionContainsContent: function(t) {
          var r = t.getSelection();
          if (!r || r.isCollapsed || !r.rangeCount) return !1;
          if (r.toString().trim() !== "") return !0;
          var a = this.getSelectedParentElement(r.getRangeAt(0));
          return !!(a && (a.nodeName.toLowerCase() === "img" || a.nodeType === 1 && a.querySelector("img")));
        },
        selectionInContentEditableFalse: function(t) {
          var r, a = this.findMatchingSelectionParent(function(s) {
            var d = s && s.getAttribute("contenteditable");
            return d === "true" && (r = !0), s.nodeName !== "#text" && d === "false";
          }, t);
          return !r && a;
        },
        getSelectionHtml: function(r) {
          var a, s = "", d = r.getSelection(), l, u;
          if (d.rangeCount) {
            for (u = r.createElement("div"), a = 0, l = d.rangeCount; a < l; a += 1) u.appendChild(d.getRangeAt(a).cloneContents());
            s = u.innerHTML;
          }
          return s;
        },
        getCaretOffsets: function(r, a) {
          var s, d;
          return a || (a = window.getSelection().getRangeAt(0)), s = a.cloneRange(), d = a.cloneRange(), s.selectNodeContents(r), s.setEnd(a.endContainer, a.endOffset), d.selectNodeContents(r), d.setStart(a.endContainer, a.endOffset), {
            left: s.toString().length,
            right: d.toString().length
          };
        },
        rangeSelectsSingleNode: function(t) {
          var r = t.startContainer;
          return r === t.endContainer && r.hasChildNodes() && t.endOffset === t.startOffset + 1;
        },
        getSelectedParentElement: function(t) {
          return t ? this.rangeSelectsSingleNode(t) && t.startContainer.childNodes[t.startOffset].nodeType !== 3 ? t.startContainer.childNodes[t.startOffset] : t.startContainer.nodeType === 3 ? t.startContainer.parentNode : t.startContainer : null;
        },
        getSelectedElements: function(t) {
          var r = t.getSelection(), a, s, d;
          if (!r.rangeCount || r.isCollapsed || !r.getRangeAt(0).commonAncestorContainer) return [];
          if (a = r.getRangeAt(0), a.commonAncestorContainer.nodeType === 3) {
            for (s = [], d = a.commonAncestorContainer; d.parentNode && d.parentNode.childNodes.length === 1; )
              s.push(d.parentNode), d = d.parentNode;
            return s;
          }
          return [].filter.call(a.commonAncestorContainer.getElementsByTagName("*"), function(l) {
            return typeof r.containsNode == "function" ? r.containsNode(l, !0) : !0;
          });
        },
        selectNode: function(t, r) {
          var a = r.createRange();
          a.selectNodeContents(t), this.selectRange(r, a);
        },
        select: function(t, r, a, s, d) {
          var l = t.createRange();
          return l.setStart(r, a), s ? l.setEnd(s, d) : l.collapse(!0), this.selectRange(t, l), l;
        },
        clearSelection: function(t, r) {
          r ? t.getSelection().collapseToStart() : t.getSelection().collapseToEnd();
        },
        moveCursor: function(t, r, a) {
          this.select(t, r, a);
        },
        getSelectionRange: function(t) {
          var r = t.getSelection();
          return r.rangeCount === 0 ? null : r.getRangeAt(0);
        },
        selectRange: function(t, r) {
          var a = t.getSelection();
          a.removeAllRanges(), a.addRange(r);
        },
        getSelectionStart: function(t) {
          var r = t.getSelection().anchorNode;
          return r && r.nodeType === 3 ? r.parentNode : r;
        }
      };
    })(), (function() {
      "use strict";
      function i(r, a) {
        return r ? r.some(function(s) {
          if (typeof s.getInteractionElements != "function") return !1;
          var d = s.getInteractionElements();
          return d ? (Array.isArray(d) || (d = [d]), d.some(function(l) {
            return e.util.isDescendant(l, a, !0);
          })) : !1;
        }) : !1;
      }
      var t = function(r) {
        this.base = r, this.options = this.base.options, this.events = [], this.disabledEvents = {}, this.customEvents = {}, this.listeners = {};
      };
      t.prototype = {
        InputEventOnContenteditableSupported: !e.util.isIE && !e.util.isEdge,
        attachDOMEvent: function(r, a, s, d) {
          var l = this.base.options.contentWindow, u = this.base.options.ownerDocument;
          r = e.util.isElement(r) || [l, u].indexOf(r) > -1 ? [r] : r, Array.prototype.forEach.call(r, function(c) {
            c.addEventListener(a, s, d), this.events.push([
              c,
              a,
              s,
              d
            ]);
          }.bind(this));
        },
        detachDOMEvent: function(r, a, s, d) {
          var l, u, c = this.base.options.contentWindow, h = this.base.options.ownerDocument;
          r && (r = e.util.isElement(r) || [c, h].indexOf(r) > -1 ? [r] : r, Array.prototype.forEach.call(r, function(f) {
            l = this.indexOfListener(f, a, s, d), l !== -1 && (u = this.events.splice(l, 1)[0], u[0].removeEventListener(u[1], u[2], u[3]));
          }.bind(this)));
        },
        indexOfListener: function(r, a, s, d) {
          var l, u, c;
          for (l = 0, u = this.events.length; l < u; l = l + 1)
            if (c = this.events[l], c[0] === r && c[1] === a && c[2] === s && c[3] === d) return l;
          return -1;
        },
        detachAllDOMEvents: function() {
          for (var r = this.events.pop(); r; )
            r[0].removeEventListener(r[1], r[2], r[3]), r = this.events.pop();
        },
        detachAllEventsFromElement: function(r) {
          for (var a = this.events.filter(function(u) {
            return u && u[0].getAttribute && u[0].getAttribute("medium-editor-index") === r.getAttribute("medium-editor-index");
          }), s = 0, d = a.length; s < d; s++) {
            var l = a[s];
            this.detachDOMEvent(l[0], l[1], l[2], l[3]);
          }
        },
        attachAllEventsToElement: function(r) {
          this.listeners.editableInput && (this.contentCache[r.getAttribute("medium-editor-index")] = r.innerHTML), this.eventsCache && this.eventsCache.forEach(function(a) {
            this.attachDOMEvent(r, a.name, a.handler.bind(this));
          }, this);
        },
        enableCustomEvent: function(r) {
          this.disabledEvents[r] !== void 0 && delete this.disabledEvents[r];
        },
        disableCustomEvent: function(r) {
          this.disabledEvents[r] = !0;
        },
        attachCustomEvent: function(r, a) {
          this.setupListener(r), this.customEvents[r] || (this.customEvents[r] = []), this.customEvents[r].push(a);
        },
        detachCustomEvent: function(r, a) {
          var s = this.indexOfCustomListener(r, a);
          s !== -1 && this.customEvents[r].splice(s, 1);
        },
        indexOfCustomListener: function(r, a) {
          return !this.customEvents[r] || !this.customEvents[r].length ? -1 : this.customEvents[r].indexOf(a);
        },
        detachAllCustomEvents: function() {
          this.customEvents = {};
        },
        triggerCustomEvent: function(r, a, s) {
          this.customEvents[r] && !this.disabledEvents[r] && this.customEvents[r].forEach(function(d) {
            d(a, s);
          });
        },
        destroy: function() {
          this.detachAllDOMEvents(), this.detachAllCustomEvents(), this.detachExecCommand(), this.base.elements && this.base.elements.forEach(function(r) {
            r.removeAttribute("data-medium-focused");
          });
        },
        attachToExecCommand: function() {
          this.execCommandListener || (this.execCommandListener = function(r) {
            this.handleDocumentExecCommand(r);
          }.bind(this), this.wrapExecCommand(), this.options.ownerDocument.execCommand.listeners.push(this.execCommandListener));
        },
        detachExecCommand: function() {
          var r = this.options.ownerDocument;
          if (!(!this.execCommandListener || !r.execCommand.listeners)) {
            var a = r.execCommand.listeners.indexOf(this.execCommandListener);
            a !== -1 && r.execCommand.listeners.splice(a, 1), r.execCommand.listeners.length || this.unwrapExecCommand();
          }
        },
        wrapExecCommand: function() {
          var r = this.options.ownerDocument;
          if (!r.execCommand.listeners) {
            var a = function(d, l) {
              r.execCommand.listeners && r.execCommand.listeners.forEach(function(u) {
                u({
                  command: d[0],
                  value: d[2],
                  args: d,
                  result: l
                });
              });
            }, s = function() {
              var d = r.execCommand.orig.apply(this, arguments);
              return r.execCommand.listeners && a(Array.prototype.slice.call(arguments), d), d;
            };
            s.orig = r.execCommand, s.listeners = [], s.callListeners = a, r.execCommand = s;
          }
        },
        unwrapExecCommand: function() {
          var r = this.options.ownerDocument;
          r.execCommand.orig && (r.execCommand = r.execCommand.orig);
        },
        setupListener: function(r) {
          if (!this.listeners[r]) {
            switch (r) {
              case "externalInteraction":
                this.attachDOMEvent(this.options.ownerDocument.body, "mousedown", this.handleBodyMousedown.bind(this), !0), this.attachDOMEvent(this.options.ownerDocument.body, "click", this.handleBodyClick.bind(this), !0), this.attachDOMEvent(this.options.ownerDocument.body, "focus", this.handleBodyFocus.bind(this), !0);
                break;
              case "blur":
                this.setupListener("externalInteraction");
                break;
              case "focus":
                this.setupListener("externalInteraction");
                break;
              case "editableInput":
                this.contentCache = {}, this.base.elements.forEach(function(a) {
                  this.contentCache[a.getAttribute("medium-editor-index")] = a.innerHTML;
                }, this), this.InputEventOnContenteditableSupported && this.attachToEachElement("input", this.handleInput), this.InputEventOnContenteditableSupported || (this.setupListener("editableKeypress"), this.keypressUpdateInput = !0, this.attachDOMEvent(document, "selectionchange", this.handleDocumentSelectionChange.bind(this)), this.attachToExecCommand());
                break;
              case "editableClick":
                this.attachToEachElement("click", this.handleClick);
                break;
              case "editableBlur":
                this.attachToEachElement("blur", this.handleBlur);
                break;
              case "editableKeypress":
                this.attachToEachElement("keypress", this.handleKeypress);
                break;
              case "editableKeyup":
                this.attachToEachElement("keyup", this.handleKeyup);
                break;
              case "editableKeydown":
                this.attachToEachElement("keydown", this.handleKeydown);
                break;
              case "editableKeydownSpace":
                this.setupListener("editableKeydown");
                break;
              case "editableKeydownEnter":
                this.setupListener("editableKeydown");
                break;
              case "editableKeydownTab":
                this.setupListener("editableKeydown");
                break;
              case "editableKeydownDelete":
                this.setupListener("editableKeydown");
                break;
              case "editableMouseover":
                this.attachToEachElement("mouseover", this.handleMouseover);
                break;
              case "editableDrag":
                this.attachToEachElement("dragover", this.handleDragging), this.attachToEachElement("dragleave", this.handleDragging);
                break;
              case "editableDrop":
                this.attachToEachElement("drop", this.handleDrop);
                break;
              case "editablePaste":
                this.attachToEachElement("paste", this.handlePaste);
            }
            this.listeners[r] = !0;
          }
        },
        attachToEachElement: function(r, a) {
          this.eventsCache || (this.eventsCache = []), this.base.elements.forEach(function(s) {
            this.attachDOMEvent(s, r, a.bind(this));
          }, this), this.eventsCache.push({
            name: r,
            handler: a
          });
        },
        cleanupElement: function(r) {
          var a = r.getAttribute("medium-editor-index");
          a && (this.detachAllEventsFromElement(r), this.contentCache && delete this.contentCache[a]);
        },
        focusElement: function(r) {
          r.focus(), this.updateFocus(r, {
            target: r,
            type: "focus"
          });
        },
        updateFocus: function(r, a) {
          var s = this.base.getFocusedElement(), d;
          s && a.type === "click" && this.lastMousedownTarget && (e.util.isDescendant(s, this.lastMousedownTarget, !0) || i(this.base.extensions, this.lastMousedownTarget)) && (d = s), d || this.base.elements.some(function(u) {
            return !d && e.util.isDescendant(u, r, !0) && (d = u), !!d;
          }, this);
          var l = !e.util.isDescendant(s, r, !0) && !i(this.base.extensions, r);
          d !== s && (s && l && (s.removeAttribute("data-medium-focused"), this.triggerCustomEvent("blur", a, s)), d && (d.setAttribute("data-medium-focused", !0), this.triggerCustomEvent("focus", a, d))), l && this.triggerCustomEvent("externalInteraction", a);
        },
        updateInput: function(r, a) {
          if (this.contentCache) {
            var s = r.getAttribute("medium-editor-index"), d = r.innerHTML;
            d !== this.contentCache[s] && this.triggerCustomEvent("editableInput", a, r), this.contentCache[s] = d;
          }
        },
        handleDocumentSelectionChange: function(r) {
          if (r.currentTarget && r.currentTarget.activeElement) {
            var a = r.currentTarget.activeElement, s;
            this.base.elements.some(function(d) {
              return e.util.isDescendant(d, a, !0) ? (s = d, !0) : !1;
            }, this), s && this.updateInput(s, {
              target: a,
              currentTarget: s
            });
          }
        },
        handleDocumentExecCommand: function() {
          var r = this.base.getFocusedElement();
          r && this.updateInput(r, {
            target: r,
            currentTarget: r
          });
        },
        handleBodyClick: function(r) {
          this.updateFocus(r.target, r);
        },
        handleBodyFocus: function(r) {
          this.updateFocus(r.target, r);
        },
        handleBodyMousedown: function(r) {
          this.lastMousedownTarget = r.target;
        },
        handleInput: function(r) {
          this.updateInput(r.currentTarget, r);
        },
        handleClick: function(r) {
          this.triggerCustomEvent("editableClick", r, r.currentTarget);
        },
        handleBlur: function(r) {
          this.triggerCustomEvent("editableBlur", r, r.currentTarget);
        },
        handleKeypress: function(r) {
          if (this.triggerCustomEvent("editableKeypress", r, r.currentTarget), this.keypressUpdateInput) {
            var a = {
              target: r.target,
              currentTarget: r.currentTarget
            };
            setTimeout(function() {
              this.updateInput(a.currentTarget, a);
            }.bind(this), 0);
          }
        },
        handleKeyup: function(r) {
          this.triggerCustomEvent("editableKeyup", r, r.currentTarget);
        },
        handleMouseover: function(r) {
          this.triggerCustomEvent("editableMouseover", r, r.currentTarget);
        },
        handleDragging: function(r) {
          this.triggerCustomEvent("editableDrag", r, r.currentTarget);
        },
        handleDrop: function(r) {
          this.triggerCustomEvent("editableDrop", r, r.currentTarget);
        },
        handlePaste: function(r) {
          this.triggerCustomEvent("editablePaste", r, r.currentTarget);
        },
        handleKeydown: function(r) {
          if (this.triggerCustomEvent("editableKeydown", r, r.currentTarget), e.util.isKey(r, e.util.keyCode.SPACE)) return this.triggerCustomEvent("editableKeydownSpace", r, r.currentTarget);
          if (e.util.isKey(r, e.util.keyCode.ENTER) || r.ctrlKey && e.util.isKey(r, e.util.keyCode.M)) return this.triggerCustomEvent("editableKeydownEnter", r, r.currentTarget);
          if (e.util.isKey(r, e.util.keyCode.TAB)) return this.triggerCustomEvent("editableKeydownTab", r, r.currentTarget);
          if (e.util.isKey(r, [e.util.keyCode.DELETE, e.util.keyCode.BACKSPACE])) return this.triggerCustomEvent("editableKeydownDelete", r, r.currentTarget);
        }
      }, e.Events = t;
    })(), (function() {
      "use strict";
      var i = e.Extension.extend({
        action: void 0,
        aria: void 0,
        tagNames: void 0,
        style: void 0,
        useQueryState: void 0,
        contentDefault: void 0,
        contentFA: void 0,
        classList: void 0,
        attrs: void 0,
        constructor: function(t) {
          i.isBuiltInButton(t) ? e.Extension.call(this, this.defaults[t]) : e.Extension.call(this, t);
        },
        init: function() {
          e.Extension.prototype.init.apply(this, arguments), this.button = this.createButton(), this.on(this.button, "click", this.handleClick.bind(this));
        },
        getButton: function() {
          return this.button;
        },
        getAction: function() {
          return typeof this.action == "function" ? this.action(this.base.options) : this.action;
        },
        getAria: function() {
          return typeof this.aria == "function" ? this.aria(this.base.options) : this.aria;
        },
        getTagNames: function() {
          return typeof this.tagNames == "function" ? this.tagNames(this.base.options) : this.tagNames;
        },
        createButton: function() {
          var t = this.document.createElement("button"), r = this.contentDefault, a = this.getAria(), s = this.getEditorOption("buttonLabels");
          return t.classList.add("medium-editor-action"), t.classList.add("medium-editor-action-" + this.name), this.classList && this.classList.forEach(function(d) {
            t.classList.add(d);
          }), t.setAttribute("data-action", this.getAction()), a && (t.setAttribute("title", a), t.setAttribute("aria-label", a)), this.attrs && Object.keys(this.attrs).forEach(function(d) {
            t.setAttribute(d, this.attrs[d]);
          }, this), s === "fontawesome" && this.contentFA && (r = this.contentFA), t.innerHTML = r, t;
        },
        handleClick: function(t) {
          t.preventDefault(), t.stopPropagation();
          var r = this.getAction();
          r && this.execAction(r);
        },
        isActive: function() {
          return this.button.classList.contains(this.getEditorOption("activeButtonClass"));
        },
        setInactive: function() {
          this.button.classList.remove(this.getEditorOption("activeButtonClass")), delete this.knownState;
        },
        setActive: function() {
          this.button.classList.add(this.getEditorOption("activeButtonClass")), delete this.knownState;
        },
        queryCommandState: function() {
          var t = null;
          return this.useQueryState && (t = this.base.queryCommandState(this.getAction())), t;
        },
        isAlreadyApplied: function(t) {
          var r = !1, a = this.getTagNames(), s, d;
          return this.knownState === !1 || this.knownState === !0 ? this.knownState : (a && a.length > 0 && (r = a.indexOf(t.nodeName.toLowerCase()) !== -1), !r && this.style && (s = this.style.value.split("|"), d = this.window.getComputedStyle(t, null).getPropertyValue(this.style.prop), s.forEach(function(l) {
            this.knownState || (r = d.indexOf(l) !== -1, (r || this.style.prop !== "text-decoration") && (this.knownState = r));
          }, this)), r);
        }
      });
      i.isBuiltInButton = function(t) {
        return typeof t == "string" && e.extensions.button.prototype.defaults.hasOwnProperty(t);
      }, e.extensions.button = i;
    })(), (function() {
      "use strict";
      e.extensions.button.prototype.defaults = {
        bold: {
          name: "bold",
          action: "bold",
          aria: "bold",
          tagNames: ["b", "strong"],
          style: {
            prop: "font-weight",
            value: "700|bold"
          },
          useQueryState: !0,
          contentDefault: "<b>B</b>",
          contentFA: '<i class="fa fa-bold"></i>'
        },
        italic: {
          name: "italic",
          action: "italic",
          aria: "italic",
          tagNames: ["i", "em"],
          style: {
            prop: "font-style",
            value: "italic"
          },
          useQueryState: !0,
          contentDefault: "<b><i>I</i></b>",
          contentFA: '<i class="fa fa-italic"></i>'
        },
        underline: {
          name: "underline",
          action: "underline",
          aria: "underline",
          tagNames: ["u"],
          style: {
            prop: "text-decoration",
            value: "underline"
          },
          useQueryState: !0,
          contentDefault: "<b><u>U</u></b>",
          contentFA: '<i class="fa fa-underline"></i>'
        },
        strikethrough: {
          name: "strikethrough",
          action: "strikethrough",
          aria: "strike through",
          tagNames: ["strike"],
          style: {
            prop: "text-decoration",
            value: "line-through"
          },
          useQueryState: !0,
          contentDefault: "<s>A</s>",
          contentFA: '<i class="fa fa-strikethrough"></i>'
        },
        superscript: {
          name: "superscript",
          action: "superscript",
          aria: "superscript",
          tagNames: ["sup"],
          contentDefault: "<b>x<sup>1</sup></b>",
          contentFA: '<i class="fa fa-superscript"></i>'
        },
        subscript: {
          name: "subscript",
          action: "subscript",
          aria: "subscript",
          tagNames: ["sub"],
          contentDefault: "<b>x<sub>1</sub></b>",
          contentFA: '<i class="fa fa-subscript"></i>'
        },
        image: {
          name: "image",
          action: "image",
          aria: "image",
          tagNames: ["img"],
          contentDefault: "<b>image</b>",
          contentFA: '<i class="fa fa-picture-o"></i>'
        },
        html: {
          name: "html",
          action: "html",
          aria: "evaluate html",
          tagNames: ["iframe", "object"],
          contentDefault: "<b>html</b>",
          contentFA: '<i class="fa fa-code"></i>'
        },
        orderedlist: {
          name: "orderedlist",
          action: "insertorderedlist",
          aria: "ordered list",
          tagNames: ["ol"],
          useQueryState: !0,
          contentDefault: "<b>1.</b>",
          contentFA: '<i class="fa fa-list-ol"></i>'
        },
        unorderedlist: {
          name: "unorderedlist",
          action: "insertunorderedlist",
          aria: "unordered list",
          tagNames: ["ul"],
          useQueryState: !0,
          contentDefault: "<b>&bull;</b>",
          contentFA: '<i class="fa fa-list-ul"></i>'
        },
        indent: {
          name: "indent",
          action: "indent",
          aria: "indent",
          tagNames: [],
          contentDefault: "<b>&rarr;</b>",
          contentFA: '<i class="fa fa-indent"></i>'
        },
        outdent: {
          name: "outdent",
          action: "outdent",
          aria: "outdent",
          tagNames: [],
          contentDefault: "<b>&larr;</b>",
          contentFA: '<i class="fa fa-outdent"></i>'
        },
        justifyCenter: {
          name: "justifyCenter",
          action: "justifyCenter",
          aria: "center justify",
          tagNames: [],
          style: {
            prop: "text-align",
            value: "center"
          },
          contentDefault: "<b>C</b>",
          contentFA: '<i class="fa fa-align-center"></i>'
        },
        justifyFull: {
          name: "justifyFull",
          action: "justifyFull",
          aria: "full justify",
          tagNames: [],
          style: {
            prop: "text-align",
            value: "justify"
          },
          contentDefault: "<b>J</b>",
          contentFA: '<i class="fa fa-align-justify"></i>'
        },
        justifyLeft: {
          name: "justifyLeft",
          action: "justifyLeft",
          aria: "left justify",
          tagNames: [],
          style: {
            prop: "text-align",
            value: "left"
          },
          contentDefault: "<b>L</b>",
          contentFA: '<i class="fa fa-align-left"></i>'
        },
        justifyRight: {
          name: "justifyRight",
          action: "justifyRight",
          aria: "right justify",
          tagNames: [],
          style: {
            prop: "text-align",
            value: "right"
          },
          contentDefault: "<b>R</b>",
          contentFA: '<i class="fa fa-align-right"></i>'
        },
        removeFormat: {
          name: "removeFormat",
          aria: "remove formatting",
          action: "removeFormat",
          contentDefault: "<b>X</b>",
          contentFA: '<i class="fa fa-eraser"></i>'
        },
        quote: {
          name: "quote",
          action: "append-blockquote",
          aria: "blockquote",
          tagNames: ["blockquote"],
          contentDefault: "<b>&ldquo;</b>",
          contentFA: '<i class="fa fa-quote-right"></i>'
        },
        pre: {
          name: "pre",
          action: "append-pre",
          aria: "preformatted text",
          tagNames: ["pre"],
          contentDefault: "<b>0101</b>",
          contentFA: '<i class="fa fa-code fa-lg"></i>'
        },
        h1: {
          name: "h1",
          action: "append-h1",
          aria: "header type one",
          tagNames: ["h1"],
          contentDefault: "<b>H1</b>",
          contentFA: '<i class="fa fa-header"><sup>1</sup>'
        },
        h2: {
          name: "h2",
          action: "append-h2",
          aria: "header type two",
          tagNames: ["h2"],
          contentDefault: "<b>H2</b>",
          contentFA: '<i class="fa fa-header"><sup>2</sup>'
        },
        h3: {
          name: "h3",
          action: "append-h3",
          aria: "header type three",
          tagNames: ["h3"],
          contentDefault: "<b>H3</b>",
          contentFA: '<i class="fa fa-header"><sup>3</sup>'
        },
        h4: {
          name: "h4",
          action: "append-h4",
          aria: "header type four",
          tagNames: ["h4"],
          contentDefault: "<b>H4</b>",
          contentFA: '<i class="fa fa-header"><sup>4</sup>'
        },
        h5: {
          name: "h5",
          action: "append-h5",
          aria: "header type five",
          tagNames: ["h5"],
          contentDefault: "<b>H5</b>",
          contentFA: '<i class="fa fa-header"><sup>5</sup>'
        },
        h6: {
          name: "h6",
          action: "append-h6",
          aria: "header type six",
          tagNames: ["h6"],
          contentDefault: "<b>H6</b>",
          contentFA: '<i class="fa fa-header"><sup>6</sup>'
        }
      };
    })(), (function() {
      "use strict";
      var i = e.extensions.button.extend({
        init: function() {
          e.extensions.button.prototype.init.apply(this, arguments);
        },
        formSaveLabel: "&#10003;",
        formCloseLabel: "&times;",
        activeClass: "medium-editor-toolbar-form-active",
        hasForm: !0,
        getForm: function() {
        },
        isDisplayed: function() {
          return this.hasForm ? this.getForm().classList.contains(this.activeClass) : !1;
        },
        showForm: function() {
          this.hasForm && this.getForm().classList.add(this.activeClass);
        },
        hideForm: function() {
          this.hasForm && this.getForm().classList.remove(this.activeClass);
        },
        showToolbarDefaultActions: function() {
          var t = this.base.getExtensionByName("toolbar");
          t && t.showToolbarDefaultActions();
        },
        hideToolbarDefaultActions: function() {
          var t = this.base.getExtensionByName("toolbar");
          t && t.hideToolbarDefaultActions();
        },
        setToolbarPosition: function() {
          var t = this.base.getExtensionByName("toolbar");
          t && t.setToolbarPosition();
        }
      });
      e.extensions.form = i;
    })(), (function() {
      "use strict";
      var i = e.extensions.form.extend({
        customClassOption: null,
        customClassOptionText: "Button",
        linkValidation: !1,
        placeholderText: "Paste or type a link",
        targetCheckbox: !1,
        targetCheckboxText: "Open in new window",
        name: "anchor",
        action: "createLink",
        aria: "link",
        tagNames: ["a"],
        contentDefault: "<b>#</b>",
        contentFA: '<i class="fa fa-link"></i>',
        init: function() {
          e.extensions.form.prototype.init.apply(this, arguments), this.subscribe("editableKeydown", this.handleKeydown.bind(this));
        },
        handleClick: function(t) {
          t.preventDefault(), t.stopPropagation();
          var r = e.selection.getSelectionRange(this.document);
          return r.startContainer.nodeName.toLowerCase() === "a" || r.endContainer.nodeName.toLowerCase() === "a" || e.util.getClosestTag(e.selection.getSelectedParentElement(r), "a") ? this.execAction("unlink") : (this.isDisplayed() || this.showForm(), !1);
        },
        handleKeydown: function(t) {
          e.util.isKey(t, e.util.keyCode.K) && e.util.isMetaCtrlKey(t) && !t.shiftKey && this.handleClick(t);
        },
        getForm: function() {
          return this.form || (this.form = this.createForm()), this.form;
        },
        getTemplate: function() {
          var t = [
            '<input type="text" class="medium-editor-toolbar-input" placeholder="',
            this.placeholderText,
            '">'
          ];
          return t.push('<a href="#" class="medium-editor-toolbar-save">', this.getEditorOption("buttonLabels") === "fontawesome" ? '<i class="fa fa-check"></i>' : this.formSaveLabel, "</a>"), t.push('<a href="#" class="medium-editor-toolbar-close">', this.getEditorOption("buttonLabels") === "fontawesome" ? '<i class="fa fa-times"></i>' : this.formCloseLabel, "</a>"), this.targetCheckbox && t.push('<div class="medium-editor-toolbar-form-row">', '<input type="checkbox" class="medium-editor-toolbar-anchor-target" id="medium-editor-toolbar-anchor-target-field-' + this.getEditorId() + '">', '<label for="medium-editor-toolbar-anchor-target-field-' + this.getEditorId() + '">', this.targetCheckboxText, "</label>", "</div>"), this.customClassOption && t.push('<div class="medium-editor-toolbar-form-row">', '<input type="checkbox" class="medium-editor-toolbar-anchor-button">', "<label>", this.customClassOptionText, "</label>", "</div>"), t.join("");
        },
        isDisplayed: function() {
          return e.extensions.form.prototype.isDisplayed.apply(this);
        },
        hideForm: function() {
          e.extensions.form.prototype.hideForm.apply(this), this.getInput().value = "";
        },
        showForm: function(t) {
          var r = this.getInput(), a = this.getAnchorTargetCheckbox(), s = this.getAnchorButtonCheckbox();
          t = t || { value: "" }, typeof t == "string" && (t = { value: t }), this.base.saveSelection(), this.hideToolbarDefaultActions(), e.extensions.form.prototype.showForm.apply(this), this.setToolbarPosition(), r.value = t.value, r.focus(), a && (a.checked = t.target === "_blank"), s && (s.checked = (t.buttonClass ? t.buttonClass.split(" ") : []).indexOf(this.customClassOption) !== -1);
        },
        destroy: function() {
          if (!this.form) return !1;
          this.form.parentNode && this.form.parentNode.removeChild(this.form), delete this.form;
        },
        getFormOpts: function() {
          var t = this.getAnchorTargetCheckbox(), r = this.getAnchorButtonCheckbox(), a = { value: this.getInput().value.trim() };
          return this.linkValidation && (a.value = this.checkLinkFormat(a.value)), a.target = "_self", t && t.checked && (a.target = "_blank"), r && r.checked && (a.buttonClass = this.customClassOption), a;
        },
        doFormSave: function() {
          var t = this.getFormOpts();
          this.completeFormSave(t);
        },
        completeFormSave: function(t) {
          this.base.restoreSelection(), this.execAction(this.action, t), this.base.checkSelection();
        },
        ensureEncodedUri: function(t) {
          return t === decodeURI(t) ? encodeURI(t) : t;
        },
        ensureEncodedUriComponent: function(t) {
          return t === decodeURIComponent(t) ? encodeURIComponent(t) : t;
        },
        ensureEncodedParam: function(t) {
          var r = t.split("="), a = r[0], s = r[1];
          return a + (s === void 0 ? "" : "=" + this.ensureEncodedUriComponent(s));
        },
        ensureEncodedQuery: function(t) {
          return t.split("&").map(this.ensureEncodedParam.bind(this)).join("&");
        },
        checkLinkFormat: function(t) {
          var r = /^([a-z]+:)?\/\/|^(mailto|tel|maps):|^\#/i.test(t), a = "", s = /^\+?\s?\(?(?:\d\s?\-?\)?){3,20}$/, d = t.match(/^(.*?)(?:\?(.*?))?(?:#(.*))?$/), l = d[1], u = d[2], c = d[3];
          if (s.test(t)) return "tel:" + t;
          if (!r) {
            var h = l.split("/")[0];
            (h.match(/.+(\.|:).+/) || h === "localhost") && (a = "http://");
          }
          return a + this.ensureEncodedUri(l) + (u === void 0 ? "" : "?" + this.ensureEncodedQuery(u)) + (c === void 0 ? "" : "#" + c);
        },
        doFormCancel: function() {
          this.base.restoreSelection(), this.base.checkSelection();
        },
        attachFormEvents: function(t) {
          var r = t.querySelector(".medium-editor-toolbar-close"), a = t.querySelector(".medium-editor-toolbar-save"), s = t.querySelector(".medium-editor-toolbar-input");
          this.on(t, "click", this.handleFormClick.bind(this)), this.on(s, "keyup", this.handleTextboxKeyup.bind(this)), this.on(r, "click", this.handleCloseClick.bind(this)), this.on(a, "click", this.handleSaveClick.bind(this), !0);
        },
        createForm: function() {
          var t = this.document.createElement("div");
          return t.className = "medium-editor-toolbar-form", t.id = "medium-editor-toolbar-form-anchor-" + this.getEditorId(), t.innerHTML = this.getTemplate(), this.attachFormEvents(t), t;
        },
        getInput: function() {
          return this.getForm().querySelector("input.medium-editor-toolbar-input");
        },
        getAnchorTargetCheckbox: function() {
          return this.getForm().querySelector(".medium-editor-toolbar-anchor-target");
        },
        getAnchorButtonCheckbox: function() {
          return this.getForm().querySelector(".medium-editor-toolbar-anchor-button");
        },
        handleTextboxKeyup: function(t) {
          if (t.keyCode === e.util.keyCode.ENTER) {
            t.preventDefault(), this.doFormSave();
            return;
          }
          t.keyCode === e.util.keyCode.ESCAPE && (t.preventDefault(), this.doFormCancel());
        },
        handleFormClick: function(t) {
          t.stopPropagation();
        },
        handleSaveClick: function(t) {
          t.preventDefault(), this.doFormSave();
        },
        handleCloseClick: function(t) {
          t.preventDefault(), this.doFormCancel();
        }
      });
      e.extensions.anchor = i;
    })(), (function() {
      "use strict";
      var i = e.Extension.extend({
        name: "anchor-preview",
        hideDelay: 500,
        previewValueSelector: "a",
        showWhenToolbarIsVisible: !1,
        showOnEmptyLinks: !0,
        init: function() {
          this.anchorPreview = this.createPreview(), this.getEditorOption("elementsContainer").appendChild(this.anchorPreview), this.attachToEditables();
        },
        getInteractionElements: function() {
          return this.getPreviewElement();
        },
        getPreviewElement: function() {
          return this.anchorPreview;
        },
        createPreview: function() {
          var t = this.document.createElement("div");
          return t.id = "medium-editor-anchor-preview-" + this.getEditorId(), t.className = "medium-editor-anchor-preview", t.innerHTML = this.getTemplate(), this.on(t, "click", this.handleClick.bind(this)), t;
        },
        getTemplate: function() {
          return '<div class="medium-editor-toolbar-anchor-preview" id="medium-editor-toolbar-anchor-preview">    <a class="medium-editor-toolbar-anchor-preview-inner"></a></div>';
        },
        destroy: function() {
          this.anchorPreview && (this.anchorPreview.parentNode && this.anchorPreview.parentNode.removeChild(this.anchorPreview), delete this.anchorPreview);
        },
        hidePreview: function() {
          this.anchorPreview && this.anchorPreview.classList.remove("medium-editor-anchor-preview-active"), this.activeAnchor = null;
        },
        showPreview: function(t) {
          return this.anchorPreview.classList.contains("medium-editor-anchor-preview-active") || t.getAttribute("data-disable-preview") ? !0 : (this.previewValueSelector && (this.anchorPreview.querySelector(this.previewValueSelector).textContent = t.attributes.href.value, this.anchorPreview.querySelector(this.previewValueSelector).href = t.attributes.href.value), this.anchorPreview.classList.add("medium-toolbar-arrow-over"), this.anchorPreview.classList.remove("medium-toolbar-arrow-under"), this.anchorPreview.classList.contains("medium-editor-anchor-preview-active") || this.anchorPreview.classList.add("medium-editor-anchor-preview-active"), this.activeAnchor = t, this.positionPreview(), this.attachPreviewHandlers(), this);
        },
        positionPreview: function(t) {
          t = t || this.activeAnchor;
          var r = this.window.innerWidth, a = this.anchorPreview.offsetHeight, s = t.getBoundingClientRect(), d = this.diffLeft, l = this.diffTop, u = this.getEditorOption("elementsContainer"), c = ["absolute", "fixed"].indexOf(window.getComputedStyle(u).getPropertyValue("position")) > -1, h = {}, f = this.anchorPreview.offsetWidth / 2, p, v, g, b, _ = this.base.getExtensionByName("toolbar");
          _ && (d = _.diffLeft, l = _.diffTop), p = d - f, c ? (g = u.getBoundingClientRect(), ["top", "left"].forEach(function(D) {
            h[D] = s[D] - g[D];
          }), h.width = s.width, h.height = s.height, s = h, r = g.width, b = u.scrollTop) : b = this.window.pageYOffset, v = s.left + s.width / 2, b += a + s.top + s.height - l - this.anchorPreview.offsetHeight, this.anchorPreview.style.top = Math.round(b) + "px", this.anchorPreview.style.right = "initial", v < f ? (this.anchorPreview.style.left = p + f + "px", this.anchorPreview.style.right = "initial") : r - v < f ? (this.anchorPreview.style.left = "auto", this.anchorPreview.style.right = 0) : (this.anchorPreview.style.left = p + v + "px", this.anchorPreview.style.right = "initial");
        },
        attachToEditables: function() {
          this.subscribe("editableMouseover", this.handleEditableMouseover.bind(this)), this.subscribe("positionedToolbar", this.handlePositionedToolbar.bind(this));
        },
        handlePositionedToolbar: function() {
          this.showWhenToolbarIsVisible || this.hidePreview();
        },
        handleClick: function(t) {
          var r = this.base.getExtensionByName("anchor"), a = this.activeAnchor;
          r && a && (t.preventDefault(), this.base.selectElement(this.activeAnchor), this.base.delay(function() {
            if (a) {
              var s = {
                value: a.attributes.href.value,
                target: a.getAttribute("target"),
                buttonClass: a.getAttribute("class")
              };
              r.showForm(s), a = null;
            }
          }.bind(this))), this.hidePreview();
        },
        handleAnchorMouseout: function() {
          this.anchorToPreview = null, this.off(this.activeAnchor, "mouseout", this.instanceHandleAnchorMouseout), this.instanceHandleAnchorMouseout = null;
        },
        handleEditableMouseover: function(t) {
          var r = e.util.getClosestTag(t.target, "a");
          if (r !== !1) {
            if (!this.showOnEmptyLinks && (!/href=["']\S+["']/.test(r.outerHTML) || /href=["']#\S+["']/.test(r.outerHTML))) return !0;
            var a = this.base.getExtensionByName("toolbar");
            if (!this.showWhenToolbarIsVisible && a && a.isDisplayed && a.isDisplayed()) return !0;
            this.activeAnchor && this.activeAnchor !== r && this.detachPreviewHandlers(), this.anchorToPreview = r, this.instanceHandleAnchorMouseout = this.handleAnchorMouseout.bind(this), this.on(this.anchorToPreview, "mouseout", this.instanceHandleAnchorMouseout), this.base.delay(function() {
              this.anchorToPreview && this.showPreview(this.anchorToPreview);
            }.bind(this));
          }
        },
        handlePreviewMouseover: function() {
          this.lastOver = (/* @__PURE__ */ new Date()).getTime(), this.hovering = !0;
        },
        handlePreviewMouseout: function(t) {
          (!t.relatedTarget || !/anchor-preview/.test(t.relatedTarget.className)) && (this.hovering = !1);
        },
        updatePreview: function() {
          if (this.hovering) return !0;
          (/* @__PURE__ */ new Date()).getTime() - this.lastOver > this.hideDelay && this.detachPreviewHandlers();
        },
        detachPreviewHandlers: function() {
          clearInterval(this.intervalTimer), this.instanceHandlePreviewMouseover && (this.off(this.anchorPreview, "mouseover", this.instanceHandlePreviewMouseover), this.off(this.anchorPreview, "mouseout", this.instanceHandlePreviewMouseout), this.activeAnchor && (this.off(this.activeAnchor, "mouseover", this.instanceHandlePreviewMouseover), this.off(this.activeAnchor, "mouseout", this.instanceHandlePreviewMouseout))), this.hidePreview(), this.hovering = this.instanceHandlePreviewMouseover = this.instanceHandlePreviewMouseout = null;
        },
        attachPreviewHandlers: function() {
          this.lastOver = (/* @__PURE__ */ new Date()).getTime(), this.hovering = !0, this.instanceHandlePreviewMouseover = this.handlePreviewMouseover.bind(this), this.instanceHandlePreviewMouseout = this.handlePreviewMouseout.bind(this), this.intervalTimer = setInterval(this.updatePreview.bind(this), 200), this.on(this.anchorPreview, "mouseover", this.instanceHandlePreviewMouseover), this.on(this.anchorPreview, "mouseout", this.instanceHandlePreviewMouseout), this.on(this.activeAnchor, "mouseover", this.instanceHandlePreviewMouseover), this.on(this.activeAnchor, "mouseout", this.instanceHandlePreviewMouseout);
        }
      });
      e.extensions.anchorPreview = i;
    })(), (function() {
      "use strict";
      var i = [
        " ",
        "	",
        `
`,
        "\r",
        " ",
        " ",
        " ",
        " ",
        " ",
        "\u2028",
        "\u2029"
      ], t = "com|net|org|edu|gov|mil|aero|asia|biz|cat|coop|info|int|jobs|mobi|museum|name|post|pro|tel|travel|xxx|ac|ad|ae|af|ag|ai|al|am|an|ao|aq|ar|as|at|au|aw|ax|az|ba|bb|bd|be|bf|bg|bh|bi|bj|bm|bn|bo|br|bs|bt|bv|bw|by|bz|ca|cc|cd|cf|cg|ch|ci|ck|cl|cm|cn|co|cr|cs|cu|cv|cx|cy|cz|dd|de|dj|dk|dm|do|dz|ec|ee|eg|eh|er|es|et|eu|fi|fj|fk|fm|fo|fr|ga|gb|gd|ge|gf|gg|gh|gi|gl|gm|gn|gp|gq|gr|gs|gt|gu|gw|gy|hk|hm|hn|hr|ht|hu|id|ie|il|im|in|io|iq|ir|is|it|je|jm|jo|jp|ke|kg|kh|ki|km|kn|kp|kr|kw|ky|kz|la|lb|lc|li|lk|lr|ls|lt|lu|lv|ly|ma|mc|md|me|mg|mh|mk|ml|mm|mn|mo|mp|mq|mr|ms|mt|mu|mv|mw|mx|my|mz|na|nc|ne|nf|ng|ni|nl|no|np|nr|nu|nz|om|pa|pe|pf|pg|ph|pk|pl|pm|pn|pr|ps|pt|pw|py|qa|re|ro|rs|ru|rw|sa|sb|sc|sd|se|sg|sh|si|sj|ja|sk|sl|sm|sn|so|sr|ss|st|su|sv|sx|sy|sz|tc|td|tf|tg|th|tj|tk|tl|tm|tn|to|tp|tr|tt|tv|tw|tz|ua|ug|uk|us|uy|uz|va|vc|ve|vg|vi|vn|vu|wf|ws|ye|yt|yu|za|zm|zw", r = "(((?:(https?://|ftps?://|nntp://)|www\\d{0,3}[.]|[a-z0-9.\\-]+[.](" + t + ")\\/)\\S+(?:[^\\s`!\\[\\]{};:'\".,?«»“”‘’])))|(([a-z0-9\\-]+\\.)?[a-z0-9\\-]+\\.(" + t + "))", a = new RegExp("^(" + t + ")$", "i"), s = new RegExp(r, "gi");
      function d(u) {
        return !e.util.getClosestTag(u, "a");
      }
      var l = e.Extension.extend({
        init: function() {
          e.Extension.prototype.init.apply(this, arguments), this.disableEventHandling = !1, this.subscribe("editableKeypress", this.onKeypress.bind(this)), this.subscribe("editableBlur", this.onBlur.bind(this)), this.document.execCommand("AutoUrlDetect", !1, !1);
        },
        isLastInstance: function() {
          for (var u = 0, c = 0; c < this.window._mediumEditors.length; c++) {
            var h = this.window._mediumEditors[c];
            h !== null && h.getExtensionByName("autoLink") !== void 0 && u++;
          }
          return u === 1;
        },
        destroy: function() {
          this.document.queryCommandSupported("AutoUrlDetect") && this.isLastInstance() && this.document.execCommand("AutoUrlDetect", !1, !0);
        },
        onBlur: function(u, c) {
          this.performLinking(c);
        },
        onKeypress: function(u) {
          this.disableEventHandling || e.util.isKey(u, [e.util.keyCode.SPACE, e.util.keyCode.ENTER]) && (clearTimeout(this.performLinkingTimeout), this.performLinkingTimeout = setTimeout(function() {
            try {
              var c = this.base.exportSelection();
              this.performLinking(u.target) && this.base.importSelection(c, !0);
            } catch (h) {
              window.console && window.console.error("Failed to perform linking", h), this.disableEventHandling = !0;
            }
          }.bind(this), 0));
        },
        performLinking: function(u) {
          var c = e.util.splitByBlockElements(u), h = !1;
          c.length === 0 && (c = [u]);
          for (var f = 0; f < c.length; f++)
            h = this.removeObsoleteAutoLinkSpans(c[f]) || h, h = this.performLinkingWithinElement(c[f]) || h;
          return this.base.events.updateInput(u, {
            target: u,
            currentTarget: u
          }), h;
        },
        removeObsoleteAutoLinkSpans: function(u) {
          if (!u || u.nodeType === 3) return !1;
          for (var c = u.querySelectorAll('span[data-auto-link="true"]'), h = !1, f = 0; f < c.length; f++) {
            var p = c[f].textContent;
            if (p.indexOf("://") === -1 && (p = e.util.ensureUrlHasProtocol(p)), c[f].getAttribute("data-href") !== p && d(c[f])) {
              h = !0;
              var v = p.replace(/\s+$/, "");
              if (c[f].getAttribute("data-href") === v) {
                var g = p.length - v.length, b = e.util.splitOffDOMTree(c[f], this.splitTextBeforeEnd(c[f], g));
                c[f].parentNode.insertBefore(b, c[f].nextSibling);
              } else e.util.unwrap(c[f], this.document);
            }
          }
          return h;
        },
        splitTextBeforeEnd: function(u, c) {
          for (var h = this.document.createTreeWalker(u, NodeFilter.SHOW_TEXT, null, !1), f = !0; f; ) f = h.lastChild() !== null;
          for (var p, v, g; c > 0 && g !== null; )
            p = h.currentNode, v = p.nodeValue, v.length > c ? (g = p.splitText(v.length - c), c = 0) : (g = h.previousNode(), c -= v.length);
          return g;
        },
        performLinkingWithinElement: function(u) {
          for (var c = this.findLinkableText(u), h = !1, f = 0; f < c.length; f++) {
            var p = e.util.findOrCreateMatchingTextNodes(this.document, u, c[f]);
            this.shouldNotLink(p) || this.createAutoLink(p, c[f].href);
          }
          return h;
        },
        shouldNotLink: function(u) {
          for (var c = !1, h = 0; h < u.length && c === !1; h++) c = !!e.util.traverseUp(u[h], function(f) {
            return f.nodeName.toLowerCase() === "a" || f.getAttribute && f.getAttribute("data-auto-link") === "true";
          });
          return c;
        },
        findLinkableText: function(u) {
          for (var c = u.textContent, h = null, f = []; (h = s.exec(c)) !== null; ) {
            var p = !0, v = h.index + h[0].length;
            p = (h.index === 0 || i.indexOf(c[h.index - 1]) !== -1) && (v === c.length || i.indexOf(c[v]) !== -1), p = p && (h[0].indexOf("/") !== -1 || a.test(h[0].split(".").pop().split("?").shift())), p && f.push({
              href: h[0],
              start: h.index,
              end: v
            });
          }
          return f;
        },
        createAutoLink: function(u, c) {
          c = e.util.ensureUrlHasProtocol(c);
          var h = e.util.createLink(this.document, u, c, this.getEditorOption("targetBlank") ? "_blank" : null), f = this.document.createElement("span");
          for (f.setAttribute("data-auto-link", "true"), f.setAttribute("data-href", c), h.insertBefore(f, h.firstChild); h.childNodes.length > 1; ) f.appendChild(h.childNodes[1]);
        }
      });
      e.extensions.autoLink = l;
    })(), (function() {
      "use strict";
      var i = "medium-editor-dragover";
      function t(a) {
        var s = e.util.getContainerEditorElement(a);
        Array.prototype.slice.call(s.parentElement.querySelectorAll("." + i)).forEach(function(d) {
          d.classList.remove(i);
        });
      }
      var r = e.Extension.extend({
        name: "fileDragging",
        allowedTypes: ["image"],
        init: function() {
          e.Extension.prototype.init.apply(this, arguments), this.subscribe("editableDrag", this.handleDrag.bind(this)), this.subscribe("editableDrop", this.handleDrop.bind(this));
        },
        handleDrag: function(a) {
          a.preventDefault(), a.dataTransfer.dropEffect = "copy";
          var s = a.target.classList ? a.target : a.target.parentElement;
          t(s), a.type === "dragover" && s.classList.add(i);
        },
        handleDrop: function(a) {
          a.preventDefault(), a.stopPropagation(), this.base.selectElement(a.target);
          var s = this.base.exportSelection();
          s.start = s.end, this.base.importSelection(s), a.dataTransfer.files && Array.prototype.slice.call(a.dataTransfer.files).forEach(function(d) {
            this.isAllowedFile(d) && d.type.match("image") && this.insertImageFile(d);
          }, this), t(a.target);
        },
        isAllowedFile: function(a) {
          return this.allowedTypes.some(function(s) {
            return !!a.type.match(s);
          });
        },
        insertImageFile: function(a) {
          if (typeof FileReader == "function") {
            var s = new FileReader();
            s.readAsDataURL(a), s.addEventListener("load", function(d) {
              var l = this.document.createElement("img");
              l.src = d.target.result, e.util.insertHTMLCommand(this.document, l.outerHTML);
            }.bind(this));
          }
        }
      });
      e.extensions.fileDragging = r;
    })(), (function() {
      "use strict";
      var i = e.Extension.extend({
        name: "keyboard-commands",
        commands: [
          {
            command: "bold",
            key: "B",
            meta: !0,
            shift: !1,
            alt: !1
          },
          {
            command: "italic",
            key: "I",
            meta: !0,
            shift: !1,
            alt: !1
          },
          {
            command: "underline",
            key: "U",
            meta: !0,
            shift: !1,
            alt: !1
          }
        ],
        init: function() {
          e.Extension.prototype.init.apply(this, arguments), this.subscribe("editableKeydown", this.handleKeydown.bind(this)), this.keys = {}, this.commands.forEach(function(t) {
            var r = t.key.charCodeAt(0);
            this.keys[r] || (this.keys[r] = []), this.keys[r].push(t);
          }, this);
        },
        handleKeydown: function(t) {
          var r = e.util.getKeyCode(t);
          if (this.keys[r]) {
            var a = e.util.isMetaCtrlKey(t), s = !!t.shiftKey, d = !!t.altKey;
            this.keys[r].forEach(function(l) {
              l.meta === a && l.shift === s && (l.alt === d || l.alt === void 0) && (t.preventDefault(), t.stopPropagation(), typeof l.command == "function" ? l.command.apply(this) : l.command !== !1 && this.execAction(l.command));
            }, this);
          }
        }
      });
      e.extensions.keyboardCommands = i;
    })(), (function() {
      "use strict";
      var i = e.extensions.form.extend({
        name: "fontname",
        action: "fontName",
        aria: "change font name",
        contentDefault: "&#xB1;",
        contentFA: '<i class="fa fa-font"></i>',
        fonts: [
          "",
          "Arial",
          "Verdana",
          "Times New Roman"
        ],
        init: function() {
          e.extensions.form.prototype.init.apply(this, arguments);
        },
        handleClick: function(t) {
          if (t.preventDefault(), t.stopPropagation(), !this.isDisplayed()) {
            var r = this.document.queryCommandValue("fontName") + "";
            this.showForm(r);
          }
          return !1;
        },
        getForm: function() {
          return this.form || (this.form = this.createForm()), this.form;
        },
        isDisplayed: function() {
          return this.getForm().style.display === "block";
        },
        hideForm: function() {
          this.getForm().style.display = "none", this.getSelect().value = "";
        },
        showForm: function(t) {
          var r = this.getSelect();
          this.base.saveSelection(), this.hideToolbarDefaultActions(), this.getForm().style.display = "block", this.setToolbarPosition(), r.value = t || "", r.focus();
        },
        destroy: function() {
          if (!this.form) return !1;
          this.form.parentNode && this.form.parentNode.removeChild(this.form), delete this.form;
        },
        doFormSave: function() {
          this.base.restoreSelection(), this.base.checkSelection();
        },
        doFormCancel: function() {
          this.base.restoreSelection(), this.clearFontName(), this.base.checkSelection();
        },
        createForm: function() {
          var t = this.document, r = t.createElement("div"), a = t.createElement("select"), s = t.createElement("a"), d = t.createElement("a"), l;
          r.className = "medium-editor-toolbar-form", r.id = "medium-editor-toolbar-form-fontname-" + this.getEditorId(), this.on(r, "click", this.handleFormClick.bind(this));
          for (var u = 0; u < this.fonts.length; u++)
            l = t.createElement("option"), l.innerHTML = this.fonts[u], l.value = this.fonts[u], a.appendChild(l);
          return a.className = "medium-editor-toolbar-select", r.appendChild(a), this.on(a, "change", this.handleFontChange.bind(this)), d.setAttribute("href", "#"), d.className = "medium-editor-toobar-save", d.innerHTML = this.getEditorOption("buttonLabels") === "fontawesome" ? '<i class="fa fa-check"></i>' : "&#10003;", r.appendChild(d), this.on(d, "click", this.handleSaveClick.bind(this), !0), s.setAttribute("href", "#"), s.className = "medium-editor-toobar-close", s.innerHTML = this.getEditorOption("buttonLabels") === "fontawesome" ? '<i class="fa fa-times"></i>' : "&times;", r.appendChild(s), this.on(s, "click", this.handleCloseClick.bind(this)), r;
        },
        getSelect: function() {
          return this.getForm().querySelector("select.medium-editor-toolbar-select");
        },
        clearFontName: function() {
          e.selection.getSelectedElements(this.document).forEach(function(t) {
            t.nodeName.toLowerCase() === "font" && t.hasAttribute("face") && t.removeAttribute("face");
          });
        },
        handleFontChange: function() {
          var t = this.getSelect().value;
          t === "" ? this.clearFontName() : this.execAction("fontName", { value: t });
        },
        handleFormClick: function(t) {
          t.stopPropagation();
        },
        handleSaveClick: function(t) {
          t.preventDefault(), this.doFormSave();
        },
        handleCloseClick: function(t) {
          t.preventDefault(), this.doFormCancel();
        }
      });
      e.extensions.fontName = i;
    })(), (function() {
      "use strict";
      var i = e.extensions.form.extend({
        name: "fontsize",
        action: "fontSize",
        aria: "increase/decrease font size",
        contentDefault: "&#xB1;",
        contentFA: '<i class="fa fa-text-height"></i>',
        init: function() {
          e.extensions.form.prototype.init.apply(this, arguments);
        },
        handleClick: function(t) {
          if (t.preventDefault(), t.stopPropagation(), !this.isDisplayed()) {
            var r = this.document.queryCommandValue("fontSize") + "";
            this.showForm(r);
          }
          return !1;
        },
        getForm: function() {
          return this.form || (this.form = this.createForm()), this.form;
        },
        isDisplayed: function() {
          return this.getForm().style.display === "block";
        },
        hideForm: function() {
          this.getForm().style.display = "none", this.getInput().value = "";
        },
        showForm: function(t) {
          var r = this.getInput();
          this.base.saveSelection(), this.hideToolbarDefaultActions(), this.getForm().style.display = "block", this.setToolbarPosition(), r.value = t || "", r.focus();
        },
        destroy: function() {
          if (!this.form) return !1;
          this.form.parentNode && this.form.parentNode.removeChild(this.form), delete this.form;
        },
        doFormSave: function() {
          this.base.restoreSelection(), this.base.checkSelection();
        },
        doFormCancel: function() {
          this.base.restoreSelection(), this.clearFontSize(), this.base.checkSelection();
        },
        createForm: function() {
          var t = this.document, r = t.createElement("div"), a = t.createElement("input"), s = t.createElement("a"), d = t.createElement("a");
          return r.className = "medium-editor-toolbar-form", r.id = "medium-editor-toolbar-form-fontsize-" + this.getEditorId(), this.on(r, "click", this.handleFormClick.bind(this)), a.setAttribute("type", "range"), a.setAttribute("min", "1"), a.setAttribute("max", "7"), a.className = "medium-editor-toolbar-input", r.appendChild(a), this.on(a, "change", this.handleSliderChange.bind(this)), d.setAttribute("href", "#"), d.className = "medium-editor-toobar-save", d.innerHTML = this.getEditorOption("buttonLabels") === "fontawesome" ? '<i class="fa fa-check"></i>' : "&#10003;", r.appendChild(d), this.on(d, "click", this.handleSaveClick.bind(this), !0), s.setAttribute("href", "#"), s.className = "medium-editor-toobar-close", s.innerHTML = this.getEditorOption("buttonLabels") === "fontawesome" ? '<i class="fa fa-times"></i>' : "&times;", r.appendChild(s), this.on(s, "click", this.handleCloseClick.bind(this)), r;
        },
        getInput: function() {
          return this.getForm().querySelector("input.medium-editor-toolbar-input");
        },
        clearFontSize: function() {
          e.selection.getSelectedElements(this.document).forEach(function(t) {
            t.nodeName.toLowerCase() === "font" && t.hasAttribute("size") && t.removeAttribute("size");
          });
        },
        handleSliderChange: function() {
          var t = this.getInput().value;
          t === "4" ? this.clearFontSize() : this.execAction("fontSize", { value: t });
        },
        handleFormClick: function(t) {
          t.stopPropagation();
        },
        handleSaveClick: function(t) {
          t.preventDefault(), this.doFormSave();
        },
        handleCloseClick: function(t) {
          t.preventDefault(), this.doFormCancel();
        }
      });
      e.extensions.fontSize = i;
    })(), (function() {
      "use strict";
      var i = "%ME_PASTEBIN%", t = null, r = null, a = function(u) {
        u.stopPropagation();
      };
      function s() {
        return [
          [/* @__PURE__ */ new RegExp(/^[\s\S]*<body[^>]*>\s*|\s*<\/body[^>]*>[\s\S]*$/g), ""],
          [/* @__PURE__ */ new RegExp(/<!--StartFragment-->|<!--EndFragment-->/g), ""],
          [/* @__PURE__ */ new RegExp(/<br>$/i), ""],
          [/* @__PURE__ */ new RegExp(/<[^>]*docs-internal-guid[^>]*>/gi), ""],
          [/* @__PURE__ */ new RegExp(/<\/b>(<br[^>]*>)?$/gi), ""],
          [/* @__PURE__ */ new RegExp(/<span class="Apple-converted-space">\s+<\/span>/g), " "],
          [/* @__PURE__ */ new RegExp(/<br class="Apple-interchange-newline">/g), "<br>"],
          [/* @__PURE__ */ new RegExp(/<span[^>]*(font-style:italic;font-weight:(bold|700)|font-weight:(bold|700);font-style:italic)[^>]*>/gi), '<span class="replace-with italic bold">'],
          [/* @__PURE__ */ new RegExp(/<span[^>]*font-style:italic[^>]*>/gi), '<span class="replace-with italic">'],
          [/* @__PURE__ */ new RegExp(/<span[^>]*font-weight:(bold|700)[^>]*>/gi), '<span class="replace-with bold">'],
          [/* @__PURE__ */ new RegExp(/&lt;(\/?)(i|b|a)&gt;/gi), "<$1$2>"],
          [/* @__PURE__ */ new RegExp(/&lt;a(?:(?!href).)+href=(?:&quot;|&rdquo;|&ldquo;|"|“|”)(((?!&quot;|&rdquo;|&ldquo;|"|“|”).)*)(?:&quot;|&rdquo;|&ldquo;|"|“|”)(?:(?!&gt;).)*&gt;/gi), '<a href="$1">'],
          [/* @__PURE__ */ new RegExp(/<\/p>\n+/gi), "</p>"],
          [/* @__PURE__ */ new RegExp(/\n+<p/gi), "<p"],
          [/* @__PURE__ */ new RegExp(/<\/?o:[a-z]*>/gi), ""],
          [/* @__PURE__ */ new RegExp(/<!\[if !supportLists\]>(((?!<!).)*)<!\[endif]\>/gi), "$1"]
        ];
      }
      function d(u, c, h) {
        var f = u.clipboardData || c.clipboardData || h.dataTransfer, p = {};
        if (!f) return p;
        if (f.getData) {
          var v = f.getData("Text");
          v && v.length > 0 && (p["text/plain"] = v);
        }
        if (f.types) for (var g = 0; g < f.types.length; g++) {
          var b = f.types[g];
          p[b] = f.getData(b);
        }
        return p;
      }
      var l = e.Extension.extend({
        forcePlainText: !0,
        cleanPastedHTML: !1,
        preCleanReplacements: [],
        cleanReplacements: [],
        cleanAttrs: [
          "class",
          "style",
          "dir"
        ],
        cleanTags: ["meta"],
        unwrapTags: [],
        init: function() {
          e.Extension.prototype.init.apply(this, arguments), (this.forcePlainText || this.cleanPastedHTML) && (this.subscribe("editableKeydown", this.handleKeydown.bind(this)), this.getEditorElements().forEach(function(u) {
            this.on(u, "paste", this.handlePaste.bind(this));
          }, this), this.subscribe("addElement", this.handleAddElement.bind(this)));
        },
        handleAddElement: function(u, c) {
          this.on(c, "paste", this.handlePaste.bind(this));
        },
        destroy: function() {
          (this.forcePlainText || this.cleanPastedHTML) && this.removePasteBin();
        },
        handlePaste: function(u, c) {
          if (!u.defaultPrevented) {
            var h = d(u, this.window, this.document), f = h["text/html"], p = h["text/plain"];
            this.window.clipboardData && u.clipboardData === void 0 && !f && (f = p), (f || p) && (u.preventDefault(), this.doPaste(f, p, c));
          }
        },
        doPaste: function(u, c, h) {
          var f, p = "", v;
          if (this.cleanPastedHTML && u) return this.cleanPaste(u);
          if (c) {
            if (this.getEditorOption("disableReturn") || h && h.getAttribute("data-disable-return"))
              p = e.util.htmlEntities(c);
            else if (f = c.split(/[\r\n]+/g), f.length > 1)
              for (v = 0; v < f.length; v += 1) f[v] !== "" && (p += "<p>" + e.util.htmlEntities(f[v]) + "</p>");
            else p = e.util.htmlEntities(f[0]);
            e.util.insertHTMLCommand(this.document, p);
          }
        },
        handlePasteBinPaste: function(u) {
          if (u.defaultPrevented) {
            this.removePasteBin();
            return;
          }
          var c = d(u, this.window, this.document), h = c["text/html"], f = c["text/plain"], p = r;
          if (!this.cleanPastedHTML || h) {
            u.preventDefault(), this.removePasteBin(), this.doPaste(h, f, p), this.trigger("editablePaste", {
              currentTarget: p,
              target: p
            }, p);
            return;
          }
          setTimeout(function() {
            this.cleanPastedHTML && (h = this.getPasteBinHtml()), this.removePasteBin(), this.doPaste(h, f, p), this.trigger("editablePaste", {
              currentTarget: p,
              target: p
            }, p);
          }.bind(this), 0);
        },
        handleKeydown: function(u, c) {
          e.util.isKey(u, e.util.keyCode.V) && e.util.isMetaCtrlKey(u) && (u.stopImmediatePropagation(), this.removePasteBin(), this.createPasteBin(c));
        },
        createPasteBin: function(u) {
          var c, h = e.selection.getSelectionRange(this.document), f = this.window.pageYOffset;
          r = u, h && (c = h.getClientRects(), c.length ? f += c[0].top : h.startContainer.getBoundingClientRect !== void 0 ? f += h.startContainer.getBoundingClientRect().top : f += h.getBoundingClientRect().top), t = h;
          var p = this.document.createElement("div");
          p.id = this.pasteBinId = "medium-editor-pastebin-" + +Date.now(), p.setAttribute("style", "border: 1px red solid; position: absolute; top: " + f + "px; width: 10px; height: 10px; overflow: hidden; opacity: 0"), p.setAttribute("contentEditable", !0), p.innerHTML = i, this.document.body.appendChild(p), this.on(p, "focus", a), this.on(p, "focusin", a), this.on(p, "focusout", a), p.focus(), e.selection.selectNode(p, this.document), this.boundHandlePaste || (this.boundHandlePaste = this.handlePasteBinPaste.bind(this)), this.on(p, "paste", this.boundHandlePaste);
        },
        removePasteBin: function() {
          t !== null && (e.selection.selectRange(this.document, t), t = null), r !== null && (r = null);
          var u = this.getPasteBin();
          u && u && (this.off(u, "focus", a), this.off(u, "focusin", a), this.off(u, "focusout", a), this.off(u, "paste", this.boundHandlePaste), u.parentElement.removeChild(u));
        },
        getPasteBin: function() {
          return this.document.getElementById(this.pasteBinId);
        },
        getPasteBinHtml: function() {
          var u = this.getPasteBin();
          if (!u || u.firstChild && u.firstChild.id === "mcepastebin") return !1;
          var c = u.innerHTML;
          return !c || c === i ? !1 : c;
        },
        cleanPaste: function(u) {
          var c, h, f, p, v = /<p|<br|<div/.test(u), g = [].concat(this.preCleanReplacements || [], s(), this.cleanReplacements || []);
          for (c = 0; c < g.length; c += 1) u = u.replace(g[c][0], g[c][1]);
          if (!v) return this.pasteHTML(u);
          for (f = this.document.createElement("div"), f.innerHTML = "<p>" + u.split("<br><br>").join("</p><p>") + "</p>", h = f.querySelectorAll("a,p,div,br"), c = 0; c < h.length; c += 1)
            switch (p = h[c], p.innerHTML = p.innerHTML.replace(/\n/gi, " "), p.nodeName.toLowerCase()) {
              case "p":
              case "div":
                this.filterCommonBlocks(p);
                break;
              case "br":
                this.filterLineBreak(p);
            }
          this.pasteHTML(f.innerHTML);
        },
        pasteHTML: function(u, c) {
          c = e.util.defaults({}, c, {
            cleanAttrs: this.cleanAttrs,
            cleanTags: this.cleanTags,
            unwrapTags: this.unwrapTags
          });
          var h, f, p, v, g = this.document.createDocumentFragment();
          for (g.appendChild(this.document.createElement("body")), v = g.querySelector("body"), v.innerHTML = u, this.cleanupSpans(v), h = v.querySelectorAll("*"), p = 0; p < h.length; p += 1)
            f = h[p], f.nodeName.toLowerCase() === "a" && this.getEditorOption("targetBlank") && e.util.setTargetBlank(f), e.util.cleanupAttrs(f, c.cleanAttrs), e.util.cleanupTags(f, c.cleanTags), e.util.unwrapTags(f, c.unwrapTags);
          e.util.insertHTMLCommand(this.document, v.innerHTML.replace(/&nbsp;/g, " "));
        },
        isCommonBlock: function(u) {
          return u && (u.nodeName.toLowerCase() === "p" || u.nodeName.toLowerCase() === "div");
        },
        filterCommonBlocks: function(u) {
          /^\s*$/.test(u.textContent) && u.parentNode && u.parentNode.removeChild(u);
        },
        filterLineBreak: function(u) {
          this.isCommonBlock(u.previousElementSibling) ? this.removeWithParent(u) : this.isCommonBlock(u.parentNode) && (u.parentNode.firstChild === u || u.parentNode.lastChild === u) ? this.removeWithParent(u) : u.parentNode && u.parentNode.childElementCount === 1 && u.parentNode.textContent === "" && this.removeWithParent(u);
        },
        removeWithParent: function(u) {
          u && u.parentNode && (u.parentNode.parentNode && u.parentNode.childElementCount === 1 ? u.parentNode.parentNode.removeChild(u.parentNode) : u.parentNode.removeChild(u));
        },
        cleanupSpans: function(u) {
          var c, h, f, p = u.querySelectorAll(".replace-with"), v = function(g) {
            return g && g.nodeName !== "#text" && g.getAttribute("contenteditable") === "false";
          };
          for (c = 0; c < p.length; c += 1)
            h = p[c], f = this.document.createElement(h.classList.contains("bold") ? "b" : "i"), h.classList.contains("bold") && h.classList.contains("italic") ? f.innerHTML = "<i>" + h.innerHTML + "</i>" : f.innerHTML = h.innerHTML, h.parentNode.replaceChild(f, h);
          for (p = u.querySelectorAll("span"), c = 0; c < p.length; c += 1) {
            if (h = p[c], e.util.traverseUp(h, v)) return !1;
            e.util.unwrap(h, this.document);
          }
        }
      });
      e.extensions.paste = l;
    })(), (function() {
      "use strict";
      var i = e.Extension.extend({
        name: "placeholder",
        text: "Type your text",
        hideOnClick: !0,
        init: function() {
          e.Extension.prototype.init.apply(this, arguments), this.initPlaceholders(), this.attachEventHandlers();
        },
        initPlaceholders: function() {
          this.getEditorElements().forEach(this.initElement, this);
        },
        handleAddElement: function(t, r) {
          this.initElement(r);
        },
        initElement: function(t) {
          t.getAttribute("data-placeholder") || t.setAttribute("data-placeholder", this.text), this.updatePlaceholder(t);
        },
        destroy: function() {
          this.getEditorElements().forEach(this.cleanupElement, this);
        },
        handleRemoveElement: function(t, r) {
          this.cleanupElement(r);
        },
        cleanupElement: function(t) {
          t.getAttribute("data-placeholder") === this.text && t.removeAttribute("data-placeholder");
        },
        showPlaceholder: function(t) {
          t && (e.util.isFF && t.childNodes.length === 0 ? (t.classList.add("medium-editor-placeholder-relative"), t.classList.remove("medium-editor-placeholder")) : (t.classList.add("medium-editor-placeholder"), t.classList.remove("medium-editor-placeholder-relative")));
        },
        hidePlaceholder: function(t) {
          t && (t.classList.remove("medium-editor-placeholder"), t.classList.remove("medium-editor-placeholder-relative"));
        },
        updatePlaceholder: function(t, r) {
          if (t.querySelector("img, blockquote, ul, ol, table") || t.textContent.replace(/^\s+|\s+$/g, "") !== "") return this.hidePlaceholder(t);
          r || this.showPlaceholder(t);
        },
        attachEventHandlers: function() {
          this.hideOnClick && this.subscribe("focus", this.handleFocus.bind(this)), this.subscribe("editableInput", this.handleInput.bind(this)), this.subscribe("blur", this.handleBlur.bind(this)), this.subscribe("addElement", this.handleAddElement.bind(this)), this.subscribe("removeElement", this.handleRemoveElement.bind(this));
        },
        handleInput: function(t, r) {
          var a = this.hideOnClick && r === this.base.getFocusedElement();
          this.updatePlaceholder(r, a);
        },
        handleFocus: function(t, r) {
          this.hidePlaceholder(r);
        },
        handleBlur: function(t, r) {
          this.updatePlaceholder(r);
        }
      });
      e.extensions.placeholder = i;
    })(), (function() {
      "use strict";
      var i = e.Extension.extend({
        name: "toolbar",
        align: "center",
        allowMultiParagraphSelection: !0,
        buttons: [
          "bold",
          "italic",
          "underline",
          "anchor",
          "h2",
          "h3",
          "quote"
        ],
        diffLeft: 0,
        diffTop: -10,
        firstButtonClass: "medium-editor-button-first",
        lastButtonClass: "medium-editor-button-last",
        standardizeSelectionStart: !1,
        static: !1,
        sticky: !1,
        stickyTopOffset: 0,
        updateOnEmptySelection: !1,
        relativeContainer: null,
        init: function() {
          e.Extension.prototype.init.apply(this, arguments), this.initThrottledMethods(), this.relativeContainer ? this.relativeContainer.appendChild(this.getToolbarElement()) : this.getEditorOption("elementsContainer").appendChild(this.getToolbarElement());
        },
        forEachExtension: function(t, r) {
          return this.base.extensions.forEach(function(a) {
            if (a !== this)
              return t.apply(r || this, arguments);
          }, this);
        },
        createToolbar: function() {
          var t = this.document.createElement("div");
          return t.id = "medium-editor-toolbar-" + this.getEditorId(), t.className = "medium-editor-toolbar", this.static ? t.className += " static-toolbar" : this.relativeContainer ? t.className += " medium-editor-relative-toolbar" : t.className += " medium-editor-stalker-toolbar", t.appendChild(this.createToolbarButtons()), this.forEachExtension(function(r) {
            r.hasForm && t.appendChild(r.getForm());
          }), this.attachEventHandlers(), t;
        },
        createToolbarButtons: function() {
          var t = this.document.createElement("ul"), r, a, s, d, l, u;
          return t.id = "medium-editor-toolbar-actions" + this.getEditorId(), t.className = "medium-editor-toolbar-actions", t.style.display = "block", this.buttons.forEach(function(c) {
            typeof c == "string" ? (l = c, u = null) : (l = c.name, u = c), d = this.base.addBuiltInExtension(l, u), d && typeof d.getButton == "function" && (a = d.getButton(this.base), r = this.document.createElement("li"), e.util.isElement(a) ? r.appendChild(a) : r.innerHTML = a, t.appendChild(r));
          }, this), s = t.querySelectorAll("button"), s.length > 0 && (s[0].classList.add(this.firstButtonClass), s[s.length - 1].classList.add(this.lastButtonClass)), t;
        },
        destroy: function() {
          this.toolbar && (this.toolbar.parentNode && this.toolbar.parentNode.removeChild(this.toolbar), delete this.toolbar);
        },
        getInteractionElements: function() {
          return this.getToolbarElement();
        },
        getToolbarElement: function() {
          return this.toolbar || (this.toolbar = this.createToolbar()), this.toolbar;
        },
        getToolbarActionsElement: function() {
          return this.getToolbarElement().querySelector(".medium-editor-toolbar-actions");
        },
        initThrottledMethods: function() {
          this.throttledPositionToolbar = e.util.throttle(function() {
            this.base.isActive && this.positionToolbarIfShown();
          }.bind(this));
        },
        attachEventHandlers: function() {
          this.subscribe("blur", this.handleBlur.bind(this)), this.subscribe("focus", this.handleFocus.bind(this)), this.subscribe("editableClick", this.handleEditableClick.bind(this)), this.subscribe("editableKeyup", this.handleEditableKeyup.bind(this)), this.on(this.document.documentElement, "mouseup", this.handleDocumentMouseup.bind(this)), this.static && this.sticky && this.on(this.window, "scroll", this.handleWindowScroll.bind(this), !0), this.on(this.window, "resize", this.handleWindowResize.bind(this));
        },
        handleWindowScroll: function() {
          this.positionToolbarIfShown();
        },
        handleWindowResize: function() {
          this.throttledPositionToolbar();
        },
        handleDocumentMouseup: function(t) {
          if (t && t.target && e.util.isDescendant(this.getToolbarElement(), t.target)) return !1;
          this.checkState();
        },
        handleEditableClick: function() {
          setTimeout(function() {
            this.checkState();
          }.bind(this), 0);
        },
        handleEditableKeyup: function() {
          this.checkState();
        },
        handleBlur: function() {
          clearTimeout(this.hideTimeout), clearTimeout(this.delayShowTimeout), this.hideTimeout = setTimeout(function() {
            this.hideToolbar();
          }.bind(this), 1);
        },
        handleFocus: function() {
          this.checkState();
        },
        isDisplayed: function() {
          return this.getToolbarElement().classList.contains("medium-editor-toolbar-active");
        },
        showToolbar: function() {
          clearTimeout(this.hideTimeout), this.isDisplayed() || (this.getToolbarElement().classList.add("medium-editor-toolbar-active"), this.trigger("showToolbar", {}, this.base.getFocusedElement()));
        },
        hideToolbar: function() {
          this.isDisplayed() && (this.getToolbarElement().classList.remove("medium-editor-toolbar-active"), this.trigger("hideToolbar", {}, this.base.getFocusedElement()));
        },
        isToolbarDefaultActionsDisplayed: function() {
          return this.getToolbarActionsElement().style.display === "block";
        },
        hideToolbarDefaultActions: function() {
          this.isToolbarDefaultActionsDisplayed() && (this.getToolbarActionsElement().style.display = "none");
        },
        showToolbarDefaultActions: function() {
          this.hideExtensionForms(), this.isToolbarDefaultActionsDisplayed() || (this.getToolbarActionsElement().style.display = "block"), this.delayShowTimeout = this.base.delay(function() {
            this.showToolbar();
          }.bind(this));
        },
        hideExtensionForms: function() {
          this.forEachExtension(function(t) {
            t.hasForm && t.isDisplayed() && t.hideForm();
          });
        },
        multipleBlockElementsSelected: function() {
          var t = /<[^\/>][^>]*><\/[^>]+>/gim, r = new RegExp("<(" + e.util.blockContainerElementNames.join("|") + ")[^>]*>", "g"), a = e.selection.getSelectionHtml(this.document).replace(t, "").match(r);
          return !!a && a.length > 1;
        },
        modifySelection: function() {
          var t = this.window.getSelection().getRangeAt(0);
          if (this.standardizeSelectionStart && t.startContainer.nodeValue && t.startOffset === t.startContainer.nodeValue.length) {
            var r = e.util.findAdjacentTextNodeWithContent(e.selection.getSelectionElement(this.window), t.startContainer, this.document);
            if (r) {
              for (var a = 0; r.nodeValue.substr(a, 1).trim().length === 0; ) a = a + 1;
              t = e.selection.select(this.document, r, a, t.endContainer, t.endOffset);
            }
          }
        },
        checkState: function() {
          if (!this.base.preventSelectionUpdates) {
            if (!this.base.getFocusedElement() || e.selection.selectionInContentEditableFalse(this.window)) return this.hideToolbar();
            var t = e.selection.getSelectionElement(this.window);
            if (!t || this.getEditorElements().indexOf(t) === -1 || t.getAttribute("data-disable-toolbar")) return this.hideToolbar();
            if (this.updateOnEmptySelection && this.static) return this.showAndUpdateToolbar();
            if (!e.selection.selectionContainsContent(this.document) || this.allowMultiParagraphSelection === !1 && this.multipleBlockElementsSelected()) return this.hideToolbar();
            this.showAndUpdateToolbar();
          }
        },
        showAndUpdateToolbar: function() {
          this.modifySelection(), this.setToolbarButtonStates(), this.trigger("positionToolbar", {}, this.base.getFocusedElement()), this.showToolbarDefaultActions(), this.setToolbarPosition();
        },
        setToolbarButtonStates: function() {
          this.forEachExtension(function(t) {
            typeof t.isActive == "function" && typeof t.setInactive == "function" && t.setInactive();
          }), this.checkActiveButtons();
        },
        checkActiveButtons: function() {
          var t = [], r = null, a = e.selection.getSelectionRange(this.document), s, d = function(l) {
            typeof l.checkState == "function" ? l.checkState(s) : typeof l.isActive == "function" && typeof l.isAlreadyApplied == "function" && typeof l.setActive == "function" && !l.isActive() && l.isAlreadyApplied(s) && l.setActive();
          };
          if (a && (this.forEachExtension(function(l) {
            if (typeof l.queryCommandState == "function" && (r = l.queryCommandState(), r !== null)) {
              r && typeof l.setActive == "function" && l.setActive();
              return;
            }
            t.push(l);
          }), s = e.selection.getSelectedParentElement(a), !!this.getEditorElements().some(function(l) {
            return e.util.isDescendant(l, s, !0);
          })))
            for (; s && (t.forEach(d), !e.util.isMediumEditorElement(s)); )
              s = s.parentNode;
        },
        positionToolbarIfShown: function() {
          this.isDisplayed() && this.setToolbarPosition();
        },
        setToolbarPosition: function() {
          var t = this.base.getFocusedElement(), r = this.window.getSelection();
          if (!t) return this;
          (this.static || !r.isCollapsed) && (this.showToolbar(), this.relativeContainer || (this.static ? this.positionStaticToolbar(t) : this.positionToolbar(r)), this.trigger("positionedToolbar", {}, this.base.getFocusedElement()));
        },
        positionStaticToolbar: function(t) {
          this.getToolbarElement().style.left = "0";
          var r = this.document.documentElement && this.document.documentElement.scrollTop || this.document.body.scrollTop, a = this.window.innerWidth, s = this.getToolbarElement(), d = t.getBoundingClientRect(), l = d.top + r, u = d.left + d.width / 2, c = s.offsetHeight, h = s.offsetWidth, f = h / 2, p;
          switch (this.sticky ? r > l + t.offsetHeight - c - this.stickyTopOffset ? (s.style.top = l + t.offsetHeight - c + "px", s.classList.remove("medium-editor-sticky-toolbar")) : r > l - c - this.stickyTopOffset ? (s.classList.add("medium-editor-sticky-toolbar"), s.style.top = this.stickyTopOffset + "px") : (s.classList.remove("medium-editor-sticky-toolbar"), s.style.top = l - c + "px") : s.style.top = l - c + "px", this.align) {
            case "left":
              p = d.left;
              break;
            case "right":
              p = d.right - h;
              break;
            case "center":
              p = u - f;
          }
          p < 0 ? p = 0 : p + h > a && (p = a - Math.ceil(h) - 1), s.style.left = p + "px";
        },
        positionToolbar: function(t) {
          this.getToolbarElement().style.left = "0", this.getToolbarElement().style.right = "initial";
          var r = t.getRangeAt(0), a = r.getBoundingClientRect();
          (!a || a.height === 0 && a.width === 0 && r.startContainer === r.endContainer) && (r.startContainer.nodeType === 1 && r.startContainer.querySelector("img") ? a = r.startContainer.querySelector("img").getBoundingClientRect() : a = r.startContainer.getBoundingClientRect());
          var s = this.window.innerWidth, d = this.getToolbarElement(), l = d.offsetHeight, u = d.offsetWidth / 2, c = 50, h = this.diffLeft - u, f = this.getEditorOption("elementsContainer"), p = ["absolute", "fixed"].indexOf(window.getComputedStyle(f).getPropertyValue("position")) > -1, v = {}, g = {}, b, _;
          p ? (_ = f.getBoundingClientRect(), ["top", "left"].forEach(function(D) {
            g[D] = a[D] - _[D];
          }), g.width = a.width, g.height = a.height, a = g, s = _.width, v.top = f.scrollTop) : v.top = this.window.pageYOffset, b = a.left + a.width / 2, v.top += a.top - l, a.top < c ? (d.classList.add("medium-toolbar-arrow-over"), d.classList.remove("medium-toolbar-arrow-under"), v.top += c + a.height - this.diffTop) : (d.classList.add("medium-toolbar-arrow-under"), d.classList.remove("medium-toolbar-arrow-over"), v.top += this.diffTop), b < u ? (v.left = h + u, v.right = "initial") : s - b < u ? (v.left = "auto", v.right = 0) : (v.left = h + b, v.right = "initial"), [
            "top",
            "left",
            "right"
          ].forEach(function(D) {
            d.style[D] = v[D] + (isNaN(v[D]) ? "" : "px");
          });
        }
      });
      e.extensions.toolbar = i;
    })(), (function() {
      "use strict";
      var i = e.Extension.extend({
        init: function() {
          e.Extension.prototype.init.apply(this, arguments), this.subscribe("editableDrag", this.handleDrag.bind(this)), this.subscribe("editableDrop", this.handleDrop.bind(this));
        },
        handleDrag: function(t) {
          var r = "medium-editor-dragover";
          t.preventDefault(), t.dataTransfer.dropEffect = "copy", t.type === "dragover" ? t.target.classList.add(r) : t.type === "dragleave" && t.target.classList.remove(r);
        },
        handleDrop: function(t) {
          var r = "medium-editor-dragover", a;
          t.preventDefault(), t.stopPropagation(), t.dataTransfer.files && (a = Array.prototype.slice.call(t.dataTransfer.files, 0), a.some(function(s) {
            if (s.type.match("image")) {
              var d = new FileReader(), l;
              d.readAsDataURL(s), l = "medium-img-" + +/* @__PURE__ */ new Date(), e.util.insertHTMLCommand(this.document, '<img class="medium-editor-image-loading" id="' + l + '" />'), d.onload = function() {
                var u = this.document.getElementById(l);
                u && (u.removeAttribute("id"), u.removeAttribute("class"), u.src = d.result);
              }.bind(this);
            }
          }.bind(this))), t.target.classList.remove(r);
        }
      });
      e.extensions.imageDragging = i;
    })(), (function() {
      "use strict";
      function i(w) {
        var O = e.selection.getSelectionStart(this.options.ownerDocument), T = O.textContent, U = e.selection.getCaretOffsets(O);
        (T[U.left - 1] === void 0 || T[U.left - 1].trim() === "" || T[U.left] !== void 0 && T[U.left].trim() === "") && w.preventDefault();
      }
      function t(w, O) {
        if (this.options.disableReturn || O.getAttribute("data-disable-return")) w.preventDefault();
        else if (this.options.disableDoubleReturn || O.getAttribute("data-disable-double-return")) {
          var T = e.selection.getSelectionStart(this.options.ownerDocument);
          (T && T.textContent.trim() === "" && T.nodeName.toLowerCase() !== "li" || T.previousElementSibling && T.previousElementSibling.nodeName.toLowerCase() !== "br" && T.previousElementSibling.textContent.trim() === "") && w.preventDefault();
        }
      }
      function r(w) {
        var O = e.selection.getSelectionStart(this.options.ownerDocument);
        (O && O.nodeName.toLowerCase()) === "pre" && (w.preventDefault(), e.util.insertHTMLCommand(this.options.ownerDocument, "    ")), e.util.isListItem(O) && (w.preventDefault(), w.shiftKey ? this.options.ownerDocument.execCommand("outdent", !1, null) : this.options.ownerDocument.execCommand("indent", !1, null));
      }
      function a(w) {
        var O, T = e.selection.getSelectionStart(this.options.ownerDocument), U = T.nodeName.toLowerCase(), ie = /^(\s+|<br\/?>)?$/i, pe = /h\d/i;
        e.util.isKey(w, [e.util.keyCode.BACKSPACE, e.util.keyCode.ENTER]) && T.previousElementSibling && pe.test(U) && e.selection.getCaretOffsets(T).left === 0 ? e.util.isKey(w, e.util.keyCode.BACKSPACE) && ie.test(T.previousElementSibling.innerHTML) ? (T.previousElementSibling.parentNode.removeChild(T.previousElementSibling), w.preventDefault()) : !this.options.disableDoubleReturn && e.util.isKey(w, e.util.keyCode.ENTER) && (O = this.options.ownerDocument.createElement("p"), O.innerHTML = "<br>", T.previousElementSibling.parentNode.insertBefore(O, T), w.preventDefault()) : e.util.isKey(w, e.util.keyCode.DELETE) && T.nextElementSibling && T.previousElementSibling && !pe.test(U) && ie.test(T.innerHTML) && pe.test(T.nextElementSibling.nodeName.toLowerCase()) ? (e.selection.moveCursor(this.options.ownerDocument, T.nextElementSibling), T.previousElementSibling.parentNode.removeChild(T), w.preventDefault()) : e.util.isKey(w, e.util.keyCode.BACKSPACE) && U === "li" && ie.test(T.innerHTML) && !T.previousElementSibling && !T.parentElement.previousElementSibling && T.nextElementSibling && T.nextElementSibling.nodeName.toLowerCase() === "li" ? (O = this.options.ownerDocument.createElement("p"), O.innerHTML = "<br>", T.parentElement.parentElement.insertBefore(O, T.parentElement), e.selection.moveCursor(this.options.ownerDocument, O), T.parentElement.removeChild(T), w.preventDefault()) : e.util.isKey(w, e.util.keyCode.BACKSPACE) && e.util.getClosestTag(T, "blockquote") !== !1 && e.selection.getCaretOffsets(T).left === 0 ? (w.preventDefault(), e.util.execFormatBlock(this.options.ownerDocument, "p")) : e.util.isKey(w, e.util.keyCode.ENTER) && e.util.getClosestTag(T, "blockquote") !== !1 && e.selection.getCaretOffsets(T).right === 0 ? (O = this.options.ownerDocument.createElement("p"), O.innerHTML = "<br>", T.parentElement.insertBefore(O, T.nextSibling), e.selection.moveCursor(this.options.ownerDocument, O), w.preventDefault()) : e.util.isKey(w, e.util.keyCode.BACKSPACE) && e.util.isMediumEditorElement(T.parentElement) && !T.previousElementSibling && T.nextElementSibling && ie.test(T.innerHTML) && (w.preventDefault(), e.selection.moveCursor(this.options.ownerDocument, T.nextSibling), T.parentElement.removeChild(T));
      }
      function s(w) {
        var O = e.selection.getSelectionStart(this.options.ownerDocument), T;
        O && (e.util.isMediumEditorElement(O) && O.children.length === 0 && !e.util.isBlockContainer(O) && this.options.ownerDocument.execCommand("formatBlock", !1, "p"), e.util.isKey(w, e.util.keyCode.ENTER) && !e.util.isListItem(O) && !e.util.isBlockContainer(O) && (T = O.nodeName.toLowerCase(), T === "a" ? this.options.ownerDocument.execCommand("unlink", !1, null) : !w.shiftKey && !w.ctrlKey && this.options.ownerDocument.execCommand("formatBlock", !1, "p")));
      }
      function d(w, O) {
        var T = O.parentNode.querySelector('textarea[medium-editor-textarea-id="' + O.getAttribute("medium-editor-textarea-id") + '"]');
        T && (T.value = O.innerHTML.trim());
      }
      function l(w) {
        w._mediumEditors || (w._mediumEditors = [null]), this.id || (this.id = w._mediumEditors.length), w._mediumEditors[this.id] = this;
      }
      function u(w) {
        !w._mediumEditors || !w._mediumEditors[this.id] || (w._mediumEditors[this.id] = null);
      }
      function c(w, O, T) {
        var U = [];
        if (w || (w = []), typeof w == "string" && (w = O.querySelectorAll(w)), e.util.isElement(w) && (w = [w]), T) for (var ie = 0; ie < w.length; ie++) {
          var pe = w[ie];
          e.util.isElement(pe) && !pe.getAttribute("data-medium-editor-element") && !pe.getAttribute("medium-editor-textarea-id") && U.push(pe);
        }
        else U = Array.prototype.slice.apply(w);
        return U;
      }
      function h(w) {
        var O = w.parentNode.querySelector('textarea[medium-editor-textarea-id="' + w.getAttribute("medium-editor-textarea-id") + '"]');
        O && (O.classList.remove("medium-editor-hidden"), O.removeAttribute("medium-editor-textarea-id")), w.parentNode && w.parentNode.removeChild(w);
      }
      function f(w, O) {
        return Object.keys(O).forEach(function(T) {
          w[T] === void 0 && (w[T] = O[T]);
        }), w;
      }
      function p(w, O, T) {
        var U = {
          window: T.options.contentWindow,
          document: T.options.ownerDocument,
          base: T
        };
        return w = f(w, U), typeof w.init == "function" && w.init(), w.name || (w.name = O), w;
      }
      function v() {
        return this.elements.every(function(w) {
          return !!w.getAttribute("data-disable-toolbar");
        }) ? !1 : this.options.toolbar !== !1;
      }
      function g() {
        return v.call(this) ? this.options.anchorPreview !== !1 : !1;
      }
      function b() {
        return this.options.placeholder !== !1;
      }
      function _() {
        return this.options.autoLink !== !1;
      }
      function D() {
        return this.options.imageDragging !== !1;
      }
      function L() {
        return this.options.keyboardCommands !== !1;
      }
      function W() {
        return !this.options.extensions.imageDragging;
      }
      function B(w) {
        for (var O = this.options.ownerDocument.createElement("div"), T = Date.now(), U = "medium-editor-" + T, ie = w.attributes; this.options.ownerDocument.getElementById(U); )
          T++, U = "medium-editor-" + T;
        O.className = w.className, O.id = U, O.innerHTML = w.value, w.setAttribute("medium-editor-textarea-id", U);
        for (var pe = 0, je = ie.length; pe < je; pe++) O.hasAttribute(ie[pe].nodeName) || O.setAttribute(ie[pe].nodeName, ie[pe].value);
        return w.form && this.on(w.form, "reset", function(Ge) {
          Ge.defaultPrevented || this.resetContent(this.options.ownerDocument.getElementById(U));
        }.bind(this)), w.classList.add("medium-editor-hidden"), w.parentNode.insertBefore(O, w), O;
      }
      function K(w, O) {
        if (!w.getAttribute("data-medium-editor-element")) {
          w.nodeName.toLowerCase() === "textarea" && (w = B.call(this, w), this.instanceHandleEditableInput || (this.instanceHandleEditableInput = d.bind(this), this.subscribe("editableInput", this.instanceHandleEditableInput))), !this.options.disableEditing && !w.getAttribute("data-disable-editing") && (w.setAttribute("contentEditable", !0), w.setAttribute("spellcheck", this.options.spellcheck)), this.instanceHandleEditableKeydownEnter || (w.getAttribute("data-disable-return") || w.getAttribute("data-disable-double-return")) && (this.instanceHandleEditableKeydownEnter = t.bind(this), this.subscribe("editableKeydownEnter", this.instanceHandleEditableKeydownEnter)), !this.options.disableReturn && !w.getAttribute("data-disable-return") && this.on(w, "keyup", s.bind(this));
          var T = e.util.guid();
          w.setAttribute("data-medium-editor-element", !0), w.classList.add("medium-editor-element"), w.setAttribute("role", "textbox"), w.setAttribute("aria-multiline", !0), w.setAttribute("data-medium-editor-editor-index", O), w.setAttribute("medium-editor-index", T), xe[T] = w.innerHTML, this.events.attachAllEventsToElement(w);
        }
        return w;
      }
      function Y() {
        this.subscribe("editableKeydownTab", r.bind(this)), this.subscribe("editableKeydownDelete", a.bind(this)), this.subscribe("editableKeydownEnter", a.bind(this)), this.options.disableExtraSpaces && this.subscribe("editableKeydownSpace", i.bind(this)), this.instanceHandleEditableKeydownEnter || (this.options.disableReturn || this.options.disableDoubleReturn) && (this.instanceHandleEditableKeydownEnter = t.bind(this), this.subscribe("editableKeydownEnter", this.instanceHandleEditableKeydownEnter));
      }
      function te() {
        if (this.extensions = [], Object.keys(this.options.extensions).forEach(function(ie) {
          ie !== "toolbar" && this.options.extensions[ie] && this.extensions.push(p(this.options.extensions[ie], ie, this));
        }, this), W.call(this)) {
          var w = this.options.fileDragging;
          w || (w = {}, D.call(this) || (w.allowedTypes = [])), this.addBuiltInExtension("fileDragging", w);
        }
        var O = {
          paste: !0,
          "anchor-preview": g.call(this),
          autoLink: _.call(this),
          keyboardCommands: L.call(this),
          placeholder: b.call(this)
        };
        Object.keys(O).forEach(function(ie) {
          O[ie] && this.addBuiltInExtension(ie);
        }, this);
        var T = this.options.extensions.toolbar;
        if (!T && v.call(this)) {
          var U = e.util.extend({}, this.options.toolbar, { allowMultiParagraphSelection: this.options.allowMultiParagraphSelection });
          T = new e.extensions.toolbar(U);
        }
        T && this.extensions.push(p(T, "toolbar", this));
      }
      function se(w, O) {
        var T = [["allowMultiParagraphSelection", "toolbar.allowMultiParagraphSelection"]];
        return O && T.forEach(function(U) {
          O.hasOwnProperty(U[0]) && O[U[0]] !== void 0 && e.util.deprecated(U[0], U[1], "v6.0.0");
        }), e.util.defaults({}, O, w);
      }
      function Le(w, O) {
        var T = /^append-(.+)$/gi, U = /justify([A-Za-z]*)$/g, ie = T.exec(w), pe;
        if (ie) return e.util.execFormatBlock(this.options.ownerDocument, ie[1]);
        if (w === "fontSize")
          return O.size && e.util.deprecated(".size option for fontSize command", ".value", "6.0.0"), pe = O.value || O.size, this.options.ownerDocument.execCommand("fontSize", !1, pe);
        if (w === "fontName")
          return O.name && e.util.deprecated(".name option for fontName command", ".value", "6.0.0"), pe = O.value || O.name, this.options.ownerDocument.execCommand("fontName", !1, pe);
        if (w === "createLink") return this.createLink(O);
        if (w === "image") {
          var je = this.options.contentWindow.getSelection().toString().trim();
          return this.options.ownerDocument.execCommand("insertImage", !1, je);
        }
        if (w === "html") {
          var Ge = this.options.contentWindow.getSelection().toString().trim();
          return e.util.insertHTMLCommand(this.options.ownerDocument, Ge);
        }
        if (U.exec(w)) {
          var vt = this.options.ownerDocument.execCommand(w, !1, null), dt = e.selection.getSelectedParentElement(e.selection.getSelectionRange(this.options.ownerDocument));
          return dt && ze.call(this, e.util.getTopBlockContainer(dt)), vt;
        }
        return pe = O && O.value, this.options.ownerDocument.execCommand(w, !1, pe);
      }
      function ze(w) {
        if (w) {
          var O, T = Array.prototype.slice.call(w.childNodes).filter(function(U) {
            var ie = U.nodeName.toLowerCase() === "div";
            return ie && !O && (O = U.style.textAlign), ie;
          });
          T.length && (this.saveSelection(), T.forEach(function(U) {
            if (U.style.textAlign === O) {
              var ie = U.lastChild;
              if (ie) {
                e.util.unwrap(U, this.options.ownerDocument);
                var pe = this.options.ownerDocument.createElement("BR");
                ie.parentNode.insertBefore(pe, ie.nextSibling);
              }
            }
          }, this), w.style.textAlign = O, this.restoreSelection());
        }
      }
      var xe = {};
      e.prototype = {
        init: function(w, O) {
          return this.options = se.call(this, this.defaults, O), this.origElements = w, this.options.elementsContainer || (this.options.elementsContainer = this.options.ownerDocument.body), this.setup();
        },
        setup: function() {
          this.isActive || (l.call(this, this.options.contentWindow), this.events = new e.Events(this), this.elements = [], this.addElements(this.origElements), this.elements.length !== 0 && (this.isActive = !0, te.call(this), Y.call(this)));
        },
        destroy: function() {
          this.isActive && (this.isActive = !1, this.extensions.forEach(function(w) {
            typeof w.destroy == "function" && w.destroy();
          }, this), this.events.destroy(), this.elements.forEach(function(w) {
            this.options.spellcheck && (w.innerHTML = w.innerHTML), w.removeAttribute("contentEditable"), w.removeAttribute("spellcheck"), w.removeAttribute("data-medium-editor-element"), w.classList.remove("medium-editor-element"), w.removeAttribute("role"), w.removeAttribute("aria-multiline"), w.removeAttribute("medium-editor-index"), w.removeAttribute("data-medium-editor-editor-index"), w.getAttribute("medium-editor-textarea-id") && h(w);
          }, this), this.elements = [], this.instanceHandleEditableKeydownEnter = null, this.instanceHandleEditableInput = null, u.call(this, this.options.contentWindow));
        },
        on: function(w, O, T, U) {
          return this.events.attachDOMEvent(w, O, T, U), this;
        },
        off: function(w, O, T, U) {
          return this.events.detachDOMEvent(w, O, T, U), this;
        },
        subscribe: function(w, O) {
          return this.events.attachCustomEvent(w, O), this;
        },
        unsubscribe: function(w, O) {
          return this.events.detachCustomEvent(w, O), this;
        },
        trigger: function(w, O, T) {
          return this.events.triggerCustomEvent(w, O, T), this;
        },
        delay: function(w) {
          var O = this;
          return setTimeout(function() {
            O.isActive && w();
          }, this.options.delay);
        },
        serialize: function() {
          var w, O, T = {}, U = this.elements.length;
          for (w = 0; w < U; w += 1)
            O = this.elements[w].id !== "" ? this.elements[w].id : "element-" + w, T[O] = { value: this.elements[w].innerHTML.trim() };
          return T;
        },
        getExtensionByName: function(w) {
          var O;
          return this.extensions && this.extensions.length && this.extensions.some(function(T) {
            return T.name === w ? (O = T, !0) : !1;
          }), O;
        },
        addBuiltInExtension: function(w, O) {
          var T = this.getExtensionByName(w), U;
          if (T) return T;
          switch (w) {
            case "anchor":
              U = e.util.extend({}, this.options.anchor, O), T = new e.extensions.anchor(U);
              break;
            case "anchor-preview":
              T = new e.extensions.anchorPreview(this.options.anchorPreview);
              break;
            case "autoLink":
              T = new e.extensions.autoLink();
              break;
            case "fileDragging":
              T = new e.extensions.fileDragging(O);
              break;
            case "fontname":
              T = new e.extensions.fontName(this.options.fontName);
              break;
            case "fontsize":
              T = new e.extensions.fontSize(O);
              break;
            case "keyboardCommands":
              T = new e.extensions.keyboardCommands(this.options.keyboardCommands);
              break;
            case "paste":
              T = new e.extensions.paste(this.options.paste);
              break;
            case "placeholder":
              T = new e.extensions.placeholder(this.options.placeholder);
              break;
            default:
              e.extensions.button.isBuiltInButton(w) && (O ? (U = e.util.defaults({}, O, e.extensions.button.prototype.defaults[w]), T = new e.extensions.button(U)) : T = new e.extensions.button(w));
          }
          return T && this.extensions.push(p(T, w, this)), T;
        },
        stopSelectionUpdates: function() {
          this.preventSelectionUpdates = !0;
        },
        startSelectionUpdates: function() {
          this.preventSelectionUpdates = !1;
        },
        checkSelection: function() {
          var w = this.getExtensionByName("toolbar");
          return w && w.checkState(), this;
        },
        queryCommandState: function(w) {
          var O = /^full-(.+)$/gi, T, U = null;
          T = O.exec(w), T && (w = T[1]);
          try {
            U = this.options.ownerDocument.queryCommandState(w);
          } catch (ie) {
            U = null;
          }
          return U;
        },
        execAction: function(w, O) {
          var T = /^full-(.+)$/gi.exec(w), U;
          return T ? (this.saveSelection(), this.selectAllContents(), U = Le.call(this, T[1], O), this.restoreSelection()) : U = Le.call(this, w, O), (w === "insertunorderedlist" || w === "insertorderedlist") && e.util.cleanListDOM(this.options.ownerDocument, this.getSelectedParentElement()), this.checkSelection(), U;
        },
        getSelectedParentElement: function(w) {
          return w === void 0 && (w = this.options.contentWindow.getSelection().getRangeAt(0)), e.selection.getSelectedParentElement(w);
        },
        selectAllContents: function() {
          var w = e.selection.getSelectionElement(this.options.contentWindow);
          if (w) {
            for (; w.children.length === 1; ) w = w.children[0];
            this.selectElement(w);
          }
        },
        selectElement: function(w) {
          e.selection.selectNode(w, this.options.ownerDocument);
          var O = e.selection.getSelectionElement(this.options.contentWindow);
          O && this.events.focusElement(O);
        },
        getFocusedElement: function() {
          var w;
          return this.elements.some(function(O) {
            return !w && O.getAttribute("data-medium-focused") && (w = O), !!w;
          }, this), w;
        },
        exportSelection: function() {
          var w = e.selection.getSelectionElement(this.options.contentWindow), O = this.elements.indexOf(w), T = null;
          return O >= 0 && (T = e.selection.exportSelection(w, this.options.ownerDocument)), T !== null && O !== 0 && (T.editableElementIndex = O), T;
        },
        saveSelection: function() {
          this.selectionState = this.exportSelection();
        },
        importSelection: function(w, O) {
          if (w) {
            var T = this.elements[w.editableElementIndex || 0];
            e.selection.importSelection(w, T, this.options.ownerDocument, O);
          }
        },
        restoreSelection: function() {
          this.importSelection(this.selectionState);
        },
        createLink: function(w) {
          var O = e.selection.getSelectionElement(this.options.contentWindow), T = {}, U;
          if (this.elements.indexOf(O) !== -1) {
            try {
              if (this.events.disableCustomEvent("editableInput"), w.url && e.util.deprecated(".url option for createLink", ".value", "6.0.0"), U = w.url || w.value, U && U.trim().length > 0) {
                var ie = this.options.contentWindow.getSelection();
                if (ie) {
                  var pe = ie.getRangeAt(0), je = pe.commonAncestorContainer, Ge, vt, dt, Nt;
                  if (pe.endContainer.nodeType === 3 && pe.startContainer.nodeType !== 3 && pe.startOffset === 0 && pe.startContainer.firstChild === pe.endContainer && (je = pe.endContainer), vt = e.util.getClosestBlockContainer(pe.startContainer), dt = e.util.getClosestBlockContainer(pe.endContainer), je.nodeType !== 3 && je.textContent.length !== 0 && vt === dt) {
                    var Ye = vt || O, N = this.options.ownerDocument.createDocumentFragment();
                    this.execAction("unlink"), Ge = this.exportSelection(), N.appendChild(Ye.cloneNode(!0)), O === Ye ? e.selection.select(this.options.ownerDocument, Ye.firstChild, 0, Ye.lastChild, Ye.lastChild.nodeType === 3 ? Ye.lastChild.nodeValue.length : Ye.lastChild.childNodes.length) : e.selection.select(this.options.ownerDocument, Ye, 0, Ye, Ye.childNodes.length);
                    var j = this.exportSelection();
                    Nt = e.util.findOrCreateMatchingTextNodes(this.options.ownerDocument, N, {
                      start: Ge.start - j.start,
                      end: Ge.end - j.start,
                      editableElementIndex: Ge.editableElementIndex
                    }), Nt.length === 0 && (N = this.options.ownerDocument.createDocumentFragment(), N.appendChild(je.cloneNode(!0)), Nt = [N.firstChild.firstChild, N.firstChild.lastChild]), e.util.createLink(this.options.ownerDocument, Nt, U.trim());
                    var G = (N.firstChild.innerHTML.match(/^\s+/) || [""])[0].length;
                    e.util.insertHTMLCommand(this.options.ownerDocument, N.firstChild.innerHTML.replace(/^\s+/, "")), Ge.start -= G, Ge.end -= G, this.importSelection(Ge);
                  } else this.options.ownerDocument.execCommand("createLink", !1, U);
                  this.options.targetBlank || w.target === "_blank" ? e.util.setTargetBlank(e.selection.getSelectionStart(this.options.ownerDocument), U) : e.util.removeTargetBlank(e.selection.getSelectionStart(this.options.ownerDocument), U), w.buttonClass && e.util.addClassToAnchors(e.selection.getSelectionStart(this.options.ownerDocument), w.buttonClass);
                }
              }
              if (this.options.targetBlank || w.target === "_blank" || w.buttonClass) {
                T = this.options.ownerDocument.createEvent("HTMLEvents"), T.initEvent("input", !0, !0, this.options.contentWindow);
                for (var Q = 0, ne = this.elements.length; Q < ne; Q += 1) this.elements[Q].dispatchEvent(T);
              }
            } finally {
              this.events.enableCustomEvent("editableInput");
            }
            this.events.triggerCustomEvent("editableInput", T, O);
          }
        },
        cleanPaste: function(w) {
          this.getExtensionByName("paste").cleanPaste(w);
        },
        pasteHTML: function(w, O) {
          this.getExtensionByName("paste").pasteHTML(w, O);
        },
        setContent: function(w, O) {
          if (O = O || 0, this.elements[O]) {
            var T = this.elements[O];
            T.innerHTML = w, this.checkContentChanged(T);
          }
        },
        getContent: function(w) {
          return w = w || 0, this.elements[w] ? this.elements[w].innerHTML.trim() : null;
        },
        checkContentChanged: function(w) {
          w = w || e.selection.getSelectionElement(this.options.contentWindow), this.events.updateInput(w, {
            target: w,
            currentTarget: w
          });
        },
        resetContent: function(w) {
          if (w) {
            var O = this.elements.indexOf(w);
            O !== -1 && this.setContent(xe[w.getAttribute("medium-editor-index")], O);
            return;
          }
          this.elements.forEach(function(T, U) {
            this.setContent(xe[T.getAttribute("medium-editor-index")], U);
          }, this);
        },
        addElements: function(w) {
          var O = c(w, this.options.ownerDocument, !0);
          if (O.length === 0) return !1;
          O.forEach(function(T) {
            T = K.call(this, T, this.id), this.elements.push(T), this.trigger("addElement", {
              target: T,
              currentTarget: T
            }, T);
          }, this);
        },
        removeElements: function(w) {
          var O = c(w, this.options.ownerDocument).map(function(T) {
            return T.getAttribute("medium-editor-textarea-id") && T.parentNode ? T.parentNode.querySelector('div[medium-editor-textarea-id="' + T.getAttribute("medium-editor-textarea-id") + '"]') : T;
          });
          this.elements = this.elements.filter(function(T) {
            return O.indexOf(T) !== -1 ? (this.events.cleanupElement(T), T.getAttribute("medium-editor-textarea-id") && h(T), this.trigger("removeElement", {
              target: T,
              currentTarget: T
            }, T), !1) : !0;
          }, this);
        }
      }, e.getEditorFromElement = function(w) {
        var O = w.getAttribute("data-medium-editor-editor-index"), T = w && w.ownerDocument && (w.ownerDocument.defaultView || w.ownerDocument.parentWindow);
        return T && T._mediumEditors && T._mediumEditors[O] ? T._mediumEditors[O] : null;
      };
    })(), (function() {
      e.prototype.defaults = {
        activeButtonClass: "medium-editor-button-active",
        buttonLabels: !1,
        delay: 0,
        disableReturn: !1,
        disableDoubleReturn: !1,
        disableExtraSpaces: !1,
        disableEditing: !1,
        autoLink: !1,
        elementsContainer: !1,
        contentWindow: window,
        ownerDocument: document,
        targetBlank: !1,
        extensions: {},
        spellcheck: !0
      };
    })(), e.parseVersionString = function(i) {
      var t = i.split("-"), r = t[0].split("."), a = t.length > 1 ? t[1] : "";
      return {
        major: parseInt(r[0], 10),
        minor: parseInt(r[1], 10),
        revision: parseInt(r[2], 10),
        preRelease: a,
        toString: function() {
          return [
            r[0],
            r[1],
            r[2]
          ].join(".") + (a ? "-" + a : "");
        }
      };
    }, e.version = e.parseVersionString.call(this, "5.23.3"), e;
  })());
})), Ar = function(o, n) {
  if (!(o instanceof n)) throw new TypeError("Cannot call a class as a function");
}, Or = /* @__PURE__ */ (function() {
  function o(n, e) {
    for (var i = 0; i < e.length; i++) {
      var t = e[i];
      t.enumerable = t.enumerable || !1, t.configurable = !0, "value" in t && (t.writable = !0), Object.defineProperty(n, t.key, t);
    }
  }
  return function(n, e, i) {
    return e && o(n.prototype, e), i && o(n, i), n;
  };
})(), Ji = /* @__PURE__ */ (function() {
  function o(n, e) {
    var i = [], t = !0, r = !1, a = void 0;
    try {
      for (var s = n[Symbol.iterator](), d; !(t = (d = s.next()).done) && (i.push(d.value), !(e && i.length === e)); t = !0)
        ;
    } catch (l) {
      r = !0, a = l;
    } finally {
      try {
        !t && s.return && s.return();
      } finally {
        if (r) throw a;
      }
    }
    return i;
  }
  return function(n, e) {
    if (Array.isArray(n)) return n;
    if (Symbol.iterator in Object(n)) return o(n, e);
    throw new TypeError("Invalid attempt to destructure non-iterable instance");
  };
})();
String.prototype.startsWith = String.prototype.startsWith || function(o) {
  return this.indexOf(o) === 0;
};
String.prototype.padStart = String.prototype.padStart || function(o, n) {
  for (var e = this; e.length < o; ) e = n + e;
  return e;
};
var Qd = {
  cb: "0f8ff",
  tqw: "aebd7",
  q: "-ffff",
  qmrn: "7fffd4",
  zr: "0ffff",
  bg: "5f5dc",
  bsq: "e4c4",
  bck: "---",
  nch: "ebcd",
  b: "--ff",
  bvt: "8a2be2",
  brwn: "a52a2a",
  brw: "deb887",
  ctb: "5f9ea0",
  hrt: "7fff-",
  chcT: "d2691e",
  cr: "7f50",
  rnw: "6495ed",
  crns: "8dc",
  crms: "dc143c",
  cn: "-ffff",
  Db: "--8b",
  Dcn: "-8b8b",
  Dgnr: "b8860b",
  Dgr: "a9a9a9",
  Dgrn: "-64-",
  Dkhk: "bdb76b",
  Dmgn: "8b-8b",
  Dvgr: "556b2f",
  Drng: "8c-",
  Drch: "9932cc",
  Dr: "8b--",
  Dsmn: "e9967a",
  Dsgr: "8fbc8f",
  DsTb: "483d8b",
  DsTg: "2f4f4f",
  Dtrq: "-ced1",
  Dvt: "94-d3",
  ppnk: "1493",
  pskb: "-bfff",
  mgr: "696969",
  grb: "1e90ff",
  rbrc: "b22222",
  rwht: "af0",
  stg: "228b22",
  chs: "-ff",
  gnsb: "dcdcdc",
  st: "8f8ff",
  g: "d7-",
  gnr: "daa520",
  gr: "808080",
  grn: "-8-0",
  grnw: "adff2f",
  hnw: "0fff0",
  htpn: "69b4",
  nnr: "cd5c5c",
  ng: "4b-82",
  vr: "0",
  khk: "0e68c",
  vnr: "e6e6fa",
  nrb: "0f5",
  wngr: "7cfc-",
  mnch: "acd",
  Lb: "add8e6",
  Lcr: "08080",
  Lcn: "e0ffff",
  Lgnr: "afad2",
  Lgr: "d3d3d3",
  Lgrn: "90ee90",
  Lpnk: "b6c1",
  Lsmn: "a07a",
  Lsgr: "20b2aa",
  Lskb: "87cefa",
  LsTg: "778899",
  Lstb: "b0c4de",
  Lw: "e0",
  m: "-ff-",
  mgrn: "32cd32",
  nn: "af0e6",
  mgnt: "-ff",
  mrn: "8--0",
  mqm: "66cdaa",
  mmb: "--cd",
  mmrc: "ba55d3",
  mmpr: "9370db",
  msg: "3cb371",
  mmsT: "7b68ee",
  "": "-fa9a",
  mtr: "48d1cc",
  mmvt: "c71585",
  mnLb: "191970",
  ntc: "5fffa",
  mstr: "e4e1",
  mccs: "e4b5",
  vjw: "dead",
  nv: "--80",
  c: "df5e6",
  v: "808-0",
  vrb: "6b8e23",
  rng: "a5-",
  rngr: "45-",
  rch: "da70d6",
  pgnr: "eee8aa",
  pgrn: "98fb98",
  ptrq: "afeeee",
  pvtr: "db7093",
  ppwh: "efd5",
  pchp: "dab9",
  pr: "cd853f",
  pnk: "c0cb",
  pm: "dda0dd",
  pwrb: "b0e0e6",
  prp: "8-080",
  cc: "663399",
  r: "--",
  sbr: "bc8f8f",
  rb: "4169e1",
  sbrw: "8b4513",
  smn: "a8072",
  nbr: "4a460",
  sgrn: "2e8b57",
  ssh: "5ee",
  snn: "a0522d",
  svr: "c0c0c0",
  skb: "87ceeb",
  sTb: "6a5acd",
  sTgr: "708090",
  snw: "afa",
  n: "-ff7f",
  stb: "4682b4",
  tn: "d2b48c",
  t: "-8080",
  thst: "d8bfd8",
  tmT: "6347",
  trqs: "40e0d0",
  vt: "ee82ee",
  whT: "5deb3",
  wht: "",
  hts: "5f5f5",
  w: "-",
  wgrn: "9acd32"
};
function Oo(o) {
  var n = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : 1;
  return (n > 0 ? o.toFixed(n).replace(/0+$/, "").replace(/\.$/, "") : o.toString()) || "0";
}
var Zd = (function() {
  function o(n, e, i, t) {
    Ar(this, o);
    var r = this;
    function a(d) {
      if (d.startsWith("hsl")) {
        var l = Ji(d.match(/([\-\d\.e]+)/g).map(Number), 4), u = l[0], c = l[1], h = l[2], f = l[3];
        f === void 0 && (f = 1), u /= 360, c /= 100, h /= 100, r.hsla = [
          u,
          c,
          h,
          f
        ];
      } else if (d.startsWith("rgb")) {
        var p = Ji(d.match(/([\-\d\.e]+)/g).map(Number), 4), v = p[0], g = p[1], b = p[2], _ = p[3];
        _ === void 0 && (_ = 1), r.rgba = [
          v,
          g,
          b,
          _
        ];
      } else d.startsWith("#") ? r.rgba = o.hexToRgb(d) : r.rgba = o.nameToRgb(d) || o.hexToRgb(d);
    }
    if (n !== void 0) if (Array.isArray(n)) this.rgba = n;
    else if (i === void 0) {
      var s = n && "" + n;
      s && a(s.toLowerCase());
    } else this.rgba = [
      n,
      e,
      i,
      t === void 0 ? 1 : t
    ];
  }
  return Or(o, [
    {
      key: "printRGB",
      value: function(e) {
        var i = (e ? this.rgba : this.rgba.slice(0, 3)).map(function(t, r) {
          return Oo(t, r === 3 ? 3 : 0);
        });
        return e ? "rgba(" + i + ")" : "rgb(" + i + ")";
      }
    },
    {
      key: "printHSL",
      value: function(e) {
        var i = [
          360,
          100,
          100,
          1
        ], t = [
          "",
          "%",
          "%",
          ""
        ], r = (e ? this.hsla : this.hsla.slice(0, 3)).map(function(a, s) {
          return Oo(a * i[s], s === 3 ? 3 : 1) + t[s];
        });
        return e ? "hsla(" + r + ")" : "hsl(" + r + ")";
      }
    },
    {
      key: "printHex",
      value: function(e) {
        var i = this.hex;
        return e ? i : i.substring(0, 7);
      }
    },
    {
      key: "rgba",
      get: function() {
        if (this._rgba) return this._rgba;
        if (!this._hsla) throw new Error("No color is set");
        return this._rgba = o.hslToRgb(this._hsla);
      },
      set: function(e) {
        e.length === 3 && (e[3] = 1), this._rgba = e, this._hsla = null;
      }
    },
    {
      key: "rgbString",
      get: function() {
        return this.printRGB();
      }
    },
    {
      key: "rgbaString",
      get: function() {
        return this.printRGB(!0);
      }
    },
    {
      key: "hsla",
      get: function() {
        if (this._hsla) return this._hsla;
        if (!this._rgba) throw new Error("No color is set");
        return this._hsla = o.rgbToHsl(this._rgba);
      },
      set: function(e) {
        e.length === 3 && (e[3] = 1), this._hsla = e, this._rgba = null;
      }
    },
    {
      key: "hslString",
      get: function() {
        return this.printHSL();
      }
    },
    {
      key: "hslaString",
      get: function() {
        return this.printHSL(!0);
      }
    },
    {
      key: "hex",
      get: function() {
        return "#" + this.rgba.map(function(e, i) {
          return i < 3 ? e.toString(16) : Math.round(e * 255).toString(16);
        }).map(function(e) {
          return e.padStart(2, "0");
        }).join("");
      },
      set: function(e) {
        this.rgba = o.hexToRgb(e);
      }
    }
  ], [
    {
      key: "hexToRgb",
      value: function(e) {
        var i = (e.startsWith("#") ? e.slice(1) : e).replace(/^(\w{3})$/, "$1F").replace(/^(\w)(\w)(\w)(\w)$/, "$1$1$2$2$3$3$4$4").replace(/^(\w{6})$/, "$1FF");
        if (!i.match(/^([0-9a-fA-F]{8})$/)) throw new Error("Unknown hex color; " + e);
        var t = i.match(/^(\w\w)(\w\w)(\w\w)(\w\w)$/).slice(1).map(function(r) {
          return parseInt(r, 16);
        });
        return t[3] = t[3] / 255, t;
      }
    },
    {
      key: "nameToRgb",
      value: function(e) {
        var i = Qd[e.toLowerCase().replace("at", "T").replace(/[aeiouyldf]/g, "").replace("ght", "L").replace("rk", "D").slice(-5, 4)];
        return i === void 0 ? i : o.hexToRgb(i.replace(/\-/g, "00").padStart(6, "f"));
      }
    },
    {
      key: "rgbToHsl",
      value: function(e) {
        var i = Ji(e, 4), t = i[0], r = i[1], a = i[2], s = i[3];
        t /= 255, r /= 255, a /= 255;
        var d = Math.max(t, r, a), l = Math.min(t, r, a), u = void 0, c = void 0, h = (d + l) / 2;
        if (d === l) u = c = 0;
        else {
          var f = d - l;
          switch (c = h > 0.5 ? f / (2 - d - l) : f / (d + l), d) {
            case t:
              u = (r - a) / f + (r < a ? 6 : 0);
              break;
            case r:
              u = (a - t) / f + 2;
              break;
            case a:
              u = (t - r) / f + 4;
          }
          u /= 6;
        }
        return [
          u,
          c,
          h,
          s
        ];
      }
    },
    {
      key: "hslToRgb",
      value: function(e) {
        var i = Ji(e, 4), t = i[0], r = i[1], a = i[2], s = i[3], d = void 0, l = void 0, u = void 0;
        if (r === 0) d = l = u = a;
        else {
          var c = function(g, b, _) {
            return _ < 0 && (_ += 1), _ > 1 && (_ -= 1), _ < 0.16666666666666666 ? g + (b - g) * 6 * _ : _ < 0.5 ? b : _ < 0.6666666666666666 ? g + (b - g) * (0.6666666666666666 - _) * 6 : g;
          }, h = a < 0.5 ? a * (1 + r) : a + r - a * r, f = 2 * a - h;
          d = c(f, h, t + 1 / 3), l = c(f, h, t), u = c(f, h, t - 1 / 3);
        }
        var p = [
          d * 255,
          l * 255,
          u * 255
        ].map(Math.round);
        return p[3] = s, p;
      }
    }
  ]), o;
})(), Jd = (function() {
  function o() {
    Ar(this, o), this._events = [];
  }
  return Or(o, [
    {
      key: "add",
      value: function(e, i, t) {
        e.addEventListener(i, t, !1), this._events.push({
          target: e,
          type: i,
          handler: t
        });
      }
    },
    {
      key: "remove",
      value: function(e, i, t) {
        this._events = this._events.filter(function(r) {
          var a = !0;
          return e && e !== r.target && (a = !1), i && i !== r.type && (a = !1), t && t !== r.handler && (a = !1), a && o._doRemove(r.target, r.type, r.handler), !a;
        });
      }
    },
    {
      key: "destroy",
      value: function() {
        this._events.forEach(function(e) {
          return o._doRemove(e.target, e.type, e.handler);
        }), this._events = [];
      }
    }
  ], [{
    key: "_doRemove",
    value: function(e, i, t) {
      e.removeEventListener(i, t, !1);
    }
  }]), o;
})();
function eu(o) {
  var n = document.createElement("div");
  return n.innerHTML = o, n.firstElementChild;
}
function Kn(o, n, e) {
  var i = !1;
  function t(d, l, u) {
    return Math.max(l, Math.min(d, u));
  }
  function r(d, l, u) {
    if (u && (i = !0), !!i) {
      d.preventDefault();
      var c = n.getBoundingClientRect(), h = c.width, f = c.height, p = l.clientX, v = l.clientY, g = t(p - c.left, 0, h), b = t(v - c.top, 0, f);
      e(g / h, b / f);
    }
  }
  function a(d, l) {
    (d.buttons === void 0 ? d.which : d.buttons) === 1 ? r(d, d, l) : i = !1;
  }
  function s(d, l) {
    d.touches.length === 1 ? r(d, d.touches[0], l) : i = !1;
  }
  o.add(n, "mousedown", function(d) {
    a(d, !0);
  }), o.add(n, "touchstart", function(d) {
    s(d, !0);
  }), o.add(window, "mousemove", a), o.add(n, "touchmove", s), o.add(window, "mouseup", function(d) {
    i = !1;
  }), o.add(n, "touchend", function(d) {
    i = !1;
  }), o.add(n, "touchcancel", function(d) {
    i = !1;
  });
}
var tu = `linear-gradient(45deg, lightgrey 25%, transparent 25%, transparent 75%, lightgrey 75%) 0 0 / 2em 2em,
                   linear-gradient(45deg, lightgrey 25%,       white 25%,       white 75%, lightgrey 75%) 1em 1em / 2em 2em`, iu = 360, Oa = "keydown", en = "mousedown", qn = "focusin";
function Ot(o, n) {
  return (n || document).querySelector(o);
}
function Da(o) {
  o.preventDefault(), o.stopPropagation();
}
function Qn(o, n, e, i, t) {
  o.add(n, Oa, function(r) {
    e.indexOf(r.key) >= 0 && (t && Da(r), i(r));
  });
}
var Pa = (function() {
  function o(n) {
    Ar(this, o), this.settings = {
      popup: "right",
      layout: "default",
      alpha: !0,
      editor: !0,
      editorFormat: "hex",
      cancelButton: !1,
      defaultColor: "#0cf"
    }, this._events = new Jd(), this.onChange = null, this.onDone = null, this.onOpen = null, this.onClose = null, this.setOptions(n);
  }
  return Or(o, [
    {
      key: "setOptions",
      value: function(e) {
        var i = this;
        if (!e) return;
        var t = this.settings;
        function r(l, u, c) {
          for (var h in l)
            c && c.indexOf(h) >= 0 || (u[h] = l[h]);
        }
        if (e instanceof HTMLElement) t.parent = e;
        else {
          t.parent && e.parent && t.parent !== e.parent && (this._events.remove(t.parent), this._popupInited = !1), r(e, t), e.onChange && (this.onChange = e.onChange), e.onDone && (this.onDone = e.onDone), e.onOpen && (this.onOpen = e.onOpen), e.onClose && (this.onClose = e.onClose);
          var a = e.color || e.colour;
          a && this._setColor(a);
        }
        var s = t.parent;
        if (s && t.popup && !this._popupInited) {
          var d = function(u) {
            return i.openHandler(u);
          };
          this._events.add(s, "click", d), Qn(this._events, s, [
            " ",
            "Spacebar",
            "Enter"
          ], d), this._popupInited = !0;
        } else e.parent && !t.popup && this.show();
      }
    },
    {
      key: "openHandler",
      value: function(e) {
        if (this.show()) {
          e && e.preventDefault(), this.settings.parent.style.pointerEvents = "none";
          var i = e && e.type === Oa ? this._domEdit : this.domElement;
          setTimeout(function() {
            return i.focus();
          }, 100), this.onOpen && this.onOpen(this.colour);
        }
      }
    },
    {
      key: "closeHandler",
      value: function(e) {
        var i = e && e.type, t = !1;
        if (!e) t = !0;
        else if (i === en || i === qn) {
          var r = (this.__containedEvent || 0) + 100;
          e.timeStamp > r && (t = !0);
        } else
          Da(e), t = !0;
        t && this.hide() && (this.settings.parent.style.pointerEvents = "", i !== en && this.settings.parent.focus(), this.onClose && this.onClose(this.colour));
      }
    },
    {
      key: "movePopup",
      value: function(e, i) {
        this.closeHandler(), this.setOptions(e), i && this.openHandler();
      }
    },
    {
      key: "setColor",
      value: function(e, i) {
        this._setColor(e, { silent: i });
      }
    },
    {
      key: "_setColor",
      value: function(e, i) {
        if (typeof e == "string" && (e = e.trim()), !!e) {
          i = i || {};
          var t = void 0;
          try {
            t = new Zd(e);
          } catch (a) {
            if (i.failSilently) return;
            throw a;
          }
          if (!this.settings.alpha) {
            var r = t.hsla;
            r[3] = 1, t.hsla = r;
          }
          this.colour = this.color = t, this._setHSLA(null, null, null, null, i);
        }
      }
    },
    {
      key: "setColour",
      value: function(e, i) {
        this.setColor(e, i);
      }
    },
    {
      key: "show",
      value: function() {
        if (!this.settings.parent) return !1;
        if (this.domElement) {
          var e = this._toggleDOM(!0);
          return this._setPosition(), e;
        }
        var i = eu(this.settings.template || '<div class="picker_wrapper" tabindex="-1"><div class="picker_arrow"></div><div class="picker_hue picker_slider"><div class="picker_selector"></div></div><div class="picker_sl"><div class="picker_selector"></div></div><div class="picker_alpha picker_slider"><div class="picker_selector"></div></div><div class="picker_editor"><input aria-label="Type a color name or hex value"/></div><div class="picker_sample"></div><div class="picker_done"><button>Ok</button></div><div class="picker_cancel"><button>Cancel</button></div></div>');
        return this.domElement = i, this._domH = Ot(".picker_hue", i), this._domSL = Ot(".picker_sl", i), this._domA = Ot(".picker_alpha", i), this._domEdit = Ot(".picker_editor input", i), this._domSample = Ot(".picker_sample", i), this._domOkay = Ot(".picker_done button", i), this._domCancel = Ot(".picker_cancel button", i), i.classList.add("layout_" + this.settings.layout), this.settings.alpha || i.classList.add("no_alpha"), this.settings.editor || i.classList.add("no_editor"), this.settings.cancelButton || i.classList.add("no_cancel"), this._ifPopup(function() {
          return i.classList.add("popup");
        }), this._setPosition(), this.colour ? this._updateUI() : this._setColor(this.settings.defaultColor), this._bindEvents(), !0;
      }
    },
    {
      key: "hide",
      value: function() {
        return this._toggleDOM(!1);
      }
    },
    {
      key: "destroy",
      value: function() {
        this._events.destroy(), this.domElement && this.settings.parent.removeChild(this.domElement);
      }
    },
    {
      key: "_bindEvents",
      value: function() {
        var e = this, i = this, t = this.domElement, r = this._events;
        function a(l, u, c) {
          r.add(l, u, c);
        }
        a(t, "click", function(l) {
          return l.preventDefault();
        }), Kn(r, this._domH, function(l, u) {
          return i._setHSLA(l);
        }), Kn(r, this._domSL, function(l, u) {
          return i._setHSLA(null, l, 1 - u);
        }), this.settings.alpha && Kn(r, this._domA, function(l, u) {
          return i._setHSLA(null, null, null, 1 - u);
        });
        var s = this._domEdit;
        a(s, "input", function(l) {
          i._setColor(this.value, {
            fromEditor: !0,
            failSilently: !0
          });
        }), a(s, "focus", function(l) {
          var u = this;
          u.selectionStart === u.selectionEnd && u.select();
        }), this._ifPopup(function() {
          var l = function(h) {
            return e.closeHandler(h);
          };
          a(window, en, l), a(window, qn, l), Qn(r, t, ["Esc", "Escape"], l);
          var u = function(h) {
            e.__containedEvent = h.timeStamp;
          };
          a(t, en, u), a(t, qn, u), a(e._domCancel, "click", l);
        });
        var d = function(u) {
          e._ifPopup(function() {
            return e.closeHandler(u);
          }), e.onDone && e.onDone(e.colour);
        };
        a(this._domOkay, "click", d), Qn(r, t, ["Enter"], d);
      }
    },
    {
      key: "_setPosition",
      value: function() {
        var e = this.settings.parent, i = this.domElement;
        e !== i.parentNode && e.appendChild(i), this._ifPopup(function(t) {
          getComputedStyle(e).position === "static" && (e.style.position = "relative");
          var r = t === !0 ? "popup_right" : "popup_" + t;
          [
            "popup_top",
            "popup_bottom",
            "popup_left",
            "popup_right"
          ].forEach(function(a) {
            a === r ? i.classList.add(a) : i.classList.remove(a);
          }), i.classList.add(r);
        });
      }
    },
    {
      key: "_setHSLA",
      value: function(e, i, t, r, a) {
        a = a || {};
        var s = this.colour, d = s.hsla;
        [
          e,
          i,
          t,
          r
        ].forEach(function(l, u) {
          (l || l === 0) && (d[u] = l);
        }), s.hsla = d, this._updateUI(a), this.onChange && !a.silent && this.onChange(s);
      }
    },
    {
      key: "_updateUI",
      value: function(e) {
        if (!this.domElement) return;
        e = e || {};
        var i = this.colour, t = i.hsla, r = "hsl(" + t[0] * iu + ", 100%, 50%)", a = i.hslString, s = i.hslaString, d = this._domH, l = this._domSL, u = this._domA, c = Ot(".picker_selector", d), h = Ot(".picker_selector", l), f = Ot(".picker_selector", u);
        function p(W, B, K) {
          B.style.left = K * 100 + "%";
        }
        function v(W, B, K) {
          B.style.top = K * 100 + "%";
        }
        p(d, c, t[0]), this._domSL.style.backgroundColor = this._domH.style.color = r, p(l, h, t[1]), v(l, h, 1 - t[2]), l.style.color = a, v(u, f, 1 - t[3]);
        var g = a, b = "linear-gradient(" + [g, g.replace("hsl", "hsla").replace(")", ", 0)")] + ")";
        if (this._domA.style.background = b + ", " + tu, !e.fromEditor) {
          var _ = this.settings.editorFormat, D = this.settings.alpha, L = void 0;
          switch (_) {
            case "rgb":
              L = i.printRGB(D);
              break;
            case "hsl":
              L = i.printHSL(D);
              break;
            default:
              L = i.printHex(D);
          }
          this._domEdit.value = L;
        }
        this._domSample.style.color = s;
      }
    },
    {
      key: "_ifPopup",
      value: function(e, i) {
        this.settings.parent && this.settings.popup ? e && e(this.settings.popup) : i && i();
      }
    },
    {
      key: "_toggleDOM",
      value: function(e) {
        var i = this.domElement;
        if (!i) return !1;
        var t = e ? "" : "none", r = i.style.display !== t;
        return r && (i.style.display = t), r;
      }
    }
  ]), o;
})(), Dr = document.createElement("style");
Dr.textContent = '.picker_wrapper.no_alpha .picker_alpha{display:none}.picker_wrapper.no_editor .picker_editor{position:absolute;z-index:-1;opacity:0}.picker_wrapper.no_cancel .picker_cancel{display:none}.layout_default.picker_wrapper{display:flex;flex-flow:row wrap;justify-content:space-between;align-items:stretch;font-size:10px;width:25em;padding:.5em}.layout_default.picker_wrapper input,.layout_default.picker_wrapper button{font-size:1rem}.layout_default.picker_wrapper>*{margin:.5em}.layout_default.picker_wrapper::before{content:"";display:block;width:100%;height:0;order:1}.layout_default .picker_slider,.layout_default .picker_selector{padding:1em}.layout_default .picker_hue{width:100%}.layout_default .picker_sl{flex:1 1 auto}.layout_default .picker_sl::before{content:"";display:block;padding-bottom:100%}.layout_default .picker_editor{order:1;width:6.5rem}.layout_default .picker_editor input{width:100%;height:100%}.layout_default .picker_sample{order:1;flex:1 1 auto}.layout_default .picker_done,.layout_default .picker_cancel{order:1}.picker_wrapper{box-sizing:border-box;background:#f2f2f2;box-shadow:0 0 0 1px silver;cursor:default;font-family:sans-serif;color:#444;pointer-events:auto}.picker_wrapper:focus{outline:none}.picker_wrapper button,.picker_wrapper input{box-sizing:border-box;border:none;box-shadow:0 0 0 1px silver;outline:none}.picker_wrapper button:focus,.picker_wrapper button:active,.picker_wrapper input:focus,.picker_wrapper input:active{box-shadow:0 0 2px 1px #1e90ff}.picker_wrapper button{padding:.4em .6em;cursor:pointer;background-color:#f5f5f5;background-image:linear-gradient(0deg, gainsboro, transparent)}.picker_wrapper button:active{background-image:linear-gradient(0deg, transparent, gainsboro)}.picker_wrapper button:hover{background-color:#fff}.picker_selector{position:absolute;z-index:1;display:block;-webkit-transform:translate(-50%, -50%);transform:translate(-50%, -50%);border:2px solid #fff;border-radius:100%;box-shadow:0 0 3px 1px #67b9ff;background:currentColor;cursor:pointer}.picker_slider .picker_selector{border-radius:2px}.picker_hue{position:relative;background-image:linear-gradient(90deg, red, yellow, lime, cyan, blue, magenta, red);box-shadow:0 0 0 1px silver}.picker_sl{position:relative;box-shadow:0 0 0 1px silver;background-image:linear-gradient(180deg, white, rgba(255, 255, 255, 0) 50%),linear-gradient(0deg, black, rgba(0, 0, 0, 0) 50%),linear-gradient(90deg, #808080, rgba(128, 128, 128, 0))}.picker_alpha,.picker_sample{position:relative;background:linear-gradient(45deg, lightgrey 25%, transparent 25%, transparent 75%, lightgrey 75%) 0 0/2em 2em,linear-gradient(45deg, lightgrey 25%, white 25%, white 75%, lightgrey 75%) 1em 1em/2em 2em;box-shadow:0 0 0 1px silver}.picker_alpha .picker_selector,.picker_sample .picker_selector{background:none}.picker_editor input{font-family:monospace;padding:.2em .4em}.picker_sample::before{content:"";position:absolute;display:block;width:100%;height:100%;background:currentColor}.picker_arrow{position:absolute;z-index:-1}.picker_wrapper.popup{position:absolute;z-index:2;margin:1.5em}.picker_wrapper.popup,.picker_wrapper.popup .picker_arrow::before,.picker_wrapper.popup .picker_arrow::after{background:#f2f2f2;box-shadow:0 0 10px 1px rgba(0,0,0,.4)}.picker_wrapper.popup .picker_arrow{width:3em;height:3em;margin:0}.picker_wrapper.popup .picker_arrow::before,.picker_wrapper.popup .picker_arrow::after{content:"";display:block;position:absolute;top:0;left:0;z-index:-99}.picker_wrapper.popup .picker_arrow::before{width:100%;height:100%;-webkit-transform:skew(45deg);transform:skew(45deg);-webkit-transform-origin:0 100%;transform-origin:0 100%}.picker_wrapper.popup .picker_arrow::after{width:150%;height:150%;box-shadow:none}.popup.popup_top{bottom:100%;left:0}.popup.popup_top .picker_arrow{bottom:0;left:0;-webkit-transform:rotate(-90deg);transform:rotate(-90deg)}.popup.popup_bottom{top:100%;left:0}.popup.popup_bottom .picker_arrow{top:0;left:0;-webkit-transform:rotate(90deg) scale(1, -1);transform:rotate(90deg) scale(1, -1)}.popup.popup_left{top:0;right:100%}.popup.popup_left .picker_arrow{top:0;right:0;-webkit-transform:scale(-1, 1);transform:scale(-1, 1)}.popup.popup_right{top:0;left:100%}.popup.popup_right .picker_arrow{top:0;left:0}';
document.documentElement.firstElementChild.appendChild(Dr);
Pa.StyleElement = Dr;
var Ra = /* @__PURE__ */ br(((o, n) => {
  (function(e, i) {
    typeof define == "function" && define.amd ? define(e) : typeof n != "undefined" && typeof o == "object" ? n.exports = e() : i.rangy = e();
  })(function() {
    var e = "object", i = "function", t = "undefined", r = [
      "startContainer",
      "startOffset",
      "endContainer",
      "endOffset",
      "collapsed",
      "commonAncestorContainer"
    ], a = [
      "setStart",
      "setStartBefore",
      "setStartAfter",
      "setEnd",
      "setEndBefore",
      "setEndAfter",
      "collapse",
      "selectNode",
      "selectNodeContents",
      "compareBoundaryPoints",
      "deleteContents",
      "extractContents",
      "cloneContents",
      "insertNode",
      "surroundContents",
      "cloneRange",
      "toString",
      "detach"
    ], s = [
      "boundingHeight",
      "boundingLeft",
      "boundingTop",
      "boundingWidth",
      "htmlText",
      "text"
    ], d = [
      "collapse",
      "compareEndPoints",
      "duplicate",
      "moveToElementText",
      "parentElement",
      "select",
      "setEndPoint",
      "getBoundingClientRect"
    ];
    function l(N, j) {
      var G = typeof N[j];
      return G == i || !!(G == e && N[j]) || G == "unknown";
    }
    function u(N, j) {
      return !!(typeof N[j] == e && N[j]);
    }
    function c(N, j) {
      return typeof N[j] != t;
    }
    function h(N) {
      return function(j, G) {
        for (var Q = G.length; Q--; ) if (!N(j, G[Q])) return !1;
        return !0;
      };
    }
    var f = h(l), p = h(u), v = h(c);
    function g(N) {
      return N && f(N, d) && v(N, s);
    }
    function b(N) {
      return u(N, "body") ? N.body : N.getElementsByTagName("body")[0];
    }
    var _ = [].forEach ? function(N, j) {
      N.forEach(j);
    } : function(N, j) {
      for (var G = 0, Q = N.length; G < Q; ++G) j(N[G], G);
    }, D = {}, L = typeof window != t && typeof document != t, W = {
      isHostMethod: l,
      isHostObject: u,
      isHostProperty: c,
      areHostMethods: f,
      areHostObjects: p,
      areHostProperties: v,
      isTextRange: g,
      getBody: b,
      forEach: _
    }, B = {
      version: "1.3.2",
      initialized: !1,
      isBrowser: L,
      supported: !0,
      util: W,
      features: {},
      modules: D,
      config: {
        alertOnFail: !1,
        alertOnWarn: !1,
        preferTextRange: !1,
        autoInitialize: typeof rangyAutoInitialize == t ? !0 : rangyAutoInitialize
      }
    };
    function K(N) {
      typeof console != t && l(console, "log");
    }
    function Y(N, j) {
      L && j ? alert(N) : K(N);
    }
    function te(N) {
      B.initialized = !0, B.supported = !1, Y("Rangy is not supported in this environment. Reason: " + N, B.config.alertOnFail);
    }
    B.fail = te;
    function se(N) {
      Y("Rangy warning: " + N, B.config.alertOnWarn);
    }
    B.warn = se;
    var Le;
    ({}).hasOwnProperty ? (W.extend = Le = function(N, j, G) {
      var Q, ne;
      for (var ce in j)
        ce === "__proto__" || ce === "constructor" || ce === "prototype" || j.hasOwnProperty(ce) && (Q = N[ce], ne = j[ce], G && Q !== null && typeof Q == "object" && ne !== null && typeof ne == "object" && Le(Q, ne, !0), N[ce] = ne);
      return j.hasOwnProperty("toString") && (N.toString = j.toString), N;
    }, W.createOptions = function(N, j) {
      var G = {};
      return Le(G, j), N && Le(G, N), G;
    }) : te("hasOwnProperty not supported"), L || te("Rangy can only run in a browser"), (function() {
      var N;
      if (L) {
        var j = document.createElement("div");
        j.appendChild(document.createElement("span"));
        var G = [].slice;
        try {
          G.call(j.childNodes, 0)[0].nodeType == 1 && (N = function(Q) {
            return G.call(Q, 0);
          });
        } catch (Q) {
        }
      }
      N || (N = function(Q) {
        for (var ne = [], ce = 0, ge = Q.length; ce < ge; ++ce) ne[ce] = Q[ce];
        return ne;
      }), W.toArray = N;
    })();
    var ze;
    L && (l(document, "addEventListener") ? ze = function(N, j, G) {
      N.addEventListener(j, G, !1);
    } : l(document, "attachEvent") ? ze = function(N, j, G) {
      N.attachEvent("on" + j, G);
    } : te("Document does not have required addEventListener or attachEvent method"), W.addListener = ze);
    var xe = [];
    function w(N) {
      return N.message || N.description || String(N);
    }
    function O() {
      if (!(!L || B.initialized)) {
        var N, j = !1, G = !1;
        l(document, "createRange") && (N = document.createRange(), f(N, a) && v(N, r) && (j = !0));
        var Q = b(document);
        if (!Q || Q.nodeName.toLowerCase() != "body") {
          te("No body element found");
          return;
        }
        if (Q && l(Q, "createTextRange") && (N = Q.createTextRange(), g(N) && (G = !0)), !j && !G) {
          te("Neither Range nor TextRange are available");
          return;
        }
        B.initialized = !0, B.features = {
          implementsDomRange: j,
          implementsTextRange: G
        };
        var ne, ce;
        for (var ge in D) (ne = D[ge]) instanceof je && ne.init(ne, B);
        for (var Ie = 0, Be = xe.length; Ie < Be; ++Ie) try {
          xe[Ie](B);
        } catch (We) {
          ce = "Rangy init listener threw an exception. Continuing. Detail: " + w(We), K(ce);
        }
      }
    }
    function T(N, j, G) {
      G && (N += " in module " + G.name), B.warn("DEPRECATED: " + N + " is deprecated. Please use " + j + " instead.");
    }
    function U(N, j, G, Q) {
      N[j] = function() {
        return T(j, G, Q), N[G].apply(N, W.toArray(arguments));
      };
    }
    W.deprecationNotice = T, W.createAliasForDeprecatedMethod = U, B.init = O, B.addInitListener = function(N) {
      B.initialized ? N(B) : xe.push(N);
    };
    var ie = [];
    B.addShimListener = function(N) {
      ie.push(N);
    };
    function pe(N) {
      N = N || window, O();
      for (var j = 0, G = ie.length; j < G; ++j) ie[j](N);
    }
    L && (B.shim = B.createMissingNativeApi = pe, U(B, "createMissingNativeApi", "shim"));
    function je(N, j, G) {
      this.name = N, this.dependencies = j, this.initialized = !1, this.supported = !1, this.initializer = G;
    }
    je.prototype = {
      init: function() {
        for (var N = this.dependencies || [], j = 0, G = N.length, Q, ne; j < G; ++j) {
          if (ne = N[j], Q = D[ne], !Q || !(Q instanceof je)) throw new Error("required module '" + ne + "' not found");
          if (Q.init(), !Q.supported) throw new Error("required module '" + ne + "' not supported");
        }
        this.initializer(this);
      },
      fail: function(N) {
        throw this.initialized = !0, this.supported = !1, new Error(N);
      },
      warn: function(N) {
        B.warn("Module " + this.name + ": " + N);
      },
      deprecationNotice: function(N, j) {
        B.warn("DEPRECATED: " + N + " in module " + this.name + " is deprecated. Please use " + j + " instead");
      },
      createError: function(N) {
        return /* @__PURE__ */ new Error("Error in Rangy " + this.name + " module: " + N);
      }
    };
    function Ge(N, j, G) {
      var Q = new je(N, j, function(ne) {
        if (!ne.initialized) {
          ne.initialized = !0;
          try {
            G(B, ne), ne.supported = !0;
          } catch (ce) {
            K("Module '" + N + "' failed to load: " + w(ce)), ce.stack && K(ce.stack);
          }
        }
      });
      return D[N] = Q, Q;
    }
    B.createModule = function(N) {
      var j, G;
      arguments.length == 2 ? (j = arguments[1], G = []) : (j = arguments[2], G = arguments[1]);
      var Q = Ge(N, G, j);
      B.initialized && B.supported && Q.init();
    }, B.createCoreModule = function(N, j, G) {
      Ge(N, j, G);
    };
    function vt() {
    }
    B.RangePrototype = vt, B.rangePrototype = new vt();
    function dt() {
    }
    B.selectionPrototype = new dt(), B.createCoreModule("DomUtil", [], function(N, j) {
      var G = "undefined", Q = N.util, ne = Q.getBody;
      Q.areHostMethods(document, [
        "createDocumentFragment",
        "createElement",
        "createTextNode"
      ]) || j.fail("document missing a Node creation method"), Q.isHostMethod(document, "getElementsByTagName") || j.fail("document missing getElementsByTagName method");
      var ce = document.createElement("div");
      Q.areHostMethods(ce, [
        "insertBefore",
        "appendChild",
        "cloneNode"
      ]) || j.fail("Incomplete Element implementation"), Q.isHostProperty(ce, "innerHTML") || j.fail("Element is missing innerHTML property");
      var ge = document.createTextNode("test");
      Q.areHostMethods(ge, [
        "splitText",
        "deleteData",
        "insertData",
        "appendData",
        "cloneNode"
      ]) || j.fail("Incomplete Text Node implementation");
      var Ie = function(P, q) {
        for (var me = P.length; me--; ) if (P[me] === q) return !0;
        return !1;
      };
      function Be(P) {
        var q;
        return typeof P.namespaceURI == G || (q = P.namespaceURI) === null || q == "http://www.w3.org/1999/xhtml";
      }
      function We(P) {
        var q = P.parentNode;
        return q.nodeType == 1 ? q : null;
      }
      function Ae(P) {
        for (var q = 0; P = P.previousSibling; ) ++q;
        return q;
      }
      function Ue(P) {
        switch (P.nodeType) {
          case 7:
          case 10:
            return 0;
          case 3:
          case 8:
            return P.length;
          default:
            return P.childNodes.length;
        }
      }
      function Ve(P, q) {
        var me = [], ue;
        for (ue = P; ue; ue = ue.parentNode) me.push(ue);
        for (ue = q; ue; ue = ue.parentNode) if (Ie(me, ue)) return ue;
        return null;
      }
      function x(P, q, me) {
        for (var ue = me ? q : q.parentNode; ue; ) {
          if (ue === P) return !0;
          ue = ue.parentNode;
        }
        return !1;
      }
      function E(P, q) {
        return x(P, q, !0);
      }
      function C(P, q, me) {
        for (var ue, ke = me ? P : P.parentNode; ke; ) {
          if (ue = ke.parentNode, ue === q) return ke;
          ke = ue;
        }
        return null;
      }
      function R(P) {
        var q = P.nodeType;
        return q == 3 || q == 4 || q == 8;
      }
      function S(P) {
        if (!P) return !1;
        var q = P.nodeType;
        return q == 3 || q == 8;
      }
      function z(P, q) {
        var me = q.nextSibling, ue = q.parentNode;
        return me ? ue.insertBefore(P, me) : ue.appendChild(P), P;
      }
      function k(P, q, me) {
        var ue = P.cloneNode(!1);
        if (ue.deleteData(0, q), P.deleteData(q, P.length - q), z(ue, P), me)
          for (var ke = 0, Oe; Oe = me[ke++]; ) Oe.node == P && Oe.offset > q ? (Oe.node = ue, Oe.offset -= q) : Oe.node == P.parentNode && Oe.offset > Ae(P) && ++Oe.offset;
        return ue;
      }
      function X(P) {
        if (P.nodeType == 9) return P;
        if (typeof P.ownerDocument != G) return P.ownerDocument;
        if (typeof P.document != G) return P.document;
        if (P.parentNode) return X(P.parentNode);
        throw j.createError("getDocument: no document found for node");
      }
      function he(P) {
        var q = X(P);
        if (typeof q.defaultView != G) return q.defaultView;
        if (typeof q.parentWindow != G) return q.parentWindow;
        throw j.createError("Cannot get a window object for node");
      }
      function ae(P) {
        if (typeof P.contentDocument != G) return P.contentDocument;
        if (typeof P.contentWindow != G) return P.contentWindow.document;
        throw j.createError("getIframeDocument: No Document object found for iframe element");
      }
      function Z(P) {
        if (typeof P.contentWindow != G) return P.contentWindow;
        if (typeof P.contentDocument != G) return P.contentDocument.defaultView;
        throw j.createError("getIframeWindow: No Window object found for iframe element");
      }
      function Ne(P) {
        return P && Q.isHostMethod(P, "setTimeout") && Q.isHostObject(P, "document");
      }
      function we(P, q, me) {
        var ue;
        if (P ? Q.isHostProperty(P, "nodeType") ? ue = P.nodeType == 1 && P.tagName.toLowerCase() == "iframe" ? ae(P) : X(P) : Ne(P) && (ue = P.document) : ue = document, !ue) throw q.createError(me + "(): Parameter must be a Window object or DOM node");
        return ue;
      }
      function _e(P) {
        for (var q; q = P.parentNode; ) P = q;
        return P;
      }
      function Ke(P, q, me, ue) {
        var ke, Oe, Tt, mt, tt;
        if (P == me) return q === ue ? 0 : q < ue ? -1 : 1;
        if (ke = C(me, P, !0)) return q <= Ae(ke) ? -1 : 1;
        if (ke = C(P, me, !0)) return Ae(ke) < ue ? -1 : 1;
        if (Oe = Ve(P, me), !Oe) throw new Error("comparePoints error: nodes have no common ancestor");
        if (Tt = P === Oe ? Oe : C(P, Oe, !0), mt = me === Oe ? Oe : C(me, Oe, !0), Tt === mt) throw j.createError("comparePoints got to case 4 and childA and childB are the same!");
        for (tt = Oe.firstChild; tt; ) {
          if (tt === Tt) return -1;
          if (tt === mt) return 1;
          tt = tt.nextSibling;
        }
      }
      var J = !1;
      function le(P) {
        try {
          return P.parentNode, !1;
        } catch (q) {
          return !0;
        }
      }
      (function() {
        var P = document.createElement("b");
        P.innerHTML = "1";
        var q = P.firstChild;
        P.innerHTML = "<br />", J = le(q), N.features.crashyTextNodes = J;
      })();
      function Te(P) {
        if (!P) return "[No node]";
        if (J && le(P)) return "[Broken node]";
        if (R(P)) return '"' + P.data + '"';
        if (P.nodeType == 1) {
          var q = P.id ? ' id="' + P.id + '"' : "";
          return "<" + P.nodeName + q + ">[index:" + Ae(P) + ",length:" + P.childNodes.length + "][" + (P.innerHTML || "[innerHTML not supported]").slice(0, 25) + "]";
        }
        return P.nodeName;
      }
      function Pe(P) {
        for (var q = X(P).createDocumentFragment(), me; me = P.firstChild; ) q.appendChild(me);
        return q;
      }
      var $e;
      typeof window.getComputedStyle != G ? $e = function(P, q) {
        return he(P).getComputedStyle(P, null)[q];
      } : typeof document.documentElement.currentStyle != G ? $e = function(P, q) {
        return P.currentStyle ? P.currentStyle[q] : "";
      } : j.fail("No means of obtaining computed style properties found");
      function gt(P, q, me) {
        var ue = ne(P), ke = P.createElement("div");
        ke.contentEditable = "" + !!me, q && (ke.innerHTML = q);
        var Oe = ue.firstChild;
        return Oe ? ue.insertBefore(ke, Oe) : ue.appendChild(ke), ke;
      }
      function et(P) {
        return P.parentNode.removeChild(P);
      }
      function qe(P) {
        this.root = P, this._next = P;
      }
      qe.prototype = {
        _current: null,
        hasNext: function() {
          return !!this._next;
        },
        next: function() {
          var P = this._current = this._next, q, me;
          if (this._current)
            if (q = P.firstChild, q) this._next = q;
            else {
              for (me = null; P !== this.root && !(me = P.nextSibling); ) P = P.parentNode;
              this._next = me;
            }
          return this._current;
        },
        detach: function() {
          this._current = this._next = this.root = null;
        }
      };
      function Qe(P) {
        return new qe(P);
      }
      function Ze(P, q) {
        this.node = P, this.offset = q;
      }
      Ze.prototype = {
        equals: function(P) {
          return !!P && this.node === P.node && this.offset == P.offset;
        },
        inspect: function() {
          return "[DomPosition(" + Te(this.node) + ":" + this.offset + ")]";
        },
        toString: function() {
          return this.inspect();
        }
      };
      function ut(P) {
        this.code = this[P], this.codeName = P, this.message = "DOMException: " + this.codeName;
      }
      ut.prototype = {
        INDEX_SIZE_ERR: 1,
        HIERARCHY_REQUEST_ERR: 3,
        WRONG_DOCUMENT_ERR: 4,
        NO_MODIFICATION_ALLOWED_ERR: 7,
        NOT_FOUND_ERR: 8,
        NOT_SUPPORTED_ERR: 9,
        INVALID_STATE_ERR: 11,
        INVALID_NODE_TYPE_ERR: 24
      }, ut.prototype.toString = function() {
        return this.message;
      }, N.dom = {
        arrayContains: Ie,
        isHtmlNamespace: Be,
        parentElement: We,
        getNodeIndex: Ae,
        getNodeLength: Ue,
        getCommonAncestor: Ve,
        isAncestorOf: x,
        isOrIsAncestorOf: E,
        getClosestAncestorIn: C,
        isCharacterDataNode: R,
        isTextOrCommentNode: S,
        insertAfter: z,
        splitDataNode: k,
        getDocument: X,
        getWindow: he,
        getIframeWindow: Z,
        getIframeDocument: ae,
        getBody: ne,
        isWindow: Ne,
        getContentDocument: we,
        getRootContainer: _e,
        comparePoints: Ke,
        isBrokenNode: le,
        inspectNode: Te,
        getComputedStyleProperty: $e,
        createTestElement: gt,
        removeNode: et,
        fragmentFromNodeChildren: Pe,
        createIterator: Qe,
        DomPosition: Ze
      }, N.DOMException = ut;
    }), B.createCoreModule("DomRange", ["DomUtil"], function(N, j) {
      var G = N.dom, Q = N.util, ne = G.DomPosition, ce = N.DOMException, ge = G.isCharacterDataNode, Ie = G.getNodeIndex, Be = G.isOrIsAncestorOf, We = G.getDocument, Ae = G.comparePoints, Ue = G.splitDataNode, Ve = G.getClosestAncestorIn, x = G.getNodeLength, E = G.arrayContains, C = G.getRootContainer, R = N.features.crashyTextNodes, S = G.removeNode;
      function z(y, A) {
        return y.nodeType != 3 && (Be(y, A.startContainer) || Be(y, A.endContainer));
      }
      function k(y) {
        return y.document || We(y.startContainer);
      }
      function X(y) {
        return C(y.startContainer);
      }
      function he(y) {
        return new ne(y.parentNode, Ie(y));
      }
      function ae(y) {
        return new ne(y.parentNode, Ie(y) + 1);
      }
      function Z(y, A, H) {
        var V = y.nodeType == 11 ? y.firstChild : y;
        return ge(A) ? H == A.length ? G.insertAfter(y, A) : A.parentNode.insertBefore(y, H == 0 ? A : Ue(A, H)) : H >= A.childNodes.length ? A.appendChild(y) : A.insertBefore(y, A.childNodes[H]), V;
      }
      function Ne(y, A, H) {
        if (De(y), De(A), k(A) != k(y)) throw new ce("WRONG_DOCUMENT_ERR");
        var V = Ae(y.startContainer, y.startOffset, A.endContainer, A.endOffset), de = Ae(y.endContainer, y.endOffset, A.startContainer, A.startOffset);
        return H ? V <= 0 && de >= 0 : V < 0 && de > 0;
      }
      function we(y) {
        for (var A, H, V = k(y.range).createDocumentFragment(), de; H = y.next(); ) {
          if (A = y.isPartiallySelectedSubtree(), H = H.cloneNode(!A), A && (de = y.getSubtreeIterator(), H.appendChild(we(de)), de.detach()), H.nodeType == 10) throw new ce("HIERARCHY_REQUEST_ERR");
          V.appendChild(H);
        }
        return V;
      }
      function _e(y, A, H) {
        var V, de;
        H = H || { stop: !1 };
        for (var Se, $; Se = y.next(); ) if (y.isPartiallySelectedSubtree()) {
          if (A(Se) === !1) {
            H.stop = !0;
            return;
          } else if ($ = y.getSubtreeIterator(), _e($, A, H), $.detach(), H.stop) return;
        } else
          for (V = G.createIterator(Se); de = V.next(); ) if (A(de) === !1) {
            H.stop = !0;
            return;
          }
      }
      function Ke(y) {
        for (var A; y.next(); ) y.isPartiallySelectedSubtree() ? (A = y.getSubtreeIterator(), Ke(A), A.detach()) : y.remove();
      }
      function J(y) {
        for (var A, H = k(y.range).createDocumentFragment(), V; A = y.next(); ) {
          if (y.isPartiallySelectedSubtree() ? (A = A.cloneNode(!1), V = y.getSubtreeIterator(), A.appendChild(J(V)), V.detach()) : y.remove(), A.nodeType == 10) throw new ce("HIERARCHY_REQUEST_ERR");
          H.appendChild(A);
        }
        return H;
      }
      function le(y, A, H) {
        var V = !!(A && A.length), de, Se = !!H;
        V && (de = new RegExp("^(" + A.join("|") + ")$"));
        var $ = [];
        return _e(new Pe(y, !1), function(re) {
          if (!(V && !de.test(re.nodeType)) && !(Se && !H(re))) {
            var fe = y.startContainer;
            if (!(re == fe && ge(fe) && y.startOffset == fe.length)) {
              var Ee = y.endContainer;
              re == Ee && ge(Ee) && y.endOffset == 0 || $.push(re);
            }
          }
        }), $;
      }
      function Te(y) {
        return "[" + (typeof y.getName == "undefined" ? "Range" : y.getName()) + "(" + G.inspectNode(y.startContainer) + ":" + y.startOffset + ", " + G.inspectNode(y.endContainer) + ":" + y.endOffset + ")]";
      }
      function Pe(y, A) {
        if (this.range = y, this.clonePartiallySelectedTextNodes = A, !y.collapsed) {
          this.sc = y.startContainer, this.so = y.startOffset, this.ec = y.endContainer, this.eo = y.endOffset;
          var H = y.commonAncestorContainer;
          this.sc === this.ec && ge(this.sc) ? (this.isSingleCharacterDataNode = !0, this._first = this._last = this._next = this.sc) : (this._first = this._next = this.sc === H && !ge(this.sc) ? this.sc.childNodes[this.so] : Ve(this.sc, H, !0), this._last = this.ec === H && !ge(this.ec) ? this.ec.childNodes[this.eo - 1] : Ve(this.ec, H, !0));
        }
      }
      Pe.prototype = {
        _current: null,
        _next: null,
        _first: null,
        _last: null,
        isSingleCharacterDataNode: !1,
        reset: function() {
          this._current = null, this._next = this._first;
        },
        hasNext: function() {
          return !!this._next;
        },
        next: function() {
          var y = this._current = this._next;
          return y && (this._next = y !== this._last ? y.nextSibling : null, ge(y) && this.clonePartiallySelectedTextNodes && (y === this.ec && (y = y.cloneNode(!0)).deleteData(this.eo, y.length - this.eo), this._current === this.sc && (y = y.cloneNode(!0)).deleteData(0, this.so))), y;
        },
        remove: function() {
          var y = this._current, A, H;
          ge(y) && (y === this.sc || y === this.ec) ? (A = y === this.sc ? this.so : 0, H = y === this.ec ? this.eo : y.length, A != H && y.deleteData(A, H - A)) : y.parentNode && S(y);
        },
        isPartiallySelectedSubtree: function() {
          var y = this._current;
          return z(y, this.range);
        },
        getSubtreeIterator: function() {
          var y;
          if (this.isSingleCharacterDataNode)
            y = this.range.cloneRange(), y.collapse(!1);
          else {
            y = new Xe(k(this.range));
            var A = this._current, H = A, V = 0, de = A, Se = x(A);
            Be(A, this.sc) && (H = this.sc, V = this.so), Be(A, this.ec) && (de = this.ec, Se = this.eo), Me(y, H, V, de, Se);
          }
          return new Pe(y, this.clonePartiallySelectedTextNodes);
        },
        detach: function() {
          this.range = this._current = this._next = this._first = this._last = this.sc = this.so = this.ec = this.eo = null;
        }
      };
      var $e = [
        1,
        3,
        4,
        5,
        7,
        8,
        10
      ], gt = [
        2,
        9,
        11
      ], et = [
        5,
        6,
        10,
        12
      ], qe = [
        1,
        3,
        4,
        5,
        7,
        8,
        10,
        11
      ], Qe = [
        1,
        3,
        4,
        5,
        7,
        8
      ];
      function Ze(y) {
        return function(A, H) {
          for (var V, de = H ? A : A.parentNode; de; ) {
            if (V = de.nodeType, E(y, V)) return de;
            de = de.parentNode;
          }
          return null;
        };
      }
      var ut = Ze([9, 11]), P = Ze(et), q = Ze([
        6,
        10,
        12
      ]), me = Ze([1]);
      function ue(y, A) {
        if (q(y, A)) throw new ce("INVALID_NODE_TYPE_ERR");
      }
      function ke(y, A) {
        if (!E(A, y.nodeType)) throw new ce("INVALID_NODE_TYPE_ERR");
      }
      function Oe(y, A) {
        if (A < 0 || A > (ge(y) ? y.length : y.childNodes.length)) throw new ce("INDEX_SIZE_ERR");
      }
      function Tt(y, A) {
        if (ut(y, !0) !== ut(A, !0)) throw new ce("WRONG_DOCUMENT_ERR");
      }
      function mt(y) {
        if (P(y, !0)) throw new ce("NO_MODIFICATION_ALLOWED_ERR");
      }
      function tt(y, A) {
        if (!y) throw new ce(A);
      }
      function Si(y, A) {
        return A <= (ge(y) ? y.length : y.childNodes.length);
      }
      function $t(y) {
        return !!y.startContainer && !!y.endContainer && !(R && (G.isBrokenNode(y.startContainer) || G.isBrokenNode(y.endContainer))) && C(y.startContainer) == C(y.endContainer) && Si(y.startContainer, y.startOffset) && Si(y.endContainer, y.endOffset);
      }
      function De(y) {
        if (!$t(y)) throw new Error("Range error: Range is not valid. This usually happens after DOM mutation. Range: (" + y.inspect() + ")");
      }
      var Ni = document.createElement("style"), Lt = !1;
      try {
        Ni.innerHTML = "<b>x</b>", Lt = Ni.firstChild.nodeType == 3;
      } catch (y) {
      }
      N.features.htmlParsingConforms = Lt;
      var Ti = Lt ? function(y) {
        var A = this.startContainer, H = We(A);
        if (!A) throw new ce("INVALID_STATE_ERR");
        var V = null;
        return A.nodeType == 1 ? V = A : ge(A) && (V = G.parentElement(A)), V === null || V.nodeName == "HTML" && G.isHtmlNamespace(We(V).documentElement) && G.isHtmlNamespace(V) ? V = H.createElement("body") : V = V.cloneNode(!1), V.innerHTML = y, G.fragmentFromNodeChildren(V);
      } : function(y) {
        var A = k(this).createElement("body");
        return A.innerHTML = y, G.fragmentFromNodeChildren(A);
      };
      function oi(y, A) {
        De(y);
        var H = y.startContainer, V = y.startOffset, de = y.endContainer, Se = y.endOffset, $ = H === de;
        ge(de) && Se > 0 && Se < de.length && Ue(de, Se, A), ge(H) && V > 0 && V < H.length && (H = Ue(H, V, A), $ ? (Se -= V, de = H) : de == H.parentNode && Se >= Ie(H) && Se++, V = 0), y.setStartAndEnd(H, V, de, Se);
      }
      function ye(y) {
        De(y);
        var A = y.commonAncestorContainer.parentNode.cloneNode(!1);
        return A.appendChild(y.cloneContents()), A.innerHTML;
      }
      var ai = [
        "startContainer",
        "startOffset",
        "endContainer",
        "endOffset",
        "collapsed",
        "commonAncestorContainer"
      ], si = 0, Xt = 1, Ki = 2, kt = 3, Yt = 0, Mi = 1, Ai = 2, li = 3;
      Q.extend(N.rangePrototype, {
        compareBoundaryPoints: function(y, A) {
          De(this), Tt(this.startContainer, A.startContainer);
          var H, V, de, Se, $ = y == kt || y == si ? "start" : "end", re = y == Xt || y == si ? "start" : "end";
          return H = this[$ + "Container"], V = this[$ + "Offset"], de = A[re + "Container"], Se = A[re + "Offset"], Ae(H, V, de, Se);
        },
        insertNode: function(y) {
          if (De(this), ke(y, qe), mt(this.startContainer), Be(y, this.startContainer)) throw new ce("HIERARCHY_REQUEST_ERR");
          var A = Z(y, this.startContainer, this.startOffset);
          this.setStartBefore(A);
        },
        cloneContents: function() {
          De(this);
          var y, A;
          if (this.collapsed) return k(this).createDocumentFragment();
          if (this.startContainer === this.endContainer && ge(this.startContainer))
            return y = this.startContainer.cloneNode(!0), y.data = y.data.slice(this.startOffset, this.endOffset), A = k(this).createDocumentFragment(), A.appendChild(y), A;
          var H = new Pe(this, !0);
          return y = we(H), H.detach(), y;
        },
        canSurroundContents: function() {
          De(this), mt(this.startContainer), mt(this.endContainer);
          var y = new Pe(this, !0), A = y._first && z(y._first, this) || y._last && z(y._last, this);
          return y.detach(), !A;
        },
        surroundContents: function(y) {
          if (ke(y, Qe), !this.canSurroundContents()) throw new ce("INVALID_STATE_ERR");
          var A = this.extractContents();
          if (y.hasChildNodes()) for (; y.lastChild; ) y.removeChild(y.lastChild);
          Z(y, this.startContainer, this.startOffset), y.appendChild(A), this.selectNode(y);
        },
        cloneRange: function() {
          De(this);
          for (var y = new Xe(k(this)), A = ai.length, H; A--; )
            H = ai[A], y[H] = this[H];
          return y;
        },
        toString: function() {
          De(this);
          var y = this.startContainer;
          if (y === this.endContainer && ge(y)) return y.nodeType == 3 || y.nodeType == 4 ? y.data.slice(this.startOffset, this.endOffset) : "";
          var A = [], H = new Pe(this, !0);
          return _e(H, function(V) {
            (V.nodeType == 3 || V.nodeType == 4) && A.push(V.data);
          }), H.detach(), A.join("");
        },
        compareNode: function(y) {
          De(this);
          var A = y.parentNode, H = Ie(y);
          if (!A) throw new ce("NOT_FOUND_ERR");
          var V = this.comparePoint(A, H), de = this.comparePoint(A, H + 1);
          return V < 0 ? de > 0 ? Ai : Yt : de > 0 ? Mi : li;
        },
        comparePoint: function(y, A) {
          return De(this), tt(y, "HIERARCHY_REQUEST_ERR"), Tt(y, this.startContainer), Ae(y, A, this.startContainer, this.startOffset) < 0 ? -1 : Ae(y, A, this.endContainer, this.endOffset) > 0 ? 1 : 0;
        },
        createContextualFragment: Ti,
        toHtml: function() {
          return ye(this);
        },
        intersectsNode: function(y, A) {
          if (De(this), C(y) != X(this)) return !1;
          var H = y.parentNode, V = Ie(y);
          if (!H) return !0;
          var de = Ae(H, V, this.endContainer, this.endOffset), Se = Ae(H, V + 1, this.startContainer, this.startOffset);
          return A ? de <= 0 && Se >= 0 : de < 0 && Se > 0;
        },
        isPointInRange: function(y, A) {
          return De(this), tt(y, "HIERARCHY_REQUEST_ERR"), Tt(y, this.startContainer), Ae(y, A, this.startContainer, this.startOffset) >= 0 && Ae(y, A, this.endContainer, this.endOffset) <= 0;
        },
        intersectsRange: function(y) {
          return Ne(this, y, !1);
        },
        intersectsOrTouchesRange: function(y) {
          return Ne(this, y, !0);
        },
        intersection: function(y) {
          if (this.intersectsRange(y)) {
            var A = Ae(this.startContainer, this.startOffset, y.startContainer, y.startOffset), H = Ae(this.endContainer, this.endOffset, y.endContainer, y.endOffset), V = this.cloneRange();
            return A == -1 && V.setStart(y.startContainer, y.startOffset), H == 1 && V.setEnd(y.endContainer, y.endOffset), V;
          }
          return null;
        },
        union: function(y) {
          if (this.intersectsOrTouchesRange(y)) {
            var A = this.cloneRange();
            return Ae(y.startContainer, y.startOffset, this.startContainer, this.startOffset) == -1 && A.setStart(y.startContainer, y.startOffset), Ae(y.endContainer, y.endOffset, this.endContainer, this.endOffset) == 1 && A.setEnd(y.endContainer, y.endOffset), A;
          } else throw new ce("Ranges do not intersect");
        },
        containsNode: function(y, A) {
          return A ? this.intersectsNode(y, !1) : this.compareNode(y) == li;
        },
        containsNodeContents: function(y) {
          return this.comparePoint(y, 0) >= 0 && this.comparePoint(y, x(y)) <= 0;
        },
        containsRange: function(y) {
          var A = this.intersection(y);
          return A !== null && y.equals(A);
        },
        containsNodeText: function(y) {
          var A = this.cloneRange();
          A.selectNode(y);
          var H = A.getNodes([3]);
          if (H.length > 0) {
            A.setStart(H[0], 0);
            var V = H.pop();
            return A.setEnd(V, V.length), this.containsRange(A);
          } else return this.containsNodeContents(y);
        },
        getNodes: function(y, A) {
          return De(this), le(this, y, A);
        },
        getDocument: function() {
          return k(this);
        },
        collapseBefore: function(y) {
          this.setEndBefore(y), this.collapse(!1);
        },
        collapseAfter: function(y) {
          this.setStartAfter(y), this.collapse(!0);
        },
        getBookmark: function(y) {
          var A = k(this), H = N.createRange(A);
          y = y || G.getBody(A), H.selectNodeContents(y);
          var V = this.intersection(H), de = 0, Se = 0;
          return V && (H.setEnd(V.startContainer, V.startOffset), de = H.toString().length, Se = de + V.toString().length), {
            start: de,
            end: Se,
            containerNode: y
          };
        },
        moveToBookmark: function(y) {
          var A = y.containerNode, H = 0;
          this.setStart(A, 0), this.collapse(!0);
          for (var V = [A], de, Se = !1, $ = !1, re, fe, Ee; !$ && (de = V.pop()); ) if (de.nodeType == 3)
            re = H + de.length, !Se && y.start >= H && y.start <= re && (this.setStart(de, y.start - H), Se = !0), Se && y.end >= H && y.end <= re && (this.setEnd(de, y.end - H), $ = !0), H = re;
          else
            for (Ee = de.childNodes, fe = Ee.length; fe--; ) V.push(Ee[fe]);
        },
        getName: function() {
          return "DomRange";
        },
        equals: function(y) {
          return Xe.rangesEqual(this, y);
        },
        isValid: function() {
          return $t(this);
        },
        inspect: function() {
          return Te(this);
        },
        detach: function() {
        }
      });
      function m(y) {
        y.START_TO_START = si, y.START_TO_END = Xt, y.END_TO_END = Ki, y.END_TO_START = kt, y.NODE_BEFORE = Yt, y.NODE_AFTER = Mi, y.NODE_BEFORE_AND_AFTER = Ai, y.NODE_INSIDE = li;
      }
      function M(y) {
        m(y), m(y.prototype);
      }
      function F(y, A) {
        return function() {
          De(this);
          var H = this.startContainer, V = this.startOffset, de = this.commonAncestorContainer, Se = new Pe(this, !0), $, re;
          H !== de && ($ = Ve(H, de, !0), re = ae($), H = re.node, V = re.offset), _e(Se, mt), Se.reset();
          var fe = y(Se);
          return Se.detach(), A(this, H, V, H, V), fe;
        };
      }
      function ee(y, A) {
        function H($, re) {
          return function(fe) {
            ke(fe, $e), ke(C(fe), gt);
            var Ee = ($ ? he : ae)(fe);
            (re ? V : de)(this, Ee.node, Ee.offset);
          };
        }
        function V($, re, fe) {
          var Ee = $.endContainer, it = $.endOffset;
          (re !== $.startContainer || fe !== $.startOffset) && ((C(re) != C(Ee) || Ae(re, fe, Ee, it) == 1) && (Ee = re, it = fe), A($, re, fe, Ee, it));
        }
        function de($, re, fe) {
          var Ee = $.startContainer, it = $.startOffset;
          (re !== $.endContainer || fe !== $.endOffset) && ((C(re) != C(Ee) || Ae(re, fe, Ee, it) == -1) && (Ee = re, it = fe), A($, Ee, it, re, fe));
        }
        var Se = function() {
        };
        Se.prototype = N.rangePrototype, y.prototype = new Se(), Q.extend(y.prototype, {
          setStart: function($, re) {
            ue($, !0), Oe($, re), V(this, $, re);
          },
          setEnd: function($, re) {
            ue($, !0), Oe($, re), de(this, $, re);
          },
          setStartAndEnd: function() {
            var $ = arguments, re = $[0], fe = $[1], Ee = re, it = fe;
            switch ($.length) {
              case 3:
                it = $[2];
                break;
              case 4:
                Ee = $[2], it = $[3];
            }
            ue(re, !0), Oe(re, fe), ue(Ee, !0), Oe(Ee, it), A(this, re, fe, Ee, it);
          },
          setBoundary: function($, re, fe) {
            this["set" + (fe ? "Start" : "End")]($, re);
          },
          setStartBefore: H(!0, !0),
          setStartAfter: H(!1, !0),
          setEndBefore: H(!0, !1),
          setEndAfter: H(!1, !1),
          collapse: function($) {
            De(this), $ ? A(this, this.startContainer, this.startOffset, this.startContainer, this.startOffset) : A(this, this.endContainer, this.endOffset, this.endContainer, this.endOffset);
          },
          selectNodeContents: function($) {
            ue($, !0), A(this, $, 0, $, x($));
          },
          selectNode: function($) {
            ue($, !1), ke($, $e);
            var re = he($), fe = ae($);
            A(this, re.node, re.offset, fe.node, fe.offset);
          },
          extractContents: F(J, A),
          deleteContents: F(Ke, A),
          canSurroundContents: function() {
            De(this), mt(this.startContainer), mt(this.endContainer);
            var $ = new Pe(this, !0), re = $._first && z($._first, this) || $._last && z($._last, this);
            return $.detach(), !re;
          },
          splitBoundaries: function() {
            oi(this);
          },
          splitBoundariesPreservingPositions: function($) {
            oi(this, $);
          },
          normalizeBoundaries: function() {
            De(this);
            var $ = this.startContainer, re = this.startOffset, fe = this.endContainer, Ee = this.endOffset, it = function(ct) {
              var At = ct.nextSibling;
              At && At.nodeType == ct.nodeType && (fe = ct, Ee = ct.length, ct.appendData(At.data), S(At));
            }, Pr = function(ct) {
              var At = ct.previousSibling;
              if (At && At.nodeType == ct.nodeType) {
                $ = ct;
                var za = ct.length;
                if (re = At.length, ct.insertData(0, At.data), S(At), $ == fe)
                  Ee += re, fe = $;
                else if (fe == ct.parentNode) {
                  var Rr = Ie(ct);
                  Ee == Rr ? (fe = ct, Ee = za) : Ee > Rr && Ee--;
                }
              }
            }, Hn = !0, wt;
            if (ge(fe))
              Ee == fe.length ? it(fe) : Ee == 0 && (wt = fe.previousSibling, wt && wt.nodeType == fe.nodeType && (Ee = wt.length, $ == fe && (Hn = !1), wt.appendData(fe.data), S(fe), fe = wt));
            else {
              if (Ee > 0) {
                var Fn = fe.childNodes[Ee - 1];
                Fn && ge(Fn) && it(Fn);
              }
              Hn = !this.collapsed;
            }
            if (Hn) {
              if (ge($))
                re == 0 ? Pr($) : re == $.length && (wt = $.nextSibling, wt && wt.nodeType == $.nodeType && (fe == wt && (fe = $, Ee += $.length), $.appendData(wt.data), S(wt)));
              else if (re < $.childNodes.length) {
                var Gn = $.childNodes[re];
                Gn && ge(Gn) && Pr(Gn);
              }
            } else
              $ = fe, re = Ee;
            A(this, $, re, fe, Ee);
          },
          collapseToPoint: function($, re) {
            ue($, !0), Oe($, re), this.setStartAndEnd($, re);
          },
          parentElement: function() {
            return De(this), this.commonAncestorContainer ? me(this.commonAncestorContainer, !0) : null;
          }
        }), M(y);
      }
      function ve(y) {
        y.collapsed = y.startContainer === y.endContainer && y.startOffset === y.endOffset, y.commonAncestorContainer = y.collapsed ? y.startContainer : G.getCommonAncestor(y.startContainer, y.endContainer);
      }
      function Me(y, A, H, V, de) {
        y.startContainer = A, y.startOffset = H, y.endContainer = V, y.endOffset = de, y.document = G.getDocument(A), ve(y);
      }
      function Xe(y) {
        Me(this, y, 0, y, 0);
      }
      ee(Xe, Me), Q.extend(Xe, {
        rangeProperties: ai,
        RangeIterator: Pe,
        copyComparisonConstants: M,
        createPrototypeRange: ee,
        inspect: Te,
        toHtml: ye,
        getRangeDocument: k,
        rangesEqual: function(y, A) {
          return y.startContainer === A.startContainer && y.startOffset === A.startOffset && y.endContainer === A.endContainer && y.endOffset === A.endOffset;
        }
      }), N.DomRange = Xe;
    }), B.createCoreModule("WrappedRange", ["DomRange"], function(N, j) {
      var G, Q, ne = N.dom, ce = N.util, ge = ne.DomPosition, Ie = N.DomRange, Be = ne.getBody, We = ne.getContentDocument, Ae = ne.isCharacterDataNode;
      if (N.features.implementsDomRange && (function() {
        var S, z = Ie.rangeProperties;
        function k(J) {
          for (var le = z.length, Te; le--; )
            Te = z[le], J[Te] = J.nativeRange[Te];
          J.collapsed = J.startContainer === J.endContainer && J.startOffset === J.endOffset;
        }
        function X(J, le, Te, Pe, $e) {
          var gt = J.startContainer !== le || J.startOffset != Te, et = J.endContainer !== Pe || J.endOffset != $e, qe = !J.equals(J.nativeRange);
          (gt || et || qe) && (J.setEnd(Pe, $e), J.setStart(le, Te));
        }
        var he;
        G = function(J) {
          if (!J) throw j.createError("WrappedRange: Range must be specified");
          this.nativeRange = J, k(this);
        }, Ie.createPrototypeRange(G, X), S = G.prototype, S.selectNode = function(J) {
          this.nativeRange.selectNode(J), k(this);
        }, S.cloneContents = function() {
          return this.nativeRange.cloneContents();
        }, S.surroundContents = function(J) {
          this.nativeRange.surroundContents(J), k(this);
        }, S.collapse = function(J) {
          this.nativeRange.collapse(J), k(this);
        }, S.cloneRange = function() {
          return new G(this.nativeRange.cloneRange());
        }, S.refresh = function() {
          k(this);
        }, S.toString = function() {
          return this.nativeRange.toString();
        };
        var ae = document.createTextNode("test");
        Be(document).appendChild(ae);
        var Z = document.createRange();
        Z.setStart(ae, 0), Z.setEnd(ae, 0);
        try {
          Z.setStart(ae, 1), S.setStart = function(J, le) {
            this.nativeRange.setStart(J, le), k(this);
          }, S.setEnd = function(J, le) {
            this.nativeRange.setEnd(J, le), k(this);
          }, he = function(J) {
            return function(le) {
              this.nativeRange[J](le), k(this);
            };
          };
        } catch (J) {
          S.setStart = function(le, Te) {
            try {
              this.nativeRange.setStart(le, Te);
            } catch (Pe) {
              this.nativeRange.setEnd(le, Te), this.nativeRange.setStart(le, Te);
            }
            k(this);
          }, S.setEnd = function(le, Te) {
            try {
              this.nativeRange.setEnd(le, Te);
            } catch (Pe) {
              this.nativeRange.setStart(le, Te), this.nativeRange.setEnd(le, Te);
            }
            k(this);
          }, he = function(le, Te) {
            return function(Pe) {
              try {
                this.nativeRange[le](Pe);
              } catch ($e) {
                this.nativeRange[Te](Pe), this.nativeRange[le](Pe);
              }
              k(this);
            };
          };
        }
        S.setStartBefore = he("setStartBefore", "setEndBefore"), S.setStartAfter = he("setStartAfter", "setEndAfter"), S.setEndBefore = he("setEndBefore", "setStartBefore"), S.setEndAfter = he("setEndAfter", "setStartAfter"), S.selectNodeContents = function(J) {
          this.setStartAndEnd(J, 0, ne.getNodeLength(J));
        }, Z.selectNodeContents(ae), Z.setEnd(ae, 3);
        var Ne = document.createRange();
        Ne.selectNodeContents(ae), Ne.setEnd(ae, 4), Ne.setStart(ae, 2), Z.compareBoundaryPoints(Z.START_TO_END, Ne) == -1 && Z.compareBoundaryPoints(Z.END_TO_START, Ne) == 1 ? S.compareBoundaryPoints = function(J, le) {
          return le = le.nativeRange || le, J == le.START_TO_END ? J = le.END_TO_START : J == le.END_TO_START && (J = le.START_TO_END), this.nativeRange.compareBoundaryPoints(J, le);
        } : S.compareBoundaryPoints = function(J, le) {
          return this.nativeRange.compareBoundaryPoints(J, le.nativeRange || le);
        };
        var we = document.createElement("div");
        we.innerHTML = "123";
        var _e = we.firstChild, Ke = Be(document);
        Ke.appendChild(we), Z.setStart(_e, 1), Z.setEnd(_e, 2), Z.deleteContents(), _e.data == "13" && (S.deleteContents = function() {
          this.nativeRange.deleteContents(), k(this);
        }, S.extractContents = function() {
          var J = this.nativeRange.extractContents();
          return k(this), J;
        }), Ke.removeChild(we), Ke = null, ce.isHostMethod(Z, "createContextualFragment") && (S.createContextualFragment = function(J) {
          return this.nativeRange.createContextualFragment(J);
        }), Be(document).removeChild(ae), S.getName = function() {
          return "WrappedRange";
        }, N.WrappedRange = G, N.createNativeRange = function(J) {
          return J = We(J, j, "createNativeRange"), J.createRange();
        };
      })(), N.features.implementsTextRange) {
        var Ue = function(S) {
          var z = S.parentElement(), k = S.duplicate();
          k.collapse(!0);
          var X = k.parentElement();
          k = S.duplicate(), k.collapse(!1);
          var he = k.parentElement(), ae = X == he ? X : ne.getCommonAncestor(X, he);
          return ae == z ? ae : ne.getCommonAncestor(z, ae);
        }, Ve = function(S) {
          return S.compareEndPoints("StartToEnd", S) == 0;
        }, x = function(S, z, k, X, he) {
          var ae = S.duplicate();
          ae.collapse(k);
          var Z = ae.parentElement();
          if (ne.isOrIsAncestorOf(z, Z) || (Z = z), !Z.canHaveHTML) {
            var Ne = new ge(Z.parentNode, ne.getNodeIndex(Z));
            return {
              boundaryPosition: Ne,
              nodeInfo: {
                nodeIndex: Ne.offset,
                containerElement: Ne.node
              }
            };
          }
          var we = ne.getDocument(Z).createElement("span");
          we.parentNode && ne.removeNode(we);
          for (var _e, Ke = k ? "StartToStart" : "StartToEnd", J, le, Te, Pe, $e = he && he.containerElement == Z ? he.nodeIndex : 0, gt = Z.childNodes.length, et = gt, qe = et; qe == gt ? Z.appendChild(we) : Z.insertBefore(we, Z.childNodes[qe]), ae.moveToElementText(we), _e = ae.compareEndPoints(Ke, S), !(_e == 0 || $e == et); ) {
            if (_e == -1) {
              if (et == $e + 1) break;
              $e = qe;
            } else et = et == $e + 1 ? $e : qe;
            qe = Math.floor(($e + et) / 2), Z.removeChild(we);
          }
          if (Pe = we.nextSibling, _e == -1 && Pe && Ae(Pe)) {
            ae.setEndPoint(k ? "EndToStart" : "EndToEnd", S);
            var Qe;
            if (/[\r\n]/.test(Pe.data)) {
              var Ze = ae.duplicate(), ut = Ze.text.replace(/\r\n/g, "\r").length;
              for (Qe = Ze.moveStart("character", ut); (_e = Ze.compareEndPoints("StartToEnd", Ze)) == -1; )
                Qe++, Ze.moveStart("character", 1);
            } else Qe = ae.text.length;
            Te = new ge(Pe, Qe);
          } else
            J = (X || !k) && we.previousSibling, le = (X || k) && we.nextSibling, le && Ae(le) ? Te = new ge(le, 0) : J && Ae(J) ? Te = new ge(J, J.data.length) : Te = new ge(Z, ne.getNodeIndex(we));
          return ne.removeNode(we), {
            boundaryPosition: Te,
            nodeInfo: {
              nodeIndex: qe,
              containerElement: Z
            }
          };
        }, E = function(S, z) {
          var k, X, he = S.offset, ae = ne.getDocument(S.node), Z, Ne, we = Be(ae).createTextRange(), _e = Ae(S.node);
          return _e ? (k = S.node, X = k.parentNode) : (Ne = S.node.childNodes, k = he < Ne.length ? Ne[he] : null, X = S.node), Z = ae.createElement("span"), Z.innerHTML = "&#feff;", k ? X.insertBefore(Z, k) : X.appendChild(Z), we.moveToElementText(Z), we.collapse(!z), X.removeChild(Z), _e && we[z ? "moveStart" : "moveEnd"]("character", he), we;
        };
        Q = function(S) {
          this.textRange = S, this.refresh();
        }, Q.prototype = new Ie(document), Q.prototype.refresh = function() {
          var S, z, k, X = Ue(this.textRange);
          Ve(this.textRange) ? z = S = x(this.textRange, X, !0, !0).boundaryPosition : (k = x(this.textRange, X, !0, !1), S = k.boundaryPosition, z = x(this.textRange, X, !1, !1, k.nodeInfo).boundaryPosition), this.setStart(S.node, S.offset), this.setEnd(z.node, z.offset);
        }, Q.prototype.getName = function() {
          return "WrappedTextRange";
        }, Ie.copyComparisonConstants(Q);
        var C = function(S) {
          if (S.collapsed) return E(new ge(S.startContainer, S.startOffset), !0);
          var z = E(new ge(S.startContainer, S.startOffset), !0), k = E(new ge(S.endContainer, S.endOffset), !1), X = Be(Ie.getRangeDocument(S)).createTextRange();
          return X.setEndPoint("StartToStart", z), X.setEndPoint("EndToEnd", k), X;
        };
        if (Q.rangeToTextRange = C, Q.prototype.toTextRange = function() {
          return C(this);
        }, N.WrappedTextRange = Q, !N.features.implementsDomRange || N.config.preferTextRange) {
          var R = (function(S) {
            return S("return this;")();
          })(Function);
          typeof R.Range == "undefined" && (R.Range = Q), N.createNativeRange = function(S) {
            return S = We(S, j, "createNativeRange"), Be(S).createTextRange();
          }, N.WrappedRange = Q;
        }
      }
      N.createRange = function(S) {
        return S = We(S, j, "createRange"), new N.WrappedRange(N.createNativeRange(S));
      }, N.createRangyRange = function(S) {
        return S = We(S, j, "createRangyRange"), new Ie(S);
      }, ce.createAliasForDeprecatedMethod(N, "createIframeRange", "createRange"), ce.createAliasForDeprecatedMethod(N, "createIframeRangyRange", "createRangyRange"), N.addShimListener(function(S) {
        var z = S.document;
        typeof z.createRange == "undefined" && (z.createRange = function() {
          return N.createRange(z);
        }), z = S = null;
      });
    }), B.createCoreModule("WrappedSelection", ["DomRange", "WrappedRange"], function(N, j) {
      N.config.checkSelectionRanges = !0;
      var G = "boolean", Q = "number", ne = N.dom, ce = N.util, ge = ce.isHostMethod, Ie = N.DomRange, Be = N.WrappedRange, We = N.DOMException, Ae = ne.DomPosition, Ue, Ve, x = N.features, E = "Control", C = ne.getDocument, R = ne.getBody, S = Ie.rangesEqual;
      function z(m) {
        return typeof m == "string" ? /^backward(s)?$/i.test(m) : !!m;
      }
      function k(m, M) {
        if (m) {
          if (ne.isWindow(m)) return m;
          if (m instanceof De) return m.win;
          var F = ne.getContentDocument(m, j, M);
          return ne.getWindow(F);
        } else return window;
      }
      function X(m) {
        return k(m, "getWinSelection").getSelection();
      }
      function he(m) {
        return k(m, "getDocSelection").document.selection;
      }
      function ae(m) {
        var M = !1;
        return m.anchorNode && (M = ne.comparePoints(m.anchorNode, m.anchorOffset, m.focusNode, m.focusOffset) == 1), M;
      }
      var Z = ge(window, "getSelection"), Ne = ce.isHostObject(document, "selection");
      x.implementsWinGetSelection = Z, x.implementsDocSelection = Ne;
      var we = Ne && (!Z || N.config.preferTextRange);
      if (we)
        Ue = he, N.isSelectionValid = function(m) {
          var M = k(m, "isSelectionValid").document, F = M.selection;
          return F.type != "None" || C(F.createRange().parentElement()) == M;
        };
      else if (Z)
        Ue = X, N.isSelectionValid = function() {
          return !0;
        };
      else
        return j.fail("Neither document.selection or window.getSelection() detected."), !1;
      N.getNativeSelection = Ue;
      var _e = Ue();
      if (!_e)
        return j.fail("Native selection was null (possibly issue 138?)"), !1;
      var Ke = N.createNativeRange(document), J = R(document), le = ce.areHostProperties(_e, [
        "anchorNode",
        "focusNode",
        "anchorOffset",
        "focusOffset"
      ]);
      x.selectionHasAnchorAndFocus = le;
      var Te = ge(_e, "extend");
      x.selectionHasExtend = Te;
      var Pe = ge(_e, "setBaseAndExtent");
      x.selectionHasSetBaseAndExtent = Pe;
      var $e = typeof _e.rangeCount == Q;
      x.selectionHasRangeCount = $e;
      var gt = !1, et = !0, qe = Te ? function(m, M) {
        var F = Ie.getRangeDocument(M), ee = N.createRange(F);
        ee.collapseToPoint(M.endContainer, M.endOffset), m.addRange(ue(ee)), m.extend(M.startContainer, M.startOffset);
      } : null;
      ce.areHostMethods(_e, [
        "addRange",
        "getRangeAt",
        "removeAllRanges"
      ]) && typeof _e.rangeCount == Q && x.implementsDomRange && (function() {
        var m = window.getSelection();
        if (m) {
          for (var M = m.rangeCount, F = M > 1, ee = [], ve = ae(m), Me = 0; Me < M; ++Me) ee[Me] = m.getRangeAt(Me);
          var Xe = ne.createTestElement(document, "", !1), y = Xe.appendChild(document.createTextNode("   ")), A = document.createRange();
          if (A.setStart(y, 1), A.collapse(!0), m.removeAllRanges(), m.addRange(A), et = m.rangeCount == 1, m.removeAllRanges(), !F) {
            var H = window.navigator.appVersion.match(/Chrome\/(.*?) /);
            if (H && parseInt(H[1]) >= 36) gt = !1;
            else {
              var V = A.cloneRange();
              A.setStart(y, 0), V.setEnd(y, 3), V.setStart(y, 2), m.addRange(A), m.addRange(V), gt = m.rangeCount == 2;
            }
          }
          for (ne.removeNode(Xe), m.removeAllRanges(), Me = 0; Me < M; ++Me) Me == 0 && ve ? qe ? qe(m, ee[Me]) : (N.warn("Rangy initialization: original selection was backwards but selection has been restored forwards because the browser does not support Selection.extend"), m.addRange(ee[Me])) : m.addRange(ee[Me]);
        }
      })(), x.selectionSupportsMultipleRanges = gt, x.collapsedNonEditableSelectionsSupported = et;
      var Qe = !1, Ze;
      J && ge(J, "createControlRange") && (Ze = J.createControlRange(), ce.areHostProperties(Ze, ["item", "add"]) && (Qe = !0)), x.implementsControlRange = Qe, le ? Ve = function(m) {
        return m.anchorNode === m.focusNode && m.anchorOffset === m.focusOffset;
      } : Ve = function(m) {
        return m.rangeCount ? m.getRangeAt(m.rangeCount - 1).collapsed : !1;
      };
      function ut(m, M, F) {
        var ee = F ? "end" : "start", ve = F ? "start" : "end";
        m.anchorNode = M[ee + "Container"], m.anchorOffset = M[ee + "Offset"], m.focusNode = M[ve + "Container"], m.focusOffset = M[ve + "Offset"];
      }
      function P(m) {
        var M = m.nativeSelection;
        m.anchorNode = M.anchorNode, m.anchorOffset = M.anchorOffset, m.focusNode = M.focusNode, m.focusOffset = M.focusOffset;
      }
      function q(m) {
        m.anchorNode = m.focusNode = null, m.anchorOffset = m.focusOffset = 0, m.rangeCount = 0, m.isCollapsed = !0, m._ranges.length = 0, me(m);
      }
      function me(m) {
        m.type = m.rangeCount == 0 ? "None" : Ve(m) ? "Caret" : "Range";
      }
      function ue(m) {
        var M;
        return m instanceof Ie ? (M = N.createNativeRange(m.getDocument()), M.setEnd(m.endContainer, m.endOffset), M.setStart(m.startContainer, m.startOffset)) : m instanceof Be ? M = m.nativeRange : x.implementsDomRange && m instanceof ne.getWindow(m.startContainer).Range && (M = m), M;
      }
      function ke(m) {
        if (!m.length || m[0].nodeType != 1) return !1;
        for (var M = 1, F = m.length; M < F; ++M) if (!ne.isAncestorOf(m[0], m[M])) return !1;
        return !0;
      }
      function Oe(m) {
        var M = m.getNodes();
        if (!ke(M)) throw j.createError("getSingleElementFromRange: range " + m.inspect() + " did not consist of a single element");
        return M[0];
      }
      function Tt(m) {
        return !!m && typeof m.text != "undefined";
      }
      function mt(m, M) {
        var F = new Be(M);
        m._ranges = [F], ut(m, F, !1), m.rangeCount = 1, m.isCollapsed = F.collapsed, me(m);
      }
      function tt(m) {
        if (m._ranges.length = 0, m.docSelection.type == "None") q(m);
        else {
          var M = m.docSelection.createRange();
          if (Tt(M)) mt(m, M);
          else {
            m.rangeCount = M.length;
            for (var F, ee = C(M.item(0)), ve = 0; ve < m.rangeCount; ++ve)
              F = N.createRange(ee), F.selectNode(M.item(ve)), m._ranges.push(F);
            m.isCollapsed = m.rangeCount == 1 && m._ranges[0].collapsed, ut(m, m._ranges[m.rangeCount - 1], !1), me(m);
          }
        }
      }
      function Si(m, M) {
        for (var F = m.docSelection.createRange(), ee = Oe(M), ve = R(C(F.item(0))).createControlRange(), Me = 0, Xe = F.length; Me < Xe; ++Me) ve.add(F.item(Me));
        try {
          ve.add(ee);
        } catch (y) {
          throw j.createError("addRange(): Element within the specified Range could not be added to control selection (does it have layout?)");
        }
        ve.select(), tt(m);
      }
      var $t;
      ge(_e, "getRangeAt") ? $t = function(m, M) {
        try {
          return m.getRangeAt(M);
        } catch (F) {
          return null;
        }
      } : le && ($t = function(m) {
        var M = C(m.anchorNode), F = N.createRange(M);
        return F.setStartAndEnd(m.anchorNode, m.anchorOffset, m.focusNode, m.focusOffset), F.collapsed !== this.isCollapsed && F.setStartAndEnd(m.focusNode, m.focusOffset, m.anchorNode, m.anchorOffset), F;
      });
      function De(m, M, F) {
        this.nativeSelection = m, this.docSelection = M, this._ranges = [], this.win = F, this.refresh();
      }
      De.prototype = N.selectionPrototype;
      function Ni(m) {
        m.win = m.anchorNode = m.focusNode = m._ranges = null, m.rangeCount = m.anchorOffset = m.focusOffset = 0, m.detached = !0, me(m);
      }
      var Lt = [];
      function Ti(m, M) {
        for (var F = Lt.length, ee, ve; F--; )
          if (ee = Lt[F], ve = ee.selection, M == "deleteAll") Ni(ve);
          else if (ee.win == m)
            return M == "delete" ? (Lt.splice(F, 1), !0) : ve;
        return M == "deleteAll" && (Lt.length = 0), null;
      }
      var oi = function(m) {
        if (m && m instanceof De)
          return m.refresh(), m;
        m = k(m, "getNativeSelection");
        var M = Ti(m), F = Ue(m), ee = Ne ? he(m) : null;
        return M ? (M.nativeSelection = F, M.docSelection = ee, M.refresh()) : (M = new De(F, ee, m), Lt.push({
          win: m,
          selection: M
        })), M;
      };
      N.getSelection = oi, ce.createAliasForDeprecatedMethod(N, "getIframeSelection", "getSelection");
      var ye = De.prototype;
      function ai(m, M) {
        for (var F = R(C(M[0].startContainer)).createControlRange(), ee = 0, ve, Me = M.length; ee < Me; ++ee) {
          ve = Oe(M[ee]);
          try {
            F.add(ve);
          } catch (Xe) {
            throw j.createError("setRanges(): Element within one of the specified Ranges could not be added to control selection (does it have layout?)");
          }
        }
        F.select(), tt(m);
      }
      if (!we && le && ce.areHostMethods(_e, ["removeAllRanges", "addRange"])) {
        ye.removeAllRanges = function() {
          this.nativeSelection.removeAllRanges(), q(this);
        };
        var si = function(m, M) {
          qe(m.nativeSelection, M), m.refresh();
        };
        $e ? ye.addRange = function(m, M) {
          if (Qe && Ne && this.docSelection.type == E) Si(this, m);
          else if (z(M) && Te) si(this, m);
          else {
            var F;
            gt ? F = this.rangeCount : (this.removeAllRanges(), F = 0);
            var ee = ue(m).cloneRange();
            try {
              this.nativeSelection.addRange(ee);
            } catch (Me) {
            }
            if (this.rangeCount = this.nativeSelection.rangeCount, this.rangeCount == F + 1) {
              if (N.config.checkSelectionRanges) {
                var ve = $t(this.nativeSelection, this.rangeCount - 1);
                ve && !S(ve, m) && (m = new Be(ve));
              }
              this._ranges[this.rangeCount - 1] = m, ut(this, m, kt(this.nativeSelection)), this.isCollapsed = Ve(this), me(this);
            } else this.refresh();
          }
        } : ye.addRange = function(m, M) {
          z(M) && Te ? si(this, m) : (this.nativeSelection.addRange(ue(m)), this.refresh());
        }, ye.setRanges = function(m) {
          if (Qe && Ne && m.length > 1) ai(this, m);
          else {
            this.removeAllRanges();
            for (var M = 0, F = m.length; M < F; ++M) this.addRange(m[M]);
          }
        };
      } else if (ge(_e, "empty") && ge(Ke, "select") && Qe && we)
        ye.removeAllRanges = function() {
          try {
            if (this.docSelection.empty(), this.docSelection.type != "None") {
              var m;
              if (this.anchorNode) m = C(this.anchorNode);
              else if (this.docSelection.type == E) {
                var M = this.docSelection.createRange();
                M.length && (m = C(M.item(0)));
              }
              m && (R(m).createTextRange().select(), this.docSelection.empty());
            }
          } catch (F) {
          }
          q(this);
        }, ye.addRange = function(m) {
          this.docSelection.type == E ? Si(this, m) : (N.WrappedTextRange.rangeToTextRange(m).select(), this._ranges[0] = m, this.rangeCount = 1, this.isCollapsed = this._ranges[0].collapsed, ut(this, m, !1), me(this));
        }, ye.setRanges = function(m) {
          this.removeAllRanges();
          var M = m.length;
          M > 1 ? ai(this, m) : M && this.addRange(m[0]);
        };
      else
        return j.fail("No means of selecting a Range or TextRange was found"), !1;
      ye.getRangeAt = function(m) {
        if (m < 0 || m >= this.rangeCount) throw new We("INDEX_SIZE_ERR");
        return this._ranges[m].cloneRange();
      };
      var Xt;
      if (we) Xt = function(m) {
        var M;
        N.isSelectionValid(m.win) ? M = m.docSelection.createRange() : (M = R(m.win.document).createTextRange(), M.collapse(!0)), m.docSelection.type == E ? tt(m) : Tt(M) ? mt(m, M) : q(m);
      };
      else if (ge(_e, "getRangeAt") && typeof _e.rangeCount == Q) Xt = function(m) {
        if (Qe && Ne && m.docSelection.type == E) tt(m);
        else if (m._ranges.length = m.rangeCount = m.nativeSelection.rangeCount, m.rangeCount) {
          for (var M = 0, F = m.rangeCount; M < F; ++M) m._ranges[M] = new N.WrappedRange(m.nativeSelection.getRangeAt(M));
          ut(m, m._ranges[m.rangeCount - 1], kt(m.nativeSelection)), m.isCollapsed = Ve(m), me(m);
        } else q(m);
      };
      else if (le && typeof _e.isCollapsed == G && typeof Ke.collapsed == G && x.implementsDomRange) Xt = function(m) {
        var M, F = m.nativeSelection;
        F.anchorNode ? (M = $t(F, 0), m._ranges = [M], m.rangeCount = 1, P(m), m.isCollapsed = Ve(m), me(m)) : q(m);
      };
      else
        return j.fail("No means of obtaining a Range or TextRange from the user's selection was found"), !1;
      ye.refresh = function(m) {
        var M = m ? this._ranges.slice(0) : null, F = this.anchorNode, ee = this.anchorOffset;
        if (Xt(this), m) {
          var ve = M.length;
          if (ve != this._ranges.length || this.anchorNode != F || this.anchorOffset != ee) return !0;
          for (; ve--; ) if (!S(M[ve], this._ranges[ve])) return !0;
          return !1;
        }
      };
      var Ki = function(m, M) {
        var F = m.getAllRanges();
        m.removeAllRanges();
        for (var ee = 0, ve = F.length; ee < ve; ++ee) S(M, F[ee]) || m.addRange(F[ee]);
        m.rangeCount || q(m);
      };
      Qe && Ne ? ye.removeRange = function(m) {
        if (this.docSelection.type == E) {
          for (var M = this.docSelection.createRange(), F = Oe(m), ee = R(C(M.item(0))).createControlRange(), ve, Me = !1, Xe = 0, y = M.length; Xe < y; ++Xe)
            ve = M.item(Xe), ve !== F || Me ? ee.add(M.item(Xe)) : Me = !0;
          ee.select(), tt(this);
        } else Ki(this, m);
      } : ye.removeRange = function(m) {
        Ki(this, m);
      };
      var kt;
      !we && le && x.implementsDomRange ? (kt = ae, ye.isBackward = function() {
        return kt(this);
      }) : kt = ye.isBackward = function() {
        return !1;
      }, ye.isBackwards = ye.isBackward, ye.toString = function() {
        for (var m = [], M = 0, F = this.rangeCount; M < F; ++M) m[M] = "" + this._ranges[M];
        return m.join("");
      };
      function Yt(m, M) {
        if (m.win.document != C(M)) throw new We("WRONG_DOCUMENT_ERR");
      }
      function Mi(m, M) {
        if (M < 0 || M > (ne.isCharacterDataNode(m) ? m.length : m.childNodes.length)) throw new We("INDEX_SIZE_ERR");
      }
      ye.collapse = function(m, M) {
        Yt(this, m);
        var F = N.createRange(m);
        F.collapseToPoint(m, M), this.setSingleRange(F), this.isCollapsed = !0;
      }, ye.collapseToStart = function() {
        if (this.rangeCount) {
          var m = this._ranges[0];
          this.collapse(m.startContainer, m.startOffset);
        } else throw new We("INVALID_STATE_ERR");
      }, ye.collapseToEnd = function() {
        if (this.rangeCount) {
          var m = this._ranges[this.rangeCount - 1];
          this.collapse(m.endContainer, m.endOffset);
        } else throw new We("INVALID_STATE_ERR");
      }, ye.selectAllChildren = function(m) {
        Yt(this, m);
        var M = N.createRange(m);
        M.selectNodeContents(m), this.setSingleRange(M);
      }, Pe ? ye.setBaseAndExtent = function(m, M, F, ee) {
        this.nativeSelection.setBaseAndExtent(m, M, F, ee), this.refresh();
      } : Te && (ye.setBaseAndExtent = function(m, M, F, ee) {
        Mi(m, M), Mi(F, ee), Yt(this, m), Yt(this, F);
        var ve = N.createRange(node), Me = ne.comparePoints(m, M, F, ee) == -1;
        Me ? ve.setStartAndEnd(F, ee, m, M) : ve.setStartAndEnd(m, M, F, ee), this.setSingleRange(ve, Me);
      }), ye.deleteFromDocument = function() {
        if (Qe && Ne && this.docSelection.type == E) {
          for (var m = this.docSelection.createRange(), M; m.length; )
            M = m.item(0), m.remove(M), ne.removeNode(M);
          this.refresh();
        } else if (this.rangeCount) {
          var F = this.getAllRanges();
          if (F.length) {
            this.removeAllRanges();
            for (var ee = 0, ve = F.length; ee < ve; ++ee) F[ee].deleteContents();
            this.addRange(F[ve - 1]);
          }
        }
      }, ye.eachRange = function(m, M) {
        for (var F = 0, ee = this._ranges.length; F < ee; ++F) if (m(this.getRangeAt(F))) return M;
      }, ye.getAllRanges = function() {
        var m = [];
        return this.eachRange(function(M) {
          m.push(M);
        }), m;
      }, ye.setSingleRange = function(m, M) {
        this.removeAllRanges(), this.addRange(m, M);
      }, ye.callMethodOnEachRange = function(m, M) {
        var F = [];
        return this.eachRange(function(ee) {
          F.push(ee[m].apply(ee, M || []));
        }), F;
      };
      function Ai(m) {
        return function(M, F) {
          var ee;
          this.rangeCount ? (ee = this.getRangeAt(0), ee["set" + (m ? "Start" : "End")](M, F)) : (ee = N.createRange(this.win.document), ee.setStartAndEnd(M, F)), this.setSingleRange(ee, this.isBackward());
        };
      }
      ye.setStart = Ai(!0), ye.setEnd = Ai(!1), N.rangePrototype.select = function(m) {
        oi(this.getDocument()).setSingleRange(this, m);
      }, ye.changeEachRange = function(m) {
        var M = [], F = this.isBackward();
        this.eachRange(function(ee) {
          m(ee), M.push(ee);
        }), this.removeAllRanges(), F && M.length == 1 ? this.addRange(M[0], "backward") : this.setRanges(M);
      }, ye.containsNode = function(m, M) {
        return this.eachRange(function(F) {
          return F.containsNode(m, M);
        }, !0) || !1;
      }, ye.getBookmark = function(m) {
        return {
          backward: this.isBackward(),
          rangeBookmarks: this.callMethodOnEachRange("getBookmark", [m])
        };
      }, ye.moveToBookmark = function(m) {
        for (var M = [], F = 0, ee, ve; ee = m.rangeBookmarks[F++]; )
          ve = N.createRange(this.win), ve.moveToBookmark(ee), M.push(ve);
        m.backward ? this.setSingleRange(M[0], "backward") : this.setRanges(M);
      }, ye.saveRanges = function() {
        return {
          backward: this.isBackward(),
          ranges: this.callMethodOnEachRange("cloneRange")
        };
      }, ye.restoreRanges = function(m) {
        this.removeAllRanges();
        for (var M = 0, F; F = m.ranges[M]; ++M) this.addRange(F, m.backward && M == 0);
      }, ye.toHtml = function() {
        var m = [];
        return this.eachRange(function(M) {
          m.push(Ie.toHtml(M));
        }), m.join("");
      }, x.implementsTextRange && (ye.getNativeTextRange = function() {
        var m;
        if (m = this.docSelection) {
          var M = m.createRange();
          if (Tt(M)) return M;
          throw j.createError("getNativeTextRange: selection is a control selection");
        } else {
          if (this.rangeCount > 0) return N.WrappedTextRange.rangeToTextRange(this.getRangeAt(0));
          throw j.createError("getNativeTextRange: selection contains no range");
        }
      });
      function li(m) {
        var M = [], F = new Ae(m.anchorNode, m.anchorOffset), ee = new Ae(m.focusNode, m.focusOffset), ve = typeof m.getName == "function" ? m.getName() : "Selection";
        if (typeof m.rangeCount != "undefined") for (var Me = 0, Xe = m.rangeCount; Me < Xe; ++Me) M[Me] = Ie.inspect(m.getRangeAt(Me));
        return "[" + ve + "(Ranges: " + M.join(", ") + ")(anchor: " + F.inspect() + ", focus: " + ee.inspect() + "]";
      }
      ye.getName = function() {
        return "WrappedSelection";
      }, ye.inspect = function() {
        return li(this);
      }, ye.detach = function() {
        Ti(this.win, "delete"), Ni(this);
      }, De.detachAll = function() {
        Ti(null, "deleteAll");
      }, De.inspect = li, De.isDirectionBackward = z, N.Selection = De, N.selectionPrototype = ye, N.addShimListener(function(m) {
        typeof m.getSelection == "undefined" && (m.getSelection = function() {
          return oi(m);
        }), m = null;
      });
    });
    var Nt = !1, Ye = function(N) {
      Nt || (Nt = !0, !B.initialized && B.config.autoInitialize && O());
    };
    return L && (document.readyState == "complete" ? Ye() : (l(document, "addEventListener") && document.addEventListener("DOMContentLoaded", Ye, !1), ze(window, "load", Ye))), B;
  }, o);
})), nu = /* @__PURE__ */ br(((o, n) => {
  (function(e, i) {
    typeof define == "function" && define.amd ? define(["./rangy-core"], e) : typeof n != "undefined" && typeof o == "object" ? n.exports = e(Ra()) : e(i.rangy);
  })(function(e) {
    return e.createModule("ClassApplier", ["WrappedSelection"], function(i, t) {
      var r = i.dom, a = r.DomPosition, s = r.arrayContains, d = i.util, l = d.forEach, u = "span", c = d.isHostMethod(document, "createElementNS");
      function h(x, E) {
        for (var C in x) if (x.hasOwnProperty(C) && E(C, x[C]) === !1)
          return !1;
        return !0;
      }
      function f(x) {
        return x.replace(/^\s\s*/, "").replace(/\s\s*$/, "");
      }
      function p(x, E) {
        return !!x && new RegExp("(?:^|\\s)" + E + "(?:\\s|$)").test(x);
      }
      function v(x, E) {
        return typeof x.classList == "object" ? x.classList.contains(E) : p(typeof x.className == "string" ? x.className : x.getAttribute("class"), E);
      }
      function g(x, E) {
        if (typeof x.classList == "object") x.classList.add(E);
        else {
          var C = typeof x.className == "string", R = C ? x.className : x.getAttribute("class");
          R ? p(R, E) || (R += " " + E) : R = E, C ? x.className = R : x.setAttribute("class", R);
        }
      }
      var b = /* @__PURE__ */ (function() {
        function x(E, C, R) {
          return C && R ? " " : "";
        }
        return function(E, C) {
          if (typeof E.classList == "object") E.classList.remove(C);
          else {
            var R = typeof E.className == "string", S = R ? E.className : E.getAttribute("class");
            S = S.replace(new RegExp("(^|\\s)" + C + "(\\s|$)"), x), R ? E.className = S : E.setAttribute("class", S);
          }
        };
      })();
      function _(x) {
        return typeof x.className == "string" ? x.className : x.getAttribute("class");
      }
      function D(x) {
        return x && x.split(/\s+/).sort().join(" ");
      }
      function L(x) {
        return D(_(x));
      }
      function W(x, E) {
        return L(x) == L(E);
      }
      function B(x, E) {
        for (var C = E.split(/\s+/), R = 0, S = C.length; R < S; ++R) if (!v(x, f(C[R]))) return !1;
        return !0;
      }
      function K(x) {
        var E = x.parentNode;
        return E && E.nodeType == 1 && !/^(textarea|style|script|select|iframe)$/i.test(E.nodeName);
      }
      function Y(x, E, C, R, S) {
        var z = x.node, k = x.offset, X = z, he = k;
        z == R && k > S && ++he, z == E && (k == C || k == C + 1) && (X = R, he += S - C), z == E && k > C + 1 && --he, x.node = X, x.offset = he;
      }
      function te(x, E, C) {
        x.node == E && x.offset > C && --x.offset;
      }
      function se(x, E, C, R) {
        C == -1 && (C = E.childNodes.length);
        var S = x.parentNode, z = r.getNodeIndex(x);
        l(R, function(k) {
          Y(k, S, z, E, C);
        }), E.childNodes.length == C ? E.appendChild(x) : E.insertBefore(x, E.childNodes[C]);
      }
      function Le(x, E) {
        var C = x.parentNode, R = r.getNodeIndex(x);
        l(E, function(S) {
          te(S, C, R);
        }), r.removeNode(x);
      }
      function ze(x, E, C, R, S) {
        for (var z, k = []; z = x.firstChild; )
          se(z, E, C++, S), k.push(z);
        return R && Le(x, S), k;
      }
      function xe(x, E) {
        return ze(x, x.parentNode, r.getNodeIndex(x), !0, E);
      }
      function w(x, E) {
        var C = x.cloneRange();
        C.selectNodeContents(E);
        var R = C.intersection(x);
        return (R ? R.toString() : "") != "";
      }
      function O(x) {
        for (var E = x.getNodes([3]), C = 0, R; (R = E[C]) && !w(x, R); ) ++C;
        for (var S = E.length - 1; (R = E[S]) && !w(x, R); ) --S;
        return E.slice(C, S + 1);
      }
      function T(x, E) {
        if (x.attributes.length != E.attributes.length) return !1;
        for (var C = 0, R = x.attributes.length, S, z, k; C < R; ++C)
          if (S = x.attributes[C], k = S.name, k != "class" && (z = E.attributes.getNamedItem(k), S === null != (z === null) || S.specified != z.specified || S.specified && S.nodeValue !== z.nodeValue))
            return !1;
        return !0;
      }
      function U(x, E) {
        for (var C = 0, R = x.attributes.length, S; C < R; ++C)
          if (S = x.attributes[C].name, !(E && s(E, S)) && x.attributes[C].specified && S != "class") return !0;
        return !1;
      }
      var ie = r.getComputedStyleProperty, pe = (function() {
        return typeof document.createElement("div").isContentEditable == "boolean" ? function(x) {
          return x && x.nodeType == 1 && x.isContentEditable;
        } : function(x) {
          return !x || x.nodeType != 1 || x.contentEditable == "false" ? !1 : x.contentEditable == "true" || pe(x.parentNode);
        };
      })();
      function je(x) {
        var E;
        return x && x.nodeType == 1 && ((E = x.parentNode) && E.nodeType == 9 && E.designMode == "on" || pe(x) && !pe(x.parentNode));
      }
      function Ge(x) {
        return (pe(x) || x.nodeType != 1 && pe(x.parentNode)) && !je(x);
      }
      var vt = /^inline(-block|-table)?$/i;
      function dt(x) {
        return x && x.nodeType == 1 && !vt.test(ie(x, "display"));
      }
      var Nt = /[^\r\n\t\f \u200B]/;
      function Ye(x) {
        if (x.data.length == 0) return !0;
        if (Nt.test(x.data)) return !1;
        switch (ie(x.parentNode, "whiteSpace")) {
          case "pre":
          case "pre-wrap":
          case "-moz-pre-wrap":
            return !1;
          case "pre-line":
            if (/[\r\n]/.test(x.data)) return !1;
        }
        return dt(x.previousSibling) || dt(x.nextSibling);
      }
      function N(x) {
        var E = [], C, R;
        for (C = 0; R = x[C++]; ) E.push(new a(R.startContainer, R.startOffset), new a(R.endContainer, R.endOffset));
        return E;
      }
      function j(x, E) {
        for (var C = 0, R, S, z, k = x.length; C < k; ++C)
          R = x[C], S = E[C * 2], z = E[C * 2 + 1], R.setStartAndEnd(S.node, S.offset, z.node, z.offset);
      }
      function G(x, E) {
        return r.isCharacterDataNode(x) ? E == 0 ? !!x.previousSibling : E == x.length ? !!x.nextSibling : !0 : E > 0 && E < x.childNodes.length;
      }
      function Q(x, E, C, R) {
        var S, z, k = C == 0;
        if (r.isAncestorOf(E, x)) return x;
        if (r.isCharacterDataNode(E)) {
          var X = r.getNodeIndex(E);
          if (C == 0) C = X;
          else if (C == E.length) C = X + 1;
          else throw t.createError("splitNodeAt() should not be called with offset in the middle of a data node (" + C + " in " + E.data);
          E = E.parentNode;
        }
        if (G(E, C)) {
          S = E.cloneNode(!1), z = E.parentNode, S.id && S.removeAttribute("id");
          for (var he, ae = 0; he = E.childNodes[C]; ) se(he, S, ae++, R);
          return se(S, z, r.getNodeIndex(E) + 1, R), E == x ? S : Q(x, z, r.getNodeIndex(S), R);
        } else if (x != E) {
          S = E.parentNode;
          var Z = r.getNodeIndex(E);
          return k || Z++, Q(x, S, Z, R);
        }
        return x;
      }
      function ne(x, E) {
        return x.namespaceURI == E.namespaceURI && x.tagName.toLowerCase() == E.tagName.toLowerCase() && W(x, E) && T(x, E) && ie(x, "display") == "inline" && ie(E, "display") == "inline";
      }
      function ce(x) {
        var E = x ? "nextSibling" : "previousSibling";
        return function(C, R) {
          var S = C.parentNode, z = C[E];
          if (z) {
            if (z && z.nodeType == 3) return z;
          } else if (R && (z = S[E], z && z.nodeType == 1 && ne(S, z))) {
            var k = z[x ? "firstChild" : "lastChild"];
            if (k && k.nodeType == 3) return k;
          }
          return null;
        };
      }
      var ge = ce(!1), Ie = ce(!0);
      function Be(x) {
        this.isElementMerge = x.nodeType == 1, this.textNodes = [];
        var E = this.isElementMerge ? x.lastChild : x;
        E && (this.textNodes[0] = E);
      }
      Be.prototype = {
        doMerge: function(x) {
          var E = this.textNodes, C = E[0];
          if (E.length > 1) {
            var R = r.getNodeIndex(C), S = [], z = 0, k;
            l(E, function(X, he) {
              k = X.parentNode, he > 0 && (k.removeChild(X), k.hasChildNodes() || r.removeNode(k), x && l(x, function(ae) {
                ae.node == X && (ae.node = C, ae.offset += z), ae.node == k && ae.offset > R && (--ae.offset, ae.offset == R + 1 && he < E.length - 1 && (ae.node = C, ae.offset = z));
              })), S[he] = X.data, z += X.data.length;
            }), C.data = S.join("");
          }
          return C.data;
        },
        getLength: function() {
          for (var x = this.textNodes.length, E = 0; x--; ) E += this.textNodes[x].length;
          return E;
        },
        toString: function() {
          var x = [];
          return l(this.textNodes, function(E, C) {
            x[C] = "'" + E.data + "'";
          }), "[Merge(" + x.join(",") + ")]";
        }
      };
      var We = [
        "elementTagName",
        "ignoreWhiteSpace",
        "applyToEditableOnly",
        "useExistingElements",
        "removeEmptyElements",
        "onElementCreate"
      ], Ae = {};
      function Ue(x, E, C) {
        var R, S, z, k, X = this;
        X.cssClass = X.className = x;
        var he = null, ae = {};
        if (typeof E == "object" && E !== null) {
          for (typeof E.elementTagName != "undefined" && (E.elementTagName = E.elementTagName.toLowerCase()), C = E.tagNames, he = E.elementProperties, ae = E.elementAttributes, S = 0; k = We[S++]; ) E.hasOwnProperty(k) && (X[k] = E[k]);
          R = E.normalize;
        } else R = E;
        X.normalize = typeof R == "undefined" ? !0 : R, X.attrExceptions = [];
        var Z = document.createElement(X.elementTagName);
        X.elementProperties = X.copyPropertiesToElement(he, Z, !0), h(ae, function(we, _e) {
          X.attrExceptions.push(we), ae[we] = "" + _e;
        }), X.elementAttributes = ae, X.elementSortedClassName = X.elementProperties.hasOwnProperty("className") ? D(X.elementProperties.className + " " + x) : x, X.applyToAnyTagName = !1;
        var Ne = typeof C;
        if (Ne == "string")
          C == "*" ? X.applyToAnyTagName = !0 : X.tagNames = f(C.toLowerCase()).split(/\s*,\s*/);
        else if (Ne == "object" && typeof C.length == "number")
          for (X.tagNames = [], S = 0, z = C.length; S < z; ++S) C[S] == "*" ? X.applyToAnyTagName = !0 : X.tagNames.push(C[S].toLowerCase());
        else X.tagNames = [X.elementTagName];
      }
      Ue.prototype = {
        elementTagName: u,
        elementProperties: {},
        elementAttributes: {},
        ignoreWhiteSpace: !0,
        applyToEditableOnly: !1,
        useExistingElements: !0,
        removeEmptyElements: !0,
        onElementCreate: null,
        copyPropertiesToElement: function(x, E, C) {
          var R, S, z = {}, k, X, he, ae;
          for (var Z in x) if (x.hasOwnProperty(Z))
            if (X = x[Z], he = E[Z], Z == "className")
              g(E, X), g(E, this.className), E[Z] = D(E[Z]), C && (z[Z] = X);
            else if (Z == "style") {
              S = he, C && (z[Z] = k = {});
              for (R in x[Z]) x[Z].hasOwnProperty(R) && (S[R] = X[R], C && (k[R] = S[R]));
              this.attrExceptions.push(Z);
            } else
              E[Z] = X, C && (z[Z] = E[Z], ae = Ae.hasOwnProperty(Z) ? Ae[Z] : Z, this.attrExceptions.push(ae));
          return C ? z : "";
        },
        copyAttributesToElement: function(x, E) {
          for (var C in x) x.hasOwnProperty(C) && !/^class(?:Name)?$/i.test(C) && E.setAttribute(C, x[C]);
        },
        appliesToElement: function(x) {
          return s(this.tagNames, x.tagName.toLowerCase());
        },
        getEmptyElements: function(x) {
          var E = this;
          return x.getNodes([1], function(C) {
            return E.appliesToElement(C) && !C.hasChildNodes();
          });
        },
        hasClass: function(x) {
          return x.nodeType == 1 && (this.applyToAnyTagName || this.appliesToElement(x)) && v(x, this.className);
        },
        getSelfOrAncestorWithClass: function(x) {
          for (; x; ) {
            if (this.hasClass(x)) return x;
            x = x.parentNode;
          }
          return null;
        },
        isModifiable: function(x) {
          return !this.applyToEditableOnly || Ge(x);
        },
        isIgnorableWhiteSpaceNode: function(x) {
          return this.ignoreWhiteSpace && x && x.nodeType == 3 && Ye(x);
        },
        postApply: function(x, E, C, R) {
          var S = x[0], z = x[x.length - 1], k = [], X, he = S, ae = z, Z = 0, Ne = z.length, we;
          l(x, function(le) {
            we = ge(le, !R), we ? (X || (X = new Be(we), k.push(X)), X.textNodes.push(le), le === S && (he = X.textNodes[0], Z = he.length), le === z && (ae = X.textNodes[0], Ne = X.getLength())) : X = null;
          });
          var _e = Ie(z, !R);
          if (_e && (X || (X = new Be(z), k.push(X)), X.textNodes.push(_e)), k.length) {
            for (var Ke = 0, J = k.length; Ke < J; ++Ke) k[Ke].doMerge(C);
            E.setStartAndEnd(he, Z, ae, Ne);
          }
        },
        createContainer: function(x) {
          var E = r.getDocument(x), C = c && !r.isHtmlNamespace(x) && x.namespaceURI ? E.createElementNS(x.namespaceURI, this.elementTagName) : E.createElement(this.elementTagName);
          return this.copyPropertiesToElement(this.elementProperties, C, !1), this.copyAttributesToElement(this.elementAttributes, C), g(C, this.className), this.onElementCreate && this.onElementCreate(C, this), C;
        },
        elementHasProperties: function(x, E) {
          var C = this;
          return h(E, function(R, S) {
            if (R == "className") return B(x, S);
            if (typeof S == "object") {
              if (!C.elementHasProperties(x[R], S)) return !1;
            } else if (x[R] !== S) return !1;
          });
        },
        elementHasAttributes: function(x, E) {
          return h(E, function(C, R) {
            if (x.getAttribute(C) !== R) return !1;
          });
        },
        applyToTextNode: function(x, E) {
          if (K(x)) {
            var C = x.parentNode;
            if (C.childNodes.length == 1 && this.useExistingElements && this.appliesToElement(C) && this.elementHasProperties(C, this.elementProperties) && this.elementHasAttributes(C, this.elementAttributes)) g(C, this.className);
            else {
              var R = x.parentNode, S = this.createContainer(R);
              R.insertBefore(S, x), S.appendChild(x);
            }
          }
        },
        isRemovable: function(x) {
          return x.tagName.toLowerCase() == this.elementTagName && L(x) == this.elementSortedClassName && this.elementHasProperties(x, this.elementProperties) && !U(x, this.attrExceptions) && this.elementHasAttributes(x, this.elementAttributes) && this.isModifiable(x);
        },
        isEmptyContainer: function(x) {
          var E = x.childNodes.length;
          return x.nodeType == 1 && this.isRemovable(x) && (E == 0 || E == 1 && this.isEmptyContainer(x.firstChild));
        },
        removeEmptyContainers: function(x) {
          var E = this, C = x.getNodes([1], function(z) {
            return E.isEmptyContainer(z);
          }), R = [x], S = N(R);
          l(C, function(z) {
            Le(z, S);
          }), j(R, S);
        },
        undoToTextNode: function(x, E, C, R) {
          if (!E.containsNode(C)) {
            var S = E.cloneRange();
            S.selectNode(C), S.isPointInRange(E.endContainer, E.endOffset) && (Q(C, E.endContainer, E.endOffset, R), E.setEndAfter(C)), S.isPointInRange(E.startContainer, E.startOffset) && (C = Q(C, E.startContainer, E.startOffset, R));
          }
          this.isRemovable(C) ? xe(C, R) : b(C, this.className);
        },
        splitAncestorWithClass: function(x, E, C) {
          var R = this.getSelfOrAncestorWithClass(x);
          R && Q(R, x, E, C);
        },
        undoToAncestor: function(x, E) {
          this.isRemovable(x) ? xe(x, E) : b(x, this.className);
        },
        applyToRange: function(x, E) {
          var C = this;
          E = E || [];
          var R = N(E || []);
          x.splitBoundariesPreservingPositions(R), C.removeEmptyElements && C.removeEmptyContainers(x);
          var S = O(x);
          if (S.length) {
            l(S, function(k) {
              !C.isIgnorableWhiteSpaceNode(k) && !C.getSelfOrAncestorWithClass(k) && C.isModifiable(k) && C.applyToTextNode(k, R);
            });
            var z = S[S.length - 1];
            x.setStartAndEnd(S[0], 0, z, z.length), C.normalize && C.postApply(S, x, R, !1), j(E, R);
          }
          l(C.getEmptyElements(x), function(k) {
            g(k, C.className);
          });
        },
        applyToRanges: function(x) {
          for (var E = x.length; E--; ) this.applyToRange(x[E], x);
          return x;
        },
        applyToSelection: function(x) {
          var E = i.getSelection(x);
          E.setRanges(this.applyToRanges(E.getAllRanges()));
        },
        undoToRange: function(x, E) {
          var C = this;
          E = E || [];
          var R = N(E);
          x.splitBoundariesPreservingPositions(R), C.removeEmptyElements && C.removeEmptyContainers(x, R);
          var S = O(x), z, k, X = S[S.length - 1];
          if (S.length) {
            C.splitAncestorWithClass(x.endContainer, x.endOffset, R), C.splitAncestorWithClass(x.startContainer, x.startOffset, R);
            for (var he = 0, ae = S.length; he < ae; ++he)
              z = S[he], k = C.getSelfOrAncestorWithClass(z), k && C.isModifiable(z) && C.undoToAncestor(k, R);
            x.setStartAndEnd(S[0], 0, X, X.length), C.normalize && C.postApply(S, x, R, !0), j(E, R);
          }
          l(C.getEmptyElements(x), function(Z) {
            b(Z, C.className);
          });
        },
        undoToRanges: function(x) {
          for (var E = x.length; E--; ) this.undoToRange(x[E], x);
          return x;
        },
        undoToSelection: function(x) {
          var E = i.getSelection(x), C = i.getSelection(x).getAllRanges();
          this.undoToRanges(C), E.setRanges(C);
        },
        isAppliedToRange: function(x) {
          if (x.collapsed || x.toString() == "") return !!this.getSelfOrAncestorWithClass(x.commonAncestorContainer);
          var E = x.getNodes([3]);
          if (E.length) {
            for (var C = 0, R; R = E[C++]; ) if (!this.isIgnorableWhiteSpaceNode(R) && w(x, R) && this.isModifiable(R) && !this.getSelfOrAncestorWithClass(R)) return !1;
          }
          return !0;
        },
        isAppliedToRanges: function(x) {
          var E = x.length;
          if (E == 0) return !1;
          for (; E--; ) if (!this.isAppliedToRange(x[E])) return !1;
          return !0;
        },
        isAppliedToSelection: function(x) {
          var E = i.getSelection(x);
          return this.isAppliedToRanges(E.getAllRanges());
        },
        toggleRange: function(x) {
          this.isAppliedToRange(x) ? this.undoToRange(x) : this.applyToRange(x);
        },
        toggleSelection: function(x) {
          this.isAppliedToSelection(x) ? this.undoToSelection(x) : this.applyToSelection(x);
        },
        getElementsWithClassIntersectingRange: function(x) {
          var E = [], C = this;
          return x.getNodes([3], function(R) {
            var S = C.getSelfOrAncestorWithClass(R);
            S && !s(E, S) && E.push(S);
          }), E;
        },
        detach: function() {
        }
      };
      function Ve(x, E, C) {
        return new Ue(x, E, C);
      }
      Ue.util = {
        hasClass: v,
        addClass: g,
        removeClass: b,
        getClass: _,
        hasSameClasses: W,
        hasAllClasses: B,
        replaceWithOwnChildren: xe,
        elementsHaveSameNonClassAttributes: T,
        elementHasNonClassAttributes: U,
        splitNodeAt: Q,
        isEditableElement: pe,
        isEditingHost: je,
        isEditable: Ge
      }, i.CssClassApplier = i.ClassApplier = Ue, i.createClassApplier = Ve, d.createAliasForDeprecatedMethod(i, "createCssClassApplier", "createClassApplier", t);
    }), e;
  }, o);
})), tn = /* @__PURE__ */ xr(qd()), Do = /* @__PURE__ */ xr(Ra()), pc = nu(), Po = {
  toolbar: {
    allowMultiParagraphSelection: !0,
    buttons: [
      "bold",
      "colorpicker",
      "italic",
      "underline",
      "strikethrough",
      "quote",
      "justifyLeft",
      "justifyCenter",
      "justifyRight",
      "justifyFull",
      "superscript",
      "subscript",
      "orderedlist",
      "unorderedlist",
      "pre",
      "removeFormat",
      "outdent",
      "indent",
      "h2",
      "h3"
    ],
    standardizeSelectionStart: !1,
    updateOnEmptySelection: !1
  },
  placeholder: {
    text: "请输入内容",
    hideOnClick: !0
  },
  disableEditing: !0
};
function Ro(o) {
  var n, e, i = ((n = o == null ? void 0 : o.extensions) === null || n === void 0 ? void 0 : n.button) || ((e = o == null ? void 0 : o.extensions) === null || e === void 0 ? void 0 : e.button), t = (o == null ? void 0 : o.Extension) || (o == null ? void 0 : o.Extension), r = i || t;
  return r ? r.extend({
    name: "colorpicker",
    tagNames: ["mark"],
    contentDefault: "<b>Color</b>",
    aria: "Color Picker",
    action: "colorPicker",
    init: function() {
      var a = this, s, d;
      try {
        Do.default.init();
      } catch (l) {
      }
      try {
        (d = (s = i == null ? void 0 : i.prototype) === null || s === void 0 ? void 0 : s.init) === null || d === void 0 || d.call(this);
      } catch (l) {
      }
      this.colorPicker = new Pa({
        parent: this.button || void 0,
        color: "#000",
        onDone: function(l) {
          var u, c, h, f, p;
          try {
            a.coloredText && (!((c = (u = a.coloredText).isAppliedToSelection) === null || c === void 0) && c.call(u)) && a.coloredText.undoToSelection(), a.coloredText = Do.default.createClassApplier("colored", {
              elementTagName: "span",
              elementProperties: { style: { color: l.hex } },
              normalize: !0
            }), a.coloredText.toggleSelection(), (f = (h = a.base) === null || h === void 0 ? void 0 : h.checkContentChanged) === null || f === void 0 || f.call(h), (p = a.setInactive) === null || p === void 0 || p.call(a);
          } catch (v) {
          }
        }
      });
    },
    getButton: function() {
      return this.button;
    },
    handleClick: function() {
      var a, s, d;
      (a = this.setActive) === null || a === void 0 || a.call(this), (d = (s = this.colorPicker) === null || s === void 0 ? void 0 : s.show) === null || d === void 0 || d.call(s);
    },
    isAlreadyApplied: function(a) {
      var s, d;
      return ((d = (s = a == null ? void 0 : a.nodeName) === null || s === void 0 ? void 0 : s.toLowerCase) === null || d === void 0 ? void 0 : d.call(s)) === "mark";
    },
    isActive: function() {
      var a, s;
      return (s = (a = this.button) === null || a === void 0 ? void 0 : a.classList) === null || s === void 0 ? void 0 : s.contains("medium-editor-button-active");
    },
    setInactive: function() {
      var a, s;
      (s = (a = this.button) === null || a === void 0 ? void 0 : a.classList) === null || s === void 0 || s.remove("medium-editor-button-active");
    },
    setActive: function() {
      var a, s;
      (s = (a = this.button) === null || a === void 0 ? void 0 : a.classList) === null || s === void 0 || s.add("medium-editor-button-active");
    }
  }) : /* @__PURE__ */ (function() {
    function a() {
    }
    return a;
  })();
}
var ru = /* @__PURE__ */ (function() {
  var o = function(n, e) {
    return o = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(i, t) {
      i.__proto__ = t;
    } || function(i, t) {
      for (var r in t) Object.prototype.hasOwnProperty.call(t, r) && (i[r] = t[r]);
    }, o(n, e);
  };
  return function(n, e) {
    if (typeof e != "function" && e !== null) throw new TypeError("Class extends value " + String(e) + " is not a constructor or null");
    o(n, e);
    function i() {
      this.constructor = n;
    }
    n.prototype = e === null ? Object.create(e) : (i.prototype = e.prototype, new i());
  };
})(), ou = function(o, n, e, i) {
  var t = arguments.length, r = t < 3 ? n : i === null ? i = Object.getOwnPropertyDescriptor(n, e) : i, a;
  if (typeof Reflect == "object" && typeof Reflect.decorate == "function") r = Reflect.decorate(o, n, e, i);
  else for (var s = o.length - 1; s >= 0; s--) (a = o[s]) && (r = (t < 3 ? a(r) : t > 3 ? a(n, e, r) : a(n, e)) || r);
  return t > 3 && r && Object.defineProperty(n, e, r), r;
}, Lo = function(o, n) {
  var e = typeof Symbol == "function" && o[Symbol.iterator];
  if (!e) return o;
  var i = e.call(o), t, r = [], a;
  try {
    for (; (n === void 0 || n-- > 0) && !(t = i.next()).done; ) r.push(t.value);
  } catch (s) {
    a = { error: s };
  } finally {
    try {
      t && !t.done && (e = i.return) && e.call(i);
    } finally {
      if (a) throw a.error;
    }
  }
  return r;
}, Io = function(o, n, e) {
  if (e || arguments.length === 2)
    for (var i = 0, t = n.length, r; i < t; i++) (r || !(i in n)) && (r || (r = Array.prototype.slice.call(n, 0, i)), r[i] = n[i]);
  return o.concat(r || Array.prototype.slice.call(n));
}, nn = (function(o) {
  ru(n, o);
  function n(e) {
    var i = o.call(this, e) || this;
    i.labelMap = /* @__PURE__ */ new Map();
    var t = e.lf, r = e.graphModel;
    return i.lf = t, i.graphModel = r, i.state = { tick: 0 }, i;
  }
  return n.prototype.componentDidMount = function() {
    var e = this, i = this.props.graphModel;
    this.editor = new tn.default(".lf-label-editor", Hi(Po, {
      autoLink: !0,
      extensions: { colorPicker: new (Ro(tn.default))() }
    })), i.eventCenter.on("text:update,node:mousemove,node:resize,node:rotate,node:drag,label:drop,node:drop", function() {
    }), i.eventCenter.on("node:properties-change,node:properties-delete", function() {
      e.setState({ tick: e.state.tick + 1 });
    });
  }, n.prototype.componentDidUpdate = function() {
    var e;
    this.editor && this.editor.elements.length > 0 ? this.editor.addElements(".lf-label-editor") : ((e = this.editor) === null || e === void 0 || e.destroy(), this.editor = new tn.default(".lf-label-editor", Hi(Po, {
      autoLink: !0,
      extensions: { colorPicker: new (Ro(tn.default))() }
    })));
  }, n.prototype.componentWillUnmount = function() {
    var e;
    (e = this.editor) === null || e === void 0 || e.destroy();
  }, n.prototype.getLabels = function() {
    var e = this, i = this.props, t = i.lf.extension, r = i.graphModel, a = Io(Io([], Lo(r.nodes), !1), Lo(r.edges), !1);
    if (t.label) {
      var s = [];
      return be(a, function(d) {
        var l, u, c = (u = (l = d.getData().properties) === null || l === void 0 ? void 0 : l._label) !== null && u !== void 0 ? u : [];
        be(c, function(h) {
          var f = e.labelMap, p = new Kd(h, d, r);
          f.set(p.id, p), s.push(Fe(Ud, {
            label: p,
            element: d,
            graphModel: r
          }, p.id));
        });
      }), s;
    }
    return null;
  }, n.prototype.render = function() {
    return Fe("foreignObject", {
      id: "lf-label-overlay",
      class: "lf-label-overlay",
      children: this.getLabels()
    });
  }, n.toolName = "label-edit-tool", n = ou([ea], n), n;
})(Pn), yt = function() {
  return yt = Object.assign || function(o) {
    for (var n, e = 1, i = arguments.length; e < i; e++) {
      n = arguments[e];
      for (var t in n) Object.prototype.hasOwnProperty.call(n, t) && (o[t] = n[t]);
    }
    return o;
  }, yt.apply(this, arguments);
}, vc = (function() {
  function o(n) {
    var e = n.lf, i = n.options, t, r, a;
    this.labelInitPositionMap = /* @__PURE__ */ new Map(), this.lf = e, this.options = i != null ? i : {}, this.textOverflowMode = (t = i.textOverflowMode) !== null && t !== void 0 ? t : "default", this.isMultiple = (r = i.isMultiple) !== null && r !== void 0 ? r : !0, this.labelWidth = i.labelWidth, this.maxCount = (a = i.maxCount) !== null && a !== void 0 ? a : 1 / 0, e.graphModel.editConfigModel.updateTextMode(qt.LABEL), this.addEventListeners(), this.rewriteShortcut(), e.tool.registerTool(nn.toolName, nn), e.tool.disableTool("text-edit-tool");
  }
  return o.prototype.formatConfig = function(n, e) {
    var i = n.editConfigModel, t = i.nodeTextEdit, r = i.edgeTextEdit, a = i.nodeTextDraggable, s = i.edgeTextDraggable, d = this, l = d.textOverflowMode, u = d.isMultiple, c = d.maxCount, h = d.labelWidth, f = e.text, p = e.zIndex, v = e.properties, g = v._label, b = v._labelOption, _ = b === void 0 ? {} : b, D = g, L = _, W = L.isMultiple, B = L.maxCount, K = [];
    if (rn(D)) {
      var Y = B != null ? B : c;
      u && W ? D.length > Y ? K = D.slice(0, Y) : K = D : K = [D[0]];
    } else if (ia(D)) K = [D];
    else if (typeof D == "string" || !D) {
      var te = yt(yt({}, f), {
        content: D || (f == null ? void 0 : f.value),
        draggable: e.BaseType === "edge" ? s : a
      });
      K = te.value ? [te] : [];
    }
    return e.BaseType === "edge" && (K = Jt(K, function(se) {
      return se;
    })), Jt(K, function(se) {
      se.id || (se.id = lr());
      var Le = se.value, ze = se.content, xe = se.vertical, w = se.editable, O = se.draggable, T = se.textOverflowMode, U = e.BaseType === "node" ? t : r, ie = e.BaseType === "node" ? a : s;
      return yt(yt({}, se), {
        zIndex: p,
        labelWidth: h,
        content: ze != null ? ze : Le,
        vertical: xe != null ? xe : !1,
        editable: !!U && w,
        draggable: !!ie && O,
        textOverflowMode: T != null ? T : l
      });
    });
  }, o.prototype.setupLabels = function(n) {
    var e = this, i = n.sortElements;
    be(i, function(t) {
      e.rewriteInnerMethods(t);
      var r = e.formatConfig(n, t);
      t.setProperty("_label", r);
    });
  }, o.prototype.addLabel = function(n, e) {
    var i, t, r, a = this, s = a.isMultiple, d = a.maxCount, l = n.properties, u = l._label, c = l._labelOption, h = (i = u) !== null && i !== void 0 ? i : [], f = (t = c) !== null && t !== void 0 ? t : {}, p = h.length, v = {
      id: lr(),
      x: e.x,
      y: e.y,
      content: "Label".concat(p + 1),
      value: "Label".concat(p + 1),
      style: {},
      draggable: !0,
      editable: !0,
      vertical: !1
    };
    !s || s && f.isMultiple === !1 || p >= ((r = f == null ? void 0 : f.maxCount) !== null && r !== void 0 ? r : d) || (h.push(v), n.setProperty("_label", h));
  }, o.prototype.addEventListeners = function() {
    var n = this, e = this.lf.graphModel, i = e.eventCenter, t = e.editConfigModel;
    i.on("graph:rendered", function(r) {
      var a = r.graphModel;
      n.setupLabels(a);
    }), i.on("node:dbclick,edge:dbclick", function(r) {
      var a = r.e, s = r.data, d = e.getElement(s.id), l = e.getPointByClient({
        x: a.clientX,
        y: a.clientY
      }).canvasOverlayPosition, u = {
        x: l.x,
        y: l.y
      };
      d && t.textMode === qt.LABEL && n.addLabel(d, u);
    }), i.on("node:resize", function(r) {
      var a, s, d = r.preData, l = r.data, u = r.model, c = (a = d.properties) !== null && a !== void 0 ? a : {}, h = c.width, f = c.height, p = c._label, v = p === void 0 ? [] : p, g = (s = l.properties) !== null && s !== void 0 ? s : {}, b = g.width, _ = g.height;
      if (h && f && b && _) {
        var D = {
          x: d.x,
          y: d.y,
          width: h,
          height: f
        }, L = {
          x: l.x,
          y: l.y,
          width: b,
          height: _
        }, W = Jt(v, function(B) {
          var K = B.x, Y = B.y, te = yd(D, L, {
            x: K,
            y: Y
          });
          return yt(yt({}, B), te);
        });
        u.setProperty("_label", W);
      }
    }), i.on("node:rotate", function(r) {
      var a = r.model, s = a.x, d = a.y, l = a.rotate, u = a.properties._label, c = u === void 0 ? [] : u, h = {
        x: s,
        y: d
      }, f = Jt(c, function(p) {
        if (!p.id) return p;
        var v = {
          x: p.x,
          y: p.y
        };
        n.labelInitPositionMap.has(p.id) ? v = n.labelInitPositionMap.get(p.id) : n.labelInitPositionMap.set(p.id, v);
        var g = l * (180 / Math.PI);
        g < 0 && (g += 360);
        var b = g * (Math.PI / 180), _ = Aa(v, h, b);
        return yt(yt(yt({}, p), _), { rotate: g });
      });
      a.setProperty("_label", f);
    }), i.on("node:dnd-add,node:add,edge:add", function(r) {
      var a = r.data, s = e.getElement(a.id);
      if (s) {
        n.rewriteInnerMethods(s);
        var d = s.properties._label;
        if (!rn(d) || d.length === 0 || !d[0].id) {
          var l = n.formatConfig(e, a);
          s.setProperty("_label", l);
        }
      }
    });
  }, o.prototype.rewriteInnerMethods = function(n) {
    n.moveText = function(e, i) {
      if (n.text) {
        var t = n.text, r = t.x, a = t.y, s = t.value, d = t.draggable;
        n.text = {
          value: s,
          editable: t.editable,
          draggable: d,
          x: r + e,
          y: a + i
        };
        var l = ft(n.getProperties());
        if (rn(l._label)) {
          var u = Jt(l._label, function(c) {
            return yt(yt({}, c), {
              x: c.x + e,
              y: c.y + i
            });
          });
          n == null || n.setProperty("_label", u);
        }
      }
    };
  }, o.prototype.rewriteShortcut = function() {
    var n = this, e = this.lf, i = e.keyboard, t = e.graphModel, r = i.options.keyboard;
    i.off(["backspace"]), i.on(["backspace"], function() {
      if (!(r != null && r.enabled) || t.textEditElement) return !0;
      var a = t.getSelectElements(!0);
      n.lf.clearSelectElements();
      var s = n.lf.graphModel.editConfigModel;
      return a.edges.forEach(function(d) {
        var l = d.properties;
        if (l && !ti(l._label) && s.textMode === qt.LABEL) {
          var u = l._label.filter(function(h) {
            return !h.isSelected;
          });
          if (!_t(u.length, l._label.length)) {
            var c = t.getEdgeModelById(d.id);
            c == null || c.setProperty("_label", u);
            return;
          }
        }
        d.id && n.lf.deleteEdge(d.id);
      }), a.nodes.forEach(function(d) {
        var l = d.properties;
        if (l && !ti(l._label) && s.textMode === qt.LABEL) {
          var u = l._label.filter(function(h) {
            return !h.isSelected;
          });
          if (!_t(u.length, l._label.length)) {
            var c = t.getNodeModelById(d.id);
            c == null || c.setProperty("_label", u);
            return;
          }
        }
        d.id && n.lf.deleteNode(d.id);
      }), !1;
    });
  }, o.prototype.updateTextMode = function(n) {
    var e = this.lf.graphModel.editConfigModel;
    n !== e.textMode && (e.updateTextMode(n), n === qt.LABEL ? (this.lf.tool.enableTool(nn.toolName), this.lf.tool.disableTool("text-edit-tool")) : n === qt.TEXT && (this.lf.tool.enableTool("text-edit-tool"), this.lf.tool.disableTool(nn.toolName)));
  }, o.prototype.render = function() {
  }, o.prototype.destroy = function() {
  }, o.pluginName = "label", o;
})(), kn = function(o, n, e, i) {
  function t(r) {
    return r instanceof e ? r : new e(function(a) {
      a(r);
    });
  }
  return new (e || (e = Promise))(function(r, a) {
    function s(u) {
      try {
        l(i.next(u));
      } catch (c) {
        a(c);
      }
    }
    function d(u) {
      try {
        l(i.throw(u));
      } catch (c) {
        a(c);
      }
    }
    function l(u) {
      u.done ? r(u.value) : t(u.value).then(s, d);
    }
    l((i = i.apply(o, n || [])).next());
  });
}, Bn = function(o, n) {
  var e = {
    label: 0,
    sent: function() {
      if (r[0] & 1) throw r[1];
      return r[1];
    },
    trys: [],
    ops: []
  }, i, t, r, a;
  return a = {
    next: s(0),
    throw: s(1),
    return: s(2)
  }, typeof Symbol == "function" && (a[Symbol.iterator] = function() {
    return this;
  }), a;
  function s(l) {
    return function(u) {
      return d([l, u]);
    };
  }
  function d(l) {
    if (i) throw new TypeError("Generator is already executing.");
    for (; a && (a = 0, l[0] && (e = 0)), e; ) try {
      if (i = 1, t && (r = l[0] & 2 ? t.return : l[0] ? t.throw || ((r = t.return) && r.call(t), 0) : t.next) && !(r = r.call(t, l[1])).done) return r;
      switch (t = 0, r && (l = [l[0] & 2, r.value]), l[0]) {
        case 0:
        case 1:
          r = l;
          break;
        case 4:
          return e.label++, {
            value: l[1],
            done: !1
          };
        case 5:
          e.label++, t = l[1], l = [0];
          continue;
        case 7:
          l = e.ops.pop(), e.trys.pop();
          continue;
        default:
          if (r = e.trys, !(r = r.length > 0 && r[r.length - 1]) && (l[0] === 6 || l[0] === 2)) {
            e = 0;
            continue;
          }
          if (l[0] === 3 && (!r || l[1] > r[0] && l[1] < r[3])) {
            e.label = l[1];
            break;
          }
          if (l[0] === 6 && e.label < r[1]) {
            e.label = r[1], r = l;
            break;
          }
          if (r && e.label < r[2]) {
            e.label = r[2], e.ops.push(l);
            break;
          }
          r[2] && e.ops.pop(), e.trys.pop();
          continue;
      }
      l = n.call(o, e);
    } catch (u) {
      l = [6, u], t = 0;
    } finally {
      i = r = 0;
    }
    if (l[0] & 5) throw l[1];
    return {
      value: l[0] ? l[1] : void 0,
      done: !0
    };
  }
}, au = function(o, n) {
  var e = typeof Symbol == "function" && o[Symbol.iterator];
  if (!e) return o;
  var i = e.call(o), t, r = [], a;
  try {
    for (; (n === void 0 || n-- > 0) && !(t = i.next()).done; ) r.push(t.value);
  } catch (s) {
    a = { error: s };
  } finally {
    try {
      t && !t.done && (e = i.return) && e.call(i);
    } finally {
      if (a) throw a.error;
    }
  }
  return r;
}, su = function(o, n, e) {
  if (e || arguments.length === 2)
    for (var i = 0, t = n.length, r; i < t; i++) (r || !(i in n)) && (r || (r = Array.prototype.slice.call(n, 0, i)), r[i] = n[i]);
  return o.concat(r || Array.prototype.slice.call(n));
}, Pi = {};
function La(o) {
  return o.startsWith("data:text/plain");
}
function Ia(o) {
  return kn(this, void 0, void 0, function() {
    return Bn(this, function(n) {
      return Pi[o] ? [2, Pi[o]] : [2, new Promise(function(e, i) {
        try {
          fetch(o).then(function(t) {
            return t.blob();
          }).then(function(t) {
            var r = new FileReader();
            r.onloadend = function() {
              e(Pi[o] = r.result);
            }, r.onerror = i, r.readAsDataURL(t);
          }).catch(function() {
            e(Pi[o] = o);
          });
        } catch (t) {
          return Pi[o] = o;
        }
      })];
    });
  });
}
function ko(o, n) {
  return kn(this, void 0, void 0, function() {
    var e, i, t;
    return Bn(this, function(r) {
      switch (r.label) {
        case 0:
          return r.trys.push([
            0,
            2,
            ,
            3
          ]), e = o.getAttribute(n) || "", e.startsWith("data:") ? [2] : [4, Ia(e)];
        case 1:
          return i = r.sent(), La(i) ? [2] : (o.setAttribute(n, i), [3, 3]);
        case 2:
          return t = r.sent(), [3, 3];
        case 3:
          return [2];
      }
    });
  });
}
function Bo(o, n) {
  return kn(this, void 0, void 0, function() {
    var e, i;
    return Bn(this, function(t) {
      switch (t.label) {
        case 0:
          return t.trys.push([
            0,
            2,
            ,
            3
          ]), n.startsWith("data:") ? [2] : [4, Ia(n)];
        case 1:
          return e = t.sent(), La(e) ? [2] : (o.style.backgroundImage = "url(".concat(e, ")"), [3, 3]);
        case 2:
          return i = t.sent(), [3, 3];
        case 3:
          return [2];
      }
    });
  });
}
function Zn(o) {
  return kn(this, void 0, void 0, function() {
    var n, e, i, t, r, a, s, l, d, l;
    return Bn(this, function(u) {
      switch (u.label) {
        case 0:
          for (n = [o], i = []; n.length; )
            e = n.shift(), e.children.length && n.push.apply(n, su([], au(e.children), !1)), e instanceof HTMLElement && (t = e.style, r = t.background, a = t.backgroundImage, s = r.match(/url\(["']?(.*?)["']?\)/), s && s[1] && (l = s[1], i.push(Bo(e, l))), d = a.match(/url\(["']?(.*?)["']?\)/), d && d[1] && (l = d[1], i.push(Bo(e, l)))), e instanceof HTMLImageElement ? i.push(ko(e, "src")) : e instanceof SVGImageElement && i.push(ko(e, "href"));
          return [4, Promise.all(i)];
        case 1:
          return u.sent(), [2];
      }
    });
  });
}
function Ri(o, n, e) {
  var i = document.createElement("canvas");
  i.width = n, i.height = e;
  var t = i.getContext("2d");
  return t && t.drawImage(o, 0, 0, o.width, o.height, 0, 0, n, e), i;
}
var Tn = function() {
  return Tn = Object.assign || function(o) {
    for (var n, e = 1, i = arguments.length; e < i; e++) {
      n = arguments[e];
      for (var t in n) Object.prototype.hasOwnProperty.call(n, t) && (o[t] = n[t]);
    }
    return o;
  }, Tn.apply(this, arguments);
}, nt = function(o, n, e, i) {
  function t(r) {
    return r instanceof e ? r : new e(function(a) {
      a(r);
    });
  }
  return new (e || (e = Promise))(function(r, a) {
    function s(u) {
      try {
        l(i.next(u));
      } catch (c) {
        a(c);
      }
    }
    function d(u) {
      try {
        l(i.throw(u));
      } catch (c) {
        a(c);
      }
    }
    function l(u) {
      u.done ? r(u.value) : t(u.value).then(s, d);
    }
    l((i = i.apply(o, n || [])).next());
  });
}, rt = function(o, n) {
  var e = {
    label: 0,
    sent: function() {
      if (r[0] & 1) throw r[1];
      return r[1];
    },
    trys: [],
    ops: []
  }, i, t, r, a;
  return a = {
    next: s(0),
    throw: s(1),
    return: s(2)
  }, typeof Symbol == "function" && (a[Symbol.iterator] = function() {
    return this;
  }), a;
  function s(l) {
    return function(u) {
      return d([l, u]);
    };
  }
  function d(l) {
    if (i) throw new TypeError("Generator is already executing.");
    for (; a && (a = 0, l[0] && (e = 0)), e; ) try {
      if (i = 1, t && (r = l[0] & 2 ? t.return : l[0] ? t.throw || ((r = t.return) && r.call(t), 0) : t.next) && !(r = r.call(t, l[1])).done) return r;
      switch (t = 0, r && (l = [l[0] & 2, r.value]), l[0]) {
        case 0:
        case 1:
          r = l;
          break;
        case 4:
          return e.label++, {
            value: l[1],
            done: !1
          };
        case 5:
          e.label++, t = l[1], l = [0];
          continue;
        case 7:
          l = e.ops.pop(), e.trys.pop();
          continue;
        default:
          if (r = e.trys, !(r = r.length > 0 && r[r.length - 1]) && (l[0] === 6 || l[0] === 2)) {
            e = 0;
            continue;
          }
          if (l[0] === 3 && (!r || l[1] > r[0] && l[1] < r[3])) {
            e.label = l[1];
            break;
          }
          if (l[0] === 6 && e.label < r[1]) {
            e.label = r[1], r = l;
            break;
          }
          if (r && e.label < r[2]) {
            e.label = r[2], e.ops.push(l);
            break;
          }
          r[2] && e.ops.pop(), e.trys.pop();
          continue;
      }
      l = n.call(o, e);
    } catch (u) {
      l = [6, u], t = 0;
    } finally {
      i = r = 0;
    }
    if (l[0] & 5) throw l[1];
    return {
      value: l[0] ? l[1] : void 0,
      done: !0
    };
  }
}, gc = (function() {
  function o(n) {
    var e = n.lf, i = this;
    this.lf = e, this.customCssRules = "", this.useGlobalRules = !0, e.getSnapshot = function(t, r) {
      return nt(i, void 0, void 0, function() {
        return rt(this, function(a) {
          switch (a.label) {
            case 0:
              return [4, this.getSnapshot(t, r)];
            case 1:
              return [2, a.sent()];
          }
        });
      });
    }, e.getSnapshotBlob = function(t, r, a) {
      return nt(i, void 0, void 0, function() {
        return rt(this, function(s) {
          switch (s.label) {
            case 0:
              return [4, this.getSnapshotBlob(t, r, a)];
            case 1:
              return [2, s.sent()];
          }
        });
      });
    }, e.getSnapshotBase64 = function(t, r, a) {
      return nt(i, void 0, void 0, function() {
        return rt(this, function(s) {
          switch (s.label) {
            case 0:
              return [4, this.getSnapshotBase64(t, r, a)];
            case 1:
              return [2, s.sent()];
          }
        });
      });
    };
  }
  return o.prototype.getSvgRootElement = function(n) {
    return n.container.querySelector(".lf-canvas-overlay");
  }, o.prototype.triggerDownload = function(n) {
    var e = new MouseEvent("click", {
      view: document.defaultView,
      bubbles: !1,
      cancelable: !0
    }), i = document.createElement("a");
    i.setAttribute("download", this.fileName), i.setAttribute("href", n), i.setAttribute("target", "_blank"), i.dispatchEvent(e);
  }, o.prototype.removeAnchor = function(n) {
    for (var e = n.childNodes, i = n.childNodes && n.childNodes.length, t = 0; t < i; t++) {
      var r = e[t];
      (r.classList && Array.from(r.classList) || []).indexOf("lf-anchor") > -1 && (n.removeChild(n.childNodes[t]), i--, t--);
    }
  }, o.prototype.removeRotateControl = function(n) {
    for (var e = n.childNodes, i = n.childNodes && n.childNodes.length, t = 0; t < i; t++) {
      var r = e[t];
      (r.classList && Array.from(r.classList) || []).indexOf("lf-rotate-control") > -1 && (n.removeChild(n.childNodes[t]), i--, t--);
    }
  }, o.prototype.convertImageToBase64 = function(n) {
    return nt(this, void 0, void 0, function() {
      return rt(this, function(e) {
        return [2, new Promise(function(i, t) {
          var r = new Image();
          r.crossOrigin = "anonymous", r.onload = function() {
            var a = document.createElement("canvas");
            a.width = r.width, a.height = r.height;
            var s = a.getContext("2d");
            s == null || s.drawImage(r, 0, 0), i(a.toDataURL("image/png"));
          }, r.onerror = function() {
            t(new Error("Failed to load image: ".concat(n)));
          }, r.src = n;
        })];
      });
    });
  }, o.prototype.isRelativePath = function(n) {
    return !n.startsWith("data:") && !n.startsWith("http://") && !n.startsWith("https://") && !n.startsWith("//");
  }, o.prototype.processImages = function(n) {
    return nt(this, void 0, void 0, function() {
      var e, a, u, i, h, t, r, a, s, d, l, u, c, h, f;
      return rt(this, function(p) {
        switch (p.label) {
          case 0:
            e = n.getElementsByTagName("image"), a = 0, p.label = 1;
          case 1:
            if (!(a < e.length)) return [3, 6];
            if (u = e[a], i = u.getAttributeNS("http://www.w3.org/1999/xlink", "href") || u.getAttribute("href"), !(i && this.isRelativePath(i))) return [3, 5];
            p.label = 2;
          case 2:
            return p.trys.push([
              2,
              4,
              ,
              5
            ]), [4, this.convertImageToBase64(i)];
          case 3:
            return h = p.sent(), u.setAttributeNS("http://www.w3.org/1999/xlink", "href", h), u.setAttribute("href", h), [3, 5];
          case 4:
            return t = p.sent(), [3, 5];
          case 5:
            return a++, [3, 1];
          case 6:
            r = n.getElementsByTagName("foreignObject"), a = 0, p.label = 7;
          case 7:
            if (!(a < r.length)) return [3, 14];
            s = r[a], d = s.getElementsByTagName("img"), l = 0, p.label = 8;
          case 8:
            if (!(l < d.length)) return [3, 13];
            if (u = d[l], c = u.getAttribute("src"), !(c && this.isRelativePath(c))) return [3, 12];
            p.label = 9;
          case 9:
            return p.trys.push([
              9,
              11,
              ,
              12
            ]), [4, this.convertImageToBase64(c)];
          case 10:
            return h = p.sent(), u.setAttribute("src", h), [3, 12];
          case 11:
            return f = p.sent(), [3, 12];
          case 12:
            return l++, [3, 8];
          case 13:
            return a++, [3, 7];
          case 14:
            return [2];
        }
      });
    });
  }, o.prototype.cloneSvg = function(n) {
    return nt(this, arguments, void 0, function(e, i) {
      var t, r, a, s, d, l, u, c, h, f = this, p;
      return i === void 0 && (i = !0), rt(this, function(v) {
        switch (v.label) {
          case 0:
            if (t = e.cloneNode(!0), r = t.lastChild, a = (p = r == null ? void 0 : r.childNodes) === null || p === void 0 ? void 0 : p.length, a) for (s = 0; s < a; s++)
              d = r == null ? void 0 : r.childNodes[s], l = d.classList && Array.from(d.classList), l && l.indexOf("lf-base") < 0 ? (r == null || r.removeChild(r.childNodes[s]), a--, s--) : (u = r == null ? void 0 : r.childNodes[s], u && u.childNodes.forEach(function(g) {
                var b = g;
                f.removeAnchor(b.firstChild), f.removeRotateControl(b.firstChild);
              }));
            return [4, this.processImages(t)];
          case 1:
            return v.sent(), i && (c = document.createElement("style"), c.innerHTML = this.getClassRules(), h = document.createElement("foreignObject"), h.appendChild(c), t.appendChild(h)), [2, t];
        }
      });
    });
  }, o.prototype.getClassRules = function() {
    var n = "";
    if (this.useGlobalRules)
      for (var e = document.styleSheets, i = 0; i < e.length; i++) {
        var t = e[i];
        try {
          for (var r = 0; r < t.cssRules.length; r++) n += t.cssRules[r].cssText;
        } catch (a) {
        }
      }
    return this.customCssRules && (n += this.customCssRules), n;
  }, o.prototype.getCanvasScaleRatio = function(n, e) {
    var i = 32767, t = 268435456, r = n * e;
    if (n <= i && e <= i && r <= t) return 1;
    var a = i / n, s = i / e, d = t / r;
    return Math.min(a, s, d);
  }, o.prototype.getCanvasData = function(n, e) {
    return nt(this, void 0, void 0, function() {
      var i, t, r, a, s, d, l, u, c, h, f, p, v, g, b, _, D, L, W, B, K, Y, te, se, Le, ze, xe, w, O, T, U, ie, pe, je, Ge;
      return rt(this, function(vt) {
        switch (vt.label) {
          case 0:
            return i = e.width, t = e.height, r = e.backgroundColor, a = e.padding, s = a === void 0 ? 40 : a, [4, this.cloneSvg(n, !1)];
          case 1:
            return d = vt.sent(), l = window.devicePixelRatio || 1, l < 1 && (l = 1), u = this.lf.graphModel.rootEl.querySelector(".lf-base"), c = u.getBoundingClientRect(), h = this.lf.container.querySelector(".lf-canvas-overlay"), f = h.getBoundingClientRect(), p = c.x - f.x, v = c.y - f.y, g = this.lf.graphModel, b = g.transformModel, _ = b.SCALE_X, D = b.SCALE_Y, L = b.TRANSLATE_X, W = b.TRANSLATE_Y, B = e.safetyFactor || 1, K = c.width / _, Y = c.height / D, te = K * (B - 1), se = Y * (B - 1), Le = Math.ceil(K + te), ze = Math.ceil(Y + se), xe = document.createElement("canvas"), xe.style.width = "".concat(Le, "px"), xe.style.height = "".concat(ze, "px"), w = e.safetyMargin || 0, O = Le * l, T = ze * l, U = this.getCanvasScaleRatio(O, T), U < 1 && (O = Math.floor(O * U), T = Math.floor(T * U)), d.lastChild.style.transform = "matrix(".concat(U, ", 0, 0, ").concat(U, ", ").concat((-p + L) * (1 / _) * U + s + te / 2 + w, ", ").concat((-v + W) * (1 / D) * U + s + se / 2 + w, ")"), xe.width = O + (s + w) * 2 * l, xe.height = T + (s + w) * 2 * l, ie = xe.getContext("2d"), ie && (ie.clearRect(0, 0, xe.width, xe.height), ie.scale(l, l), r ? (ie.fillStyle = r, ie.fillRect(0, 0, xe.width, xe.height)) : ie.clearRect(0, 0, xe.width, xe.height)), pe = new Image(), je = document.createElement("style"), je.innerHTML = this.getClassRules(), Ge = document.createElement("foreignObject"), Ge.appendChild(je), d.appendChild(Ge), [2, new Promise(function(dt) {
              pe.onload = function() {
                var Ye = navigator.userAgent.indexOf("Firefox") > -1;
                try {
                  Ye ? createImageBitmap(pe, {
                    resizeWidth: i && t ? Ri(xe, i, t).width : xe.width,
                    resizeHeight: i && t ? Ri(xe, i, t).height : xe.height
                  }).then(function(N) {
                    ie == null || ie.drawImage(N, 0, 0), dt(i && t ? Ri(xe, i, t) : xe);
                  }) : (ie == null || ie.drawImage(pe, 0, 0), dt(i && t ? Ri(xe, i, t) : xe));
                } catch (N) {
                  ie == null || ie.drawImage(pe, 0, 0), dt(i && t ? Ri(xe, i, t) : xe);
                }
              };
              var Nt = "data:image/svg+xml;charset=utf-8,".concat(new XMLSerializer().serializeToString(d)).replace(/\n/g, "").replace(/\t/g, "").replace(/#/g, "%23");
              pe.src = Nt;
            })];
        }
      });
    });
  }, o.prototype.withExportPreparation = function(n, e) {
    return nt(this, void 0, void 0, function() {
      var i, t, r, a, s, d = this;
      return rt(this, function(l) {
        switch (l.label) {
          case 0:
            i = this.lf.graphModel.getPartial(), t = (e != null ? e : {}).partial, r = t === void 0 ? i : t, a = this.lf.getEditConfig(), this.lf.updateEditConfig({
              isSilentMode: !0,
              stopScrollGraph: !0,
              stopMoveGraph: !0
            }), l.label = 1;
          case 1:
            return l.trys.push([
              1,
              ,
              6,
              7
            ]), i === r ? [3, 3] : (this.lf.graphModel.setPartial(r), [4, new Promise(function(u) {
              d.lf.graphModel.eventCenter.once("graph:updated", function() {
                return nt(d, void 0, void 0, function() {
                  var c;
                  return rt(this, function(h) {
                    switch (h.label) {
                      case 0:
                        return [4, n()];
                      case 1:
                        return c = h.sent(), this.lf.graphModel.setPartial(i), u(c), [2];
                    }
                  });
                });
              });
            })]);
          case 2:
            return s = l.sent(), [3, 5];
          case 3:
            return [4, n()];
          case 4:
            s = l.sent(), l.label = 5;
          case 5:
            return [3, 7];
          case 6:
            return this.lf.updateEditConfig(a), [7];
          case 7:
            return [2, s];
        }
      });
    });
  }, o.prototype.getSnapshot = function(n, e) {
    return nt(this, void 0, void 0, function() {
      var i = this;
      return rt(this, function(t) {
        switch (t.label) {
          case 0:
            return [4, this.withExportPreparation(function() {
              return i.snapshot(n, e);
            }, e)];
          case 1:
            return t.sent(), [2];
        }
      });
    });
  }, o.prototype.snapshot = function(n, e) {
    return nt(this, void 0, void 0, function() {
      var i, t, r, a, s, d, l, u, c, h = this;
      return rt(this, function(f) {
        switch (f.label) {
          case 0:
            return i = e != null ? e : {}, t = i.fileType, r = t === void 0 ? "png" : t, a = i.quality, this.fileName = "".concat(n != null ? n : "logic-flow.".concat(Date.now()), ".").concat(r), s = this.getSvgRootElement(this.lf), [4, Zn(s)];
          case 1:
            return f.sent(), r !== "svg" ? [3, 3] : [4, this.cloneSvg(s)];
          case 2:
            return d = f.sent(), l = new XMLSerializer().serializeToString(d), u = new Blob([l], { type: "image/svg+xml;charset=utf-8" }), c = URL.createObjectURL(u), this.triggerDownload(c), [3, 4];
          case 3:
            this.getCanvasData(s, e != null ? e : {}).then(function(p) {
              var v = p.toDataURL("image/".concat(r), a).replace("image/".concat(r), "image/octet-stream");
              h.triggerDownload(v);
            }), f.label = 4;
          case 4:
            return [2];
        }
      });
    });
  }, o.prototype.getSnapshotBlob = function(n, e, i) {
    return nt(this, void 0, void 0, function() {
      var t = this;
      return rt(this, function(r) {
        switch (r.label) {
          case 0:
            return [4, this.withExportPreparation(function() {
              return t.snapshotBlob(i, e, n);
            }, i)];
          case 1:
            return [2, r.sent()];
        }
      });
    });
  }, o.prototype.snapshotBlob = function(n, e, i) {
    return nt(this, void 0, void 0, function() {
      var t, r, a, s, d, l, u = this;
      return rt(this, function(c) {
        switch (c.label) {
          case 0:
            return t = (n != null ? n : {}).fileType, r = t === void 0 ? e : t, a = this.getSvgRootElement(this.lf), [4, Zn(a)];
          case 1:
            return c.sent(), r !== "svg" ? [3, 3] : [4, this.cloneSvg(a)];
          case 2:
            return s = c.sent(), d = new XMLSerializer().serializeToString(s), l = new Blob([d], { type: "image/svg+xml;charset=utf-8" }), [2, {
              data: l,
              width: 0,
              height: 0
            }];
          case 3:
            return [2, new Promise(function(h) {
              u.getCanvasData(a, Tn({ backgroundColor: i }, n != null ? n : {})).then(function(f) {
                f.toBlob(function(p) {
                  h({
                    data: p,
                    width: f.width,
                    height: f.height
                  });
                }, "image/".concat(r != null ? r : "png"));
              });
            })];
        }
      });
    });
  }, o.prototype.getSnapshotBase64 = function(n, e, i) {
    return nt(this, void 0, void 0, function() {
      var t = this;
      return rt(this, function(r) {
        switch (r.label) {
          case 0:
            return [4, this.withExportPreparation(function() {
              return t._getSnapshotBase64(n, e, i);
            }, i)];
          case 1:
            return [2, r.sent()];
        }
      });
    });
  }, o.prototype._getSnapshotBase64 = function(n, e, i) {
    return nt(this, void 0, void 0, function() {
      var t, r, a, s = this;
      return rt(this, function(d) {
        switch (d.label) {
          case 0:
            return t = (i != null ? i : {}).fileType, r = t === void 0 ? e : t, a = this.getSvgRootElement(this.lf), [4, Zn(a)];
          case 1:
            return d.sent(), [2, new Promise(function(l) {
              s.getCanvasData(a, Tn({ backgroundColor: n }, i != null ? i : {})).then(function(u) {
                l({
                  data: u.toDataURL("image/".concat(r != null ? r : "png")),
                  width: u.width,
                  height: u.height
                });
              });
            })];
        }
      });
    });
  }, o.pluginName = "snapshot", o;
})(), Li = function(o, n) {
  var e = typeof Symbol == "function" && o[Symbol.iterator];
  if (!e) return o;
  var i = e.call(o), t, r = [], a;
  try {
    for (; (n === void 0 || n-- > 0) && !(t = i.next()).done; ) r.push(t.value);
  } catch (s) {
    a = { error: s };
  } finally {
    try {
      t && !t.done && (e = i.return) && e.call(i);
    } finally {
      if (a) throw a.error;
    }
  }
  return r;
}, pi = function(o, n, e) {
  if (e || arguments.length === 2)
    for (var i = 0, t = n.length, r; i < t; i++) (r || !(i in n)) && (r || (r = Array.prototype.slice.call(n, 0, i)), r[i] = n[i]);
  return o.concat(r || Array.prototype.slice.call(n));
}, mc = (function() {
  function o(n) {
    var e = n.lf, i = this;
    this.lf = e, this.paths = [], e.getPathes = function() {
      if (!i.startNodeType) throw new Error("需要预先指定开始节点类型");
      return i.getPathes();
    }, e.setRawPaths = function(t) {
      i.setPathes(t);
    }, e.getRawPathes = function() {
      return i.paths;
    }, e.setStartNodeType = function(t) {
      i.startNodeType = t;
    };
  }
  return o.prototype.setPathes = function(n) {
    this.paths = n.map(function(e) {
      return {
        routeId: e.routeId,
        name: e.name,
        elements: e.elements,
        type: e.type,
        similarElement: null,
        weight: 0
      };
    });
  }, o.prototype.getPathes = function() {
    var n = this, e = this.lf.getGraphRawData(), i = /* @__PURE__ */ new Map(), t = [];
    e.nodes.forEach(function(a) {
      i.set(a.id, {
        id: a.id,
        data: a,
        nextNodes: []
      }), a.type === n.startNodeType && t.push(a.id);
    }), e.edges.forEach(function(a) {
      var s = i.get(a.sourceNodeId);
      s == null || s.nextNodes.push(a.targetNodeId);
    });
    var r = [];
    return t.forEach(function(a) {
      var s = i.get(a);
      s && (r = r.concat(n.findPathElements(s, i, [])));
    }), this.getNewPathes(r);
  }, o.prototype.findPathElements = function(n, e, i) {
    i === void 0 && (i = []);
    var t = pi([], Li(i), !1);
    if (t.push(n.id), n.nextNodes.length === 0) return [t];
    for (var r = [], a = 0; a < n.nextNodes.length; a++) {
      var s = e.get(n.nextNodes[a]), d = void 0;
      if (s) {
        var l = t.indexOf(s.id);
        l !== -1 ? d = [pi(pi([], Li(t.slice(l)), !1), [s.id], !1)] : d = this.findPathElements(s, e, pi([], Li(t), !1)), r = r.concat(d);
      }
    }
    return r;
  }, o.prototype.getNewPathes = function(n) {
    var e = this, i = [], t = /* @__PURE__ */ new Set();
    n.forEach(function(a) {
      var s = e.getNewId("path"), d = e.getNewId("路径"), l = e.isLoopPath(a), u = a.join(",");
      t.has(u) || (t.add(u), i.push({
        routeId: s,
        name: d,
        elements: a,
        type: l,
        weight: 0,
        similarElement: ""
      }));
    });
    var r = JSON.parse(JSON.stringify(this.paths));
    return i.forEach(function(a) {
      for (var s = 0; s < r.length; s++) {
        var d = r[s], l = e.similar2Path(pi([], Li(a.elements), !1), pi([], Li(d.elements), !1));
        l > a.weight && d.weight <= l && (a.weight = l, a.similarElement = d, l === d.weight && d.similarElement ? (d.similarElement.similarElement = null, d.similarElement.weight = 0, d.similarElement = null, d.weight = 0) : (d.similarElement = a, d.weight = l));
      }
    }), i.forEach(function(a) {
      a.similarElement && a.similarElement.similarElement === a && (a.routeId = a.similarElement.routeId, a.name = a.similarElement.name), delete a.similarElement, delete a.weight;
    }), this.setPathes(i), i;
  }, o.prototype.similar2Path = function(n, e) {
    var i = 0, t = n.length + e.length;
    n.sort(), e.sort();
    for (var r = n.shift(), a = e.shift(); r !== void 0 && a !== void 0; ) r === a ? (i++, r = n.shift(), a = e.shift()) : r < a ? r = n.shift() : r > a && (a = e.shift());
    return i / t * 200;
  }, o.prototype.getNewId = function(n) {
    return "".concat(n, "_").concat(ri());
  }, o.prototype.isLoopPath = function(n) {
    var e = n.length;
    return n.indexOf(n[e - 1]) !== e - 1 ? 1 : 0;
  }, o.pluginName = "flowPath", o;
})(), $i = function() {
  return $i = Object.assign || function(o) {
    for (var n, e = 1, i = arguments.length; e < i; e++) {
      n = arguments[e];
      for (var t in n) Object.prototype.hasOwnProperty.call(n, t) && (o[t] = n[t]);
    }
    return o;
  }, $i.apply(this, arguments);
}, Jn = {
  LEFT_TOP: -1,
  LEFT: 0,
  LEFT_BOTTOM: 1
}, yc = (function() {
  function o(n) {
    var e = n.lf, i = this;
    this.levelHeight = [], this.newNodeMap = /* @__PURE__ */ new Map(), this.lf = e, this.trunk = [], e.layout = function(t) {
      var r = i.lf.getGraphRawData();
      i.lf.setStartNodeType(t);
      var a = i.lf.getPathes();
      return i.levelHeight = [], i.newNodeMap = /* @__PURE__ */ new Map(), i.layout(r, a);
    };
  }
  return o.prototype.layout = function(n, e) {
    var i = this, t = [];
    e.forEach(function(d) {
      var l = d.elements;
      l.length > t.length ? t = l : l.length === t.length && JSON.stringify(l) === JSON.stringify(i.trunk) && (t = i.trunk);
    }), this.trunk = t;
    for (var r = this.formatData(n), a = {
      nodes: [],
      edges: []
    }, s = t.length - 1; s >= 0; s--) this.setNodePosition(t[s], r, a, s, 1);
    this.lf.graphModel.graphDataToModel(a);
  }, o.prototype.setNodePosition = function(n, e, i, t, r) {
    var a = this, s = e[n], d = s.text, l = s.type, u = s.next, c = s.properties, h = t * 160 + 40, f = r * 120, p = {
      id: n,
      x: h,
      text: d,
      y: f,
      type: l,
      properties: c
    };
    return d && typeof d == "object" && (p.text = $i($i({}, d), {
      x: h + d.x,
      y: f + d.y
    })), this.newNodeMap.set(p.id, {
      x: p.x,
      y: p.y,
      type: l
    }), i.nodes.push(p), s.isFixed = !0, this.addLevelHeight(t, 1), u && u.length > 0 && u.forEach(function(v) {
      if (!e[v.nodeId].isFixed) {
        var g = a.getLevelHeight(t + 1);
        a.addLevelHeight(t, 1), a.setNodePosition(v.nodeId, e, i, t + 1, g + 1);
      }
      i.edges.push($i({
        id: v.edgeId,
        type: v.edgeType,
        sourceNodeId: n,
        targetNodeId: v.nodeId,
        properties: v.properties,
        text: v.text
      }, a.getEdgeDataPoints(n, v.nodeId)));
    }), p;
  }, o.prototype.getEdgeDataPoints = function(n, e) {
    var i = this.newNodeMap.get(n), t = this.newNodeMap.get(e), r = this.getShape(n), a = r.width, s = r.height, d = this.getShape(e), l = d.width, u = d.height, c = this.getRelativePosition(i, t), h = {
      x: i.x,
      y: i.y
    }, f = {
      x: t.x,
      y: t.y
    };
    switch (c) {
      case Jn.LEFT:
        h.x = i.x + a / 2, f.x = t.x - l / 2;
        break;
      case Jn.LEFT_TOP:
        h.y = i.y + s / 2, f.x = t.x - l / 2;
        break;
      case Jn.LEFT_BOTTOM:
        h.x = i.x + a / 2, f.y = t.y + u / 2;
    }
    return {
      startPoint: h,
      endPoint: f
    };
  }, o.prototype.getRelativePosition = function(n, e) {
    var i = n.y, t = e.y, r;
    return i < t ? r = -1 : i === t ? r = 0 : r = 1, r;
  }, o.prototype.getShape = function(n) {
    var e, i, t = this.lf.getNodeModelById(n);
    return {
      height: (e = t == null ? void 0 : t.height) !== null && e !== void 0 ? e : 0,
      width: (i = t == null ? void 0 : t.width) !== null && i !== void 0 ? i : 0
    };
  }, o.prototype.formatData = function(n) {
    var e = n.nodes.reduce(function(i, t) {
      var r = t.type, a = t.properties, s = t.text, d = t.x, l = t.y;
      return s && typeof s == "object" && (s.x = s.x - d, s.y = s.y - l), i[t.id] = {
        type: r,
        properties: a,
        text: s,
        prev: [],
        next: []
      }, i;
    }, {});
    return n.edges.forEach(function(i) {
      var t = i.sourceNodeId, r = i.targetNodeId, a = i.id, s = i.properties, d = i.text, l = d;
      typeof d == "object" && (l = d.value), e[t].next.push({
        edgeId: a,
        nodeId: r,
        edgeType: i.type,
        properties: s,
        text: l
      }), e[r].prev.push({
        edgeId: a,
        nodeId: t,
        properties: s,
        text: l
      });
    }), e;
  }, o.prototype.addLevelHeight = function(n, e, i) {
    e === void 0 && (e = 1), i === void 0 && (i = !1);
    var t = this.levelHeight[n];
    t || (t = {
      positiveHeight: 0,
      negativeHeight: 0
    }, this.levelHeight[n] = t), i ? t.negativeHeight -= e : t.positiveHeight += e;
  }, o.prototype.getLevelHeight = function(n, e) {
    e === void 0 && (e = !1);
    var i = this.levelHeight[n];
    return i ? e ? i.negativeHeight : i.positiveHeight : 0;
  }, o.pluginName = "AutoLayout", o;
})(), Mn = function() {
  return Mn = Object.assign || function(o) {
    for (var n, e = 1, i = arguments.length; e < i; e++) {
      n = arguments[e];
      for (var t in n) Object.prototype.hasOwnProperty.call(n, t) && (o[t] = n[t]);
    }
    return o;
  }, Mn.apply(this, arguments);
}, bc = (function() {
  function o(n) {
    var e = n.lf, i = n.options;
    this.enable = !0, this.type = "default", this.currentDistance = 1 / 0, this.thresholdDistance = 100, this.reverseDirection = !1, this.virtualEdgeStyle = {
      strokeDasharray: "10,10",
      stroke: "#acacac"
    }, this.lf = e, Rn(this, i);
  }
  return o.prototype.render = function() {
    this.addEventListeners();
  }, o.prototype.addEventListeners = function() {
    var n = this;
    this.lf.graphModel.eventCenter.on("node:dragstart", function(e) {
      var i = e.data;
      if (n.type !== "anchor" && n.enable) {
        var t = n.lf.graphModel, r = i.id;
        n.currentNode = t.getNodeModelById(r);
      }
    }), this.lf.graphModel.eventCenter.on("node:drag", function() {
      n.type !== "anchor" && n.handleNodeDrag();
    }), this.lf.graphModel.eventCenter.on("anchor:dragstart", function(e) {
      var i = e.data, t = e.nodeModel;
      !n.enable || n.type === "node" || (n.currentNode = t, n.currentAnchor = i);
    }), this.lf.graphModel.eventCenter.on("anchor:drag", function(e) {
      var i = e.e, t = i.clientX, r = i.clientY;
      !n.enable || n.type === "node" || n.handleAnchorDrag(t, r);
    }), this.lf.graphModel.eventCenter.on("node:drop", function() {
      !n.enable || n.type === "anchor" || n.handleDrop();
    }), this.lf.graphModel.eventCenter.on("anchor:dragend", function(e) {
      var i = e.e, t = e.edgeModel;
      if (!(!n.enable || n.type === "node")) {
        var r = n.lf.graphModel.getPointByClient({
          x: i.clientX,
          y: i.clientY
        }).canvasOverlayPosition, a = r.x, s = r.y;
        if (t && n.virtualEdge) {
          var d = n.virtualEdge.id, l = t.targetNodeId, u = n.lf.graphModel.getNodeModelById(l);
          if (u && us({
            x: a,
            y: s
          }, u, 10)) {
            n.lf.deleteEdge(d);
            return;
          }
        }
        n.handleDrop();
      }
    });
  }, o.prototype.handleNodeDrag = function() {
    var n = this.lf.graphModel.nodes;
    if (!ht(this.virtualEdge)) {
      var e = this.virtualEdge, i = e.startPoint, t = e.endPoint, r = e.id;
      qi(i, t) > this.thresholdDistance && (this.lf.deleteEdge(r), this.virtualEdge = void 0);
    }
    this.currentNode && this.findClosestAnchorOfNode(this.currentNode, n), this.currentDistance < this.thresholdDistance && this.addVirtualEdge();
  }, o.prototype.handleDrop = function() {
    this.addActualEdge(), this.resetData();
  }, o.prototype.handleAnchorDrag = function(n, e) {
    var i = this.lf.graphModel, t = i.getPointByClient({
      x: n,
      y: e
    }).canvasOverlayPosition, r = t.x, a = t.y;
    if (!(ht(r) || ht(a))) {
      var s = {
        x: r,
        y: a
      }, d = i.nodes;
      if (!ht(this.virtualEdge)) {
        var l = this.virtualEdge, u = l.endPoint, c = l.id;
        qi(s, u) > this.thresholdDistance && (this.lf.deleteEdge(c), this.virtualEdge = void 0);
      }
      this.findClosestAnchorOfAnchor(s, d), this.currentDistance < this.thresholdDistance && this.addVirtualEdge();
    }
  }, o.prototype.findClosestAnchorOfNode = function(n, e) {
    var i = this;
    if (!(ht(n) || ti(n))) {
      var t = n.anchors, r = t === void 0 ? [] : t, a = n.id, s, d, l, u;
      e.forEach(function(c) {
        if (!_t(c.id, a)) {
          var h = c.anchors;
          (h === void 0 ? [] : h).forEach(function(f) {
            r.forEach(function(p) {
              if (i.anchorAllowConnect(c, f, p)) {
                var v = qi(p, f);
                (!s || v < s) && (s = v, d = p, l = f, u = c);
              }
            });
          });
        }
      }), this.currentDistance = s, this.currentAnchor = d, this.closestAnchor = l, this.closestNode = u;
    }
  }, o.prototype.findClosestAnchorOfAnchor = function(n, e) {
    var i = this;
    if (!ht(n)) {
      var t, r, a, s = this, d = s.currentNode, l = s.currentAnchor;
      e.forEach(function(u) {
        if (d) {
          var c = u.anchors;
          (c === void 0 ? [] : c).forEach(function(h) {
            var f;
            if (!_t((f = i.currentAnchor) === null || f === void 0 ? void 0 : f.id, h.id) && i.anchorAllowConnect(u, h, l)) {
              var p = qi(n, h);
              (!t || p < t) && (t = p, r = h, a = u);
            }
          });
        }
      }), this.currentDistance = t, this.closestAnchor = r, this.closestNode = a;
    }
  }, o.prototype.anchorAllowConnect = function(n, e, i) {
    var t = this.currentNode;
    if (t) {
      var r = (this.reverseDirection ? n.isAllowConnectedAsSource(t, e, i) : t.isAllowConnectedAsSource(n, i, e)).isAllPass, a = (this.reverseDirection ? t.isAllowConnectedAsTarget(n, e, i) : n.isAllowConnectedAsTarget(t, i, e)).isAllPass;
      return r && a;
    }
  }, o.prototype.sameEdgeIsExist = function(n) {
    if (ht(this.closestNode) || ht(this.currentNode) || ht(this.closestAnchor) || ht(this.currentAnchor) || ht(n)) return !1;
    var e = this, i = e.closestNode.id, t = e.currentNode.id, r = e.closestAnchor.id, a = e.currentAnchor.id, s = e.reverseDirection, d = n.sourceNodeId, l = n.targetNodeId, u = n.sourceAnchorId, c = n.targetAnchorId;
    return s ? _t(i, d) && _t(t, l) && _t(r, u) && _t(a, c) : _t(t, d) && _t(i, l) && _t(a, u) && _t(r, c);
  }, o.prototype.addVirtualEdge = function() {
    var n = this, e = this.lf.graphModel.edges;
    if (!Ms(e, function(c, h) {
      return h.virtual ? c : c || n.sameEdgeIsExist(h);
    }, !1)) {
      if (!ht(this.virtualEdge)) {
        var i = this.virtualEdge.id;
        if (this.sameEdgeIsExist(this.virtualEdge)) return;
        this.lf.deleteEdge(i);
      }
      var t = this, r = t.reverseDirection, a = t.currentNode, s = t.closestNode, d = t.currentAnchor, l = t.closestAnchor;
      if (!(ti(a) || ti(s))) {
        var u = { style: this.virtualEdgeStyle };
        this.virtualEdge = this.lf.addEdge(r ? {
          sourceNodeId: s == null ? void 0 : s.id,
          targetNodeId: a == null ? void 0 : a.id,
          sourceAnchorId: l == null ? void 0 : l.id,
          targetAnchorId: d == null ? void 0 : d.id,
          properties: u
        } : {
          sourceNodeId: a == null ? void 0 : a.id,
          targetNodeId: s == null ? void 0 : s.id,
          sourceAnchorId: d == null ? void 0 : d.id,
          targetAnchorId: l == null ? void 0 : l.id,
          properties: u
        }), this.virtualEdge.virtual = !0;
      }
    }
  }, o.prototype.addActualEdge = function() {
    if (!ht(this.virtualEdge)) {
      var n = this.virtualEdge, e = n.type, i = n.sourceNodeId, t = n.targetNodeId, r = n.sourceAnchorId, a = n.targetAnchorId, s = n.startPoint, d = n.endPoint, l = n.pointsList;
      this.lf.deleteEdge(this.virtualEdge.id), this.lf.addEdge({
        type: e,
        sourceNodeId: i,
        targetNodeId: t,
        sourceAnchorId: r,
        targetAnchorId: a,
        startPoint: s,
        endPoint: d,
        pointsList: l
      });
    }
  }, o.prototype.setVirtualEdgeStyle = function(n) {
    this.virtualEdgeStyle = Mn(Mn({}, this.virtualEdgeStyle), n);
  }, o.prototype.setThresholdDistance = function(n) {
    Ts(n) && (this.thresholdDistance = n);
  }, o.prototype.setReverseDirection = function(n) {
    this.reverseDirection = n;
  }, o.prototype.setEnable = function(n) {
    this.enable = n, n || this.resetData();
  }, o.prototype.resetData = function() {
    this.closestNode = void 0, this.currentDistance = 1 / 0, this.currentNode = void 0, this.currentAnchor = void 0, this.closestAnchor = void 0, this.virtualEdge = void 0;
  }, o.pluginName = "proximityConnect", o;
})(), Ho = function(o, n) {
  var e = typeof Symbol == "function" && o[Symbol.iterator];
  if (!e) return o;
  var i = e.call(o), t, r = [], a;
  try {
    for (; (n === void 0 || n-- > 0) && !(t = i.next()).done; ) r.push(t.value);
  } catch (s) {
    a = { error: s };
  } finally {
    try {
      t && !t.done && (e = i.return) && e.call(i);
    } finally {
      if (a) throw a.error;
    }
  }
  return r;
}, Fo = function(o, n, e) {
  if (e || arguments.length === 2)
    for (var i = 0, t = n.length, r; i < t; i++) (r || !(i in n)) && (r || (r = Array.prototype.slice.call(n, 0, i)), r[i] = n[i]);
  return o.concat(r || Array.prototype.slice.call(n));
}, xc = (function() {
  function o(n) {
    var e = n.lf, i = this;
    this.controlItems = [
      {
        key: "zoom-out",
        iconClass: "lf-control-zoomOut",
        title: "缩小流程图",
        text: "缩小",
        hideText: !1,
        onClick: function() {
          i.lf.zoom(!1);
        }
      },
      {
        key: "zoom-in",
        iconClass: "lf-control-zoomIn",
        title: "放大流程图",
        text: "放大",
        hideText: !1,
        onClick: function() {
          i.lf.zoom(!0);
        }
      },
      {
        key: "reset",
        iconClass: "lf-control-fit",
        title: "恢复流程原有尺寸",
        text: "适应",
        hideText: !1,
        onClick: function() {
          i.lf.resetZoom();
        }
      },
      {
        key: "undo",
        iconClass: "lf-control-undo",
        title: "回到上一步",
        text: "上一步",
        hideText: !1,
        onClick: function() {
          i.lf.undo();
        }
      },
      {
        key: "redo",
        iconClass: "lf-control-redo",
        title: "移到下一步",
        text: "下一步",
        hideText: !1,
        onClick: function() {
          i.lf.redo();
        }
      }
    ], this.lf = e;
  }
  return o.prototype.render = function(n, e) {
    this.destroy();
    var i = this.getControlTool();
    this.toolEl = i, e.appendChild(i), this.domContainer = e;
  }, o.prototype.destroy = function() {
    this.domContainer && this.toolEl && this.domContainer.contains(this.toolEl) && this.domContainer.removeChild(this.toolEl);
  }, o.prototype.addItem = function(n) {
    this.controlItems.push(n);
  }, o.prototype.removeItem = function(n) {
    var e = this.controlItems.findIndex(function(i) {
      return i.key === n;
    });
    return e == -1 ? null : this.controlItems.splice(e, 1)[0];
  }, o.prototype.getControlTool = function() {
    var n = this, e = this.lf.graphModel.themeMode, i = "lf-control-item-".concat(e, " lf-control-item"), t = "lf-control-item disabled", r = document.createElement("div"), a = [];
    return r.className = "lf-control-".concat(e, " lf-control"), Fo([], Ho(this.controlItems), !1).forEach(function(s) {
      var d = document.createElement("div"), l = document.createElement("i");
      if (d.className = t, s.onClick && (d.onclick = s.onClick.bind(null, n.lf)), s.onMouseEnter && (d.onmouseenter = s.onMouseEnter.bind(null, n.lf)), s.onMouseLeave && (d.onmouseleave = s.onMouseLeave.bind(null, n.lf)), l.className = s.iconClass, ht(s.hideText) || s.hideText !== !0) {
        var u = document.createElement("span");
        u.className = "lf-control-text-".concat(e, " lf-control-text"), u.title = s.title, u.innerText = s.text, d.append(l, u);
      } else d.append(l);
      switch (s.key) {
        case "undo":
          n.lf.on("history:change", function(c) {
            d.className = c.data.undoAble ? i : t;
          });
          break;
        case "redo":
          n.lf.on("history:change", function(c) {
            d.className = c.data.redoAble ? i : t;
          });
          break;
        default:
          d.className = i;
      }
      a.push(d);
    }), r.append.apply(r, Fo([], Ho(a), !1)), r;
  }, o.pluginName = "control", o;
})(), vr = function() {
  return vr = Object.assign || function(o) {
    for (var n, e = 1, i = arguments.length; e < i; e++) {
      n = arguments[e];
      for (var t in n) Object.prototype.hasOwnProperty.call(n, t) && (o[t] = n[t]);
    }
    return o;
  }, vr.apply(this, arguments);
}, er = function(o, n) {
  var e = typeof Symbol == "function" && o[Symbol.iterator];
  if (!e) return o;
  var i = e.call(o), t, r = [], a;
  try {
    for (; (n === void 0 || n-- > 0) && !(t = i.next()).done; ) r.push(t.value);
  } catch (s) {
    a = { error: s };
  } finally {
    try {
      t && !t.done && (e = i.return) && e.call(i);
    } finally {
      if (a) throw a.error;
    }
  }
  return r;
}, tr = function(o, n, e) {
  if (e || arguments.length === 2)
    for (var i = 0, t = n.length, r; i < t; i++) (r || !(i in n)) && (r || (r = Array.prototype.slice.call(n, 0, i)), r[i] = n[i]);
  return o.concat(r || Array.prototype.slice.call(n));
}, sn = "lf:defaultNodeMenu", ln = "lf:defaultEdgeMenu", gr = "lf:defaultGraphMenu", dn = "lf:defaultSelectionMenu", ir = {
  nodeMenu: sn,
  edgeMenu: ln,
  graphMenu: gr,
  selectionMenu: dn
}, It = {
  nodeMenu: [],
  edgeMenu: [],
  graphMenu: [],
  selectionMenu: []
}, wc = (function() {
  function o(n) {
    var e = n.lf, i = this;
    this.__currentData = null, this.__isSilentMode = !1, this.lf = e, this.__menuDOM = document.createElement("ul"), this.__isSilentMode = e.graphModel.editConfigModel.isSilentMode, this.menuTypeMap = /* @__PURE__ */ new Map(), this.init(), this.lf.setMenuConfig = function(t) {
      i.setMenuConfig(t);
    }, this.lf.addMenuConfig = function(t) {
      i.addMenuConfig(t);
    }, this.lf.setMenuByType = function(t) {
      i.setMenuByType(t);
    }, this.lf.changeMenuItemDisableStatus = function(t, r, a) {
      i.changeMenuItemDisableStatus(t, r, a);
    }, this.lf.getMenuConfig = function(t) {
      return i.getMenuConfig(t);
    }, this.lf.resetMenuConfigByType = function(t) {
      i.resetMenuConfigByType(t);
    };
  }
  return o.prototype.init = function() {
    var n = this, e, i, t;
    It.nodeMenu = [
      {
        text: "删除",
        callback: function(r) {
          n.lf.deleteNode(r.id);
        }
      },
      {
        text: "编辑文本",
        callback: function(r) {
          n.lf.graphModel.editText(r.id);
        }
      },
      {
        text: "复制",
        callback: function(r) {
          n.lf.cloneNode(r.id);
        }
      }
    ], (e = this.menuTypeMap) === null || e === void 0 || e.set(sn, It.nodeMenu), It.edgeMenu = [{
      text: "删除",
      callback: function(r) {
        n.lf.deleteEdge(r.id);
      }
    }, {
      text: "编辑文本",
      callback: function(r) {
        n.lf.graphModel.editText(r.id);
      }
    }], (i = this.menuTypeMap) === null || i === void 0 || i.set(ln, It.edgeMenu), It.graphMenu = [], It.selectionMenu = [{
      text: "删除",
      callback: function(r) {
        n.lf.clearSelectElements(), r.edges.forEach(function(a) {
          return n.lf.deleteEdge(a.id);
        }), r.nodes.forEach(function(a) {
          return n.lf.deleteNode(a.id);
        });
      }
    }], (t = this.menuTypeMap) === null || t === void 0 || t.set(dn, It.selectionMenu);
  }, o.prototype.showMenu = function(n, e, i, t) {
    if (!this.__isSilentMode && !(!i || !i.length)) {
      var r = this.__menuDOM;
      if (r) {
        if (r.innerHTML = "", r.append.apply(r, tr([], er(this.__getMenuDom(i)), !1)), !r.children.length) return;
        if (r.style.display = "block", !t) {
          r.style.top = "".concat(e, "px"), r.style.left = "".concat(n, "px");
          return;
        }
        var a = t.width, s = t.height, d = t.clientX, l = t.clientY, u = this.lf.graphModel, c = r.offsetWidth, h = !0, f = window.innerWidth || document.documentElement.clientWidth || document.body.clientWidth, p = f - d, v = u.rootEl.getBoundingClientRect(), g = v.left + v.width;
        g < f && (p = g - d), p < c && (h = !1), h ? r.style.left = "".concat(n, "px") : r.style.left = "".concat(n - a, "px");
        var b = r.offsetHeight, _ = !0, D = window.innerHeight || document.documentElement.clientHeight || document.body.clientHeight, L = D - l, W = v.top + v.height;
        W < D && (L = W - l), L < b && (_ = !1), _ ? r.style.top = "".concat(e, "px") : r.style.top = "".concat(e - s, "px");
      }
    }
  }, o.prototype.processMenuConfig = function(n, e) {
    var i = this;
    n && [
      "nodeMenu",
      "edgeMenu",
      "graphMenu",
      "selectionMenu"
    ].forEach(function(t) {
      var r, a, s, d, l = n[t], u = ir[t];
      if (l !== void 0) {
        if (e === "set") (r = i.menuTypeMap) === null || r === void 0 || r.set(u, l || []);
        else if (e === "add" && Array.isArray(l)) {
          var c = (s = (a = i.menuTypeMap) === null || a === void 0 ? void 0 : a.get(u)) !== null && s !== void 0 ? s : [];
          (d = i.menuTypeMap) === null || d === void 0 || d.set(u, c.concat(l));
        }
      }
    });
  }, o.prototype.createImageElement = function(n, e) {
    var i = document.createElement("img");
    return i.src = n, i.alt = e, i.style.width = "16px", i.style.height = "16px", i.style.objectFit = "contain", i;
  }, o.prototype.isImageFile = function(n) {
    return [
      ".png",
      ".jpg",
      ".jpeg",
      ".gif",
      ".svg",
      ".webp",
      ".ico",
      ".bmp"
    ].some(function(e) {
      return n.toLowerCase().includes(e);
    });
  }, o.prototype.processIcon = function(n, e, i) {
    var t;
    if (typeof e == "string") {
      var r = e;
      if (r.startsWith("data:image/")) {
        var a = this.createImageElement(r, i || "icon");
        n.appendChild(a);
        return;
      }
      if (this.isImageFile(r)) {
        var a = this.createImageElement(r, i || "icon");
        n.appendChild(a);
        return;
      }
      if (r.includes("<") && r.includes(">")) {
        n.innerHTML = r;
        return;
      }
      if (r.includes(" ") || r.startsWith(".")) {
        var s = r.replace(/^\./, "").split(" ");
        (t = n.classList).add.apply(t, tr([], er(s), !1));
        return;
      }
      n.classList.add(r);
    }
  }, o.prototype.__getMenuDom = function(n) {
    var e = this, i = [];
    return n && n.length > 0 && n.forEach(function(t) {
      var r = document.createElement("li");
      if (t.className ? r.className = "lf-menu-item ".concat(t.disabled ? "lf-menu-item__disabled" : "", " ").concat(t.className) : r.className = "lf-menu-item ".concat(t.disabled ? "lf-menu-item__disabled" : ""), t.icon) {
        var a = document.createElement("span");
        a.className = "lf-menu-item-icon", e.processIcon(a, t.icon, t.text), r.appendChild(a);
      }
      var s = document.createElement("span");
      s.className = "lf-menu-item-text", t.text && (s.innerText = t.text), r.appendChild(s), t.disabled && r.setAttribute("disabled", "true"), r.onclickCallback = t.callback, i.push(r);
    }), i;
  }, o.prototype.updateMenuItemDOMStatus = function(n, e) {
    if (!(!this.__menuDOM || this.__menuDOM.style.display === "none")) {
      var i = Array.from(this.__menuDOM.querySelectorAll(".lf-menu-item")).find(function(r) {
        var a = r.querySelector(".lf-menu-item-text");
        return (a == null ? void 0 : a.textContent) === n;
      });
      if (i) {
        var t = i;
        e ? (t.classList.add("lf-menu-item__disabled"), t.setAttribute("disabled", "true")) : (t.classList.remove("lf-menu-item__disabled"), t.removeAttribute("disabled"));
      }
    }
  }, o.prototype.setupSilentModeListener = function() {
    var n = this;
    this.__editConfigChangeHandler = function(e) {
      var i = e.data.isSilentMode;
      i !== n.__isSilentMode && (n.__isSilentMode = i, n.updateMenuVisibility(!i));
    }, this.lf.on("editConfig:changed", this.__editConfigChangeHandler);
  }, o.prototype.updateMenuVisibility = function(n) {
    this.__menuDOM && (n ? this.__currentData && (this.__menuDOM.style.display = "block") : (this.__menuDOM.style.display = "none", this.__currentData = null));
  }, o.prototype.refreshCurrentMenu = function() {
    var n, e, i, t, r, a, s, d, l, u, c;
    if (!(!this.__menuDOM || this.__menuDOM.style.display === "none" || !this.__currentData)) {
      var h = this.__menuDOM.style, f = h.left, p = h.top, v = [];
      if (this.__currentData && typeof this.__currentData == "object")
        if ("sourceNodeId" in this.__currentData && "targetNodeId" in this.__currentData) {
          var g = this.lf.graphModel.getEdgeModelById(this.__currentData.id);
          if (g) {
            var b = (e = this.menuTypeMap) === null || e === void 0 ? void 0 : e.get(g.type);
            g.menu && Array.isArray(g.menu) ? v = g.menu : b ? v = b : v = (t = (i = this.menuTypeMap) === null || i === void 0 ? void 0 : i.get(ln)) !== null && t !== void 0 ? t : [];
          }
        } else if ("id" in this.__currentData && "type" in this.__currentData) {
          var g = this.lf.graphModel.getNodeModelById(this.__currentData.id);
          if (g) {
            var b = (r = this.menuTypeMap) === null || r === void 0 ? void 0 : r.get(g.type);
            g.menu && Array.isArray(g.menu) ? v = g.menu : b ? v = b : v = (s = (a = this.menuTypeMap) === null || a === void 0 ? void 0 : a.get(sn)) !== null && s !== void 0 ? s : [];
          }
        } else "nodes" in this.__currentData && "edges" in this.__currentData ? v = (l = (d = this.menuTypeMap) === null || d === void 0 ? void 0 : d.get(dn)) !== null && l !== void 0 ? l : [] : v = (c = (u = this.menuTypeMap) === null || u === void 0 ? void 0 : u.get(gr)) !== null && c !== void 0 ? c : [];
      v && v.length > 0 ? (this.__menuDOM.innerHTML = "", (n = this.__menuDOM).append.apply(n, tr([], er(this.__getMenuDom(v)), !1)), f && (this.__menuDOM.style.left = f), p && (this.__menuDOM.style.top = p)) : (this.__menuDOM.style.display = "none", this.__currentData = null);
    }
  }, o.prototype.setMenuByType = function(n) {
    var e, i = n.type, t = n.menu;
    !i || !t || ((e = this.menuTypeMap) === null || e === void 0 || e.set(i, t), this.refreshCurrentMenu());
  }, o.prototype.getMenuConfig = function(n) {
    var e, i;
    return (i = (e = this.menuTypeMap) === null || e === void 0 ? void 0 : e.get(ir[n])) !== null && i !== void 0 ? i : [];
  }, o.prototype.resetMenuConfigByType = function(n) {
    var e;
    this.setMenuConfig((e = {}, e[n] = It[n], e));
  }, o.prototype.resetAllMenuConfig = function() {
    this.setMenuConfig(It);
  }, o.prototype.setMenuConfig = function(n) {
    this.processMenuConfig(n, "set"), this.refreshCurrentMenu();
  }, o.prototype.addMenuConfig = function(n) {
    this.processMenuConfig(n, "add"), this.refreshCurrentMenu();
  }, o.prototype.changeMenuItem = function(n, e) {
    if (n === "add") this.addMenuConfig(e);
    else if (n === "reset") this.setMenuConfig(e);
    else throw new Error("The first parameter of changeMenuConfig should be 'add' or 'reset'");
  }, o.prototype.changeMenuItemDisableStatus = function(n, e, i) {
    var t, r;
    if (!(!n || !e)) {
      var a = (r = (t = this.menuTypeMap) === null || t === void 0 ? void 0 : t.get(ir[n])) !== null && r !== void 0 ? r : [];
      if (a.length) {
        var s = a.find(function(d) {
          return d.text === e;
        });
        s && (s.disabled = i, this.updateMenuItemDOMStatus(e, i));
      }
    }
  }, o.prototype.render = function(n, e) {
    var i = this;
    n.graphModel.editConfigModel.isSilentMode || (this.__container = e, this.__currentData = null, this.setupSilentModeListener(), this.__menuDOM && (this.__menuDOM.className = "lf-menu", e.appendChild(this.__menuDOM), this.__menuDOM.addEventListener("click", function(t) {
      t.stopPropagation();
      for (var r = t.target; Array.from(r.classList).indexOf("lf-menu-item") === -1 && Array.from(r.classList).indexOf("lf-menu") === -1; ) r = r == null ? void 0 : r.parentElement;
      Array.from(r.classList).indexOf("lf-menu-item__disabled") > -1 || Array.from(r.classList).indexOf("lf-menu-item") > -1 && (r.onclickCallback(i.__currentData, r), i.__menuDOM && (i.__menuDOM.style.display = "none"), i.__currentData = null);
    }, !0)), this.lf.on("node:contextmenu", function(t) {
      var r, a, s = t.data, d = t.position, l = t.e, u = d.domOverlayPosition, c = u.x, h = u.y, f = s.id, p = i.lf.graphModel.getNodeModelById(f);
      if (!(!p || i.__isSilentMode)) {
        var v = [], g = (r = i.menuTypeMap) === null || r === void 0 ? void 0 : r.get(p.type);
        p && p.menu && Array.isArray(p.menu) ? v = p.menu : g ? v = g : v = (a = i.menuTypeMap) === null || a === void 0 ? void 0 : a.get(sn), i.__currentData = s, i.showMenu(c, h, v, {
          width: p.width,
          height: p.height,
          clientX: l.clientX,
          clientY: l.clientY
        });
      }
    }), this.lf.on("edge:contextmenu", function(t) {
      var r, a, s, d = t.data, l = t.position, u = t.e, c = l.domOverlayPosition, h = c.x, f = c.y, p = d.id, v = i.lf.graphModel.getEdgeModelById(p);
      if (!(!v || i.__isSilentMode)) {
        var g = [], b = (r = i.menuTypeMap) === null || r === void 0 ? void 0 : r.get(v.type);
        v && v.menu && Array.isArray(v.menu) ? g = v.menu : b ? g = b : g = (s = (a = i.menuTypeMap) === null || a === void 0 ? void 0 : a.get(ln)) !== null && s !== void 0 ? s : [], i.__currentData = d, i.showMenu(h, f, g, {
          width: v.width,
          height: v.height,
          clientX: u.clientX,
          clientY: u.clientY
        });
      }
    }), this.lf.on("blank:contextmenu", function(t) {
      var r, a, s = t.position;
      if (!i.__isSilentMode) {
        var d = (a = (r = i.menuTypeMap) === null || r === void 0 ? void 0 : r.get(gr)) !== null && a !== void 0 ? a : [], l = s.domOverlayPosition, u = l.x, c = l.y;
        i.__currentData = vr({}, s.canvasOverlayPosition), i.showMenu(u, c, d);
      }
    }), this.lf.on("selection:contextmenu", function(t) {
      var r, a = t.data, s = t.position;
      if (!i.__isSilentMode) {
        var d = (r = i.menuTypeMap) === null || r === void 0 ? void 0 : r.get(dn), l = s.domOverlayPosition, u = l.x, c = l.y;
        i.__currentData = a, i.showMenu(u, c, d);
      }
    }), this.lf.on("node:mousedown", function() {
      i.__menuDOM.style.display = "none";
    }), this.lf.on("edge:click", function() {
      i.__menuDOM.style.display = "none";
    }), this.lf.on("blank:click", function() {
      i.__menuDOM.style.display = "none";
    }));
  }, o.prototype.destroy = function() {
    var n;
    this.__editConfigChangeHandler && this.lf.off("editConfig:changed", this.__editConfigChangeHandler), this.__menuDOM && ((n = this === null || this === void 0 ? void 0 : this.__container) === null || n === void 0 || n.removeChild(this.__menuDOM), this.__menuDOM = void 0);
  }, o.pluginName = "menu", o;
})(), nr = function(o, n) {
  var e = typeof Symbol == "function" && o[Symbol.iterator];
  if (!e) return o;
  var i = e.call(o), t, r = [], a;
  try {
    for (; (n === void 0 || n-- > 0) && !(t = i.next()).done; ) r.push(t.value);
  } catch (s) {
    a = { error: s };
  } finally {
    try {
      t && !t.done && (e = i.return) && e.call(i);
    } finally {
      if (a) throw a.error;
    }
  }
  return r;
}, Go = function(o, n, e) {
  if (e || arguments.length === 2)
    for (var i = 0, t = n.length, r; i < t; i++) (r || !(i in n)) && (r || (r = Array.prototype.slice.call(n, 0, i)), r[i] = n[i]);
  return o.concat(r || Array.prototype.slice.call(n));
}, rr = "menu-common", zo = 200, lu = 100, Ec = (function() {
  function o(n) {
    var e = n.lf, i = this;
    this.menuTypeMap = /* @__PURE__ */ new Map(), this.listenDelete = function() {
      i.hideContextMenu();
    }, this.lf = e, this.__menuDOM = document.createElement("div"), this.__menuDOM.className = "lf-inner-context", this.menuTypeMap.set(rr, []), this.lf.setContextMenuByType = function(t, r) {
      i.setContextMenuByType(t, r);
    }, this.lf.setContextMenuItems = function(t) {
      i.setContextMenuItems(t);
    }, this.lf.showContextMenu = function(t) {
      i.showContextMenu(t);
    }, this.lf.hideContextMenu = function() {
      i.hideContextMenu();
    };
  }
  return o.prototype.render = function(n, e) {
    var i = this;
    this.container = e, n.on("node:click", function(t) {
      i._activeData = t.data, i.createContextMenu();
    }), n.on("edge:click", function(t) {
      i._activeData = t.data, i.createContextMenu();
    }), n.on("blank:click", function() {
      i.hideContextMenu();
    });
  }, o.prototype.setContextMenuByType = function(n, e) {
    this.menuTypeMap.set(n, e);
  }, o.prototype.hideContextMenu = function() {
    this.__menuDOM.innerHTML = "", this.__menuDOM.style.display = "none", this.isShow && this.container.removeChild(this.__menuDOM), this.lf.off("node:delete,edge:delete,node:drag,graph:transform", this.listenDelete), this.isShow = !1;
  }, o.prototype.showContextMenu = function(n) {
    !n || !n.id || (this._activeData = n, this.createContextMenu());
  }, o.prototype.setContextMenuItems = function(n) {
    this.menuTypeMap.set(rr, n);
  }, o.prototype.getContextMenuPosition = function() {
    var n = this._activeData, e = this.lf.graphModel.getElement(n.id);
    if (e) {
      var i, t;
      if (e.BaseType === "edge") {
        i = Number.MIN_SAFE_INTEGER, t = Number.MAX_SAFE_INTEGER;
        var r = e.getData();
        i = Math.max(r.startPoint.x, i), t = Math.min(r.startPoint.y, t), i = Math.max(r.endPoint.x, i), t = Math.min(r.endPoint.y, t), r.pointsList && r.pointsList.forEach(function(a) {
          i = Math.max(a.x, i), t = Math.min(a.y, t);
        });
      }
      return e.BaseType === "node" && (i = n.x + e.width / 2, t = n.y - e.height / 2), this.lf.graphModel.transformModel.CanvasPointToHtmlPoint([i, t]);
    }
  }, o.prototype.createContextMenu = function() {
    var n = this;
    if (!this.lf.options.isSilentMode) {
      var e = Go(Go([], nr(this.menuTypeMap.get(this._activeData.type) || []), !1), nr(this.menuTypeMap.get(rr) || []), !1), i = document.createDocumentFragment();
      e.forEach(function(t) {
        var r = document.createElement("div");
        r.className = "lf-context-item";
        var a = document.createElement("img");
        a.src = t.icon, a.className = "lf-context-img", t.className && (r.className = "".concat(r.className, " ").concat(t.className)), a.addEventListener("click", function() {
          n.hideContextMenu(), t.callback ? t.callback(n._activeData) : n.addNode({
            sourceId: n._activeData.id,
            x: n._activeData.x,
            y: n._activeData.y,
            properties: t.properties,
            type: t.type
          });
        }), r.appendChild(a), i.appendChild(r);
      }), this.__menuDOM.innerHTML = "", this.__menuDOM.appendChild(i), this.showMenu();
    }
  }, o.prototype.addNode = function(n, e) {
    var i = e !== void 0;
    e === void 0 && (e = n.y);
    var t = this.lf.getNodeModelById(n.sourceId);
    if (t) {
      var r = n.x - t.width + zo, a = e - n.y / 2 - 20, s = n.x + t.width + zo, d = e + n.y / 2 + 20;
      if (this.lf.getAreaElement([r, a], [s, d]).length) {
        e = e + lu, this.addNode(n, e);
        return;
      }
      if (n.type) {
        var l = this.lf.addNode({
          type: n.type,
          x: n.x + 200,
          y: e,
          properties: n.properties
        }), u = void 0, c = void 0;
        i && (u = {
          x: n.x,
          y: n.y + t.height / 2
        }, c = {
          x: l.x - l.width / 2,
          y: l.y
        }), this.lf.addEdge({
          sourceNodeId: n.sourceId,
          targetNodeId: l.id,
          startPoint: u,
          endPoint: c
        });
      }
    }
  }, o.prototype.showMenu = function() {
    var n = this.getContextMenuPosition();
    if (n) {
      var e = nr(n, 2), i = e[0], t = e[1];
      this.__menuDOM.style.display = "flex", this.__menuDOM.style.top = "".concat(t, "px"), this.__menuDOM.style.left = "".concat(i + 10, "px"), this.container.appendChild(this.__menuDOM), !this.isShow && this.lf.on("node:delete,edge:delete,node:drag,graph:transform", this.listenDelete), this.isShow = !0;
    }
  }, o.pluginName = "contextMenu", o;
})(), _c = (function() {
  function o(n) {
    var e = n.lf, i = this;
    this.lf = e, this.lf.setPatternItems = function(t) {
      i.setPatternItems(t);
    };
  }
  return o.prototype.render = function(n, e) {
    var i = this;
    if (this.destroy(), !this.shapeList || this.shapeList.length === 0) {
      this.domContainer = e;
      return;
    }
    this.panelEl = document.createElement("div"), this.panelEl.className = "lf-dndpanel", this.panelEl.addEventListener("touchmove", function(t) {
      t.preventDefault();
    }, { passive: !1 }), this.shapeList.forEach(function(t) {
      var r;
      (r = i.panelEl) === null || r === void 0 || r.appendChild(i.createDndItem(t));
    }), e.appendChild(this.panelEl), this.domContainer = e;
  }, o.prototype.destroy = function() {
    this.domContainer && this.panelEl && this.domContainer.contains(this.panelEl) && this.domContainer.removeChild(this.panelEl);
  }, o.prototype.setPatternItems = function(n) {
    this.shapeList = n, this.domContainer && this.render(this.lf, this.domContainer);
  }, o.prototype.createDndItem = function(n) {
    var e = this, i = document.createElement("div");
    i.className = n.className ? "lf-dnd-item ".concat(n.className) : "lf-dnd-item";
    var t = document.createElement("div");
    if (t.className = "lf-dnd-shape", n.icon && (t.style.backgroundImage = "url(".concat(n.icon, ")")), i.appendChild(t), n.label) {
      var r = document.createElement("div");
      r.innerText = n.label, r.className = "lf-dnd-text", i.appendChild(r);
    }
    return n.disabled ? (i.classList.add("disabled"), i.onpointerdown = function() {
      n.callback && n.callback(e.lf, e.domContainer);
    }, i) : (i.onpointerdown = function(a) {
      n.type && e.lf.dnd.startDrag({
        type: n.type,
        properties: n.properties,
        text: n.text
      }), n.callback && n.callback(e.lf, e.domContainer), a.preventDefault();
    }, i.ondblclick = function(a) {
      e.lf.graphModel.eventCenter.emit("dnd:panel-dbclick", {
        e: a,
        data: n
      });
    }, i.onclick = function(a) {
      e.lf.graphModel.eventCenter.emit("dnd:panel-click", {
        e: a,
        data: n
      });
    }, i.oncontextmenu = function(a) {
      e.lf.graphModel.eventCenter.emit("dnd:panel-contextmenu", {
        e: a,
        data: n
      });
    }, i);
  }, o.pluginName = "dndPanel", o;
})(), du = function(o) {
  var n = typeof Symbol == "function" && Symbol.iterator, e = n && o[n], i = 0;
  if (e) return e.call(o);
  if (o && typeof o.length == "number") return { next: function() {
    return o && i >= o.length && (o = void 0), {
      value: o && o[i++],
      done: !o
    };
  } };
  throw new TypeError(n ? "Object is not iterable." : "Symbol.iterator is not defined.");
}, Cc = (function() {
  function o(n) {
    var e = n.lf, i = n.LogicFlow, t = n.options, r = this;
    this.width = 200, this.height = 150, this.scale = 1, this.translateX = 0, this.translateY = 0, this.showEdge = !1, this.viewPortTop = 0, this.viewPortLeft = 0, this.viewPortWidth = 150, this.viewPortHeight = 75, this.isShow = !1, this.isShowHeader = !1, this.isShowCloseIcon = !1, this.headerTitle = "导航", this.disabledPlugins = [
      "miniMap",
      "control",
      "selectionSelect"
    ], this.onGraphResize = function() {
      r.updateViewPortBounds(), r.isShow && r.updateViewPort();
    }, this.render = function(s, d) {
      r.container = d, r.lf.on("history:change", function() {
        r.isShow && r.setView();
      }), r.lf.on("graph:transform", function() {
        r.isShow && r.setView(!1);
      });
    }, this.show = function(s, d) {
      r.isShow || (r.initMiniMap(), r.lf.on("graph:resize", r.onGraphResize), r.createMiniMap(s, d), r.setView(!0)), r.isShow = !0;
    }, this.hide = function() {
      r.isShow && (r.lf.off("graph:resize", r.onGraphResize), r.lfMap.destroy(), r.translateX = 0, r.translateY = 0, r.removeMiniMap(), r.lf.emit("miniMap:close", {})), r.isShow = !1;
    }, this.updatePosition = function(s) {
      if (typeof s == "object")
        (s.left !== void 0 || s.right !== void 0) && (r.leftPosition = s.left, r.rightPosition = s.right), (s.top !== void 0 || s.bottom !== void 0) && (r.topPosition = s.top, r.bottomPosition = s.bottom);
      else switch (s) {
        case "left-top":
          r.leftPosition = 0, r.rightPosition = void 0, r.topPosition = 0, r.bottomPosition = void 0;
          break;
        case "right-top":
          r.leftPosition = void 0, r.rightPosition = 0, r.topPosition = 0, r.bottomPosition = void 0;
          break;
        case "left-bottom":
          r.leftPosition = 0, r.rightPosition = void 0, r.topPosition = void 0, r.bottomPosition = 0;
          break;
        case "right-bottom":
          r.leftPosition = void 0, r.rightPosition = 0, r.topPosition = void 0, r.bottomPosition = 0;
      }
      r.updateMiniMapPosition();
    }, this.reset = function() {
      r.lf.resetTranslate(), r.lf.resetZoom();
    }, this.setShowEdge = function(s) {
      r.showEdge !== s && (r.showEdge = s, r.setView());
    }, this.startDrag = function(s) {
      document.addEventListener("pointermove", r.drag), document.addEventListener("pointerup", r.drop), r.startPosition = {
        x: s.x,
        y: s.y
      };
    }, this.drag = function(s) {
      var d = s.x, l = s.y, u = (d - r.startPosition.x) / r.scale, c = (l - r.startPosition.y) / r.scale, h = r.viewPortLeft + u + r.viewPortWidth / r.scale / 2, f = r.viewPortTop + c + r.viewPortHeight / r.scale / 2;
      r.startPosition = {
        x: d,
        y: l
      }, r.lf.focusOn({ coordinate: {
        x: h,
        y: f
      } });
    }, this.drop = function() {
      document.removeEventListener("pointermove", r.drag), document.removeEventListener("pointerup", r.drop);
    }, this.mapClick = function(s) {
      var d = s.offsetX, l = s.offsetY, u = r.translateX + d / r.scale, c = r.translateY + l / r.scale;
      r.lf.focusOn({ coordinate: {
        x: u,
        y: c
      } });
    }, this.lf = e, this.LFCtor = i, t && this.setOption(t), this.viewPortWidth = e.graphModel.width, this.viewPortHeight = e.graphModel.height;
    var a = {
      left: 0,
      right: this.viewPortWidth,
      top: 0,
      bottom: this.viewPortHeight
    };
    this.bounds = a, this.elementAreaBounds = a, this.viewPortBounds = a;
  }
  return o.prototype.setOption = function(n) {
    var e = n.width, i = e === void 0 ? 200 : e, t = n.height, r = t === void 0 ? 150 : t, a = n.showEdge, s = a === void 0 ? !1 : a, d = n.isShowHeader, l = d === void 0 ? !1 : d, u = n.isShowCloseIcon, c = u === void 0 ? !1 : u, h = n.leftPosition, f = n.topPosition, p = n.rightPosition, v = p === void 0 ? 0 : p, g = n.bottomPosition, b = g === void 0 ? 0 : g, _ = n.headerTitle, D = _ === void 0 ? "导航" : _;
    this.width = i, this.height = r, this.showEdge = s, this.isShowHeader = l, this.isShowCloseIcon = c, this.leftPosition = h, this.rightPosition = h !== void 0 ? void 0 : v, this.topPosition = f, this.bottomPosition = f !== void 0 ? void 0 : b, this.headerTitle = D;
  }, o.prototype.initMiniMap = function() {
    var n = document.createElement("div");
    n.className = "lf-mini-map-graph", n.style.width = "".concat(this.width, "px"), n.style.height = "".concat(this.height, "px"), this.lfMap = new this.LFCtor({
      container: n,
      grid: !1,
      isSilentMode: !0,
      stopZoomGraph: !0,
      stopScrollGraph: !0,
      stopMoveGraph: !1,
      history: !1,
      snapline: !1,
      disabledPlugins: this.disabledPlugins,
      isMiniMap: !0
    }), this.miniMapWrap = n, this.createViewPort(), n.addEventListener("click", this.mapClick);
  }, o.prototype.createMiniMap = function(n, e) {
    var i, t = document.createElement("div");
    this.miniMapContainer = t, t.appendChild(this.miniMapWrap), t.style.position = "absolute", (n !== void 0 || e !== void 0) && (this.leftPosition = n || 0, this.topPosition = e || 0, this.rightPosition = void 0, this.bottomPosition = void 0), this.updateMiniMapPosition(), t.className = "lf-mini-map", this.isShowCloseIcon || t.classList.add("lf-mini-map-no-close-icon"), this.isShowHeader || t.classList.add("lf-mini-map-no-header"), (i = this.container) === null || i === void 0 || i.appendChild(t), this.miniMapWrap.appendChild(this.viewport);
    var r = document.createElement("div");
    r.className = "lf-mini-map-header", r.innerText = this.headerTitle, t.appendChild(r);
    var a = document.createElement("span");
    a.className = "lf-mini-map-close", a.addEventListener("click", this.hide), t.appendChild(a);
  }, o.prototype.updateMiniMapPosition = function() {
    if (this.miniMapContainer) {
      var n = this.miniMapContainer.style;
      this.rightPosition !== void 0 ? (n.right = "".concat(this.rightPosition, "px"), n.left = "") : (n.left = "".concat(this.leftPosition, "px"), n.right = ""), this.bottomPosition !== void 0 ? (n.bottom = "".concat(this.bottomPosition, "px"), n.top = "") : (n.top = "".concat(this.topPosition, "px"), n.bottom = "");
    }
  }, o.prototype.removeMiniMap = function() {
    var n;
    this.miniMapContainer && ((n = this.container) === null || n === void 0 || n.removeChild(this.miniMapContainer));
  }, o.prototype.updateBounds = function(n) {
    n && this.updateElementAreaBounds(n), this.updateViewPortBounds(), this.bounds = {
      left: Math.min(this.elementAreaBounds.left, this.viewPortBounds.left),
      right: Math.max(this.elementAreaBounds.right, this.viewPortBounds.right),
      top: Math.min(this.elementAreaBounds.top, this.viewPortBounds.top),
      bottom: Math.max(this.elementAreaBounds.bottom, this.viewPortBounds.bottom)
    };
  }, o.prototype.updateElementAreaBounds = function(n) {
    var e = {
      left: 0,
      right: 0,
      top: 0,
      bottom: 0
    }, i = n.nodes;
    i && i.length > 0 && i.forEach(function(t) {
      var r, a, s = t.x, d = t.y, l = (r = t.width) !== null && r !== void 0 ? r : 200, u = (a = t.height) !== null && a !== void 0 ? a : 200, c = s - l / 2, h = s + l / 2, f = d - u / 2, p = d + u / 2;
      e.left = Math.min(c, e.left), e.right = Math.max(h, e.right), e.top = Math.min(f, e.top), e.bottom = Math.max(p, e.bottom);
    }), this.elementAreaBounds = e;
  }, o.prototype.updateViewPortBounds = function() {
    var n = this.lf.getTransform(), e = n.TRANSLATE_X, i = n.TRANSLATE_Y, t = n.SCALE_X, r = n.SCALE_Y, a = this.lf.graphModel, s = a.width, d = a.height;
    this.viewPortBounds = {
      left: -e / t,
      right: (-e + s) / t,
      top: -i / r,
      bottom: (-i + d) / r
    };
  }, o.prototype.resetData = function(n) {
    var e = n.nodes, i = n.edges;
    return e.forEach(function(t) {
      t.text = void 0;
    }), this.showEdge && i.forEach(function(t) {
      t.text = void 0;
    }), {
      nodes: e,
      edges: this.showEdge ? i : []
    };
  }, o.prototype.setView = function(n) {
    var e, i;
    if (n === void 0 && (n = !0), n) {
      var t = this.lf.getGraphRawData(), r = this.resetData(t), a = this.lf.viewMap, s = this.lf.graphModel.modelMap, d = this.lfMap.viewMap;
      try {
        for (var l = du(a.keys()), u = l.next(); !u.done; u = l.next()) {
          var c = u.value;
          d.has(c) || this.lfMap.register({
            type: c,
            view: a.get(c),
            model: s.get(c)
          });
        }
      } catch (te) {
        e = { error: te };
      } finally {
        try {
          u && !u.done && (i = l.return) && i.call(l);
        } finally {
          if (e) throw e.error;
        }
      }
      this.lfMap.render(r), this.updateBounds(r);
    } else this.updateBounds();
    var h = this.bounds, f = h.left, p = h.top, v = h.right, g = h.bottom, b = v - f, _ = g - p, D = this.width / b, L = this.height / _, W = Math.min(D, L);
    this.scale = W;
    var B = f - (this.width / W - b) / 2, K = p - (this.height / W - _) / 2;
    if (this.lfMap.graphModel.transformModel.translate(-B + this.translateX, -K + this.translateY), this.translateX = B, this.translateY = K, this.miniMapWrap.firstChild) {
      var Y = this.miniMapWrap.firstChild.style;
      Y.pointerEvents = "none", Y.transform = "matrix(".concat(W, ", 0, 0, ").concat(W, ", 0, 0)"), Y.transformOrigin = "left top", Y.height = "".concat(this.height / W, "px"), Y.width = "".concat(this.width / W, "px"), this.updateViewPort();
    }
  }, o.prototype.updateViewPort = function() {
    var n = this.viewport.style, e = this.lf.getTransform(), i = e.TRANSLATE_X, t = e.TRANSLATE_Y, r = e.SCALE_X, a = e.SCALE_Y, s = this.lf.graphModel, d = s.width, l = s.height;
    this.viewPortLeft = -i / r, this.viewPortTop = -t / a, this.viewPortWidth = d / r * this.scale, this.viewPortHeight = l / a * this.scale, n.width = "".concat(this.viewPortWidth, "px"), n.height = "".concat(this.viewPortHeight, "px"), n.left = "".concat((this.viewPortLeft - this.translateX) * this.scale, "px"), n.top = "".concat((this.viewPortTop - this.translateY) * this.scale, "px");
  }, o.prototype.createViewPort = function() {
    var n = document.createElement("div");
    n.className = "lf-minimap-viewport", n.style.touchAction = "none", n.addEventListener("pointerdown", this.startDrag), n.addEventListener("click", function(e) {
      e.stopPropagation();
    }), this.viewport = n;
  }, o.prototype.destroy = function() {
    this.lf.off("graph:resize", this.onGraphResize);
  }, o.pluginName = "miniMap", o;
})(), jo = function(o, n) {
  var e = typeof Symbol == "function" && o[Symbol.iterator];
  if (!e) return o;
  var i = e.call(o), t, r = [], a;
  try {
    for (; (n === void 0 || n-- > 0) && !(t = i.next()).done; ) r.push(t.value);
  } catch (s) {
    a = { error: s };
  } finally {
    try {
      t && !t.done && (e = i.return) && e.call(i);
    } finally {
      if (a) throw a.error;
    }
  }
  return r;
}, Wo = function(o, n, e) {
  if (e || arguments.length === 2)
    for (var i = 0, t = n.length, r; i < t; i++) (r || !(i in n)) && (r || (r = Array.prototype.slice.call(n, 0, i)), r[i] = n[i]);
  return o.concat(r || Array.prototype.slice.call(n));
}, Sc = (function() {
  function o(n) {
    var e = n.lf, i = n.options, t = this, r;
    this.disabled = !0, this.isWholeNode = !0, this.isWholeEdge = !0, this.originStatusSaved = !1, this.exclusiveMode = !1, this.mouseDownInfo = null, this.originalStopMoveGraph = !1, this.handleBlankMouseDown = function(a) {
      var s = a.e;
      t.handleMouseDown(s);
    }, this.draw = function(a) {
      if (t.lf.graphModel.editConfigModel.isPinching) {
        t.lf.updateEditConfig({ stopMoveGraph: t.originalStopMoveGraph }), t.originStatusSaved = !1, t.cleanupSelectionState();
        return;
      }
      var s = t.lf.getPointByClient(a.clientX, a.clientY).domOverlayPosition, d = s.x, l = s.y;
      if (t.endPoint = {
        x: d,
        y: l
      }, t.startPoint) {
        var u = t.startPoint, c = u.x, h = u.y, f = c, p = h, v = d - c, g = l - h;
        d < c && (f = d, v = c - d), l < h && (p = l, g = h - l), t.wrapper && (t.wrapper.style.left = "".concat(f, "px"), t.wrapper.style.top = "".concat(p, "px"), t.wrapper.style.width = "".concat(v, "px"), t.wrapper.style.height = "".concat(g, "px"));
      }
    }, this.drawOff = function(a) {
      if (t.lf.updateEditConfig({ stopMoveGraph: t.originalStopMoveGraph }), t.originStatusSaved = !1, t.mouseDownInfo) {
        var s = t.mouseDownInfo, d = s.x, l = s.y, u = s.time;
        if (Math.abs(a.clientX - d) < 5 && Math.abs(a.clientY - l) < 5 && Date.now() - u < 200) {
          t.lf.clearSelectElements(), t.cleanupSelectionState();
          return;
        }
      }
      var c = ft(t.startPoint), h = ft(t.endPoint);
      if (document.removeEventListener("pointermove", t.draw), t.exclusiveMode || document.removeEventListener("pointerup", t.drawOff), c && h) {
        var d = c.x, l = c.y, f = h.x, p = h.y, v = [Math.min(d, f), Math.min(l, p)], g = [Math.max(d, f), Math.max(l, p)];
        if (t.lf.emit("selection:selected-area", {
          topLeft: v,
          bottomRight: g
        }), Math.abs(f - d) < 10 && Math.abs(p - l) < 10) {
          t.wrapper && (t.wrapper.oncontextmenu = null, t.container && t.wrapper.parentNode === t.container && t.container.removeChild(t.wrapper), t.wrapper = void 0);
          return;
        }
        var b = t.lf.graphModel.getAreaElement(v, g, t.isWholeEdge, t.isWholeNode, !0), _ = t.lf.graphModel, D = _.dynamicGroup, L = _.group, W = [], B = t.lf.getSelectElements(), K = new Set(Wo(Wo([], jo(B.nodes.map(function(se) {
          return se.id;
        })), !1), jo(B.edges.map(function(se) {
          return se.id;
        })), !1));
        b.forEach(function(se) {
          if (L) {
            var Le = L.getNodeGroup(se.id);
            if (b.includes(Le)) return;
          }
          if (D) {
            var Le = D.getGroupByNodeId(se.id);
            if (b.includes(Le)) return;
          }
          if (t.exclusiveMode && K.has(se.id)) {
            t.lf.deselectElementById(se.id);
            return;
          }
          t.lf.selectElementById(se.id, !0), W.push(se);
        }), t.startPoint = void 0, t.endPoint = void 0, W.length > 0 && t.lf.emit("selection:drop", { e: a }), t.lf.emit("selection:selected", {
          elements: W,
          leftTopPoint: v,
          rightBottomPoint: g
        });
      }
      t.wrapper && (t.wrapper.oncontextmenu = null, t.container && t.wrapper.parentNode === t.container && t.container.removeChild(t.wrapper), t.wrapper = void 0);
    }, this.lf = e, this.exclusiveMode = (r = i == null ? void 0 : i.exclusiveMode) !== null && r !== void 0 ? r : !1, e.openSelectionSelect = function() {
      t.openSelectionSelect();
    }, e.closeSelectionSelect = function() {
      t.closeSelectionSelect();
    }, e.setSelectionSelectMode = function(a) {
      t.setExclusiveMode(a);
    }, this.handleMouseDown = this.handleMouseDown.bind(this), this.draw = this.draw.bind(this), this.drawOff = this.drawOff.bind(this);
  }
  return o.prototype.render = function(n, e) {
    this.container = e;
  }, o.prototype.cleanupSelectionState = function() {
    this.wrapper && (this.wrapper.oncontextmenu = null, this.container && this.wrapper.parentNode === this.container && this.container.removeChild(this.wrapper), this.wrapper = void 0), this.startPoint = void 0, this.endPoint = void 0, this.mouseDownInfo = null, document.removeEventListener("pointermove", this.draw), document.removeEventListener("pointerup", this.drawOff);
  }, o.prototype.setExclusiveMode = function(n) {
    n === void 0 && (n = !1), this.exclusiveMode !== n && (this.cleanupSelectionState(), this.exclusiveMode = n, this.container && !this.disabled && (this.removeEventListeners(), this.addEventListeners()));
  }, o.prototype.addEventListeners = function() {
    this.container && (this.exclusiveMode ? (this.container.style.pointerEvents = "auto", this.container.style.touchAction = "none", this.container.addEventListener("pointerdown", this.handleMouseDown)) : (this.container.style.pointerEvents = "none", this.lf.on("blank:mousedown", this.handleBlankMouseDown)));
  }, o.prototype.removeEventListeners = function() {
    this.container && (this.container.style.pointerEvents = "none", this.container.removeEventListener("pointerdown", this.handleMouseDown)), this.lf.off("blank:mousedown", this.handleBlankMouseDown);
  }, o.prototype.handleMouseDown = function(n) {
    var e;
    if (!(!this.container || this.disabled) && !this.lf.graphModel.editConfigModel.isPinching && n.button !== 2) {
      this.cleanupSelectionState(), this.mouseDownInfo = {
        x: n.clientX,
        y: n.clientY,
        time: Date.now()
      }, this.originStatusSaved || (this.originalStopMoveGraph = this.lf.getEditConfig().stopMoveGraph, this.originStatusSaved = !0), this.lf.updateEditConfig({ stopMoveGraph: !0 });
      var i = this.lf.getPointByClient(n.clientX, n.clientY).domOverlayPosition, t = i.x, r = i.y;
      this.startPoint = {
        x: t,
        y: r
      }, this.endPoint = {
        x: t,
        y: r
      };
      var a = document.createElement("div");
      a.className = "lf-selection-select", a.oncontextmenu = function(d) {
        d.preventDefault();
      }, a.style.top = "".concat(this.startPoint.y, "px"), a.style.left = "".concat(this.startPoint.x, "px"), (e = this.container) === null || e === void 0 || e.appendChild(a), this.wrapper = a, document.addEventListener("pointermove", this.draw), document.addEventListener("pointerup", this.drawOff);
    }
  }, o.prototype.setSelectionSense = function(n, e) {
    n === void 0 && (n = !0), e === void 0 && (e = !0), this.isWholeEdge = n, this.isWholeNode = e;
  }, o.prototype.openSelectionSelect = function() {
    this.disabled || this.closeSelectionSelect(), this.container && (this.cleanupSelectionState(), this.addEventListeners(), this.open());
  }, o.prototype.closeSelectionSelect = function() {
    if (this.container) {
      if (this.wrapper && this.startPoint && this.endPoint) {
        var n = ft(this.endPoint), e = new PointerEvent("pointerup", {
          clientX: n.x,
          clientY: n.y
        });
        this.drawOff(e);
      }
      this.cleanupSelectionState(), this.removeEventListeners(), this.close();
    }
  }, o.prototype.open = function() {
    this.disabled = !1;
  }, o.prototype.close = function() {
    this.disabled = !0;
  }, o.pluginName = "selectionSelect", o;
})(), An = function() {
  return An = Object.assign || function(o) {
    for (var n, e = 1, i = arguments.length; e < i; e++) {
      n = arguments[e];
      for (var t in n) Object.prototype.hasOwnProperty.call(n, t) && (o[t] = n[t]);
    }
    return o;
  }, An.apply(this, arguments);
}, Ii = function(o, n) {
  var e = typeof Symbol == "function" && o[Symbol.iterator];
  if (!e) return o;
  var i = e.call(o), t, r = [], a;
  try {
    for (; (n === void 0 || n-- > 0) && !(t = i.next()).done; ) r.push(t.value);
  } catch (s) {
    a = { error: s };
  } finally {
    try {
      t && !t.done && (e = i.return) && e.call(i);
    } finally {
      if (a) throw a.error;
    }
  }
  return r;
}, ki = function(o, n, e) {
  if (e || arguments.length === 2)
    for (var i = 0, t = n.length, r; i < t; i++) (r || !(i in n)) && (r || (r = Array.prototype.slice.call(n, 0, i)), r[i] = n[i]);
  return o.concat(r || Array.prototype.slice.call(n));
}, uu = function(o, n) {
  var e = n.getModelById(o);
  return cu((e == null ? void 0 : e.BaseType) === "node" ? e : e == null ? void 0 : e.targetNode, n);
}, cu = function(o, n) {
  var e = [], i = [], t = function(a, s, d) {
    if (a) {
      if (d && s.unshift.apply(s, ki([], Ii(n.getEdgeModels({
        sourceNodeId: a.id,
        targetNodeId: d == null ? void 0 : d.id
      }).map(function(l) {
        return l.id;
      })), !1)), s.includes(a.id)) {
        e.push(s);
        return;
      }
      if (s.unshift(a.id), !a.incoming.nodes.length) {
        e.push(s);
        return;
      }
      a.incoming.nodes.forEach(function(l) {
        t(l, s.slice(), a);
      });
    }
  }, r = function(a, s, d) {
    if (a) {
      if (d && s.push.apply(s, ki([], Ii(n.getEdgeModels({
        sourceNodeId: d == null ? void 0 : d.id,
        targetNodeId: a.id
      }).map(function(l) {
        return l.id;
      })), !1)), s.includes(a.id)) {
        i.push(s);
        return;
      }
      if (s.push(a.id), !a.outgoing.nodes.length) {
        i.push(s);
        return;
      }
      a.outgoing.nodes.forEach(function(l) {
        r(l, s.slice(), a);
      });
    }
  };
  return t(o, []), r(o, []), ki([], Ii(new Set(ki(ki([], Ii(e.flat()), !1), Ii(i.flat()), !1))), !1);
}, Nc = (function() {
  function o(n) {
    var e = n.lf, i = n.options;
    this.mode = "path", this.enable = !0, this.tempStyles = {};
    var t = i.mode, r = t === void 0 ? "path" : t, a = i.enable, s = a === void 0 ? !0 : a;
    this.lf = e, this.mode = r, this.enable = s;
  }
  return o.prototype.setMode = function(n) {
    this.mode = n;
  }, o.prototype.setEnable = function(n) {
    this.enable = n;
  }, o.prototype.highlightSingle = function(n) {
    var e = this.lf.getModelById(n);
    (e == null ? void 0 : e.BaseType) === "node" ? e.updateStyles(this.tempStyles[n]) : (e == null ? void 0 : e.BaseType) === "edge" && (e.updateStyles(this.tempStyles[n]), e.sourceNode.updateStyles(this.tempStyles[e.sourceNode.id]), e.targetNode.updateStyles(this.tempStyles[e.targetNode.id])), this.lf.emit("highlight:single", { data: e });
  }, o.prototype.highlightNeighbours = function(n) {
    var e = this, i = this.lf.getModelById(n), t = [];
    if ((i == null ? void 0 : i.BaseType) === "node") {
      i.updateStyles(this.tempStyles[n]);
      var r = i.incoming, a = r.nodes, s = r.edges, d = i.outgoing, l = d.nodes, u = d.edges;
      jn(a, l).forEach(function(c) {
        c.updateStyles(e.tempStyles[c.id]);
      }), jn(s, u).forEach(function(c) {
        c.updateStyles(e.tempStyles[c.id]);
      }), t = Os(jn(t, a, l, s, u), "id");
    } else (i == null ? void 0 : i.BaseType) === "edge" && (i.updateStyles(this.tempStyles[n]), i.sourceNode.updateStyles(this.tempStyles[i.sourceNode.id]), i.targetNode.updateStyles(this.tempStyles[i.targetNode.id]), t = [i.sourceNode, i.targetNode]);
    this.lf.emit("highlight:neighbours", {
      data: i,
      relateElements: t
    });
  }, o.prototype.highlightPath = function(n) {
    var e = this, i = uu(n, this.lf), t = [];
    i.forEach(function(r) {
      var a = e.lf.getModelById(r);
      a == null || a.updateStyles(e.tempStyles[r]), t.push(a);
    }), this.lf.emit("highlight:path", {
      data: this.lf.getModelById(n),
      relateElements: t
    });
  }, o.prototype.highlight = function(n, e) {
    var i = this;
    e === void 0 && (e = this.mode), this.enable && (Object.keys(this.tempStyles).length && this.restoreHighlight(), Object.values(this.lf.graphModel.modelsMap).forEach(function(t) {
      var r = t.BaseType === "node" ? t.getNodeStyle() : t.getEdgeStyle();
      i.tempStyles[t.id] = An({}, r), t.setStyles({ opacity: 0.1 });
    }), {
      single: this.highlightSingle.bind(this),
      neighbour: this.highlightNeighbours.bind(this),
      path: this.highlightPath.bind(this)
    }[e](n));
  }, o.prototype.restoreHighlight = function() {
    var n = this;
    Object.keys(this.tempStyles).length && (Object.values(this.lf.graphModel.modelsMap).forEach(function(e) {
      var i, t = (i = n.tempStyles[e.id]) !== null && i !== void 0 ? i : {};
      e.updateStyles(An({}, t));
    }), this.tempStyles = {});
  }, o.prototype.render = function() {
    var n = this;
    this.lf.on("node:mouseenter", function(e) {
      var i = e.data;
      return n.highlight(i.id);
    }), this.lf.on("edge:mouseenter", function(e) {
      var i = e.data;
      return n.highlight(i.id);
    }), this.lf.on("node:mouseleave", this.restoreHighlight.bind(this)), this.lf.on("edge:mouseleave", this.restoreHighlight.bind(this)), this.lf.on("history:change", this.restoreHighlight.bind(this));
  }, o.prototype.destroy = function() {
  }, o.pluginName = "highlight", o;
})(), ka = /* @__PURE__ */ (function() {
  var o = function(n, e) {
    return o = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(i, t) {
      i.__proto__ = t;
    } || function(i, t) {
      for (var r in t) Object.prototype.hasOwnProperty.call(t, r) && (i[r] = t[r]);
    }, o(n, e);
  };
  return function(n, e) {
    if (typeof e != "function" && e !== null) throw new TypeError("Class extends value " + String(e) + " is not a constructor or null");
    o(n, e);
    function i() {
      this.constructor = n;
    }
    n.prototype = e === null ? Object.create(e) : (i.prototype = e.prototype, new i());
  };
})(), xi = function() {
  return xi = Object.assign || function(o) {
    for (var n, e = 1, i = arguments.length; e < i; e++) {
      n = arguments[e];
      for (var t in n) Object.prototype.hasOwnProperty.call(n, t) && (o[t] = n[t]);
    }
    return o;
  }, xi.apply(this, arguments);
}, Xi = function(o, n) {
  var e = typeof Symbol == "function" && o[Symbol.iterator];
  if (!e) return o;
  var i = e.call(o), t, r = [], a;
  try {
    for (; (n === void 0 || n-- > 0) && !(t = i.next()).done; ) r.push(t.value);
  } catch (s) {
    a = { error: s };
  } finally {
    try {
      t && !t.done && (e = i.return) && e.call(i);
    } finally {
      if (a) throw a.error;
    }
  }
  return r;
}, hu = function(o) {
  return Array.isArray(o) && o.length === 2 && Number.isFinite(o[0]) && Number.isFinite(o[1]);
}, fu = {
  tr: "tl",
  lb: "tl",
  tl: "tr",
  rb: "tr",
  br: "bl",
  lt: "bl",
  bl: "br",
  rt: "br"
};
function pu(o) {
  for (var n = o, e = 1; e < n.length - 1; ) {
    var i = Xi(n[e - 1], 2), t = i[0], r = i[1], a = Xi(n[e], 2), s = a[0], d = a[1], l = Xi(n[e + 1], 2), u = l[0], c = l[1];
    t === s && s === u || r === d && d === c ? n.splice(e, 1) : e++;
  }
  return n;
}
function vu(o, n, e, i) {
  var t = [o[0], o[1]], r = [o[0], o[1]];
  switch (e) {
    case "tl":
      return n === "tr" ? (t[1] += i, r[0] += i) : n === "lb" && (t[0] += i, r[1] += i), [t, r];
    case "tr":
      return n === "tl" ? (t[1] += i, r[0] -= i) : n === "rb" && (t[0] -= i, r[1] += i), [t, r];
    case "bl":
      return n === "br" ? (t[1] -= i, r[0] += i) : n === "lt" && (t[0] += i, r[1] -= i), [t, r];
    case "br":
      return n === "bl" ? (t[1] -= i, r[0] -= i) : n === "rt" && (t[0] -= i, r[1] -= i), [t, r];
    default:
      return [];
  }
}
function gu(o, n, e, i) {
  var t, r = 1, a = function(g, b) {
    var _ = b[0] - g[0], D = b[1] - g[1], L = Math.abs(_), W = Math.abs(D);
    return W <= r && L > r ? _ < 0 ? "l" : "r" : L <= r && W > r ? D < 0 ? "t" : "b" : L <= r && W <= r ? "" : L < W ? _ < 0 ? "l" : "r" : D < 0 ? "t" : "b";
  }, s = a(o, n), d = a(n, e), l = Math.min(Math.hypot(n[0] - o[0], n[1] - o[1]) / 2, Math.hypot(e[0] - n[0], e[1] - n[1]) / 2, i) || 1 / 5 * i, u = "".concat(s).concat(d), c = fu[u] || "-", h = "";
  if (c === "-") h += "L ".concat(n[0], " ").concat(n[1]);
  else {
    var f = Xi(vu(n, u, c, l), 2), p = f[0], v = f[1];
    p && v && (h += "L ".concat(p[0], " ").concat(p[1], " Q ").concat(n[0], " ").concat(n[1], " ").concat(v[0], " ").concat(v[1]), t = Xi(v, 2), n[0] = t[0], n[1] = t[1]);
  }
  return h;
}
function mu(o, n) {
  if (o.length === 0 || !o.every(hu)) return "";
  var e = 0, i = "M".concat(o[e][0], " ").concat(o[e++][1]);
  if (o.length === 1) return i;
  if (o.length === 2) i += " L ".concat(o[e][0], " ").concat(o[e][1]);
  else {
    for (; e + 1 < o.length; ) {
      var t = o[e - 1], r = o[e], a = o[e++ + 1];
      i += gu(t, r, a, n);
    }
    i += "L ".concat(o[e][0], " ").concat(o[e][1]);
  }
  return i;
}
var Tc = (function(o) {
  ka(n, o);
  function n() {
    return o !== null && o.apply(this, arguments) || this;
  }
  return n.prototype.getEdge = function() {
    var e = this.props.model, i = e.points, t = e.isAnimation, r = e.arrowConfig, a = e.radius, s = a === void 0 ? 5 : a, d = e.getEdgeStyle(), l = e.getEdgeAnimationStyle(), u = mu(pu(i.split(" ").map(function(h) {
      return h.split(",").map(function(f) {
        return +f;
      });
    })), s), c = xi(xi(xi({ style: t ? l : {} }, d), r), { fill: "none" });
    return I("path", xi({ d: u }, c));
  }, n;
})(_r), Mc = (function(o) {
  ka(n, o);
  function n() {
    return o !== null && o.apply(this, arguments) || this;
  }
  return n;
})(wr), Ba = /* @__PURE__ */ (function() {
  var o = function(n, e) {
    return o = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(i, t) {
      i.__proto__ = t;
    } || function(i, t) {
      for (var r in t) Object.prototype.hasOwnProperty.call(t, r) && (i[r] = t[r]);
    }, o(n, e);
  };
  return function(n, e) {
    if (typeof e != "function" && e !== null) throw new TypeError("Class extends value " + String(e) + " is not a constructor or null");
    o(n, e);
    function i() {
      this.constructor = n;
    }
    n.prototype = e === null ? Object.create(e) : (i.prototype = e.prototype, new i());
  };
})(), On = function() {
  return On = Object.assign || function(o) {
    for (var n, e = 1, i = arguments.length; e < i; e++) {
      n = arguments[e];
      for (var t in n) Object.prototype.hasOwnProperty.call(n, t) && (o[t] = n[t]);
    }
    return o;
  }, On.apply(this, arguments);
}, $o = function(o, n) {
  var e = typeof Symbol == "function" && o[Symbol.iterator];
  if (!e) return o;
  var i = e.call(o), t, r = [], a;
  try {
    for (; (n === void 0 || n-- > 0) && !(t = i.next()).done; ) r.push(t.value);
  } catch (s) {
    a = { error: s };
  } finally {
    try {
      t && !t.done && (e = i.return) && e.call(i);
    } finally {
      if (a) throw a.error;
    }
  }
  return r;
}, Xo = function(o, n, e) {
  if (e || arguments.length === 2)
    for (var i = 0, t = n.length, r; i < t; i++) (r || !(i in n)) && (r || (r = Array.prototype.slice.call(n, 0, i)), r[i] = n[i]);
  return o.concat(r || Array.prototype.slice.call(n));
}, yu = (function(o) {
  Ba(n, o);
  function n() {
    return o !== null && o.apply(this, arguments) || this;
  }
  return n.prototype.getLabelShape = function() {
    var e = this.props.model, i = e.id, t = e.x, r = e.y, a = e.width, s = e.height, d = e.properties, l = this.props.model.getNodeStyle();
    return I("svg", {
      x: t - a / 2,
      y: r - s / 2,
      width: 50,
      height: 24,
      style: "z-index: 0; background: none; overflow: auto;"
    }, [d.labelText ? I("text", {
      x: 0,
      y: -5,
      fontSize: "16px",
      fill: l.stroke
    }, d.labelText) : "", d.disabledDelete ? "" : I("text", {
      x: d.labelText ? 50 : 0,
      y: -5,
      fontSize: "24px",
      cursor: "pointer",
      fill: l.stroke,
      onclick: this.handleCustomDeleteIconClick.bind(this, i)
    }, "x")]);
  }, n.prototype.getShape = function() {
    var e = this.props.model, i = e.x, t = e.y, r = e.width, a = e.height, s = e.id, d = this.props.model.getNodeStyle();
    return I("g", {}, [I("rect", On(On({}, d), {
      x: i - r / 2,
      y: t - a / 2,
      width: r,
      height: a,
      id: s
    })), this.getLabelShape()]);
  }, n.prototype.toFront = function() {
  }, n.prototype.handleCustomDeleteIconClick = function(e) {
    this.props.graphModel.deleteNode(e);
  }, n;
})(Cr), bu = (function(o) {
  Ba(n, o);
  function n() {
    var e = o.apply(this, Xo([], $o(arguments), !1)) || this;
    return e.d = 10, e.isResize = !1, e;
  }
  return n.prototype.initNodeData = function(e) {
    e.text = {
      value: "",
      x: e.x,
      y: e.y,
      draggable: !1,
      editable: !1
    }, o.prototype.initNodeData.call(this, e), this.zIndex = 0, this.draggable = !0;
  }, n.prototype.setAttributes = function() {
    var e = this, i;
    this.points = [], ((i = this.properties) === null || i === void 0 ? void 0 : i.node_selection_ids).length > 1 && setTimeout(function() {
      var t;
      e.updatePointsByNodes(((t = e.properties) === null || t === void 0 ? void 0 : t.node_selection_ids) || []);
    });
  }, n.prototype.getNodeStyle = function() {
    var e = o.prototype.getNodeStyle.call(this);
    return e.stroke = this.properties.strokeColor || "#008000", e.strokeDasharray = "10 5", e;
  }, n.prototype.getDefaultAnchor = function() {
    return [];
  }, n.prototype.updatePoints = function(e) {
    this.points = e;
  }, n.prototype.updateCoordinate = function(e) {
    var i = e.x, t = e.y;
    this.x = i, this.y = t;
  }, n.prototype.updatePointsByNodes = function(e) {
    var i = this, t = [], r = 1 / 0, a = 1 / 0, s = -1 / 0, d = -1 / 0;
    e.forEach(function(l) {
      var u = i.graphModel.getNodeModelById(l);
      if (u) {
        var c = u.width, h = u.height, f = u.x, p = u.y;
        r = Math.min(r, f - c / 2 - i.d), a = Math.min(a, p - h / 2 - i.d), s = Math.max(s, f + c / 2 + i.d), d = Math.max(d, p + h / 2 + i.d);
      }
    }), t.push([r, a], [s, a], [s, d], [r, d]), ![
      r,
      a,
      s,
      d
    ].some(function(l) {
      return Math.abs(l) === 1 / 0;
    }) && (this.updatePoints(t), this.updateCoordinate({
      x: (s + r) / 2,
      y: (d + a) / 2
    }));
  }, n.prototype.resize = function(e) {
    var i;
    this.isResize = !0;
    for (var t = e.width, r = e.height, a = {
      x: t / this.width,
      y: r / this.height
    }, s = (this.properties.node_selection_ids || []).slice(), d = [], l = /* @__PURE__ */ new Set(); s.length; ) {
      var u = s.shift(), c = (i = this.graphModel.nodesMap[u]) === null || i === void 0 ? void 0 : i.model;
      if (c) {
        if (!un(c)) {
          d.push(c);
          continue;
        }
        l.has(c.id) || (l.add(c.id), s.push.apply(s, Xo([], $o(c.properties.node_selection_ids || []), !1)));
      }
    }
    var h = {
      x: this.x - this.width / 2,
      y: this.y - this.height / 2
    }, f = o.prototype.resize.call(this, e), p = {
      x: this.x - this.width / 2,
      y: this.y - this.height / 2
    };
    return d.forEach(function(v) {
      v.width = v.width * a.x, v.height = v.height * a.y;
      var g = (v.x - h.x) * a.x + p.x - v.x, b = (v.y - h.y) * a.y + p.y - v.y;
      v.move(g, b, !0);
    }), this.isResize = !1, f;
  }, n;
})(Er), mr = "node-selection", Ac = (function() {
  function o(n) {
    var e = n.lf;
    this.selectNodes = [], this.d = 10, this.lf = e, e.register({
      type: mr,
      view: yu,
      model: bu
    });
  }
  return Object.defineProperty(o.prototype, "selectNodesIds", {
    get: function() {
      return this.selectNodes.map(function(n) {
        return n.id;
      });
    },
    enumerable: !1,
    configurable: !0
  }), o.prototype.addNodeSelection = function() {
    this.lf.addNode({
      type: "node-selection",
      text: "",
      properties: { node_selection_ids: this.selectNodesIds },
      x: 0,
      y: 0
    }).updatePointsByNodes(this.selectNodesIds);
  }, o.prototype.updateNodeSelection = function() {
    var n, e = this.getNodeSelection();
    e && (this.lf.setProperties(e.id, { node_selection_ids: this.selectNodesIds }), (n = this.lf.getNodeModelById(e.id)) === null || n === void 0 || n.updatePointsByNodes(this.selectNodesIds));
  }, o.prototype.getNodeSelection = function() {
    var n = this, e = this.selectNodesIds, i = this.lf.getGraphRawData(), t = e.filter(function(r) {
      return r !== n.currentClickNode.id;
    });
    return i.nodes.find(function(r) {
      if (r.type === "node-selection") {
        var a = Ns(r, "properties.node_selection_ids", []);
        return t.every(function(s) {
          return a.includes(s);
        });
      }
      return !1;
    });
  }, o.prototype.onNodeChange = function(n, e) {
    var i = n.graphModel.nodes.filter(function(t) {
      return un(t) ? (t.properties.node_selection_ids || []).includes(e.id) : !1;
    });
    Promise.resolve().then(function() {
      i.forEach(function(t) {
        t.updatePointsByNodes(t.properties.node_selection_ids || []);
      });
    });
  }, o.prototype.render = function(n) {
    var e = this;
    this.lf = n, n.on("node:click", function(i) {
      var t;
      if (!(!i.e.shiftKey || i.data.type === mr)) {
        e.currentClickNode = i.data;
        var r = !1;
        e.selectNodesIds.includes(i.data.id) && ((t = e.lf.getNodeModelById(i.data.id)) === null || t === void 0 || t.setSelected(!1), r = !0), e.selectNodes = n.getSelectElements(!0).nodes, e.selectNodes.length === 1 ? r ? e.updateNodeSelection() : e.addNodeSelection() : e.selectNodes.length > 1 && e.updateNodeSelection();
      }
    }), n.graphModel.addNodeMoveRules(function(i, t, r) {
      if (e.onNodeChange(n, i), un(i) && !i.isResize) {
        var a = i.properties.node_selection_ids || [];
        return n.graphModel.moveNodes(a, t, r, !0), !0;
      }
      return !0;
    }), n.graphModel.addNodeResizeRules(function(i) {
      return un(i) || e.onNodeChange(n, i), !0;
    });
  }, o.pluginName = "node-selection", o;
})(), un = function(o) {
  return !!(o && o.type === mr);
}, xu = /* @__PURE__ */ (function() {
  var o = function(n, e) {
    return o = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(i, t) {
      i.__proto__ = t;
    } || function(i, t) {
      for (var r in t) Object.prototype.hasOwnProperty.call(t, r) && (i[r] = t[r]);
    }, o(n, e);
  };
  return function(n, e) {
    if (typeof e != "function" && e !== null) throw new TypeError("Class extends value " + String(e) + " is not a constructor or null");
    o(n, e);
    function i() {
      this.constructor = n;
    }
    n.prototype = e === null ? Object.create(e) : (i.prototype = e.prototype, new i());
  };
})(), Dn = function() {
  return Dn = Object.assign || function(o) {
    for (var n, e = 1, i = arguments.length; e < i; e++) {
      n = arguments[e];
      for (var t in n) Object.prototype.hasOwnProperty.call(n, t) && (o[t] = n[t]);
    }
    return o;
  }, Dn.apply(this, arguments);
}, Oc = (function(o) {
  xu(n, o);
  function n() {
    return o !== null && o.apply(this, arguments) || this;
  }
  return n.prototype.getLabelShape = function() {
    var e = this.props.model, i = e.x, t = e.y, r = e.width, a = e.height, s = e.properties;
    return I("text", {
      x: i - r / 2 + 5,
      y: t - a / 2 + 16,
      fontSize: 12,
      fill: "blue"
    }, s.moreText);
  }, n.prototype.getShape = function() {
    var e = this.props.model, i = e.x, t = e.y, r = e.width, a = e.height, s = this.props.model.getNodeStyle();
    return I("g", {}, [I("rect", Dn(Dn({}, s), {
      fill: "#FFFFFF",
      x: i - r / 2,
      y: t - a / 2
    })), this.getLabelShape()]);
  }, n;
})(_i), wu = class extends Mr.view {
  constructor(o) {
    super(o), this.$super = new os(o);
  }
  getOperateIcon() {
    return I("g", {});
  }
  get ref() {
    return this.$super.ref;
  }
  set ref(o) {
    this.$super.ref = o;
  }
  get currentProperties() {
    return this.$super.currentProperties;
  }
  set currentProperties(o) {
    this.$super.currentProperties = o;
  }
  get preProperties() {
    return this.$super.preProperties;
  }
  set preProperties(o) {
    this.$super.preProperties = o;
  }
  get rootEl() {
    return this.$super.rootEl;
  }
  setHtml(o) {
    this.$super.setHtml.call(this, o);
  }
  shouldUpdate() {
    return this.$super.shouldUpdate.call(this);
  }
  componentDidMount() {
    this.$super.componentDidMount.call(this);
  }
  componentDidUpdate() {
    this.$super.componentDidUpdate.call(this);
  }
  componentWillUnmount() {
    this.$super.componentWillUnmount.call(this);
  }
  getShape() {
    return I("g", {}, [
      this.getAppendAreaShape(),
      this.$super.getShape.call(this),
      this.getOperateIcon()
    ]);
  }
  confirmUpdate(o) {
    this.$super.confirmUpdate.call(this, o);
  }
  getAnchorShape(o) {
    return this.$super.getAnchorShape.call(this, o);
  }
  get root() {
    return this.$super.root;
  }
  set root(o) {
    this.$super.root = o;
  }
  get vm() {
    return this.$super.vm;
  }
  set vm(o) {
    this.$super.vm = o;
  }
  getComponentContainer() {
    return this.$super.getComponentContainer.call(this);
  }
  targetId() {
    return this.$super.targetId.call(this);
  }
  renderVueComponent() {
    this.$super.renderVueComponent.call(this);
  }
  unmountVueComponent() {
    this.$super.unmountVueComponent.call(this);
  }
  stopResizeObserver() {
    this.$super.stopResizeObserver.call(this);
  }
  unmount() {
    this.$super.unmount.call(this);
  }
};
Uo();
var yr = /* @__PURE__ */ new Map();
function Bi(o) {
  let n = yr.get(o);
  return n || (n = {}, yr.set(o, n)), n;
}
function Eu(o) {
  var n;
  return o.id || (o.id = es()), o.properties = cn(cn({}, o.properties), {}, {
    collapsible: !1,
    autoToFront: !1,
    transformWithContainer: !1,
    isRestrict: !0,
    autoResize: !0,
    children: (n = o.properties.children) !== null && n !== void 0 ? n : []
  }), o;
}
var _u = class extends Mr.model {
  constructor(o, n) {
    super(Eu(o), n), this.$super = new is(o, n), this.sourceRules.push(...this.$super.sourceRules), this.targetRules.push(...this.$super.targetRules), this.setTempData();
  }
  get $children() {
    var o, n;
    return (o = (n = this.$super) === null || n === void 0 || (n = n.properties) === null || n === void 0 ? void 0 : n.children) !== null && o !== void 0 ? o : [];
  }
  isAllowAppendIn(o) {
    return this.$children.includes(o.id);
  }
  getOutlineStyle() {
    const o = super.getOutlineStyle();
    return o.stroke = "none", o.hover && (o.hover.stroke = "none"), o;
  }
  addChild(o) {
    super.addChild(o);
    const n = [...this.$children];
    n.push(o), this.$super.properties.children = n, this.graphModel.$J.$groupUtils.recalcGroupSize(this.id);
  }
  removeChild(o) {
    super.removeChild(o);
    const n = [...this.$children];
    this.$super.properties.children = n.filter((e) => e !== o), this.graphModel.$J.$groupUtils.recalcGroupSize(this.id);
  }
  getAddableOutlineStyle() {
    return {
      stroke: "none",
      fill: "transparent"
    };
  }
  get width() {
    var o, n;
    const e = Bi(this);
    return (o = (n = this.$super) === null || n === void 0 ? void 0 : n.width) !== null && o !== void 0 ? o : e.width;
  }
  set width(o) {
    if (!this.$super) {
      const n = Bi(this);
      n.width = o;
      return;
    }
    this.$super.width = o;
  }
  get height() {
    var o, n;
    const e = Bi(this);
    return (o = (n = this.$super) === null || n === void 0 ? void 0 : n.height) !== null && o !== void 0 ? o : e.height;
  }
  set height(o) {
    if (!this.$super) {
      const n = Bi(this);
      n.height = o;
      return;
    }
    this.$super.height = o;
  }
  get nodeConfig() {
    var o;
    return (o = this.$super) === null || o === void 0 ? void 0 : o.nodeConfig;
  }
  getDefaultAnchor() {
    return this.$super.getDefaultAnchor.call(this);
  }
  getAnchorLineStyle(...o) {
    return this.$super.getAnchorLineStyle.call(this, ...o);
  }
  setAttributes() {
    var o, n;
    return ((o = (n = this.$super) === null || n === void 0 ? void 0 : n.setAttributes) !== null && o !== void 0 ? o : super.setAttributes).call(this);
  }
  getNodeStyle() {
    var o, n;
    return ((o = (n = this.$super) === null || n === void 0 ? void 0 : n.getNodeStyle) !== null && o !== void 0 ? o : super.getNodeStyle).call(this);
  }
  setTempData() {
    const o = Bi(this);
    Object.keys(o).forEach((n) => {
      this[n] = o[n];
    }), yr.delete(this);
  }
}, or = 320, ar = 240, Cu = /* @__PURE__ */ ys({
  __name: "LoopBodyNode",
  props: {
    node: {},
    graph: {}
  },
  setup(o) {
    const n = o, e = zn(), i = $a(), t = zn(or), r = zn(ar), { containerRef: a, containerProps: s, $node: d, $properties: l, runStatus: u } = ps(n, {
      hideAction: !0,
      addNodeDialogConfig: {
        addPayload: { edgeType: as.type },
        offset: {
          showTop: 0,
          showRight: 300
        }
      },
      updateHeightImmediate: !1,
      disableResizeListener: !0,
      listenForeignObjectResize: !0,
      onParentResize(f) {
        t.value = f.width, t.value < or && (t.value = or), r.value = f.height, r.value < ar && (r.value = ar), n.node.setProperties({
          width: t.value,
          height: r.value
        });
      },
      addNodeIsShow: (f) => Mu(f)
    }), c = vs(() => {
      var f;
      return Ga((f = d.value) === null || f === void 0 ? void 0 : f.id);
    });
    function h() {
      return i.nodeSteps.find((f) => f.node.id === c.value);
    }
    return _s(() => {
      const { graph: f, node: p } = n, v = f.getNodeEdges(p.id), g = u.value[0];
      for (const b of v) g && g !== "waiting" ? b.openEdgeAnimation() : b.closeEdgeAnimation();
    }), ws(() => {
    }), (f, p) => (Es(), gs(kr(hs), bs({
      ref_key: "containerRef",
      ref: a,
      class: "loop-body-node",
      width: t.value,
      runGetStepFn: h
    }, kr(s)), {
      default: Cs(() => [ms("div", {
        ref_key: "contentRef",
        ref: e,
        style: xs({
          width: "100%",
          height: r.value - 50 - 16 + "px",
          backgroundColor: "transparent",
          position: "relative",
          borderRadius: "8px",
          pointerEvents: "none"
        })
      }, null, 4)]),
      _: 1
    }, 16, ["width"]));
  }
}), Dc = /* @__PURE__ */ ja({ default: () => Ha }), Ha = Cu, Su = class extends wu {
}, Nu = class extends _u {
}, Yo = {
  type: Zt.LOOP_BODY,
  label: "循环体",
  components: {
    icon: fs,
    setting: cs
  },
  lfNode: {
    type: Zt.LOOP_BODY,
    view: Su,
    model: Nu,
    component: Ha
  },
  params: {
    width: 320,
    height: 240
  },
  methods: {
    createNode: Fa,
    getDefaultAnchor(o) {
      const n = o.find((i) => i.type === "left"), e = o.find((i) => i.type === "right");
      return [
        {
          id: `${this.id}_${Qt.LINK_LOOP}`,
          type: Qt.LINK_LOOP,
          x: this.x,
          y: this.y - this.height / 2
        },
        {
          id: `${this.id}_${Qt.LOOP_START}`,
          type: Qt.LOOP_START,
          allowAdd: !0,
          x: n.x + 30,
          y: this.y + 25
        },
        {
          id: `${this.id}_${Qt.LOOP_END}`,
          type: Qt.LOOP_END,
          allowAdd: !1,
          x: e.x - 30,
          y: this.y + 25
        }
      ];
    }
  },
  hooks: { beforeRemoveNode() {
    return !1;
  } }
};
function Fa(o) {
  var n;
  const { loopNodeId: e } = o;
  return {
    id: e + Qo,
    type: Yo.type,
    x: o.x,
    y: o.y,
    properties: {
      text: (n = o.text) !== null && n !== void 0 ? n : Yo.label,
      options: {},
      inputParams: [],
      outputParams: []
    }
  };
}
Uo();
var Tu = Xa();
function Mu(o) {
  return o === Zt.LOOP || o === Zt.END ? !1 : o === Zt.LOOP_CONTINUE || o === Zt.LOOP_BREAK || o === Zt.SET_LOOP_VAR ? !0 : Wa.isShow(o);
}
function Pc(o) {
  return Ga(Tu.nodeGroupMap.get(o));
}
function Ga(o) {
  if (o)
    return o.slice(0, -Qo.length);
}
var Au = 320;
function Rc(o, n) {
  if (!o || !n) return;
  const e = o.id, i = {
    x: o.x,
    y: o.y + o.height + Au
  }, t = Fa(cn(cn({}, i), {}, { loopNodeId: e })), r = n.addNode(t), a = `${e}_${rs.LINK_BODY}`, s = `${r.id}_${Qt.LINK_LOOP}`;
  setTimeout(() => {
    n.addEdge({
      sourceNodeId: e,
      sourceAnchorId: a,
      targetNodeId: r.id,
      targetAnchorId: s,
      properties: { disabled: !0 }
    });
  }, 50);
}
export {
  Dc as a,
  Yo as i,
  Mu as n,
  cc as o,
  Pc as r,
  Rc as t
};
