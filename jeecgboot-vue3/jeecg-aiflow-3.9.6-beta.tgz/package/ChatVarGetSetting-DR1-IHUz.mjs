import { a as q } from "./objectSpread2-B0BetFB8.mjs";
import { t as A } from "./_plugin-vue_export-helper-Dj7HTbfw.mjs";
import { t as I } from "./VarListShow-Dg1oan43.mjs";
import { t as O } from "./useSettings-Cq_-E7Ut.mjs";
import { Alert as B, Input as G, Popconfirm as w } from "ant-design-vue/es";
import { Fragment as N, computed as j, createBlock as D, createCommentVNode as _, createElementBlock as p, createElementVNode as n, createVNode as i, defineComponent as E, openBlock as l, renderList as F, unref as o, withCtx as L } from "vue";
import f from "/@/components/Icon";
import { cloneDeep as u } from "lodash-es";
var U = { class: "chat-var-get-setting" }, $ = { class: "vars-list" }, M = { class: "var-actions" }, R = {
  key: 0,
  class: "add-action"
}, z = /* @__PURE__ */ E({
  __name: "ChatVarGetSetting",
  props: {
    type: {
      type: String,
      required: !0
    },
    node: {
      type: Object,
      required: !0
    },
    properties: {
      type: Object,
      required: !0
    },
    isSilentMode: {
      type: Boolean,
      required: !0
    },
    setProperties: {
      type: Function,
      required: !0
    }
  },
  setup(g) {
    const d = g, { outputParams: y, options: h, updateOptions: C, isReadOnly: s } = O(d), a = j({
      get: () => u(h.value.variables) || [],
      set: (t) => {
        const e = u(t);
        C({ variables: e }), b(e);
      }
    });
    function b(t) {
      const e = t.filter((r) => r.name).map((r) => ({
        field: r.name,
        name: r.name,
        type: "string"
      }));
      d.setProperties({ outputParams: e });
    }
    function V() {
      if (s.value) return;
      const t = u(a.value);
      t.push({ name: "" }), a.value = t;
    }
    function S(t) {
      if (s.value) return;
      const e = u(a.value);
      e.splice(t, 1), a.value = e;
    }
    function k() {
      a.value = u(a.value);
    }
    return (t, e) => {
      const r = B, x = G, P = w;
      return l(), p("div", U, [
        i(r, {
          type: "info",
          "show-icon": "",
          message: "从AI应用的变量中读取值，需要在AI应用中关联该流程",
          style: { "margin-bottom": "10px" }
        }),
        e[1] || (e[1] = n("div", { class: "setting-label" }, "读取变量", -1)),
        n("div", $, [(l(!0), p(N, null, F(a.value, (m, c) => (l(), p("div", {
          key: c,
          class: "var-item"
        }, [i(x, {
          value: m.name,
          "onUpdate:value": (v) => m.name = v,
          placeholder: "请输入变量名",
          disabled: o(s),
          onChange: k
        }, null, 8, [
          "value",
          "onUpdate:value",
          "disabled"
        ]), n("div", M, [!o(s) && a.value.length > 1 ? (l(), D(P, {
          key: 0,
          title: "确定要删除该变量吗？",
          placement: "left",
          onConfirm: (v) => S(c)
        }, {
          default: L(() => [i(o(f), { icon: "ant-design:delete-outlined" })]),
          _: 1
        }, 8, ["onConfirm"])) : _("", !0)])]))), 128))]),
        o(s) ? _("", !0) : (l(), p("div", R, [n("a", { onClick: V }, [i(o(f), { icon: "ic:round-add" }), e[0] || (e[0] = n("span", null, "添加变量", -1))])])),
        e[2] || (e[2] = n("div", {
          class: "setting-label",
          style: { "margin-top": "16px" }
        }, "输出变量", -1)),
        i(I, { vars: o(y) }, null, 8, ["vars"])
      ]);
    };
  }
}), te = /* @__PURE__ */ q({ default: () => H }), H = /* @__PURE__ */ A(z, [["__scopeId", "data-v-c9a1cbef"]]);
export {
  te as n,
  H as t
};
