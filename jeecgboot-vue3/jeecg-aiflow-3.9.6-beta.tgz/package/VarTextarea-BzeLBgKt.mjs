import { a as oe } from "./objectSpread2-B0BetFB8.mjs";
import { t as re } from "./asyncToGenerator-BkhZtDh9.mjs";
import { Dropdown as ie, Empty as se, Menu as ce, MenuItem as ve, Tooltip as de } from "ant-design-vue/es";
import { Fragment as F, Teleport as fe, computed as b, createBlock as k, createCommentVNode as D, createElementBlock as T, createElementVNode as p, createVNode as E, defineComponent as pe, nextTick as me, normalizeClass as v, onMounted as ye, openBlock as i, ref as m, renderList as ge, resolveComponent as he, toDisplayString as O, unref as d, useCssVars as _e, watch as B, withCtx as w, withModifiers as H } from "vue";
import { useDesign as xe } from "/@/hooks/web/useDesign";
import { isEmpty as Y } from "/@/utils/is";
var we = { style: {
  display: "flex",
  "justify-content": "space-between"
} }, be = { style: { color: "#999999" } }, ke = ["contenteditable"], Te = /* @__PURE__ */ pe({
  __name: "VarTextarea",
  props: {
    value: {
      type: String,
      required: !0
    },
    type: {
      type: String,
      default: "textarea"
    },
    placeholder: {
      type: String,
      default: ""
    },
    width: {
      type: [Number, String],
      default: 300
    },
    height: {
      type: [Number, String],
      default: 80
    },
    minHeight: {
      type: Number,
      default: 32
    },
    varsOptions: {
      type: Array,
      default: () => []
    },
    readonly: {
      type: Boolean,
      default: !1
    }
  },
  emits: [
    "update:value",
    "blur",
    "focus"
  ],
  setup(y, { emit: P }) {
    _e((e) => ({
      v22fc9ebc: U.value,
      v1e69118c: j.value
    }));
    const { prefixCls: s } = xe("airag-var-textarea"), n = y, _ = P, a = m(), g = b(() => n.type === "input"), K = b(() => !Y(n.placeholder) && Y(n.value)), U = b(() => g.value ? typeof n.width == "number" ? `${n.width}px` : n.width : "100%"), h = m(n.height);
    B(() => n.height, (e) => h.value = e);
    const j = b(() => g.value ? "32px" : typeof h.value == "number" ? `${h.value}px` : h.value), C = m(n.value), R = m(!0), S = m(!1);
    B(() => n.value, (e) => {
      if (e === `
`) {
        e = "", _("update:value", e);
        return;
      }
      R.value && I(e);
    });
    const c = m(!1), u = m(-1), r = m(!1), q = () => document.body, G = b(() => r.value ? { zIndex: 2100 } : void 0);
    function z() {
      return V.apply(this, arguments);
    }
    function V() {
      return V = re(function* () {
        var e, l, t;
        const f = (e = (l = (t = a.value) === null || t === void 0 ? void 0 : t.innerText) !== null && l !== void 0 ? l : n.value) !== null && e !== void 0 ? e : "";
        r.value = !r.value, c.value = !1, u.value = -1, yield me(), a.value && (a.value.innerText = f, a.value.focus());
      }), V.apply(this, arguments);
    }
    let o = null, x = null;
    function W(e) {
      if (c.value = !1, u.value = -1, e.data === "/") {
        const t = window.getSelection();
        if (t) {
          const f = document.createRange();
          f.setStart(t.anchorNode, t.anchorOffset - 1), f.setEnd(t.anchorNode, t.anchorOffset), t.removeAllRanges(), t.addRange(f), x = f, o = t;
        }
        c.value = !0, u.value = -1;
      }
      const l = a.value.innerText;
      _("update:value", l);
    }
    function J(e) {
      S.value = !1, R.value = !0, _("blur", e), setTimeout(() => {
        c.value && (c.value = !1);
      }, 300);
    }
    function Q(e) {
      S.value = !0, R.value = !1, _("focus", e);
    }
    function I(e) {
      g.value ? C.value = e.replace(/\n/g, "") : C.value = e, a.value && (a.value.innerText = C.value);
    }
    function L({ key: e }) {
      e = `{{${e}}}`, a.value.focus(), x ? (x.deleteContents(), x.insertNode(document.createTextNode(e)), o == null || o.removeAllRanges(), o == null || o.addRange(x), o == null || o.collapseToEnd()) : a.value.innerText += e, c.value = !1, u.value = -1, g.value ? _("update:value", a.value.innerText.replace(/\n/g, "")) : _("update:value", a.value.innerText), x = null, o = null;
    }
    function X(e) {
      if (c.value && n.varsOptions.length) {
        const l = n.varsOptions.length;
        if (e.key === "ArrowDown") {
          e.preventDefault(), u.value = u.value < 0 ? 0 : (u.value + 1) % l;
          return;
        }
        if (e.key === "ArrowUp") {
          e.preventDefault(), u.value <= 0 ? u.value = l - 1 : u.value -= 1;
          return;
        }
        if (e.key === "Enter" && u.value >= 0) {
          e.preventDefault();
          const t = n.varsOptions[u.value];
          t != null && t.name && L({ key: t.name });
          return;
        }
        if (e.key === "Escape") {
          e.preventDefault(), c.value = !1, u.value = -1;
          return;
        }
      }
      if (e.key === "Escape" && r.value) {
        e.preventDefault(), z();
        return;
      }
      g.value && e.key === "Enter" && e.preventDefault();
    }
    function Z(e) {
      const l = e.clipboardData || window.clipboardData;
      if (!l) return;
      e.preventDefault();
      const t = l.getData("text/plain");
      document.execCommand("insertText", !1, t);
    }
    ye(() => {
      I(n.value);
    });
    let $ = 0;
    function ee(e) {
      $ = e.clientY, a.value.style.pointerEvents = "none", window.addEventListener("mousemove", A), window.addEventListener("mouseup", N);
    }
    function N() {
      window.removeEventListener("mousemove", A), window.removeEventListener("mouseup", N), a.value.style.pointerEvents = "auto";
    }
    function A(e) {
      if (typeof h.value != "number") return;
      const l = e.clientY - $, t = h.value + l;
      t > n.minHeight && (h.value = t), $ = e.clientY;
    }
    return (e, l) => {
      const t = he("Icon"), f = de, te = ve, ne = ce, le = se, ae = ie;
      return i(), T(F, null, [r.value ? (i(), T("div", {
        key: 0,
        class: v([
          d(s),
          y.type,
          `${d(s)}-placeholder`
        ])
      }, null, 2)) : D("", !0), (i(), k(fe, {
        to: "body",
        disabled: !r.value
      }, [p("div", { class: v([
        d(s),
        y.type,
        {
          focus: S.value,
          "is-fullscreen": r.value
        }
      ]) }, [
        K.value ? (i(), T("div", {
          key: 0,
          class: v([`${d(s)}-place`])
        }, [p("span", null, O(y.placeholder), 1)], 2)) : D("", !0),
        g.value ? D("", !0) : (i(), k(f, {
          key: 1,
          title: r.value ? "退出全屏" : "全屏编辑"
        }, {
          default: w(() => [p("div", {
            class: v(`${d(s)}-fullscreen-btn`),
            onMousedown: l[0] || (l[0] = H(() => {
            }, ["prevent"])),
            onClick: H(z, ["stop"])
          }, [E(t, {
            icon: r.value ? "ant-design:fullscreen-exit-outlined" : "ant-design:fullscreen-outlined",
            size: 14
          }, null, 8, ["icon"])], 34)]),
          _: 1
        }, 8, ["title"])),
        E(ae, {
          open: c.value,
          getPopupContainer: q,
          overlayStyle: G.value
        }, {
          overlay: w(() => [y.varsOptions.length ? (i(), k(ne, {
            key: 0,
            class: v(`${d(s)}-var-menu`),
            onClick: L
          }, {
            default: w(() => [(i(!0), T(F, null, ge(y.varsOptions, (M, ue) => (i(), k(te, {
              key: M.name,
              class: v({ "is-active": ue === u.value })
            }, {
              icon: w(() => [E(t, { icon: "mdi:variable" })]),
              default: w(() => [p("div", we, [p("div", null, O(M.name), 1), p("div", be, O(M.type), 1)])]),
              _: 2
            }, 1032, ["class"]))), 128))]),
            _: 1
          }, 8, ["class"])) : (i(), k(le, {
            key: 1,
            description: "没有变量可选"
          }))]),
          default: w(() => [p("div", { class: v([`${d(s)}-border`]) }, [p("div", {
            ref_key: "inputRef",
            ref: a,
            class: v([`${d(s)}-inner`]),
            contenteditable: y.readonly ? "false" : "true",
            onInput: W,
            onBlur: J,
            onFocus: Q,
            onKeydown: X,
            onPaste: Z
          }, null, 42, ke), !g.value && !r.value ? (i(), T("div", {
            key: 0,
            class: v([`${d(s)}-resize`]),
            onMousedown: ee
          }, [E(t, { icon: "hugeicons:resize-field" })], 34)) : D("", !0)], 2)]),
          _: 1
        }, 8, ["open", "overlayStyle"])
      ], 2)], 8, ["disabled"]))], 64);
    };
  }
}), Me = /* @__PURE__ */ oe({ default: () => De }), De = Te;
export {
  Me as n,
  De as t
};
