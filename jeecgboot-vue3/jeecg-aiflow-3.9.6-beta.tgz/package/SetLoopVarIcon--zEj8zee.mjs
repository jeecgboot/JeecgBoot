import { a as e } from "./objectSpread2-B0BetFB8.mjs";
import { t as o } from "./NodeIcon-Dt_fCcq_.mjs";
import { createBlock as t, defineComponent as r, openBlock as a } from "vue";
var _ = /* @__PURE__ */ r({
  __name: "SetLoopVarIcon",
  setup(p) {
    return (c, s) => (a(), t(o, {
      icon: "ic:baseline-assignment",
      color: "#9254de",
      "stroke-width": 0
    }));
  }
}), m = /* @__PURE__ */ e({ default: () => n }), n = _;
export {
  m as n,
  n as t
};
