import { a as o } from "./objectSpread2-B0BetFB8.mjs";
import { t as e } from "./NodeIcon-Dt_fCcq_.mjs";
import { createBlock as t, defineComponent as r, openBlock as _ } from "vue";
var a = /* @__PURE__ */ r({
  __name: "ToolsIcon",
  setup(l) {
    return (n, p) => (_(), t(e, {
      icon: "mdi:tools",
      color: "#33c9ff"
    }));
  }
}), m = /* @__PURE__ */ o({ default: () => c }), c = a;
export {
  m as n,
  c as t
};
