import { n as Se, s as Pe, t as Ie } from "./objectSpread2-B0BetFB8.mjs";
import { t as Oe } from "./_plugin-vue_export-helper-Dj7HTbfw.mjs";
import { t as M } from "./asyncToGenerator-BkhZtDh9.mjs";
import { t as Fe } from "./dayjs.min-DQ4QC875.mjs";
import { i as N, r as G, t as Ne } from "./ProcessAddBeforeModal-3dmdqRsr.mjs";
import { t as Ue } from "./ProcessDesignModal-DJgwD9tn.mjs";
import { t as Ae } from "./ExportAppModal-CjvJuJuU.mjs";
import { t as Ye } from "./CallCodeModal-DBWkgqxH.mjs";
import { Card as je, Col as Be, Dropdown as Ee, Form as He, FormItem as Le, Menu as $e, MenuDivider as Je, MenuItem as Ve, Row as Ge, Tag as qe, Tooltip as Ke, Upload as Qe } from "ant-design-vue/es";
import { Fragment as z, createBlock as y, createCommentVNode as v, createElementBlock as c, createElementVNode as l, createTextVNode as s, createVNode as o, defineComponent as We, openBlock as r, provide as Xe, reactive as U, ref as m, renderList as q, resolveComponent as K, toDisplayString as T, unref as C, withCtx as n, withKeys as Ze, withModifiers as _ } from "vue";
import { useMessage as et } from "/@/hooks/web/useMessage";
import { getFileAccessHttpUrl as tt, getHeaders as ot } from "/@/utils/common/compUtils";
import { Modal as A, Pagination as nt } from "ant-design-vue";
import { useModal as D } from "/@/components/Modal";
import { useGlobSetting as at } from "/@/hooks/setting";
import lt from "/@/components/Form/src/jeecg/components/JInput.vue";
import rt from "/@/assets/images/ai/aiflow.png";
Se();
var Q = /* @__PURE__ */ Pe(Fe()), st = { class: "flow p-2" }, it = { class: "jeecg-basic-table-form-container" }, dt = {
  style: {
    float: "left",
    overflow: "hidden"
  },
  class: "table-page-search-submitButtons"
}, ut = { class: "flex" }, pt = { class: "flow-header" }, ct = { class: "flex" }, ft = ["src"], mt = { class: "header-text" }, _t = ["title"], gt = { class: "header-text-top header-create-by" }, vt = {
  class: "text-desc",
  style: { "margin-top": "5px" }
}, kt = {
  key: 0,
  class: "flex text-status"
}, yt = {
  key: 0,
  class: "tag-text"
}, Ct = {
  key: 1,
  class: "more"
}, xt = { class: "flow-btn" }, wt = /* @__PURE__ */ We({
  __name: "ProcessList",
  setup(Mt) {
    const { createMessage: S } = et(), Y = m(), f = m(1), P = m(30), h = m(0), W = m([
      "10",
      "20",
      "30"
    ]), x = U({}), w = m([]), X = U({
      xs: 24,
      sm: 4,
      xl: 6,
      xxl: 6
    }), Z = U({
      xs: 24,
      sm: 20
    }), j = m(), [ee, B] = D(), [te, { openModal: oe }] = D(), [ne, ae] = D(), [le, { openModal: re }] = D(), { domainUrl: se } = at(), ie = m(`${se}/airag/flow/importFlow`);
    function E(e) {
      B.openModal(!0, {
        record: e,
        isUpdate: !0
      });
    }
    function de(e) {
      return e.updateTime ? (0, Q.default)(e.updateTime).format("YYYY-MM-DD HH:mm") : (0, Q.default)(e.createTime).format("YYYY-MM-DD HH:mm");
    }
    function ue(e) {
      ae.openModal(!0, { record: e });
    }
    function pe() {
      oe(!0, {});
    }
    function ce(e) {
      B.openModal(!0, {
        isUpdate: !1,
        record: e
      });
    }
    function fe(e) {
      return I.apply(this, arguments);
    }
    function I() {
      return I = M(function* (e) {
        A.confirm({
          title: "确认删除",
          content: "确定删除名称为" + e.name + "的流程吗？",
          okText: "确认",
          cancelText: "取消",
          onOk: (function() {
            var t = M(function* () {
              yield N.delete(e.id), w.value.length == 1 && f.value > 1 && (f.value = f.value - 1), p();
            });
            return function() {
              return t.apply(this, arguments);
            };
          })()
        });
      }), I.apply(this, arguments);
    }
    function H(e, t) {
      return O.apply(this, arguments);
    }
    function O() {
      return O = M(function* (e, t) {
        (t ? yield G.releaseProcess(e.id) : yield G.unreleaseProcess(e.id)) && p();
      }), O.apply(this, arguments);
    }
    function me(e) {
      A.confirm({
        title: "发布流程",
        content: "确定要发布流程吗？发布后将不允许修改流程。",
        okText: "确定",
        cancelText: "取消",
        onOk() {
          return M(function* () {
            yield H(e, !0);
          })();
        }
      });
    }
    function _e(e) {
      A.confirm({
        title: "取消发布流程",
        content: "确定要取消发布流程吗？取消后将允许修改流程。",
        okText: "确定",
        cancelText: "取消",
        onOk() {
          return M(function* () {
            yield H(e, !1);
          })();
        }
      });
    }
    p();
    function p() {
      let e = {
        pageNo: f.value,
        pageSize: P.value,
        column: "createTime",
        order: "desc"
      };
      Object.assign(e, x), N.list(e).then((t) => {
        if (t) {
          for (const i of t.records) {
            i.metadata = ye(i.metadata);
            try {
              var k;
              i.triggerCron = JSON.parse((k = i.triggerCron) !== null && k !== void 0 ? k : "{}");
            } catch (b) {
            }
          }
          w.value = t.records, h.value = t.total;
        } else
          w.value = [], h.value = 0;
      });
    }
    function ge(e, t) {
      f.value = e, P.value = t, p();
    }
    function ve() {
      Y.value.resetFields(), x.name = "", f.value = 1, p();
    }
    function ke(e) {
      return e ? tt(e) : rt;
    }
    function ye(e) {
      return e ? [...JSON.parse(e).inputs] : [];
    }
    function Ce(...e) {
      j.value.onSubmit(...e);
    }
    function L() {
      f.value = 1, p();
    }
    function xe(e) {
      re(!0, Ie({}, e));
    }
    function we(e) {
      if (e.file.status === "done")
        e.file.response.success ? (S.success("上传成功！"), p()) : S.error(e.file.response.message || `${e.file.name} 导入失败.`);
      else if (e.file.status === "error" || e.file.response && e.file.response.code === 500) {
        var t;
        S.error(((t = e.file.response) === null || t === void 0 ? void 0 : t.message) || "导入失败，可能原因文件超出上传大小，请查看控制台或服务端日志");
      }
    }
    function Me(e) {
      N.copyFlow({ id: e }, p);
    }
    return Xe("doSubmit", Ce), (e, t) => {
      const k = Le, i = Be, b = K("a-button"), he = Qe, $ = Ge, be = He, d = K("Icon"), J = je, F = qe, Re = Ke, g = Ve, ze = Je, Te = $e, De = Ee;
      return r(), c("div", st, [
        l("div", it, [o(be, {
          ref_key: "formRef",
          ref: Y,
          onKeyup: Ze(L, ["enter", "native"]),
          model: x,
          "label-col": X,
          "wrapper-col": Z,
          style: { "background-color": "#f7f8fc" }
        }, {
          default: n(() => [o($, { gutter: 24 }, {
            default: n(() => [o(i, { lg: 6 }, {
              default: n(() => [o(k, {
                name: "name",
                label: "流程名称"
              }, {
                default: n(() => [o(lt, {
                  value: x.name,
                  "onUpdate:value": t[0] || (t[0] = (a) => x.name = a),
                  placeholder: "请输入流程名称，回车搜索"
                }, null, 8, ["value"])]),
                _: 1
              })]),
              _: 1
            }), o(i, {
              xl: 6,
              lg: 7,
              md: 8,
              sm: 24
            }, {
              default: n(() => [l("span", dt, [o(i, { lg: 6 }, {
                default: n(() => [
                  o(b, {
                    type: "primary",
                    preIcon: "ant-design:search-outlined",
                    onClick: L
                  }, {
                    default: n(() => [...t[2] || (t[2] = [s("查询", -1)])]),
                    _: 1
                  }),
                  o(b, {
                    type: "primary",
                    preIcon: "ant-design:reload-outlined",
                    onClick: ve,
                    style: { "margin-left": "8px" }
                  }, {
                    default: n(() => [...t[3] || (t[3] = [s("重置", -1)])]),
                    _: 1
                  }),
                  o(he, {
                    headers: C(ot)(),
                    action: ie.value,
                    showUploadList: !1,
                    multiple: !1,
                    maxCount: 1,
                    accept: ".jeecgai",
                    onChange: we,
                    style: { width: "100%" }
                  }, {
                    default: n(() => [o(b, {
                      type: "primary",
                      preIcon: "ant-design:import-outlined",
                      style: { "margin-left": "8px" }
                    }, {
                      default: n(() => [...t[4] || (t[4] = [s("导入", -1)])]),
                      _: 1
                    })]),
                    _: 1
                  }, 8, ["headers", "action"])
                ]),
                _: 1
              })])]),
              _: 1
            })]),
            _: 1
          })]),
          _: 1
        }, 8, [
          "model",
          "label-col",
          "wrapper-col"
        ])]),
        o($, {
          span: 24,
          class: "flow-row"
        }, {
          default: n(() => [o(i, {
            xxl: 4,
            xl: 6,
            lg: 6,
            md: 6,
            sm: 12,
            xs: 24
          }, {
            default: n(() => [o(J, {
              class: "flow-add-card",
              onClick: pe
            }, {
              default: n(() => [l("div", ut, [o(d, {
                icon: "ant-design:plus-outlined",
                class: "flow-card-add-icon",
                size: "20"
              }), t[5] || (t[5] = l("span", { class: "flow-card-add-title" }, "添加流程", -1))])]),
              _: 1
            })]),
            _: 1
          }), (r(!0), c(z, null, q(w.value, (a) => (r(), y(i, {
            xxl: 4,
            xl: 6,
            lg: 6,
            md: 6,
            sm: 12,
            xs: 24
          }, {
            default: n(() => [o(J, {
              class: "flow-card pointer",
              onClick: (R) => E(a)
            }, {
              default: n(() => {
                var R;
                return [
                  l("div", pt, [l("div", ct, [l("img", {
                    src: ke(a.icon),
                    class: "header-icon"
                  }, null, 8, ft), l("div", mt, [l("span", {
                    class: "header-name",
                    title: a.name
                  }, T(a.name), 9, _t), l("span", gt, [
                    a.status === "release" ? (r(), c(z, { key: 0 }, [o(F, { color: "green" }, {
                      default: n(() => [...t[6] || (t[6] = [s("已发布", -1)])]),
                      _: 1
                    }), !((R = a.triggerCron) === null || R === void 0) && R.enabled ? (r(), y(Re, {
                      key: 0,
                      title: "定时触发"
                    }, {
                      default: n(() => [o(d, {
                        icon: "tabler:clock",
                        size: 16,
                        class: "trigger-cron-icon"
                      })]),
                      _: 1
                    })) : v("", !0)], 64)) : v("", !0),
                    a.status === "disable" ? (r(), y(F, { key: 1 }, {
                      default: n(() => [...t[7] || (t[7] = [s("已禁用", -1)])]),
                      _: 1
                    })) : v("", !0),
                    l("span", null, T(de(a)), 1)
                  ])])])]),
                  l("div", vt, T(a.descr || "暂无描述"), 1),
                  a.metadata && a.metadata.length > 0 ? (r(), c("div", kt, [t[8] || (t[8] = l("span", { class: "tag-input" }, "输入", -1)), (r(!0), c(z, null, q(a.metadata, (u, V) => (r(), c("div", null, [o(F, {
                    color: "#f2f3f8",
                    class: "tags-meadata"
                  }, {
                    default: n(() => [V < 3 ? (r(), c("span", yt, T(u.field), 1)) : V === 3 ? (r(), c("span", Ct, "...")) : v("", !0)]),
                    _: 2
                  }, 1024)]))), 256))])) : v("", !0),
                  l("div", xt, [o(De, {
                    placement: "bottomRight",
                    trigger: ["click"],
                    getPopupContainer: (u) => u.parentNode
                  }, {
                    overlay: n(() => [o(Te, null, {
                      default: n(() => [
                        o(g, {
                          key: "edit",
                          onClick: _((u) => E(a), ["prevent", "stop"])
                        }, {
                          default: n(() => [o(d, {
                            icon: "mdi:design",
                            size: "16"
                          }), t[9] || (t[9] = s(" 设计 ", -1))]),
                          _: 1
                        }, 8, ["onClick"]),
                        o(g, {
                          key: "call-code",
                          onClick: _((u) => ue(a), ["prevent", "stop"])
                        }, {
                          default: n(() => [o(d, {
                            icon: "mdi:code",
                            size: "16"
                          }), t[10] || (t[10] = s(" 查看调用代码 ", -1))]),
                          _: 1
                        }, 8, ["onClick"]),
                        a.status !== "release" ? (r(), y(g, {
                          key: "release",
                          onClick: _((u) => me(a), ["prevent", "stop"])
                        }, {
                          default: n(() => [o(d, {
                            icon: "lineicons:rocket-5",
                            size: "16"
                          }), t[11] || (t[11] = s(" 发布 ", -1))]),
                          _: 1
                        }, 8, ["onClick"])) : (r(), y(g, {
                          key: "unrelease",
                          onClick: _((u) => _e(a), ["prevent", "stop"])
                        }, {
                          default: n(() => [o(d, {
                            icon: "tabler:rocket-off",
                            size: "16"
                          }), t[12] || (t[12] = s(" 取消发布 ", -1))]),
                          _: 1
                        }, 8, ["onClick"])),
                        o(g, {
                          key: "copy",
                          onClick: _((u) => Me(a.id), ["prevent", "stop"])
                        }, {
                          default: n(() => [o(d, {
                            icon: "ant-design:copy-outlined",
                            size: "16"
                          }), t[13] || (t[13] = s(" 复制 ", -1))]),
                          _: 1
                        }, 8, ["onClick"]),
                        o(g, {
                          key: "export",
                          onClick: _((u) => xe(a), ["prevent", "stop"])
                        }, {
                          default: n(() => [o(d, {
                            icon: "ant-design:export-outlined",
                            size: "16"
                          }), t[14] || (t[14] = s(" 导出 ", -1))]),
                          _: 1
                        }, 8, ["onClick"]),
                        a.status !== "release" ? (r(), c(z, { key: 2 }, [o(ze), o(g, {
                          key: "delete",
                          onClick: _((u) => fe(a), ["prevent", "stop"])
                        }, {
                          default: n(() => [o(d, {
                            icon: "ant-design:delete-outlined",
                            size: "16"
                          }), t[15] || (t[15] = s(" 删除 ", -1))]),
                          _: 1
                        }, 8, ["onClick"])], 64)) : v("", !0)
                      ]),
                      _: 2
                    }, 1024)]),
                    default: n(() => [l("div", {
                      class: "ant-dropdown-link pointer flow-icon",
                      onClick: t[1] || (t[1] = _(() => {
                      }, ["prevent", "stop"]))
                    }, [o(d, { icon: "ant-design:ellipsis-outlined" })])]),
                    _: 2
                  }, 1032, ["getPopupContainer"])])
                ];
              }),
              _: 2
            }, 1032, ["onClick"])]),
            _: 2
          }, 1024))), 256))]),
          _: 1
        }),
        w.value.length > 0 ? (r(), y(C(nt), {
          key: 0,
          current: f.value,
          "page-size": P.value,
          "page-size-options": W.value,
          total: h.value,
          showQuickJumper: !0,
          showSizeChanger: !0,
          onChange: ge,
          class: "list-footer",
          size: "small",
          "show-total": () => `共${h.value}条`
        }, null, 8, [
          "current",
          "page-size",
          "page-size-options",
          "total",
          "show-total"
        ])) : v("", !0),
        o(Ue, {
          ref_key: "designModalRef",
          ref: j,
          onRegister: C(ee),
          onClose: p
        }, null, 8, ["onRegister"]),
        o(Ne, {
          onRegister: C(te),
          onOk: ce
        }, null, 8, ["onRegister"]),
        o(Ye, { onRegister: C(ne) }, null, 8, ["onRegister"]),
        o(Ae, { onRegister: C(le) }, null, 8, ["onRegister"])
      ]);
    };
  }
}), Et = /* @__PURE__ */ Oe(wt, [["__scopeId", "data-v-444a7b72"]]);
export {
  Et as default
};
