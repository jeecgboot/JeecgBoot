import { a as y } from "./objectSpread2-B0BetFB8.mjs";
import { t as g } from "./_plugin-vue_export-helper-Dj7HTbfw.mjs";
import { t as b } from "./VarTextarea-BzeLBgKt.mjs";
import { t as S } from "./VarListPicker-CrG8EHn2.mjs";
import { t as k } from "./useSettings-Cq_-E7Ut.mjs";
import "./Vars-Cgan49KR.mjs";
import { Space as h, Switch as x } from "ant-design-vue/es";
import { createElementBlock as V, createElementVNode as r, createVNode as s, defineComponent as O, isRef as p, normalizeClass as R, openBlock as C, unref as t, withCtx as q } from "vue";
var w = { class: "reply-setting" }, B = { class: "setting-item" }, P = { class: "setting-item" }, U = { class: "label flex-space-between" }, j = /* @__PURE__ */ O({
  __name: "ReplySetting",
  props: {
    type: {
      type: String,
      required: !0
    },
    node: {
      type: Object,
      required: !0
    },
    properties: {
      type: Object,
      required: !0
    },
    isSilentMode: {
      type: Boolean,
      required: !0
    },
    setProperties: {
      type: Function,
      required: !0
    }
  },
  setup(u) {
    const { inputParams: i, prevVariables: v, inputVarsOptions: m, createOptionRef: d, isReadOnly: a } = k(u), o = d("content"), l = d("stream");
    function c() {
      a.value || (l.value = !l.value);
    }
    return (E, e) => {
      const _ = x, f = h;
      return C(), V("div", w, [r("div", B, [e[3] || (e[3] = r("div", { class: "label" }, "输入变量", -1)), s(t(S), {
        vars: t(i),
        "onUpdate:vars": e[0] || (e[0] = (n) => p(i) ? i.value = n : null),
        prevVariables: t(v),
        readonly: t(a)
      }, null, 8, [
        "vars",
        "prevVariables",
        "readonly"
      ])]), r("div", P, [r("div", U, [e[5] || (e[5] = r("div", null, "回复内容", -1)), s(f, {
        class: R(["stream-rtn-switch", { disabled: t(a) }]),
        size: 4,
        onClick: c
      }, {
        default: q(() => [e[4] || (e[4] = r("span", null, "流式返回", -1)), s(_, {
          checked: t(l),
          "onUpdate:checked": e[1] || (e[1] = (n) => p(l) ? l.value = n : null),
          "checked-children": "是",
          "un-checked-children": "否",
          disabled: t(a)
        }, null, 8, ["checked", "disabled"])]),
        _: 1
      }, 8, ["class"])]), s(t(b), {
        value: t(o),
        "onUpdate:value": e[2] || (e[2] = (n) => p(o) ? o.value = n : null),
        height: 140,
        varsOptions: t(m),
        readonly: t(a),
        placeholder: "请输入回复内容。按下 “/” 可以选择变量"
      }, null, 8, [
        "value",
        "varsOptions",
        "readonly"
      ])])]);
    };
  }
}), H = /* @__PURE__ */ y({ default: () => z }), z = /* @__PURE__ */ g(j, [["__scopeId", "data-v-664eac7e"]]);
export {
  H as n,
  z as t
};
