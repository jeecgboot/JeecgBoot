import { n as b, t as d } from "./objectSpread2-B0BetFB8.mjs";
import { t as N } from "./propStore-CR0aJ5bA.mjs";
import { computed as r, inject as h, ref as p } from "vue";
b();
function K(a, f) {
  const u = h("lfRef", p()), n = p(), m = r(() => d(d({}, a), f)), v = N();
  function $(e) {
    var t;
    (t = n.value) === null || t === void 0 || t.updateHeight(e);
  }
  const P = r(() => {
    var e, t;
    return (e = (t = n.value) === null || t === void 0 ? void 0 : t.$node) !== null && e !== void 0 ? e : {};
  }), o = r(() => {
    var e;
    return v.getProps((e = a.node) === null || e === void 0 ? void 0 : e.id);
  }), _ = r(() => {
    var e, t;
    return (e = (t = n.value) === null || t === void 0 ? void 0 : t.runStatus) !== null && e !== void 0 ? e : ["", ""];
  }), y = r(() => {
    var e, t;
    return (e = (t = n.value) === null || t === void 0 ? void 0 : t.isSilentMode) !== null && e !== void 0 ? e : !1;
  }), A = r(j), c = r(() => {
    var e;
    return Array.isArray((e = o.value) === null || e === void 0 ? void 0 : e.inputParams) ? o.value.inputParams : [];
  }), s = r(() => {
    var e;
    return Array.isArray((e = o.value) === null || e === void 0 ? void 0 : e.outputParams) ? o.value.outputParams : [];
  });
  function R(e = {}) {
    const { filter: t = () => !0, label: i = "输入参数" } = e;
    return {
      label: i,
      value: c.value.filter(t).map(({ name: l }) => l).join(","),
      emptyAction: e.emptyAction ? e.emptyAction : "tip",
      emptyTip: "尚未设置"
    };
  }
  function S(e = {}) {
    const { filter: t = () => !0, label: i = "输出参数" } = e;
    return {
      label: i,
      value: s.value.filter(t).map(({ name: l }) => l).join(","),
      emptyAction: e.emptyAction ? e.emptyAction : "tip",
      emptyTip: "尚未设置"
    };
  }
  function g(e) {
    var t;
    return v.createStoreRef((t = a.node) === null || t === void 0 ? void 0 : t.id, e);
  }
  function j() {
    if (!u.value) return [];
    const { graphModel: e } = u.value;
    return e.$J.getAllPrevNodes(a.node);
  }
  return {
    lfRef: u,
    $node: P,
    $properties: o,
    runStatus: _,
    isSilentMode: y,
    updateHeight: $,
    prevNodes: A,
    inputParams: c,
    outputParams: s,
    containerRef: n,
    containerProps: m,
    createStoreRef: g,
    getInputParamKVItem: R,
    getOutputParamKVItem: S
  };
}
export {
  K as t
};
