import { a as O } from "./objectSpread2-B0BetFB8.mjs";
import { t as P } from "./_plugin-vue_export-helper-Dj7HTbfw.mjs";
import { t as w } from "./VarPicker-HOsUWkU-.mjs";
import { t as E } from "./useSettings-Cq_-E7Ut.mjs";
import { Alert as N, Input as j, Popconfirm as x } from "ant-design-vue/es";
import { Fragment as D, computed as f, createBlock as F, createCommentVNode as _, createElementBlock as c, createElementVNode as l, createVNode as d, defineComponent as U, openBlock as v, renderList as $, unref as u, withCtx as L } from "vue";
import g from "/@/components/Icon";
import { cloneDeep as s } from "lodash-es";
var M = { class: "chat-var-set-setting" }, R = { class: "vars-list" }, z = { class: "var-name" }, G = { class: "var-value" }, H = { class: "var-actions" }, J = {
  key: 0,
  class: "add-action"
}, K = /* @__PURE__ */ U({
  __name: "ChatVarSetSetting",
  props: {
    type: {
      type: String,
      required: !0
    },
    node: {
      type: Object,
      required: !0
    },
    properties: {
      type: Object,
      required: !0
    },
    isSilentMode: {
      type: Boolean,
      required: !0
    },
    setProperties: {
      type: Function,
      required: !0
    }
  },
  setup(C) {
    const { prevVariables: h, options: y, updateOptions: V, isReadOnly: o } = E(C), S = f(() => h.value.filter((a) => a.type === "string")), r = f({
      get: () => s(y.value.variables) || [],
      set: (a) => {
        V({ variables: s(a) });
      }
    });
    function b() {
      if (o.value) return;
      const a = s(r.value);
      a.push({ name: "" }), r.value = a;
    }
    function I(a) {
      if (o.value) return;
      const t = s(r.value);
      t.splice(a, 1), r.value = t;
    }
    function k(a, t) {
      if (o.value) return;
      const n = s(r.value), e = n[a];
      !e || !t || (!t.nodeId || !t.field ? (e.nodeId = "", e.field = "", e.type = void 0) : (e.nodeId = t.nodeId, e.field = t.field, e.type = t.type, e.customValue = void 0, e.isCustom = !1), n[a] = e, r.value = n);
    }
    function q(a, t) {
      if (o.value) return;
      const n = s(r.value), e = n[a];
      e && (e.nodeId = "", e.field = "", e.customValue = t, e.isCustom = !0, e.type = "string", n[a] = e, r.value = n);
    }
    function A() {
      r.value = s(r.value);
    }
    return (a, t) => {
      const n = N, e = j, B = x;
      return v(), c("div", M, [
        d(n, {
          type: "info",
          "show-icon": "",
          message: "将值赋给AI应用的变量，需要在AI应用中关联该流程",
          style: { "margin-bottom": "10px" }
        }),
        t[2] || (t[2] = l("div", { class: "setting-label" }, "赋值变量", -1)),
        l("div", R, [(v(!0), c(D, null, $(r.value, (m, p) => (v(), c("div", {
          key: p,
          class: "var-item"
        }, [
          l("div", z, [d(e, {
            value: m.name,
            "onUpdate:value": (i) => m.name = i,
            placeholder: "变量名",
            disabled: u(o),
            onChange: A
          }, null, 8, [
            "value",
            "onUpdate:value",
            "disabled"
          ])]),
          t[0] || (t[0] = l("div", { class: "var-eq" }, "=", -1)),
          l("div", G, [d(w, {
            item: m,
            vars: S.value,
            allowEditValue: !0,
            readonly: u(o),
            onChange: (i) => k(p, i),
            onChangeCustom: (i) => q(p, i)
          }, null, 8, [
            "item",
            "vars",
            "readonly",
            "onChange",
            "onChangeCustom"
          ])]),
          l("div", H, [!u(o) && r.value.length > 1 ? (v(), F(B, {
            key: 0,
            title: "确定要删除该变量吗？",
            placement: "left",
            onConfirm: (i) => I(p)
          }, {
            default: L(() => [d(u(g), { icon: "ant-design:delete-outlined" })]),
            _: 1
          }, 8, ["onConfirm"])) : _("", !0)])
        ]))), 128))]),
        u(o) ? _("", !0) : (v(), c("div", J, [l("a", { onClick: b }, [d(u(g), { icon: "ic:round-add" }), t[1] || (t[1] = l("span", null, "添加变量", -1))])]))
      ]);
    };
  }
}), ne = /* @__PURE__ */ O({ default: () => Q }), Q = /* @__PURE__ */ P(K, [["__scopeId", "data-v-c385c5d9"]]);
export {
  ne as n,
  Q as t
};
