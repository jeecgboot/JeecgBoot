import { a as E } from "./objectSpread2-B0BetFB8.mjs";
import { t as T } from "./_plugin-vue_export-helper-Dj7HTbfw.mjs";
import { t as j } from "./VarTextarea-BzeLBgKt.mjs";
import { t as H } from "./VarListPicker-CrG8EHn2.mjs";
import { t as L } from "./VarListShow-Dg1oan43.mjs";
import { t as $ } from "./useSettings-Cq_-E7Ut.mjs";
import "./Vars-Cgan49KR.mjs";
import { InputNumber as D, RadioButton as F, RadioGroup as J, Select as W, Space as K, Tooltip as Q } from "ant-design-vue/es";
import { computed as X, createBlock as C, createCommentVNode as Y, createElementBlock as Z, createElementVNode as a, createTextVNode as O, createVNode as l, defineComponent as ee, isRef as r, openBlock as I, ref as te, resolveComponent as le, unref as t, withCtx as n } from "vue";
import { defHttp as ae } from "/@/utils/http/axios";
import ie from "/@/components/Form/src/jeecg/components/JImageUpload.vue";
var ne = { class: "image-generate-setting" }, se = { class: "setting-item" }, oe = { class: "label" }, re = { class: "setting-item" }, de = { class: "label flex-space-between" }, ue = { class: "setting-item" }, pe = { class: "setting-item" }, ve = { class: "label" }, me = { class: "setting-item" }, _e = { class: "setting-item" }, ge = { class: "setting-item" }, fe = /* @__PURE__ */ ee({
  __name: "ImageGenerateSetting",
  props: {
    type: {
      type: String,
      required: !0
    },
    node: {
      type: Object,
      required: !0
    },
    properties: {
      type: Object,
      required: !0
    },
    isSilentMode: {
      type: Boolean,
      required: !0
    },
    setProperties: {
      type: Function,
      required: !0
    }
  },
  setup(U) {
    const { inputParams: g, outputParams: q, prevVariables: N, inputVarsOptions: k, createOptionRef: s, isReadOnly: o } = $(U), f = s("modelId"), M = s("modelName"), u = s("width"), p = s("height"), m = s("sizeMode"), b = s("imageCount");
    s("watermark");
    const x = s("referenceImages"), y = s("prompt"), G = [
      {
        label: "1:1（1024×1024）",
        value: "1024x1024"
      },
      {
        label: "16:9（1280×720）",
        value: "1280x720"
      },
      {
        label: "9:16（720×1280）",
        value: "720x1280"
      },
      {
        label: "4:3（1024×768）",
        value: "1024x768"
      },
      {
        label: "3:4（768×1024）",
        value: "768x1024"
      }
    ], B = X(() => `${u.value}x${p.value}`), S = te([]);
    function R() {
      ae.get({ url: "/sys/dict/getDictItems/airag_model%20where%20model_type%20=%20'IMAGE'%20and%20activate_flag%20=%201,name,id" }).then((d) => {
        S.value = Array.isArray(d) ? d : [];
      });
    }
    function A(d, e) {
      M.value = d ? e.label : "";
    }
    function P(d) {
      const [e, v] = d.split("x").map(Number);
      u.value = e, p.value = v;
    }
    return R(), (d, e) => {
      const v = le("Icon"), c = Q, _ = K, V = W, z = F, h = J, w = D;
      return I(), Z("div", ne, [
        a("div", se, [a("div", oe, [l(_, { size: 4 }, {
          default: n(() => [e[9] || (e[9] = a("span", null, "模型", -1)), l(c, { title: "需要选择在模型中已有的图像模型" }, {
            default: n(() => [l(v, { icon: "ant-design:question-circle" })]),
            _: 1
          })]),
          _: 1
        })]), l(V, {
          value: t(f),
          "onUpdate:value": e[0] || (e[0] = (i) => r(f) ? f.value = i : null),
          options: S.value,
          placeholder: "请选择图像模型",
          disabled: t(o),
          style: { width: "100%" },
          onChange: A
        }, null, 8, [
          "value",
          "options",
          "disabled"
        ])]),
        a("div", re, [a("div", de, [l(_, { size: 4 }, {
          default: n(() => [e[10] || (e[10] = a("span", null, "图片尺寸", -1)), l(c, { title: "不同模型支持的图片尺寸规则可能不同，请以所选模型的规格说明为准" }, {
            default: n(() => [l(v, { icon: "ant-design:question-circle" })]),
            _: 1
          })]),
          _: 1
        }), l(h, {
          value: t(m),
          "onUpdate:value": e[1] || (e[1] = (i) => r(m) ? m.value = i : null),
          "button-style": "solid",
          size: "small",
          disabled: t(o)
        }, {
          default: n(() => [l(z, { value: "preset" }, {
            default: n(() => [...e[11] || (e[11] = [O("预设", -1)])]),
            _: 1
          }), l(z, { value: "custom" }, {
            default: n(() => [...e[12] || (e[12] = [O("自定义", -1)])]),
            _: 1
          })]),
          _: 1
        }, 8, ["value", "disabled"])]), t(m) === "preset" ? (I(), C(V, {
          key: 0,
          value: B.value,
          options: G,
          disabled: t(o),
          style: { width: "100%" },
          onChange: P
        }, null, 8, ["value", "disabled"])) : (I(), C(_, {
          key: 1,
          class: "size-inputs"
        }, {
          default: n(() => [
            l(w, {
              value: t(u),
              "onUpdate:value": e[2] || (e[2] = (i) => r(u) ? u.value = i : null),
              min: 1,
              max: 4096,
              precision: 0,
              placeholder: "宽度",
              disabled: t(o)
            }, null, 8, ["value", "disabled"]),
            e[13] || (e[13] = a("span", null, "×", -1)),
            l(w, {
              value: t(p),
              "onUpdate:value": e[3] || (e[3] = (i) => r(p) ? p.value = i : null),
              min: 1,
              max: 4096,
              precision: 0,
              placeholder: "高度",
              disabled: t(o)
            }, null, 8, ["value", "disabled"])
          ]),
          _: 1
        }))]),
        Y("", !0),
        a("div", ue, [e[15] || (e[15] = a("div", { class: "label" }, "图片生成数量", -1)), l(w, {
          value: t(b),
          "onUpdate:value": e[5] || (e[5] = (i) => r(b) ? b.value = i : null),
          min: 1,
          max: 10,
          precision: 0,
          disabled: t(o),
          style: { width: "100%" }
        }, null, 8, ["value", "disabled"])]),
        a("div", pe, [
          a("div", ve, [l(_, { size: 4 }, {
            default: n(() => [e[16] || (e[16] = a("span", null, "参考图", -1)), l(c, { title: "当前只有千问万象模型(wanx2.1-imageedit,wan2.5-i2i-preview)支持图生图" }, {
              default: n(() => [l(v, { icon: "ant-design:question-circle" })]),
              _: 1
            })]),
            _: 1
          })]),
          l(ie, {
            value: t(x),
            "onUpdate:value": e[6] || (e[6] = (i) => r(x) ? x.value = i : null),
            fileMax: 3,
            text: "上传参考图",
            disabled: t(o)
          }, null, 8, ["value", "disabled"]),
          e[17] || (e[17] = a("div", { class: "tip" }, "最多上传 3 张图片", -1))
        ]),
        a("div", me, [e[18] || (e[18] = a("div", { class: "label" }, "输入变量", -1)), l(t(H), {
          vars: t(g),
          "onUpdate:vars": e[7] || (e[7] = (i) => r(g) ? g.value = i : null),
          prevVariables: t(N),
          readonly: t(o)
        }, null, 8, [
          "vars",
          "prevVariables",
          "readonly"
        ])]),
        a("div", _e, [e[19] || (e[19] = a("div", { class: "label" }, "提示词", -1)), l(t(j), {
          value: t(y),
          "onUpdate:value": e[8] || (e[8] = (i) => r(y) ? y.value = i : null),
          height: 160,
          varsOptions: t(k),
          readonly: t(o),
          placeholder: "请输入图片生成提示词。按下 '/' 可以选择变量"
        }, null, 8, [
          "value",
          "varsOptions",
          "readonly"
        ])]),
        a("div", ge, [e[20] || (e[20] = a("div", { class: "label" }, "输出变量", -1)), l(t(L), { vars: t(q) }, null, 8, ["vars"])])
      ]);
    };
  }
}), Ne = /* @__PURE__ */ E({ default: () => be }), be = /* @__PURE__ */ T(fe, [["__scopeId", "data-v-5e3e1304"]]);
export {
  Ne as n,
  be as t
};
