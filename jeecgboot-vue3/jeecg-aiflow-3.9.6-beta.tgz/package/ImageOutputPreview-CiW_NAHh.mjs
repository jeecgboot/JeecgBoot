import { a as I } from "./objectSpread2-B0BetFB8.mjs";
import { t as C } from "./_plugin-vue_export-helper-Dj7HTbfw.mjs";
import { Fragment as v, computed as c, createBlock as N, createCommentVNode as u, createElementBlock as l, createElementVNode as b, createTextVNode as _, createVNode as A, defineComponent as B, openBlock as o, renderList as O, resolveComponent as P, toDisplayString as U, withCtx as f } from "vue";
import { getFileAccessHttpUrl as V } from "/@/utils/common/compUtils";
import { createImgPreview as E } from "/@/components/Preview";
import { downloadByUrl as S } from "/@/utils/file/download";
var $ = {
  key: 0,
  class: "image-output-preview"
}, z = {
  key: 0,
  class: "image-output-header"
}, D = {
  key: 0,
  class: "image-output-item"
}, F = ["src", "onClick"], L = {
  key: 1,
  class: "image-output-text"
}, H = /* @__PURE__ */ B({
  __name: "ImageOutputPreview",
  props: {
    urls: {
      type: Array,
      default: () => []
    },
    segments: {
      type: Array,
      default: () => []
    }
  },
  setup(g) {
    const i = g, p = c(() => i.segments.length ? i.segments : i.urls.map((e) => ({
      type: "image",
      value: e
    }))), r = c(() => p.value.filter((e) => e.type === "image").map((e) => n(e.value)).filter(Boolean));
    function n(e) {
      return /^data:|^blob:|^https?:\/\//i.test(e) ? e : V(e);
    }
    function y(e) {
      E({
        imageList: r.value,
        index: e,
        defaultWidth: 700,
        rememberState: !0
      });
    }
    function s(e) {
      return Math.max(r.value.indexOf(n(e)), 0);
    }
    function d(e, t) {
      S({
        url: e,
        fileName: w(e, t)
      });
    }
    function k() {
      r.value.forEach(d);
    }
    function w(e, t) {
      return e.split("?")[0].split("/").pop() || `图片-${t + 1}.png`;
    }
    return (e, t) => {
      const m = P("a-button");
      return r.value.length ? (o(), l("div", $, [r.value.length > 1 ? (o(), l("div", z, [r.value.length > 1 ? (o(), N(m, {
        key: 0,
        size: "small",
        preIcon: "ant-design:download-outlined",
        onClick: k
      }, {
        default: f(() => [...t[0] || (t[0] = [_("全部下载", -1)])]),
        _: 1
      })) : u("", !0)])) : u("", !0), (o(!0), l(v, null, O(p.value, (a, h) => (o(), l(v, { key: h }, [a.type === "image" ? (o(), l("div", D, [b("img", {
        src: n(a.value),
        alt: "输出图片",
        onClick: (x) => y(s(a.value))
      }, null, 8, F), A(m, {
        size: "small",
        preIcon: "ant-design:download-outlined",
        onClick: (x) => d(n(a.value), s(a.value))
      }, {
        default: f(() => [...t[1] || (t[1] = [_("下载", -1)])]),
        _: 1
      }, 8, ["onClick"])])) : a.value ? (o(), l("span", L, U(a.value), 1)) : u("", !0)], 64))), 128))])) : u("", !0);
    };
  }
}), K = /* @__PURE__ */ I({ default: () => M }), M = /* @__PURE__ */ C(H, [["__scopeId", "data-v-f5e78d6e"]]);
export {
  K as n,
  M as t
};
