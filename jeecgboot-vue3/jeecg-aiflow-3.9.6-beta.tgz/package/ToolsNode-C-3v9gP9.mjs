import { a as c } from "./objectSpread2-B0BetFB8.mjs";
import "./base-node-CKuyN1x8.mjs";
import { t as _ } from "./NodeContainer-zpIyuhKY.mjs";
import { t as v } from "./NodeKVS-CRVYjcYN.mjs";
import { t as f } from "./useNode-lPs0rKwe.mjs";
import { computed as N, createBlock as y, createVNode as b, defineComponent as h, guardReactiveProps as g, normalizeProps as P, openBlock as T, unref as a, withCtx as $ } from "vue";
var x = /* @__PURE__ */ h({
  __name: "ToolsNode",
  props: {
    node: {
      type: Object,
      required: !0
    },
    graph: {
      type: Object,
      required: !0
    }
  },
  setup(l) {
    const { $properties: p, getInputParamKVItem: n, getOutputParamKVItem: s } = f(l), u = N(() => {
      var e;
      const t = ((e = p.value) === null || e === void 0 || (e = e.options) === null || e === void 0 ? void 0 : e.tools) || {}, o = t.toolName || "", d = t.toolDescr || "", i = t.toolParameters || [], m = o ? `${o}` : "", r = i.length;
      return [
        n({
          label: "输入变量",
          emptyAction: "hidden"
        }),
        {
          label: "工具",
          value: m,
          emptyAction: "tip",
          emptyTip: "尚未选择"
        },
        {
          label: "工具描述",
          value: d,
          emptyAction: "hidden"
        },
        {
          label: "参数数量",
          value: r > 0 ? `${r} 个` : "",
          emptyAction: "hidden"
        },
        s({ label: "输出变量" })
      ];
    });
    return (e, t) => (T(), y(a(_), P(g(e.$props)), {
      default: $(() => [b(a(v), { kvs: u.value }, null, 8, ["kvs"])]),
      _: 1
    }, 16));
  }
}), j = /* @__PURE__ */ c({ default: () => A }), A = x;
export {
  j as n,
  A as t
};
