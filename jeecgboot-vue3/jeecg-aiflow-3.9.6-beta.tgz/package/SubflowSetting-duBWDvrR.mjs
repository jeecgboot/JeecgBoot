import { a as $ } from "./objectSpread2-B0BetFB8.mjs";
import { t as H } from "./_plugin-vue_export-helper-Dj7HTbfw.mjs";
import { t as V } from "./asyncToGenerator-BkhZtDh9.mjs";
import { u as M } from "./api-BJs6o08o.mjs";
import { t as J } from "./VarListEditor-A0nqHeND.mjs";
import { t as Q } from "./VarListPicker-CrG8EHn2.mjs";
import { t as W } from "./useSettings-Cq_-E7Ut.mjs";
import "./Vars-Cgan49KR.mjs";
import { Input as X, Skeleton as Y, Space as Z } from "ant-design-vue/es";
import { Fragment as C, createBlock as K, createElementBlock as y, createElementVNode as r, createTextVNode as A, createVNode as s, defineComponent as ee, inject as te, isRef as B, openBlock as p, ref as R, resolveComponent as T, unref as a, withCtx as b } from "vue";
import { useMessage as oe } from "/@/hooks/web/useMessage";
import { useModal as ne } from "/@/components/Modal";
import le from "/@/views/super/airag/aiapp/components/AiAppAddFlowModal.vue";
var ae = {
  key: 1,
  class: "subflow-setting"
}, re = {
  key: 0,
  class: "setting-item"
}, se = { class: "setting-item" }, ie = { class: "setting-item" }, ue = { class: "subflow-info" }, de = { class: "setting-item" }, fe = /* @__PURE__ */ ee({
  __name: "SubflowSetting",
  props: {
    type: {
      type: String,
      required: !0
    },
    node: {
      type: Object,
      required: !0
    },
    properties: {
      type: Object,
      required: !0
    },
    isSilentMode: {
      type: Boolean,
      required: !0
    },
    setProperties: {
      type: Function,
      required: !0
    }
  },
  setup(h) {
    const { createMessage: P } = oe(), E = h, F = te("$flowId", R("")), f = R(!1), { inputParams: c, outputParams: m, prevVariables: N, createOptionRef: j, createStoreRef: q, isReadOnly: u } = W(E), g = j("subflowId"), i = q("subflowInfo");
    function k() {
      const t = i.value.inputParams.filter((e) => e.field !== "history");
      return O(c, t, "name", (e, n) => {
        const l = {
          name: e.field,
          nameText: e.name,
          field: "",
          nodeId: ""
        };
        if (n.has(l.name)) {
          const d = n.get(l.name);
          l.field = d.field, l.nodeId = d.nodeId;
        }
        return l;
      });
    }
    function x() {
      return O(m, i.value.outputParams, "field", (t, e) => {
        const n = {
          field: t.name,
          name: t.name,
          type: t.type || "string"
        };
        if (e.has(n.field)) {
          const l = e.get(n.field);
          n.name = l.name, n.type = l.type;
        }
        return n;
      });
    }
    function O(t, e, n, l) {
      const d = [...t.value].filter((o) => !!o[n]), v = /* @__PURE__ */ new Map();
      for (const o of d) v.set(o[n], o);
      const _ = [];
      for (const o of e) {
        const G = l(o, v);
        _.push(G);
      }
      t.value = _;
    }
    function L(t) {
      return w.apply(this, arguments);
    }
    function w() {
      return w = V(function* (t) {
        if (t = t || g.value, !!t)
          try {
            f.value = !0;
            const e = yield M(t);
            if ((e == null ? void 0 : e.endOutputType) === "card") {
              P.warning("卡片类型不支持作为子流程，已自动清空"), g.value = "", i.value = null;
              return;
            }
            i.value = e, k(), x();
          } catch (e) {
          } finally {
            f.value = !1;
          }
      }), w.apply(this, arguments);
    }
    L();
    const [U, z] = ne();
    function S() {
      u.value || z.openModal(!0, {});
    }
    function D(t) {
      return I.apply(this, arguments);
    }
    function I() {
      return I = V(function* (t) {
        if (!u.value)
          try {
            f.value = !0;
            const e = yield M(t.flowId);
            if ((e == null ? void 0 : e.endOutputType) === "card") {
              P.warning("卡片类型不支持作为子流程");
              return;
            }
            g.value = t.flowId, i.value = e, k(), x();
          } catch (e) {
          } finally {
            f.value = !1;
          }
      }), I.apply(this, arguments);
    }
    return (t, e) => {
      const n = Y, l = T("a-button"), d = X, v = T("a-space-compact"), _ = Z;
      return p(), y(C, null, [f.value ? (p(), K(n, {
        key: 0,
        active: ""
      })) : (p(), y("div", ae, [a(i) == null ? (p(), y("div", re, [e[3] || (e[3] = r("div", { class: "label" }, "子流程", -1)), s(l, {
        preIcon: "ant-design:plus",
        onClick: S,
        disabled: a(u)
      }, {
        default: b(() => [...e[2] || (e[2] = [A("选择子流程", -1)])]),
        _: 1
      }, 8, ["disabled"])])) : (p(), y(C, { key: 1 }, [
        r("div", se, [e[4] || (e[4] = r("div", { class: "label" }, "输入变量", -1)), s(a(Q), {
          vars: a(c),
          "onUpdate:vars": e[0] || (e[0] = (o) => B(c) ? c.value = o : null),
          allowAdd: !1,
          allowDelete: !1,
          allowEditName: !1,
          prevVariables: a(N),
          readonly: a(u)
        }, null, 8, [
          "vars",
          "prevVariables",
          "readonly"
        ])]),
        r("div", ie, [e[6] || (e[6] = r("div", { class: "label" }, "子流程", -1)), r("div", ue, [s(_, {
          direction: "vertical",
          size: "middle"
        }, {
          default: b(() => [s(v, { block: "" }, {
            default: b(() => {
              var o;
              return [s(d, {
                value: (o = a(i)) === null || o === void 0 ? void 0 : o.name,
                readonly: "",
                style: { width: "480px" },
                onClick: S
              }, null, 8, ["value"]), s(l, {
                onClick: S,
                disabled: a(u)
              }, {
                default: b(() => [...e[5] || (e[5] = [A("重新选择", -1)])]),
                _: 1
              }, 8, ["disabled"])];
            }),
            _: 1
          })]),
          _: 1
        })])]),
        r("div", de, [e[7] || (e[7] = r("div", { class: "label" }, "输出变量", -1)), s(a(J), {
          type: "subflow",
          vars: a(m),
          "onUpdate:vars": e[1] || (e[1] = (o) => B(m) ? m.value = o : null),
          readonly: a(u)
        }, null, 8, ["vars", "readonly"])])
      ], 64))])), s(le, {
        onRegister: a(U),
        excludedIds: a(F),
        onSuccess: D
      }, null, 8, ["onRegister", "excludedIds"])], 64);
    };
  }
}), Oe = /* @__PURE__ */ $({ default: () => pe }), pe = /* @__PURE__ */ H(fe, [["__scopeId", "data-v-bc63195e"]]);
export {
  Oe as n,
  pe as t
};
