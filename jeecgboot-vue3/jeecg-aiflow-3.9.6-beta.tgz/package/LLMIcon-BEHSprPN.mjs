import { a as e } from "./objectSpread2-B0BetFB8.mjs";
import { t as o } from "./NodeIcon-Dt_fCcq_.mjs";
import { createBlock as r, defineComponent as t, openBlock as _ } from "vue";
var a = /* @__PURE__ */ t({
  __name: "LLMIcon",
  setup(n) {
    return (p, u) => (_(), r(o, {
      icon: "lucide:brain",
      color: "#12c499"
    }));
  }
}), i = /* @__PURE__ */ e({ default: () => c }), c = a;
export {
  i as n,
  c as t
};
