import { a as _ } from "./objectSpread2-B0BetFB8.mjs";
import { t as m } from "./_plugin-vue_export-helper-Dj7HTbfw.mjs";
import { t as f } from "./VarListEditor-A0nqHeND.mjs";
import { t as v } from "./useSettings-Cq_-E7Ut.mjs";
import "./Vars-Cgan49KR.mjs";
import { t as g } from "./CronSetting-CrdizeeK.mjs";
import { createElementBlock as S, createElementVNode as i, createVNode as a, defineComponent as c, isRef as y, openBlock as x, unref as o } from "vue";
var q = { class: "start-setting" }, k = { class: "switch-setting" }, E = /* @__PURE__ */ c({
  __name: "StartSetting",
  props: {
    type: {
      type: String,
      required: !0
    },
    node: {
      type: Object,
      required: !0
    },
    properties: {
      type: Object,
      required: !0
    },
    isSilentMode: {
      type: Boolean,
      required: !0
    },
    setProperties: {
      type: Function,
      required: !0
    }
  },
  setup(n) {
    const p = n;
    let e = null;
    const s = () => (e || (e = v(p)), e), { inputParams: r, isReadOnly: u } = s(), l = {
      content: { allowEditName: !0 },
      history: { tip: "用户的对话历史记录" },
      images: { tip: "聊天时上传的图片" }
    };
    return (b, t) => (x(), S("div", q, [i("div", k, [t[1] || (t[1] = i("div", { class: "label" }, "输入字段", -1)), a(o(f), {
      vars: o(r),
      "onUpdate:vars": t[0] || (t[0] = (d) => y(r) ? r.value = d : null),
      type: "start",
      fixedVars: l,
      readonly: o(u)
    }, null, 8, ["vars", "readonly"])]), a(g, { useSettings: s })]));
  }
}), H = /* @__PURE__ */ _({ default: () => V }), V = /* @__PURE__ */ m(E, [["__scopeId", "data-v-d5304e14"]]);
export {
  H as n,
  V as t
};
