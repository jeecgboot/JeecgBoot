import { a as $, n as ee, t as x } from "./objectSpread2-B0BetFB8.mjs";
import { t as te } from "./_plugin-vue_export-helper-Dj7HTbfw.mjs";
import { InputNumber as le, Popover as ne, Select as ae, SelectOption as oe, Slider as se, Space as ie, Switch as de, Tooltip as ue } from "ant-design-vue/es";
import { Fragment as re, computed as k, createBlock as pe, createElementBlock as ce, createElementVNode as l, createVNode as e, defineComponent as me, guardReactiveProps as r, isRef as y, normalizeProps as p, openBlock as V, ref as _e, renderList as ve, resolveComponent as F, toDisplayString as fe, unref as n, withCtx as a } from "vue";
import { cloneDeep as A, omit as be } from "lodash-es";
import { defHttp as ge } from "/@/utils/http/axios";
ee();
var ye = { class: "model-params-popover" }, Pe = { class: "setting-item" }, he = { style: {
  width: "100%",
  "text-align": "right"
} }, ke = { class: "setting-item" }, xe = { class: "label" }, Le = { class: "setting-item" }, qe = { class: "label" }, Me = { class: "setting-item" }, Se = { class: "label" }, we = { class: "setting-item" }, ze = { class: "label" }, Ie = { class: "setting-item" }, Ee = { class: "label" }, Ae = { class: "setting-item" }, Ce = { class: "label" }, Te = /* @__PURE__ */ me({
  __name: "LLMModelSelect",
  props: {
    model: {
      type: Object,
      required: !0
    },
    readonly: {
      type: Boolean,
      default: !1
    }
  },
  emits: ["update:model"],
  setup(C, { emit: H }) {
    const P = C, G = H, u = k(() => P.readonly === !0), J = k(() => u.value ? [] : ["click"]), [, L, T] = _("temperature", {
      min: 0.1,
      max: 1,
      step: 0.1
    }, 0.7), [, q, U] = _("topP", {
      min: 0.1,
      max: 1,
      step: 0.1
    }, 0.7), [, M, j] = _("presencePenalty", {
      min: -2,
      max: 2,
      step: 0.1
    }, 0), [, S, R] = _("frequencyPenalty", {
      min: -2,
      max: 2,
      step: 0.1
    }, 0), [, w, O] = _("maxTokens", {
      min: 1,
      max: 16e3,
      step: 1
    }, 520), [, z, B] = _("timeout", {
      min: 1,
      step: 1,
      max: 3600
    }, 60), D = [
      {
        name: "创意",
        icon: "fxemoji:star",
        params: {
          temperature: 0.8,
          topP: 0.9,
          presencePenalty: 0.1,
          frequencyPenalty: 0.1,
          timeout: 60
        }
      },
      {
        name: "平衡",
        icon: "noto:balance-scale",
        params: {
          temperature: 0.5,
          topP: 0.8,
          presencePenalty: 0.2,
          frequencyPenalty: 0.3,
          timeout: 60
        }
      },
      {
        name: "精确",
        icon: "twemoji:direct-hit",
        params: {
          temperature: 0.2,
          topP: 0.7,
          presencePenalty: 0.5,
          frequencyPenalty: 0.5,
          timeout: 60
        }
      }
    ];
    function K(s) {
      const t = D[s];
      if (!t) return;
      const o = A(P.model);
      o.params = x(x({}, be(o.params, ...Object.keys(t.params))), t.params), E(o);
    }
    const m = {
      temperature: "值越大，回复内容越赋有多样性创造性、随机性；设为0根据事实回答，希望得到精准答案应该降低该参数；日常聊天建议0.5-0.8。",
      topP: "值越小，Ai生成的内容越单调也越容易理解；值越大，Ai回复的词汇围越大，越多样化。",
      presencePenalty: "值越大，越能够让Ai更好地控制新话题的引入，建议微调或不变。",
      frequencyPenalty: "值越大，越能够让Ai更好地避免重复之前说过的话，建议微调或不变。",
      maxTokens: "设置Ai最大回复内容大小，会影响返回结果的长度。普通聊天建议500-800；短文生成建议800-2000；代码生成建议2000-3600；长文生成建议4000左右（或选择长回复模型)",
      timeout: "等待AI响应的最长时间，单位为秒。"
    }, I = _e([]);
    function Q() {
      ge.get({ url: "/sys/dict/getDictItems/airag_model%20where%20model_type%20=%20'LLM'%20and%20activate_flag%20=%201,name,id" }).then((s) => {
        I.value = s, I.value.unshift({
          label: "请选择模型",
          value: ""
        });
      });
    }
    Q();
    function W(s, t) {
      const o = A(P.model);
      o.modeId = s, o.params.model = s ? t.label : "", E(o);
    }
    function E(s) {
      G("update:model", s);
    }
    function _(s, t, o) {
      const d = X(s), c = k({
        get: () => d.value != null,
        set: (h) => d.value = h ? o : null
      });
      return [
        d,
        c,
        k(() => x(x({}, t), {}, {
          value: d.value,
          size: "small",
          disabled: u.value || !c.value,
          "onUpdate:value": (h) => d.value = h
        }))
      ];
    }
    function X(s) {
      return k({
        get: () => P.model.params[s],
        set: (t) => {
          const o = A(P.model);
          o.params[s] = t, E(o);
        }
      });
    }
    return (s, t) => {
      const o = ae, d = F("Icon"), c = ie, h = oe, v = ue, f = de, b = se, g = le, Y = F("a-button"), Z = ne;
      return V(), pe(c, null, {
        default: a(() => [e(o, {
          value: C.model.modeId,
          options: I.value,
          style: { width: "520px" },
          disabled: u.value,
          onChange: W
        }, null, 8, [
          "value",
          "options",
          "disabled"
        ]), e(Z, {
          trigger: J.value,
          placement: "bottomRight",
          open: u.value ? !1 : void 0
        }, {
          content: a(() => [l("div", ye, [
            l("div", Pe, [l("div", he, [e(o, {
              value: "加载预设",
              style: { width: "96px" },
              size: "small",
              disabled: u.value,
              onChange: K
            }, {
              default: a(() => [(V(), ce(re, null, ve(D, (i, N) => e(h, {
                value: N,
                key: N
              }, {
                default: a(() => [e(c, null, {
                  default: a(() => [e(d, { icon: i.icon }, null, 8, ["icon"]), l("span", null, fe(i.name), 1)]),
                  _: 2
                }, 1024)]),
                _: 2
              }, 1032, ["value"])), 64))]),
              _: 1
            }, 8, ["disabled"])])]),
            l("div", ke, [l("div", xe, [t[6] || (t[6] = l("span", null, "模型温度", -1)), e(v, { title: m.temperature }, {
              default: a(() => [e(d, { icon: "ant-design:question-circle" })]),
              _: 1
            }, 8, ["title"])]), e(c, null, {
              default: a(() => [
                e(f, {
                  checked: n(L),
                  "onUpdate:checked": t[0] || (t[0] = (i) => y(L) ? L.value = i : null),
                  size: "small",
                  disabled: u.value
                }, null, 8, ["checked", "disabled"]),
                e(b, p(r(n(T))), null, 16),
                e(g, p(r(n(T))), null, 16)
              ]),
              _: 1
            })]),
            l("div", Le, [l("div", qe, [t[7] || (t[7] = l("span", null, "词汇属性", -1)), e(v, { title: m.topP }, {
              default: a(() => [e(d, { icon: "ant-design:question-circle" })]),
              _: 1
            }, 8, ["title"])]), e(c, null, {
              default: a(() => [
                e(f, {
                  checked: n(q),
                  "onUpdate:checked": t[1] || (t[1] = (i) => y(q) ? q.value = i : null),
                  size: "small",
                  disabled: u.value
                }, null, 8, ["checked", "disabled"]),
                e(b, p(r(n(U))), null, 16),
                e(g, p(r(n(U))), null, 16)
              ]),
              _: 1
            })]),
            l("div", Me, [l("div", Se, [t[8] || (t[8] = l("span", null, "话题属性", -1)), e(v, { title: m.presencePenalty }, {
              default: a(() => [e(d, { icon: "ant-design:question-circle" })]),
              _: 1
            }, 8, ["title"])]), e(c, null, {
              default: a(() => [
                e(f, {
                  checked: n(M),
                  "onUpdate:checked": t[2] || (t[2] = (i) => y(M) ? M.value = i : null),
                  size: "small",
                  disabled: u.value
                }, null, 8, ["checked", "disabled"]),
                e(b, p(r(n(j))), null, 16),
                e(g, p(r(n(j))), null, 16)
              ]),
              _: 1
            })]),
            l("div", we, [l("div", ze, [t[9] || (t[9] = l("span", null, "重复属性", -1)), e(v, { title: m.frequencyPenalty }, {
              default: a(() => [e(d, { icon: "ant-design:question-circle" })]),
              _: 1
            }, 8, ["title"])]), e(c, null, {
              default: a(() => [
                e(f, {
                  checked: n(S),
                  "onUpdate:checked": t[3] || (t[3] = (i) => y(S) ? S.value = i : null),
                  size: "small",
                  disabled: u.value
                }, null, 8, ["checked", "disabled"]),
                e(b, p(r(n(R))), null, 16),
                e(g, p(r(n(R))), null, 16)
              ]),
              _: 1
            })]),
            l("div", Ie, [l("div", Ee, [t[10] || (t[10] = l("span", null, "最大回复", -1)), e(v, { title: m.maxTokens }, {
              default: a(() => [e(d, { icon: "ant-design:question-circle" })]),
              _: 1
            }, 8, ["title"])]), e(c, null, {
              default: a(() => [
                e(f, {
                  checked: n(w),
                  "onUpdate:checked": t[4] || (t[4] = (i) => y(w) ? w.value = i : null),
                  size: "small",
                  disabled: u.value
                }, null, 8, ["checked", "disabled"]),
                e(b, p(r(n(O))), null, 16),
                e(g, p(r(n(O))), null, 16)
              ]),
              _: 1
            })]),
            l("div", Ae, [l("div", Ce, [t[11] || (t[11] = l("span", null, "超时时间", -1)), e(v, { title: m.timeout }, {
              default: a(() => [e(d, { icon: "ant-design:question-circle" })]),
              _: 1
            }, 8, ["title"])]), e(c, null, {
              default: a(() => [
                e(f, {
                  checked: n(z),
                  "onUpdate:checked": t[5] || (t[5] = (i) => y(z) ? z.value = i : null),
                  size: "small",
                  disabled: u.value
                }, null, 8, ["checked", "disabled"]),
                e(b, p(r(n(B))), null, 16),
                e(g, p(r(n(B))), null, 16)
              ]),
              _: 1
            })])
          ])]),
          default: a(() => [e(Y, {
            preIcon: "ant-design:setting",
            style: { width: "40px" },
            disabled: u.value
          }, null, 8, ["disabled"])]),
          _: 1
        }, 8, ["trigger", "open"])]),
        _: 1
      });
    };
  }
}), Ve = /* @__PURE__ */ $({ default: () => Ue }), Ue = /* @__PURE__ */ te(Te, [["__scopeId", "data-v-516fdf8f"]]);
export {
  Ve as n,
  Ue as t
};
