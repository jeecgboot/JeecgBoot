import { a as e } from "./objectSpread2-B0BetFB8.mjs";
import { t as o } from "./NodeIcon-Dt_fCcq_.mjs";
import { createBlock as r, defineComponent as t, openBlock as p } from "vue";
var _ = /* @__PURE__ */ t({
  __name: "ReplyIcon",
  setup(c) {
    return (l, n) => (p(), r(o, {
      icon: "lucide:message-square-reply",
      color: "#12c499"
    }));
  }
}), f = /* @__PURE__ */ e({ default: () => a }), a = _;
export {
  f as n,
  a as t
};
