import { a as O } from "./objectSpread2-B0BetFB8.mjs";
import { t as A } from "./asyncToGenerator-BkhZtDh9.mjs";
import { Empty as S, TabPane as $, Tabs as E, Textarea as F } from "ant-design-vue/es";
import { createBlock as y, createCommentVNode as D, createElementBlock as N, createElementVNode as T, createTextVNode as R, createVNode as i, defineComponent as U, openBlock as f, ref as m, resolveComponent as P, unref as g, withCtx as u } from "vue";
import { useMessage as K } from "/@/hooks/web/useMessage";
import { BasicModal as V, useModalInner as z } from "/@/components/Modal";
import { copyTextToClipboard as G } from "/@/hooks/web/useCopyToClipboard";
import { useGlobSetting as J } from "/@/hooks/setting";
import { getToken as q } from "/@/utils/auth";
var H = {
  key: 0,
  class: "call-code-modal-content"
}, X = { style: {
  display: "flex",
  "justify-content": "flex-end",
  "margin-top": "8px"
} }, L = /* @__PURE__ */ U({
  __name: "CallCodeModal",
  setup(W) {
    const { createMessage: k } = K(), v = m("curl"), c = m(""), p = m(""), l = m(""), { domainUrl: b } = J(), [w, { closeModal: h, getOpen: I }] = z((function() {
      var o = A(function* (e) {
        l.value = "";
        const { record: a } = e;
        if (!a) {
          l.value = "[错误] 没有传入流程数据！";
          return;
        }
        const t = q(), { id: r, metadata: n } = a;
        if (!n) {
          l.value = "[错误] 没有找到入参参数！";
          return;
        }
        M(r, n, t), j(r, n);
      });
      return function(e) {
        return o.apply(this, arguments);
      };
    })());
    function M(o, e, a) {
      let t = '"inputParams": {';
      const r = "      ", n = [];
      if (Array.isArray(e) && e.length > 0) for (const { field: d } of e)
        C(d) || n.push(`${r}  "${d}": ""`);
      n.length > 0 ? (t += `
`, t += n.join(`,
`), t += `
`, t += "      },") : t += "},", c.value = `
curl --request POST \\
  --url ${b}/airag/flow/run \\
  --header 'Accept: */*' \\
  --header 'Accept-Encoding: gzip, deflate, br' \\
  --header 'Connection: keep-alive' \\
  --header 'Content-Type: application/json' \\
  --header 'Cookie: JSESSIONID=442C48D3D1D0B2878A597AB6EBF2A07E' \\
  --header 'User-Agent: PostmanRuntime-ApipostRuntime/1.1.0' \\
  --header 'X-Access-Token: ${a}' \\
  --data '{
      "flowId": "${o}",
      ${t}
      "responseMode":"blocking"
    }'
    `.trim();
    }
    function j(o, e) {
      const a = [];
      if (Array.isArray(e) && e.length > 0) for (const { field: t } of e)
        C(t) || a.push(`inputs.put("${t}", "");`);
      p.value = `
@Autowired
ISysBaseAPI sysBaseAPI;
// ..... 省略代码
AiragFlowDTO params = new AiragFlowDTO();
params.setFlowId("${o}");
Map<String, Object> inputs = new HashMap<>();
${a.join(`
`)}
params.setInputParams(inputs);
Result<Object> o = (Result<Object>) sysBaseAPI.runAiragFlow(params);
`.trim();
    }
    function C(o) {
      return ["history"].includes(o);
    }
    function x() {
      return _.apply(this, arguments);
    }
    function _() {
      return _ = A(function* () {
        const o = v.value === "curl" ? c.value : p.value;
        G(o) ? k.success("复制成功") : prompt("复制失败，请手动复制", o);
      }), _.apply(this, arguments);
    }
    function B() {
      h();
    }
    return (o, e) => {
      const a = S, t = F, r = $, n = E, d = P("a-button");
      return f(), y(g(V), {
        onRegister: g(w),
        width: "600px",
        header: null,
        footer: null,
        canFullscreen: !1,
        wrapClassName: "call-code-modal",
        onOk: x,
        onClose: B
      }, {
        default: u(() => [g(I) ? (f(), N("div", H, [
          e[4] || (e[4] = T("p", { class: "call-code-modal-title" }, "查看调用代码", -1)),
          l.value ? (f(), y(a, {
            key: 0,
            description: l.value
          }, null, 8, ["description"])) : (f(), y(n, {
            key: 1,
            activeKey: v.value,
            "onUpdate:activeKey": e[2] || (e[2] = (s) => v.value = s),
            animated: ""
          }, {
            default: u(() => [i(r, {
              key: "curl",
              tab: "curl"
            }, {
              default: u(() => [i(t, {
                value: c.value,
                "onUpdate:value": e[0] || (e[0] = (s) => c.value = s),
                rows: 20,
                style: { resize: "none" }
              }, null, 8, ["value"])]),
              _: 1
            }), i(r, {
              key: "java",
              tab: "java"
            }, {
              default: u(() => [i(t, {
                value: p.value,
                "onUpdate:value": e[1] || (e[1] = (s) => p.value = s),
                rows: 20,
                style: { resize: "none" }
              }, null, 8, ["value"])]),
              _: 1
            })]),
            _: 1
          }, 8, ["activeKey"])),
          T("div", X, [i(d, {
            type: "primary",
            preIcon: "ant-design:copy-outlined",
            onClick: x
          }, {
            default: u(() => [...e[3] || (e[3] = [R("复制", -1)])]),
            _: 1
          })])
        ])) : D("", !0)]),
        _: 1
      }, 8, ["onRegister"]);
    };
  }
}), se = /* @__PURE__ */ O({ default: () => Q }), Q = L;
export {
  se as n,
  Q as t
};
