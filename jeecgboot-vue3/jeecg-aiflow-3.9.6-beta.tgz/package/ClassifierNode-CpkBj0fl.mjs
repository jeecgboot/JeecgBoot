import { a as v } from "./objectSpread2-B0BetFB8.mjs";
import "./base-node-CKuyN1x8.mjs";
import { t as f } from "./NodeContainer-zpIyuhKY.mjs";
import { t as m } from "./useNode-lPs0rKwe.mjs";
import { Fragment as h, createBlock as g, createCommentVNode as N, createElementBlock as i, createElementVNode as t, defineComponent as y, mergeProps as C, nextTick as L, openBlock as r, renderList as k, toDisplayString as l, unref as a, watch as x, withCtx as $ } from "vue";
var b = {
  key: 0,
  class: "classifier-node-content"
}, B = { class: "case-item" }, j = { class: "case-header" }, q = { class: "case-category" }, w = /* @__PURE__ */ y({
  __name: "ClassifierNode",
  props: {
    node: {
      type: Object,
      required: !0
    },
    graph: {
      type: Object,
      required: !0
    }
  },
  setup(c) {
    const n = c, { $node: s, updateHeight: u, containerRef: _, containerProps: p } = m(n, { onUpdateNode(e) {
      e.caseList = n.node.$caseList;
    } });
    return x(() => {
      var e;
      return (e = s.value.caseList) === null || e === void 0 ? void 0 : e.length;
    }, () => L(() => u())), (e, O) => (r(), g(a(f), C({
      ref_key: "containerRef",
      ref: _
    }, a(p)), {
      default: $(() => {
        var o;
        return [!((o = a(s).caseList) === null || o === void 0) && o.length ? (r(), i("div", b, [(r(!0), i(h, null, k(a(s).caseList, (d) => (r(), i("div", B, [t("div", j, [t("div", null, l(d.label), 1)]), t("div", q, [t("div", null, l(d.category), 1)])]))), 256))])) : N("", !0)];
      }),
      _: 1
    }, 16));
  }
}), F = /* @__PURE__ */ v({ default: () => E }), E = w;
export {
  F as n,
  E as t
};
