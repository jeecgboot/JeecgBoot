import { a as Z } from "./objectSpread2-B0BetFB8.mjs";
import { t as q } from "./NodeIcon-I60YeJ6p.mjs";
import { t as Q } from "./runStore-ByYxqieA.mjs";
import { Dropdown as X, Menu as T, MenuDivider as ee, MenuItem as te, Space as ne, Tooltip as oe } from "ant-design-vue/es";
import { computed as A, createBlock as S, createCommentVNode as C, createElementBlock as b, createElementVNode as r, createTextVNode as ie, createVNode as l, defineComponent as ae, inject as re, nextTick as se, normalizeClass as G, normalizeStyle as le, onMounted as de, onUnmounted as ue, openBlock as p, reactive as ce, ref as B, renderSlot as $, toDisplayString as w, unref as g, watch as N, watchEffect as pe, withCtx as u, withModifiers as fe } from "vue";
import { useDesign as ge } from "/@/hooks/web/useDesign";
import { sleep as ve } from "/@/utils";
import v from "/@/components/Icon";
import { addResizeListener as F, removeResizeListener as H } from "/@/utils/event";
var me = /* @__PURE__ */ (function(n) {
  return n.START = "start", n.END = "end", n.LLM = "llm", n.IMAGE_GENERATE = "imageGen", n.SWITCH = "switch", n.CLASSIFIER = "classifier", n.KNOWLEDGE = "knowledge", n.KNOWLEDGE_WRITE = "knowledgeWrite", n.CODE = "code", n.SUBFLOW = "subflow", n.ENHANCE_JAVA = "enhanceJava", n.HTTP = "http", n.TOOLS = "tools", n.BRAVE_SEARCH = "braveSearch", n.REPLY = "reply", n.SQL = "sql", n.LOOP = "loop", n.LOOP_BREAK = "loopBreak", n.LOOP_CONTINUE = "loopContinue", n.LOOP_BODY = "loopBody", n.SET_LOOP_VAR = "setLoopVar", n.VAR_MERGE = "varMerge", n.VAR_EXTRACT = "varExtract", n.CHAT_VAR_GET = "chatVarGet", n.CHAT_VAR_SET = "chatVarSet", n.CHAT_MEMORY_GET = "chatMemoryGet", n.CHAT_MEMORY_SET = "chatMemorySet", n.SYS_GET_USERINFO = "sysGetUserinfo", n;
})({}), Ge = /* @__PURE__ */ Symbol("no-setting-needed"), _e = { class: "header" }, he = ["title"], Se = { class: "text airag-node-label" }, Ee = { class: "need-app-tip" }, Ae = { class: "extra" }, Ce = { class: "shortcut-keys-tip" }, Re = {
  key: 0,
  class: "content"
}, be = ["title"], we = /* @__PURE__ */ ae({
  __name: "NodeContainer",
  props: {
    node: { type: Object },
    graph: { type: Object },
    width: Number,
    height: Number,
    hideAction: {
      type: Boolean,
      default: !1
    },
    updateHeightImmediate: {
      type: Boolean,
      default: !0
    },
    disableResizeListener: {
      type: Boolean,
      default: !1
    },
    listenForeignObjectResize: {
      type: Boolean,
      default: !1
    },
    onUpdateNode: Function,
    onParentResize: Function,
    addNodeIsShow: Function,
    runGetStepFn: Function
  },
  setup(n, { expose: U }) {
    const { prefixCls: j } = ge("airag-base-node-container"), s = n, m = () => ({
      node: s.node,
      graph: s.graph
    }), _ = B(), f = B(), o = ce({
      id: "",
      type: "",
      width: 0,
      height: 0,
      isSelected: !1,
      properties: {}
    }), O = re("editConfigModel", {}), z = A(() => O == null ? void 0 : O.isSilentMode), J = A(() => /^chat[A-Z]/.test(o.type)), k = Q(), c = A(() => {
      if (!(k.isRunning || k.isFinished)) return ["", ""];
      let t;
      const { runGetStepFn: e } = s;
      return typeof e == "function" ? t = e() : t = k.nodeSteps.find((i) => i.node.id === o.id), t ? [t.status, t.timeText] : ["waiting", ""];
    }), Y = A(() => {
      const t = [];
      if (c.value[0]) {
        const e = `run-status-${c.value[0]}`;
        t.push(e);
      }
      return [
        j,
        { selected: o.isSelected },
        t
      ];
    });
    pe(() => {
      const { graph: t, node: e } = m();
      t.$J.setEdgeRunStatus(e, c.value[0]);
    });
    const W = A(() => {
      const t = { width: `${(typeof s.width == "number" ? s.width : o.width) - 20}px` };
      return typeof s.height == "number" && (t.height = `${s.height}px`), t;
    });
    N(() => o.isSelected, (t, e) => {
      const { graph: i, node: a } = m(), d = i.$J.getAddNodeDrawerVisible();
      e && !t && d && ve(50, () => V(!1)), a.type === me.LOOP_BODY && a.zIndex > 0 && a.setZIndex(-9999);
    }), N(() => o.properties.remarks, () => se(() => R())), de(() => {
      const { graph: t, node: e } = m();
      t.$J.register(e, {
        onNodeUpdated() {
          I();
        },
        onNodeClick(i) {
        },
        onGraphUpdated(i) {
        },
        onPropertiesChange(i) {
          o.properties = i.properties;
        },
        toggleAddNodeDrawer(i, a) {
          let d = a.visible;
          d ? d = a.triggerNodeId !== o.id : d = !d, V(d, i);
        },
        onAfterAddNode(i) {
          e.draggable = !0;
        }
      }), s.disableResizeListener || F(_.value, L), f.value = _.value.closest("foreignObject"), s.listenForeignObjectResize && f.value && typeof s.onParentResize == "function" && F(f.value, D), s.updateHeightImmediate && R();
    }), ue(() => {
      H(_.value, L), f.value && H(f.value, D);
    });
    function D() {
      s.onParentResize({
        width: f.value.width.baseVal.value,
        height: f.value.height.baseVal.value,
        element: f.value
      });
    }
    function L() {
      R();
    }
    function V(t, e) {
      const { node: i, graph: a } = m();
      i.draggable = !t, t && (e = e || {}, typeof s.addNodeIsShow == "function" && (e.isShow = s.addNodeIsShow), e.prevData = { node: i }), a.$J.setAddNodeDrawerVisible(t, e, o.id);
    }
    function R(t) {
      if (!_.value) return;
      const { node: e, graph: i } = m();
      t == null && (t = _.value.offsetHeight);
      const a = e.height;
      let d, E;
      a > t ? (d = (a - t) / 2, E = e.y - d) : (d = (t - a) / 2, E = e.y + d), e.setProperties({ height: t }), e.moveTo(e.x, E);
      const y = e.getDefaultAnchor();
      for (const h of y) {
        const M = h.type === "right" ? ["getAnchorOutgoingEdge", "updateStartPoint"] : ["getAnchorIncomingEdge", "updateEndPoint"], x = i[M[0]](h.id), P = x == null ? void 0 : x[0];
        P && P[M[1]]({
          x: h.x,
          y: h.y
        });
      }
      i.$J.$groupUtils.recalcGroupSizeByNode(e.id);
    }
    function I() {
      const { node: t } = m();
      o.id = t.id, o.type = t.type, o.width = t.width, o.height = t.height, o.isSelected = t.isSelected, o.properties = t.properties, typeof s.onUpdateNode == "function" && s.onUpdateNode(o);
    }
    I();
    function K({ key: t }) {
      const { graph: e, node: i } = m();
      e.$J.doAction(t, { node: i });
    }
    return U({
      $node: o,
      runStatus: c,
      isSilentMode: z,
      updateHeight: R
    }), (t, e) => {
      const i = oe, a = ne, d = te, E = ee, y = T, h = X;
      return p(), b("div", {
        ref_key: "containerRef",
        ref: _,
        class: G(Y.value),
        style: le(W.value)
      }, [
        r("div", _e, [
          r("div", {
            class: "icon",
            title: o.id
          }, [$(t.$slots, "icon", {}, () => [l(q, { type: o.type }, null, 8, ["type"])])], 8, he),
          r("div", Se, [r("span", null, w(o.properties.text), 1), J.value ? (p(), S(i, {
            key: 0,
            title: "该节点需要关联智能体应用才能使用"
          }, {
            default: u(() => [r("span", Ee, [l(g(v), {
              icon: "ant-design:appstore-filled",
              size: 11
            }), e[1] || (e[1] = r("span", null, "应用节点", -1))])]),
            _: 1
          })) : C("", !0)]),
          r("div", Ae, [!z.value && !n.hideAction ? (p(), S(h, {
            key: 0,
            trigger: ["click"],
            placement: "bottomRight",
            overlayClassName: "airag-node-action-dropdown",
            getPopupContainer: () => _.value
          }, {
            overlay: u(() => [l(y, {
              style: { width: "240px" },
              onClick: K
            }, {
              default: u(() => [
                l(d, { key: "copy" }, {
                  default: u(() => [l(a, null, {
                    default: u(() => [l(g(v), {
                      icon: "ant-design:copy",
                      size: 16
                    }), e[2] || (e[2] = r("span", null, "复制", -1))]),
                    _: 1
                  })]),
                  _: 1
                }),
                l(E),
                l(d, {
                  key: "delete",
                  class: "hover-red"
                }, {
                  default: u(() => [l(a, null, {
                    default: u(() => [l(g(v), {
                      icon: "ant-design:delete",
                      size: 16
                    }), e[3] || (e[3] = r("span", null, "删除", -1))]),
                    _: 1
                  }), r("div", Ce, [l(i, { title: "选中节点时按下 Delete 键即可删除" }, {
                    default: u(() => [...e[4] || (e[4] = [ie("Del", -1)])]),
                    _: 1
                  })])]),
                  _: 1
                })
              ]),
              _: 1
            })]),
            default: u(() => [r("div", {
              class: "action-item dropdown",
              "data-is-node-action": "",
              onClick: e[0] || (e[0] = fe(() => {
              }, ["stop"]))
            }, [l(g(v), {
              icon: "ant-design:ellipsis",
              size: 24
            })])]),
            _: 1
          }, 8, ["getPopupContainer"])) : C("", !0)])
        ]),
        t.$slots.default ? (p(), b("div", Re, [$(t.$slots, "default")])) : C("", !0),
        c.value[0] ? (p(), b("div", {
          key: 1,
          class: G(["run-status", c.value[0]])
        }, [c.value[0] === "waiting" ? (p(), S(a, { key: 0 }, {
          default: u(() => [l(g(v), {
            icon: "tabler:clock",
            size: 12
          }), e[5] || (e[5] = r("span", null, "等待中", -1))]),
          _: 1
        })) : c.value[0] === "running" ? (p(), S(a, { key: 1 }, {
          default: u(() => [l(g(v), {
            icon: "eos-icons:bubble-loading",
            size: 12
          }), e[6] || (e[6] = r("span", null, "运行中", -1))]),
          _: 1
        })) : c.value[0] === "success" ? (p(), S(a, { key: 2 }, {
          default: u(() => [
            l(g(v), {
              icon: "ix:success",
              size: 12
            }),
            e[7] || (e[7] = r("span", null, "运行成功", -1)),
            r("span", null, "耗时：" + w(c.value[1]), 1)
          ]),
          _: 1
        })) : c.value[0] === "fail" ? (p(), S(a, { key: 3 }, {
          default: u(() => [
            l(g(v), {
              icon: "ix:namur-failure-filled",
              size: 12
            }),
            e[8] || (e[8] = r("span", null, "运行失败", -1)),
            r("span", null, "耗时：" + w(c.value[1]), 1)
          ]),
          _: 1
        })) : C("", !0)], 2)) : o.properties.remarks ? (p(), b("div", {
          key: 2,
          class: "remarks",
          title: o.properties.remarks
        }, [r("span", null, w(o.properties.remarks), 1)], 8, be)) : C("", !0)
      ], 6);
    };
  }
}), Be = /* @__PURE__ */ Z({ default: () => Oe }), Oe = we;
export {
  me as i,
  Be as n,
  Ge as r,
  Oe as t
};
