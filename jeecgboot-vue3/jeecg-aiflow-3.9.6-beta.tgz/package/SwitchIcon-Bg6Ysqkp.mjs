import { a as t } from "./objectSpread2-B0BetFB8.mjs";
import { t as o } from "./NodeIcon-Dt_fCcq_.mjs";
import { createBlock as e, defineComponent as r, openBlock as c } from "vue";
var a = /* @__PURE__ */ r({
  __name: "SwitchIcon",
  setup(n) {
    return (p, f) => (c(), e(o, {
      icon: "f7:arrow-branch",
      color: "#33c9ff",
      rotate: 90,
      strokeWidth: 2
    }));
  }
}), s = /* @__PURE__ */ t({ default: () => _ }), _ = a;
export {
  s as n,
  _ as t
};
