import { a as e } from "./objectSpread2-B0BetFB8.mjs";
import { t as o } from "./NodeIcon-Dt_fCcq_.mjs";
import { createBlock as t, defineComponent as r, openBlock as _ } from "vue";
var a = /* @__PURE__ */ r({
  __name: "CodeIcon",
  setup(n) {
    return (p, d) => (_(), t(o, {
      icon: "mdi:code",
      color: "#33c9ff",
      "stroke-width": 0.5
    }));
  }
}), s = /* @__PURE__ */ e({ default: () => c }), c = a;
export {
  s as n,
  c as t
};
