import { a as t } from "./objectSpread2-B0BetFB8.mjs";
import { t as e } from "./NodeIcon-Dt_fCcq_.mjs";
import { createBlock as r, defineComponent as o, openBlock as a } from "vue";
var _ = /* @__PURE__ */ o({
  __name: "StartIcon",
  setup(c) {
    return (p, l) => (a(), r(e, {
      icon: "tabler:home",
      color: "#4aa8ff"
    }));
  }
}), s = /* @__PURE__ */ t({ default: () => n }), n = _;
export {
  s as n,
  n as t
};
