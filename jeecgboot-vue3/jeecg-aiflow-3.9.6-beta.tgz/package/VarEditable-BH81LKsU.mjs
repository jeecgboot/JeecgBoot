import { a as x } from "./objectSpread2-B0BetFB8.mjs";
import { t as D } from "./VarTextarea-BzeLBgKt.mjs";
import { Input as E } from "ant-design-vue/es";
import { Fragment as m, computed as N, createBlock as b, createCommentVNode as v, createElementBlock as l, createElementVNode as d, createVNode as k, defineComponent as S, normalizeClass as U, onMounted as A, openBlock as e, ref as B, renderList as y, resolveComponent as R, toDisplayString as $, unref as q, watch as I } from "vue";
import { useDesign as J } from "/@/hooks/web/useDesign";
import { cloneDeep as z, debounce as F } from "lodash-es";
var L = { class: "table-header" }, M = { class: "table-row" }, T = { class: "table-body" }, j = ["onClick"], G = {
  key: 0,
  class: "table-footer"
}, H = /* @__PURE__ */ S({
  __name: "VarEditable",
  props: {
    columns: {
      type: Array,
      required: !0
    },
    data: {
      type: Array,
      required: !0
    },
    varsOptions: {
      type: Array,
      default: () => []
    },
    readonly: {
      type: Boolean,
      default: !1
    }
  },
  emits: ["update:data"],
  setup(c, { emit: h }) {
    const { prefixCls: g } = J("airag-var-editable"), s = c, C = h, o = B([]);
    I(o, F(w, 500), { deep: !0 });
    const i = N(() => s.readonly === !0);
    A(() => {
      o.value = z(s.data), o.value.length === 0 && _();
    });
    function _() {
      if (i.value) return;
      const r = {};
      for (const a of s.columns) r[a.field] = "";
      o.value.push(r);
    }
    function V(r) {
      i.value || o.value.splice(r, 1);
    }
    function w() {
      const r = [];
      e: for (const p of o.value) {
        for (const u of s.columns) if (u.required && !p[u.field]) continue e;
        r.push(p);
      }
      const a = JSON.stringify(r);
      a !== JSON.stringify(s.data) && C("update:data", JSON.parse(a));
    }
    return (r, a) => {
      const p = E, u = R("Icon");
      return e(), l("div", { class: U(`${q(g)}-container`) }, [
        d("div", L, [d("div", M, [(e(!0), l(m, null, y(c.columns, (n) => (e(), l("div", {
          key: n.field,
          class: "table-cell"
        }, $(n.label), 1))), 128)), a[0] || (a[0] = d("div", { class: "table-cell action" }, null, -1))])]),
        d("div", T, [(e(!0), l(m, null, y(o.value, (n, O) => (e(), l("div", {
          key: n.field,
          class: "table-row"
        }, [(e(!0), l(m, null, y(c.columns, (t) => (e(), l("div", {
          key: t.field,
          class: "table-cell"
        }, [t.type === "input" ? (e(), b(p, {
          key: 0,
          value: n[t.field],
          "onUpdate:value": (f) => n[t.field] = f,
          placeholder: `请输入${t.label}`,
          disabled: i.value
        }, null, 8, [
          "value",
          "onUpdate:value",
          "placeholder",
          "disabled"
        ])) : v("", !0), t.type === "var-input" ? (e(), b(D, {
          key: 1,
          value: n[t.field],
          "onUpdate:value": (f) => n[t.field] = f,
          width: 260,
          type: "input",
          placeholder: `${t.label}，按下 “/” 可以选择变量`,
          varsOptions: c.varsOptions,
          readonly: i.value
        }, null, 8, [
          "value",
          "onUpdate:value",
          "placeholder",
          "varsOptions",
          "readonly"
        ])) : v("", !0)]))), 128)), i.value ? v("", !0) : (e(), l("div", {
          key: 0,
          class: "table-cell action",
          onClick: (t) => V(O)
        }, [k(u, { icon: "ic:round-delete" })], 8, j))]))), 128))]),
        i.value ? v("", !0) : (e(), l("div", G, [d("a", { onClick: _ }, [k(u, { icon: "ic:round-add" }), a[1] || (a[1] = d("span", null, "添加参数", -1))])]))
      ], 2);
    };
  }
}), ee = /* @__PURE__ */ x({ default: () => K }), K = H;
export {
  ee as n,
  K as t
};
