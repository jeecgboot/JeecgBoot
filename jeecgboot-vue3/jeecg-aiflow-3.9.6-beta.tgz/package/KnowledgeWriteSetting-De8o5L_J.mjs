import { a as re } from "./objectSpread2-B0BetFB8.mjs";
import { t as ue } from "./_plugin-vue_export-helper-Dj7HTbfw.mjs";
import { t as ve } from "./VarTextarea-BzeLBgKt.mjs";
import { t as pe } from "./VarListPicker-CrG8EHn2.mjs";
import { t as me } from "./VarListShow-Dg1oan43.mjs";
import { t as fe } from "./WaitVectorizeSetting-BKkGAxpi.mjs";
import { t as ge } from "./useSettings-Cq_-E7Ut.mjs";
import "./Vars-Cgan49KR.mjs";
import { t as ye } from "./data-BrtUPagO.mjs";
import { Card as we, Checkbox as _e, CheckboxGroup as be, Col as ke, Input as Se, InputNumber as xe, Radio as ce, RadioGroup as Ue, Row as Ve, Select as ze, SelectOption as Ce, Space as Ie, Tooltip as Re } from "ant-design-vue/es";
import { Fragment as E, computed as $, createBlock as G, createCommentVNode as k, createElementBlock as _, createElementVNode as a, createTextVNode as d, createVNode as l, defineComponent as Ae, isRef as u, normalizeClass as Te, openBlock as f, renderList as Ke, resolveComponent as Le, toDisplayString as Ne, unref as t, withCtx as n } from "vue";
import { useMessage as Oe } from "/@/hooks/web/useMessage";
import { useModal as Fe } from "/@/components/Modal";
import D from "/@/components/Icon";
import { cloneDeep as H } from "lodash-es";
import $e from "/@/views/super/airag/aiknowledge/icon/knowledge.png";
import De from "/@/views/super/airag/aiapp/components/AiAppAddKnowledgeModal.vue";
var Me = { class: "knowledge-write-setting" }, qe = { class: "setting-item" }, We = { class: "setting-item" }, Be = { class: "knowledge-actions" }, Pe = { class: "knowledge-card__content" }, je = { class: "knowledge-info" }, Ee = ["src"], Ge = { class: "setting-item" }, He = {
  key: 0,
  class: "setting-item"
}, Je = {
  key: 0,
  class: "file-empty-tip"
}, Qe = {
  key: 1,
  class: "setting-item"
}, Xe = { class: "setting-item" }, Ye = { class: "setting-item" }, Ze = {
  key: 0,
  class: "setting-item"
}, he = { class: "setting-item" }, et = { class: "setting-item" }, tt = { class: "setting-item" }, lt = { class: "setting-item" }, ot = /* @__PURE__ */ Ae({
  __name: "KnowledgeWriteSetting",
  props: {
    type: {
      type: String,
      required: !0
    },
    node: {
      type: Object,
      required: !0
    },
    properties: {
      type: Object,
      required: !0
    },
    isSilentMode: {
      type: Boolean,
      required: !0
    },
    setProperties: {
      type: Function,
      required: !0
    }
  },
  setup(J) {
    const Q = J, { createMessage: X } = Oe(), { inputParams: z, outputParams: Y, prevVariables: C, inputVarsOptions: Z, createOptionRef: r, createStoreRef: h, isReadOnly: s } = ge(Q), S = r("writeType"), y = r("knowIds"), I = r("content"), R = r("fileSources"), A = r("waitForVectorize"), T = r("waitTimeout"), K = r("vectorizeFailStrategy"), M = $(() => (C.value || []).filter((i) => i.type === "file").map((i) => ({
      label: `${i.nodeName || "-"} / ${i.name || i.field}`,
      value: `${i.nodeId}|${i.field}`
    }))), q = $({
      get: () => (Array.isArray(R.value) ? R.value : []).map((i) => `${i.nodeId}|${i.field}`),
      set: (i) => {
        const e = (i || []).map((v) => {
          const [w, b] = v.split("|"), g = (C.value || []).find((U) => U.nodeId === w && U.field === b);
          return {
            nodeId: w,
            field: b,
            name: (g == null ? void 0 : g.name) || b,
            nodeName: (g == null ? void 0 : g.nodeName) || ""
          };
        });
        R.value = e;
      }
    }), x = r("segmentStrategy"), c = r("separator"), L = r("customSeparator"), N = r("maxSegment"), O = r("overlap"), F = r("textRules"), p = h("knowledgeDataList"), ee = $(() => ["string", "number"]), [te, { openModal: le }] = Fe();
    function oe() {
      s.value || le(!0, {
        knowledgeIds: (y.value || []).join(","),
        knowledgeDataList: p.value
      });
    }
    function ae(i, e) {
      if (s.value) return;
      const v = H(i || []), w = H(e || []);
      v.length > 1 && X.warn("仅支持选择 1 个知识库，已保留第一个"), y.value = v.length > 0 ? [v[0]] : [], p.value = w.length > 0 ? [w[0]] : [];
    }
    function ne(i) {
      if (s.value) return;
      Array.isArray(y.value) || (y.value = []);
      const e = y.value.filter((v) => v !== i);
      y.value = e, Array.isArray(p.value) ? p.value = p.value.filter((v) => v.id !== i) : p.value = [];
    }
    return ye(y, p), (i, e) => {
      const v = Le("a-button"), w = Re, b = Ie, g = we, U = ke, ie = Ve, V = ce, W = Ue, B = ze, m = Ce, se = Se, P = xe, j = _e, de = be;
      return f(), _("div", Me, [
        a("div", qe, [e[13] || (e[13] = a("div", { class: "label" }, "输入变量", -1)), l(t(pe), {
          vars: t(z),
          "onUpdate:vars": e[0] || (e[0] = (o) => u(z) ? z.value = o : null),
          prevVariables: t(C),
          allowedTypes: ee.value,
          readonly: t(s)
        }, null, 8, [
          "vars",
          "prevVariables",
          "allowedTypes",
          "readonly"
        ])]),
        a("div", We, [
          e[15] || (e[15] = a("div", { class: "label" }, "选择知识库", -1)),
          a("div", Be, [l(b, null, {
            default: n(() => [l(v, {
              type: "link",
              size: "small",
              disabled: t(s),
              onClick: oe
            }, {
              default: n(() => [l(t(D), {
                icon: "ant-design:plus-outlined",
                size: "13",
                style: { "margin-right": "4px" }
              }), e[14] || (e[14] = a("span", null, "添加", -1))]),
              _: 1
            }, 8, ["disabled"]), l(w, { title: "仅支持选择 1 个知识库" }, {
              default: n(() => [l(t(D), { icon: "ant-design:info-circle-outlined" })]),
              _: 1
            })]),
            _: 1
          })]),
          l(ie, { span: 24 }, {
            default: n(() => [t(p) && t(p).length > 0 ? (f(!0), _(E, { key: 0 }, Ke(t(p), (o) => (f(), G(U, {
              span: 12,
              key: o.id
            }, {
              default: n(() => [l(g, {
                hoverable: "",
                class: "knowledge-card",
                "body-style": { width: "100%" }
              }, {
                default: n(() => [a("div", Pe, [a("div", je, [a("img", {
                  class: "knowledge-img",
                  src: t($e)
                }, null, 8, Ee), a("span", { class: Te(["knowledge-name", { "knowledge-invalid-text": o.invalid }]) }, Ne(o.name), 3)]), t(s) ? k("", !0) : (f(), G(t(D), {
                  key: 0,
                  size: "20",
                  class: "knowledge-icon",
                  icon: "ant-design:close-outlined",
                  onClick: (nt) => ne(o.id)
                }, null, 8, ["onClick"]))])]),
                _: 2
              }, 1024)]),
              _: 2
            }, 1024))), 128)) : k("", !0)]),
            _: 1
          })
        ]),
        a("div", Ge, [e[18] || (e[18] = a("div", { class: "label" }, "写入类型", -1)), l(W, {
          value: t(S),
          "onUpdate:value": e[1] || (e[1] = (o) => u(S) ? S.value = o : null),
          disabled: t(s)
        }, {
          default: n(() => [l(V, { value: "text" }, {
            default: n(() => [...e[16] || (e[16] = [d("文本写入", -1)])]),
            _: 1
          }), l(V, { value: "file" }, {
            default: n(() => [...e[17] || (e[17] = [d("文件写入", -1)])]),
            _: 1
          })]),
          _: 1
        }, 8, ["value", "disabled"])]),
        t(S) === "file" ? (f(), _("div", He, [
          e[19] || (e[19] = a("div", { class: "label" }, "文件来源", -1)),
          l(B, {
            value: q.value,
            "onUpdate:value": e[2] || (e[2] = (o) => q.value = o),
            mode: "multiple",
            placeholder: "请选择前置节点的文件类型变量（支持多选）",
            options: M.value,
            disabled: t(s),
            "get-popup-container": (o) => o.parentNode,
            style: { width: "100%" }
          }, null, 8, [
            "value",
            "options",
            "disabled",
            "get-popup-container"
          ]),
          e[20] || (e[20] = a("div", { class: "file-accept-tip" }, " 支持格式：txt、markdown、pdf、docx、xlsx、pptx ", -1)),
          e[21] || (e[21] = a("div", { class: "file-accept-tip" }, " 每个文件将作为独立文档写入知识库；单个变量包含多个 URL 时（英文逗号分隔），同样会拆为多个文档 ", -1)),
          M.value.length === 0 ? (f(), _("div", Je, " 前置节点中暂无文件类型变量，请先在开始节点中添加 file 类型字段 ")) : k("", !0)
        ])) : (f(), _("div", Qe, [e[22] || (e[22] = a("div", { class: "label" }, "写入内容", -1)), l(t(ve), {
          value: t(I),
          "onUpdate:value": e[3] || (e[3] = (o) => u(I) ? I.value = o : null),
          varsOptions: t(Z),
          placeholder: "请输入写入知识库的文本，支持输入 / 插入变量",
          height: 120,
          readonly: t(s)
        }, null, 8, [
          "value",
          "varsOptions",
          "readonly"
        ])])),
        a("div", Xe, [e[25] || (e[25] = a("div", { class: "label" }, "分段策略", -1)), l(W, {
          value: t(x),
          "onUpdate:value": e[4] || (e[4] = (o) => u(x) ? x.value = o : null),
          disabled: t(s)
        }, {
          default: n(() => [l(V, { value: "auto" }, {
            default: n(() => [...e[23] || (e[23] = [d("自动分段与清洗", -1)])]),
            _: 1
          }), l(V, { value: "custom" }, {
            default: n(() => [...e[24] || (e[24] = [d("自定义", -1)])]),
            _: 1
          })]),
          _: 1
        }, 8, ["value", "disabled"])]),
        t(x) === "custom" ? (f(), _(E, { key: 2 }, [
          a("div", Ye, [e[35] || (e[35] = a("div", { class: "label" }, "分段标识符", -1)), l(B, {
            value: t(c),
            "onUpdate:value": e[5] || (e[5] = (o) => u(c) ? c.value = o : null),
            disabled: t(s),
            "get-popup-container": (o) => o.parentNode,
            style: { width: "100%" }
          }, {
            default: n(() => [
              l(m, { value: "\\n" }, {
                default: n(() => [...e[26] || (e[26] = [d("换行", -1)])]),
                _: 1
              }),
              l(m, { value: "\\n\\n" }, {
                default: n(() => [...e[27] || (e[27] = [d("2个换行", -1)])]),
                _: 1
              }),
              l(m, { value: "。" }, {
                default: n(() => [...e[28] || (e[28] = [d("中文句号", -1)])]),
                _: 1
              }),
              l(m, { value: "！" }, {
                default: n(() => [...e[29] || (e[29] = [d("中文叹号", -1)])]),
                _: 1
              }),
              l(m, { value: "？" }, {
                default: n(() => [...e[30] || (e[30] = [d("中文问号", -1)])]),
                _: 1
              }),
              l(m, { value: "." }, {
                default: n(() => [...e[31] || (e[31] = [d("英文句号", -1)])]),
                _: 1
              }),
              l(m, { value: "!" }, {
                default: n(() => [...e[32] || (e[32] = [d("英文叹号", -1)])]),
                _: 1
              }),
              l(m, { value: "?" }, {
                default: n(() => [...e[33] || (e[33] = [d("英文问号", -1)])]),
                _: 1
              }),
              l(m, { value: "custom" }, {
                default: n(() => [...e[34] || (e[34] = [d("自定义", -1)])]),
                _: 1
              })
            ]),
            _: 1
          }, 8, [
            "value",
            "disabled",
            "get-popup-container"
          ])]),
          t(c) === "custom" ? (f(), _("div", Ze, [e[36] || (e[36] = a("div", { class: "label" }, "自定义分段标识符", -1)), l(se, {
            value: t(L),
            "onUpdate:value": e[6] || (e[6] = (o) => u(L) ? L.value = o : null),
            disabled: t(s),
            placeholder: "请输入自定义分段标识符"
          }, null, 8, ["value", "disabled"])])) : k("", !0),
          a("div", he, [e[37] || (e[37] = a("div", { class: "label" }, "分段最大长度", -1)), l(P, {
            value: t(N),
            "onUpdate:value": e[7] || (e[7] = (o) => u(N) ? N.value = o : null),
            disabled: t(s),
            min: 100,
            max: 5e3,
            style: { width: "100%" }
          }, null, 8, ["value", "disabled"])]),
          a("div", et, [e[38] || (e[38] = a("div", { class: "label" }, "分段重叠度%", -1)), l(P, {
            value: t(O),
            "onUpdate:value": e[8] || (e[8] = (o) => u(O) ? O.value = o : null),
            disabled: t(s),
            min: 0,
            max: 90,
            style: { width: "100%" }
          }, null, 8, ["value", "disabled"])]),
          a("div", tt, [e[41] || (e[41] = a("div", { class: "label" }, "文本预处理规则", -1)), l(de, {
            value: t(F),
            "onUpdate:value": e[9] || (e[9] = (o) => u(F) ? F.value = o : null),
            disabled: t(s)
          }, {
            default: n(() => [a("div", null, [l(j, { value: "cleanSpaces" }, {
              default: n(() => [...e[39] || (e[39] = [d("替换掉连续的空格、换行符和制表符", -1)])]),
              _: 1
            })]), a("div", null, [l(j, { value: "removeUrlsEmails" }, {
              default: n(() => [...e[40] || (e[40] = [d("删除所有 URL 和电子邮箱地址", -1)])]),
              _: 1
            })])]),
            _: 1
          }, 8, ["value", "disabled"])])
        ], 64)) : k("", !0),
        l(fe, {
          "wait-for-vectorize": t(A),
          "onUpdate:waitForVectorize": e[10] || (e[10] = (o) => u(A) ? A.value = o : null),
          "wait-timeout": t(T),
          "onUpdate:waitTimeout": e[11] || (e[11] = (o) => u(T) ? T.value = o : null),
          "vectorize-fail-strategy": t(K),
          "onUpdate:vectorizeFailStrategy": e[12] || (e[12] = (o) => u(K) ? K.value = o : null),
          readonly: t(s)
        }, null, 8, [
          "wait-for-vectorize",
          "wait-timeout",
          "vectorize-fail-strategy",
          "readonly"
        ]),
        a("div", lt, [e[42] || (e[42] = a("div", { class: "label" }, "输出变量", -1)), l(t(me), { vars: t(Y) }, null, 8, ["vars"])]),
        l(De, {
          onRegister: t(te),
          onSuccess: ae
        }, null, 8, ["onRegister"])
      ]);
    };
  }
}), ct = /* @__PURE__ */ re({ default: () => at }), at = /* @__PURE__ */ ue(ot, [["__scopeId", "data-v-3e28368d"]]);
export {
  ct as n,
  at as t
};
