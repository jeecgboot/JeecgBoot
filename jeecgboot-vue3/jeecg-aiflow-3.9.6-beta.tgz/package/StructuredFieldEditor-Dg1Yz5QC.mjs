import { a as O, n as $, t as z } from "./objectSpread2-B0BetFB8.mjs";
import { t as H } from "./_plugin-vue_export-helper-Dj7HTbfw.mjs";
import { t as m } from "./asyncToGenerator-BkhZtDh9.mjs";
import { t as L } from "./rules-BcwBMgYM.mjs";
import { Divider as U, Empty as J } from "ant-design-vue/es";
import { Fragment as F, computed as K, createBlock as Q, createCommentVNode as f, createElementBlock as u, createElementVNode as r, createVNode as l, defineComponent as W, normalizeClass as X, openBlock as o, ref as S, renderList as Y, toDisplayString as k, unref as i, withCtx as Z, withModifiers as M } from "vue";
import { useMessage as ee } from "/@/hooks/web/useMessage";
import { BasicModal as te, useModal as re } from "/@/components/Modal";
import { Icon as E } from "/@/components/Icon";
import { BasicForm as ne, useForm as ae } from "/@/components/Form";
import { PlusOutlined as le } from "@ant-design/icons-vue";
$();
var oe = ["onClick"], ie = { class: "icon" }, se = { class: "name" }, de = { class: "field-name" }, ue = { class: "display-name" }, ce = { class: "desc-text" }, pe = {
  key: 0,
  class: "action"
}, me = ["onClick"], fe = {
  key: 1,
  class: "field-add"
}, ye = { style: { padding: "20px" } }, ve = /* @__PURE__ */ W({
  __name: "StructuredFieldEditor",
  props: {
    fields: {
      type: Array,
      required: !0
    },
    readonly: {
      type: Boolean,
      default: !1
    }
  },
  emits: ["update:fields"],
  setup(s, { emit: w }) {
    const { createConfirmSync: A } = ee(), c = s, x = w, p = S(!1), y = S(-1), I = K(() => p.value ? "编辑字段" : "添加字段"), [V, { openModal: C, closeModal: B }] = re(), [P, a] = ae({
      showActionButtonGroup: !1,
      schemas: [
        {
          field: "field",
          label: "字段名",
          component: "Input",
          helpMessage: "用于后续节点引用，只能包含字母、数字、下划线",
          rules: [{
            required: !0,
            message: "请输入字段名"
          }, { validator: (e, t) => {
            const n = L(t);
            return n.passed ? Promise.resolve() : Promise.reject("字段名" + n.message);
          } }]
        },
        {
          field: "name",
          label: "展示名称",
          component: "Input",
          helpMessage: "字段的可读名称，在节点卡片和变量列表中显示",
          rules: [{
            required: !0,
            message: "请输入展示名称"
          }]
        },
        {
          field: "type",
          label: "字段类型",
          component: "Select",
          componentProps: {
            options: [
              {
                label: "文本 (string)",
                value: "string"
              },
              {
                label: "数字 (number)",
                value: "number"
              },
              {
                label: "布尔 (boolean)",
                value: "boolean"
              },
              {
                label: "对象 (object)",
                value: "object"
              },
              {
                label: "数组 (array)",
                value: "array"
              },
              {
                label: "文本数组 (string[])",
                value: "string[]"
              },
              {
                label: "数字数组 (number[])",
                value: "number[]"
              },
              {
                label: "对象数组 (object[])",
                value: "object[]"
              }
            ],
            getPopupContainer: () => document.body
          },
          rules: [{
            required: !0,
            message: "请选择字段类型"
          }]
        },
        {
          field: "desc",
          label: "描述",
          component: "InputTextArea",
          helpMessage: "此描述会被注入到 AI 提示词中，帮助模型理解该字段的含义",
          componentProps: {
            rows: 2,
            placeholder: "例如：用户的姓名，不超过20个字符（可选）"
          }
        }
      ]
    });
    function R(e) {
      switch (e) {
        case "number":
          return "ant-design:number";
        case "boolean":
          return "ant-design:check-circle-outlined";
        case "object":
          return "ic:baseline-data-object";
        case "string[]":
          return "carbon:array-strings";
        case "number[]":
          return "carbon:array-numbers";
        case "object[]":
          return "carbon:array-objects";
        case "array":
          return "mdi:code-array";
        default:
          return "memory:format-text";
      }
    }
    function T() {
      return v.apply(this, arguments);
    }
    function v() {
      return v = m(function* () {
        c.readonly || (p.value = !1, y.value = -1, C(), yield a.resetFields(), yield a.setFieldsValue({ type: "string" }), yield a.clearValidate());
      }), v.apply(this, arguments);
    }
    function q(e, t) {
      return _.apply(this, arguments);
    }
    function _() {
      return _ = m(function* (e, t) {
        c.readonly || (p.value = !0, y.value = t, C(), yield a.resetFields(), yield a.setFieldsValue(z({}, e)), yield a.clearValidate());
      }), _.apply(this, arguments);
    }
    function D(e) {
      return g.apply(this, arguments);
    }
    function g() {
      return g = m(function* (e) {
        if (c.readonly || !(yield A({
          title: "删除",
          content: "确定要删除这个字段吗？"
        }))) return;
        const t = [...c.fields];
        t.splice(e, 1), x("update:fields", t);
      }), g.apply(this, arguments);
    }
    function N() {
      return b.apply(this, arguments);
    }
    function b() {
      return b = m(function* () {
        try {
          const e = yield a.validate(), t = {
            field: e.field,
            name: e.name,
            type: e.type,
            desc: e.desc || ""
          }, n = [...c.fields];
          p.value ? n[y.value] = t : n.push(t), x("update:fields", n), B();
        } catch (e) {
        }
      }), b.apply(this, arguments);
    }
    return (e, t) => {
      const n = J, j = U;
      return o(), u(F, null, [
        s.fields.length === 0 ? (o(), Q(n, {
          key: 0,
          "image-style": { height: "48px" },
          description: "尚未配置输出字段"
        })) : f("", !0),
        (o(!0), u(F, null, Y(s.fields, (d, h) => (o(), u("div", {
          key: h,
          class: X(["field-item", { "field-item-readonly": s.readonly }]),
          onClick: (G) => q(d, h)
        }, [
          r("div", ie, [l(i(E), { icon: R(d.type) }, null, 8, ["icon"])]),
          r("div", se, [
            r("span", de, k(d.field), 1),
            l(j, { type: "vertical" }),
            r("span", ue, k(d.name), 1),
            d.desc ? (o(), u(F, { key: 0 }, [l(j, { type: "vertical" }), r("span", ce, k(d.desc), 1)], 64)) : f("", !0)
          ]),
          s.readonly ? f("", !0) : (o(), u("div", pe, [r("span", { onClick: M((G) => D(h), ["stop"]) }, [l(i(E), { icon: "ant-design:delete" })], 8, me)]))
        ], 10, oe))), 128)),
        s.readonly ? f("", !0) : (o(), u("div", fe, [r("a", {
          type: "text",
          onClick: M(T, ["stop"])
        }, [l(i(le)), t[0] || (t[0] = r("span", { style: { "margin-left": "6px" } }, "添加字段", -1))])])),
        l(i(te), {
          onRegister: i(V),
          title: I.value,
          width: 570,
          minHeight: 320,
          okText: "保存",
          forceRender: "",
          onOk: N
        }, {
          default: Z(() => [r("div", ye, [l(i(ne), { onRegister: i(P) }, null, 8, ["onRegister"])])]),
          _: 1
        }, 8, ["onRegister", "title"])
      ], 64);
    };
  }
}), Ae = /* @__PURE__ */ O({ default: () => _e }), _e = /* @__PURE__ */ H(ve, [["__scopeId", "data-v-87c43cb3"]]);
export {
  Ae as n,
  _e as t
};
