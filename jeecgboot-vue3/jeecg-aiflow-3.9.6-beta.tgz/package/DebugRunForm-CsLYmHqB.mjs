import { a as h, n as x, t as c } from "./objectSpread2-B0BetFB8.mjs";
import { t as U } from "./JFileUploadSlot-DrWnwta-.mjs";
import { t as D } from "./asyncToGenerator-BkhZtDh9.mjs";
import { computed as w, createElementBlock as A, createElementVNode as B, createVNode as l, defineComponent as C, openBlock as S, ref as $, unref as d, withCtx as p } from "vue";
import { BasicForm as k, useForm as G } from "/@/components/Form";
import { defHttp as M } from "/@/utils/http/axios";
import { useGlobSetting as T } from "/@/hooks/setting";
import V from "/@/components/Form/src/jeecg/components/JImageUpload.vue";
x();
var j = { style: { "margin-top": "12px" } }, E = /* @__PURE__ */ C({
  __name: "DebugRunForm",
  props: { schemas: {
    type: Array,
    required: !0
  } },
  setup(f, { expose: _ }) {
    const v = f, { domainUrl: g } = T(), i = g + "/airag/chat/upload", [F, a] = G({
      schemas: v.schemas,
      labelCol: { span: 24 },
      wrapperCol: { span: 24 },
      showActionButtonGroup: !1
    });
    function b(t) {
      return n.apply(this, arguments);
    }
    function n() {
      return n = D(function* (t) {
        const e = "/airag/flow/aigc/test-data", o = { fields: t }, r = yield M.post({
          url: e,
          params: o,
          timeout: 3e5
        });
        yield a.resetFields(), yield a.setFieldsValue(r.data);
      }), n.apply(this, arguments);
    }
    const m = $(), y = w(() => {
      var t, e;
      return (t = (e = m.value) === null || e === void 0 ? void 0 : e.formModel) !== null && t !== void 0 ? t : {};
    });
    return _(c(c({}, a), {}, {
      genTestData: b,
      formModel: y
    })), (t, e) => (S(), A("div", j, [l(d(k), {
      ref_key: "basicFormRef",
      ref: m,
      onRegister: d(F)
    }, {
      unKnown: p(() => [...e[0] || (e[0] = [B("div", null, "未知类型", -1)])]),
      picture: p(({ model: o, field: r }) => [l(V, {
        value: o[r],
        "onUpdate:value": (s) => o[r] = s,
        fileMax: 3,
        uploadUrl: i
      }, null, 8, ["value", "onUpdate:value"])]),
      file: p(({ model: o, field: r, schema: s }) => {
        var u;
        return [l(U, {
          value: o[r],
          "onUpdate:value": (R) => o[r] = R,
          uploadUrl: i,
          accept: (u = s.componentProps) === null || u === void 0 ? void 0 : u.accept
        }, null, 8, [
          "value",
          "onUpdate:value",
          "accept"
        ])];
      }),
      _: 1
    }, 8, ["onRegister"])]));
  }
}), O = /* @__PURE__ */ h({ default: () => J }), J = E;
export {
  O as n,
  J as t
};
