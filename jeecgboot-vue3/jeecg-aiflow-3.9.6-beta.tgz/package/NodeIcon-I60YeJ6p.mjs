import { a as p } from "./objectSpread2-B0BetFB8.mjs";
import { n as a } from "./const-OjvoZKjM.mjs";
import { createBlock as c, createElementBlock as _, defineComponent as s, openBlock as o, unref as u } from "vue";
var l = { key: 0 }, d = /* @__PURE__ */ s({
  __name: "NodeIcon",
  props: { type: {
    type: String,
    required: !0
  } },
  setup(t) {
    const n = t, e = a.get(n.type), r = e == null;
    return (f, i) => r ? (o(), _("span", l, "-")) : (o(), c(u(e), { key: 1 }));
  }
}), I = /* @__PURE__ */ p({ default: () => m }), m = d;
export {
  I as n,
  m as t
};
