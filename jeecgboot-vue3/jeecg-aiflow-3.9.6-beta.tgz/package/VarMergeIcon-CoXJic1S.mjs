import { a as r } from "./objectSpread2-B0BetFB8.mjs";
import { t as o } from "./NodeIcon-Dt_fCcq_.mjs";
import { createBlock as e, openBlock as a } from "vue";
var l = /* @__PURE__ */ r({ default: () => t }), t = {
  __name: "VarMergeIcon",
  setup(c) {
    return (_, p) => (a(), e(o, {
      icon: "ph:arrows-merge-bold",
      color: "#12c499"
    }));
  }
};
export {
  t as n,
  l as t
};
