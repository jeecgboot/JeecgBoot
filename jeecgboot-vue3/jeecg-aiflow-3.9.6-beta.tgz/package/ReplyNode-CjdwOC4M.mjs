import { a as l } from "./objectSpread2-B0BetFB8.mjs";
import "./base-node-CKuyN1x8.mjs";
import { t as u } from "./NodeContainer-zpIyuhKY.mjs";
import { t as n } from "./NodeKVS-CRVYjcYN.mjs";
import { t as d } from "./useNode-lPs0rKwe.mjs";
import { computed as i, createBlock as s, createVNode as m, defineComponent as _, guardReactiveProps as c, normalizeProps as v, openBlock as f, unref as t, withCtx as y } from "vue";
var N = /* @__PURE__ */ _({
  __name: "ReplyNode",
  props: {
    node: {
      type: Object,
      required: !0
    },
    graph: {
      type: Object,
      required: !0
    }
  },
  setup(o) {
    const { $properties: r, getInputParamKVItem: p } = d(o), a = i(() => {
      var e;
      return [p({
        label: "输入变量",
        emptyAction: "hidden"
      }), {
        label: "回复内容",
        value: (e = r.value) === null || e === void 0 || (e = e.options) === null || e === void 0 ? void 0 : e.content,
        emptyAction: "tip",
        emptyTip: "尚未填写"
      }];
    });
    return (e, b) => (f(), s(t(u), v(c(e.$props)), {
      default: y(() => [m(t(n), { kvs: a.value }, null, 8, ["kvs"])]),
      _: 1
    }, 16));
  }
}), A = /* @__PURE__ */ l({ default: () => R }), R = N;
export {
  A as n,
  R as t
};
