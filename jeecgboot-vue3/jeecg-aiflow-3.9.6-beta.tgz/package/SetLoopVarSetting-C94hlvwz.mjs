import { a as F } from "./objectSpread2-B0BetFB8.mjs";
import { t as O } from "./_plugin-vue_export-helper-Dj7HTbfw.mjs";
import { t as A } from "./VarPicker-HOsUWkU-.mjs";
import { r as D } from "./utils-BH2jvfSb.mjs";
import { t as E } from "./useSettings-Cq_-E7Ut.mjs";
import "./Vars-Cgan49KR.mjs";
import { Select as R, SelectOption as j, Tag as z } from "ant-design-vue/es";
import { Fragment as M, computed as p, createBlock as w, createCommentVNode as U, createElementBlock as d, createElementVNode as s, createTextVNode as b, createVNode as y, defineComponent as $, isRef as G, openBlock as o, renderList as H, toDisplayString as m, unref as v, watch as J, withCtx as g } from "vue";
var K = { class: "set-loop-var-setting" }, Q = { class: "setting-item" }, W = { class: "loop-var-option" }, X = {
  key: 0,
  class: "p-tip warning"
}, Y = {
  key: 1,
  class: "p-tip"
}, Z = { class: "setting-item" }, ee = { class: "label flex-space-between" }, te = {
  key: 0,
  class: "p-tip"
}, re = {
  key: 1,
  class: "p-tip"
}, ae = /* @__PURE__ */ $({
  __name: "SetLoopVarSetting",
  props: {
    type: {
      type: String,
      required: !0
    },
    node: {
      type: Object,
      required: !0
    },
    properties: {
      type: Object,
      required: !0
    },
    isSilentMode: {
      type: Boolean,
      required: !0
    },
    setProperties: {
      type: Function,
      required: !0
    }
  },
  setup(k) {
    const V = k, { lfRef: h, prevVariables: N, createOptionRef: S, isReadOnly: c } = E(V), r = S("targetField"), l = S("sourceVar"), f = p(() => {
      var e;
      if (!h.value) return [];
      const t = D(V.node.id);
      if (!t) return [];
      const i = h.value.getNodeDataById(t), _ = i == null || (e = i.properties) === null || e === void 0 || (e = e.options) === null || e === void 0 ? void 0 : e.loopParams;
      return Array.isArray(_) ? _.filter((u) => !!u.name).map((u) => ({
        field: u.name,
        name: u.name,
        type: u.type || "string"
      })) : [];
    }), n = p(() => {
      if (!r.value) return "";
      const e = f.value.find((t) => t.field === r.value);
      return (e == null ? void 0 : e.type) || "string";
    }), C = p(() => n.value === "string"), T = p(() => {
      if (n.value && n.value !== "any")
        return [n.value];
    }), x = p(() => N.value), I = p(() => l.value || {});
    function B() {
      c.value || (l.value = {});
    }
    function L(e) {
      if (!c.value) {
        if (!e) {
          l.value = {};
          return;
        }
        l.value = {
          nodeId: e.nodeId,
          field: e.field,
          type: e.type
        };
      }
    }
    function P(e) {
      if (!c.value) {
        if (!e && e !== "") {
          l.value = {};
          return;
        }
        l.value = {
          customValue: e,
          type: n.value || "string"
        };
      }
    }
    J(f, (e) => {
      r.value && (e.some((t) => t.field === r.value) || (r.value = "", l.value = {}));
    }, { deep: !0 });
    function q(e) {
      switch (e) {
        case "number":
          return "green";
        case "string":
          return "blue";
        default:
          return "default";
      }
    }
    return (e, t) => {
      const i = z, _ = j, u = R;
      return o(), d("div", K, [s("div", Q, [
        t[1] || (t[1] = s("div", { class: "label" }, "目标循环变量", -1)),
        y(u, {
          value: v(r),
          "onUpdate:value": t[0] || (t[0] = (a) => G(r) ? r.value = a : null),
          placeholder: "请选择要设置的循环变量",
          disabled: v(c),
          style: { width: "100%" },
          allowClear: "",
          onChange: B
        }, {
          default: g(() => [(o(!0), d(M, null, H(f.value, (a) => (o(), w(_, {
            key: a.field,
            value: a.field
          }, {
            default: g(() => [s("div", W, [s("span", null, m(a.name || a.field), 1), y(i, {
              color: q(a.type),
              size: "small"
            }, {
              default: g(() => [b(m(a.type || "string"), 1)]),
              _: 2
            }, 1032, ["color"])])]),
            _: 2
          }, 1032, ["value"]))), 128))]),
          _: 1
        }, 8, ["value", "disabled"]),
        f.value.length === 0 ? (o(), d("p", X, " 当前循环节点未配置自定义循环变量，请先在循环节点中添加。 ")) : (o(), d("p", Y, "选择当前循环体中定义的自定义循环变量。"))
      ]), s("div", Z, [
        s("div", ee, [t[2] || (t[2] = s("span", null, "变量值", -1)), n.value ? (o(), w(i, {
          key: 0,
          color: "blue"
        }, {
          default: g(() => [b(m(n.value), 1)]),
          _: 1
        })) : U("", !0)]),
        y(v(A), {
          item: I.value,
          vars: x.value,
          allowEditValue: C.value,
          allowedTypes: T.value,
          readonly: v(c) || !v(r),
          onChange: L,
          onChangeCustom: P
        }, null, 8, [
          "item",
          "vars",
          "allowEditValue",
          "allowedTypes",
          "readonly"
        ]),
        v(r) ? (o(), d("p", re, " 选择上游节点的输出变量" + m(C.value ? "，或直接输入自定义值" : "") + "。 ", 1)) : (o(), d("p", te, "请先选择目标循环变量。"))
      ])]);
    };
  }
}), fe = /* @__PURE__ */ F({ default: () => oe }), oe = /* @__PURE__ */ O(ae, [["__scopeId", "data-v-a584df1c"]]);
export {
  fe as n,
  oe as t
};
