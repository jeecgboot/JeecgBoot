import { a as v } from "./objectSpread2-B0BetFB8.mjs";
import { t as c } from "./_plugin-vue_export-helper-Dj7HTbfw.mjs";
import "./base-node-CKuyN1x8.mjs";
import { t as _ } from "./NodeContainer-zpIyuhKY.mjs";
import { t as f } from "./NodeKVS-CRVYjcYN.mjs";
import { t as x } from "./useNode-lPs0rKwe.mjs";
import { computed as y, createBlock as b, createElementVNode as a, createVNode as V, defineComponent as g, guardReactiveProps as N, normalizeProps as A, openBlock as $, unref as l, withCtx as h } from "vue";
var E = /* @__PURE__ */ g({
  __name: "VarExtractNode",
  props: {
    node: {
      type: Object,
      required: !0
    },
    graph: {
      type: Object,
      required: !0
    }
  },
  setup(i) {
    const { $properties: p, getInputParamKVItem: s, containerProps: u } = x(i), n = y(() => {
      var t, e;
      let r = (t = p.value) === null || t === void 0 || (t = t.options) === null || t === void 0 ? void 0 : t.variables;
      r = Array.isArray(r) ? r : [];
      const d = r.length === 0 ? [{
        label: "提取变量",
        value: "",
        emptyAction: "tip",
        emptyTip: "尚未配置"
      }] : r.map((o, m) => ({
        label: m === 0 ? "提取变量" : "",
        valueList: [
          ...o.required ? [{
            text: "*",
            style: {
              color: "#ff9494",
              fontWeight: "bold",
              marginRight: "2px"
            }
          }] : [],
          { text: o.name },
          {
            text: `<${o.type}>`,
            type: "tip"
          }
        ],
        separator: ""
      }));
      return [
        s({
          label: "输入变量",
          emptyAction: "tip",
          emptyTip: "未选择输入"
        }),
        {
          label: "模型",
          value: (e = p.value) === null || e === void 0 || (e = e.options) === null || e === void 0 || (e = e.model) === null || e === void 0 || (e = e.params) === null || e === void 0 ? void 0 : e.model,
          emptyAction: "tip",
          emptyTip: "尚未选择"
        },
        ...d
      ];
    });
    return (t, e) => ($(), b(l(_), A(N(l(u))), {
      default: h(() => [V(l(f), { kvs: n.value }, null, 8, ["kvs"]), e[0] || (e[0] = a("div", { class: "var-extract-case-box" }, [a("div", { class: "case-item" }, [a("span", null, "成功")]), a("div", { class: "case-item" }, [a("span", null, "失败")])], -1))]),
      _: 1
    }, 16));
  }
}), B = /* @__PURE__ */ v({ default: () => k }), k = /* @__PURE__ */ c(E, [["__scopeId", "data-v-53534402"]]);
export {
  B as n,
  k as t
};
