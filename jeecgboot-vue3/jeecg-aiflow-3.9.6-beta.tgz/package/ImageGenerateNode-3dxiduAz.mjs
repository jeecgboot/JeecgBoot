import { a as d } from "./objectSpread2-B0BetFB8.mjs";
import "./base-node-CKuyN1x8.mjs";
import { t as v } from "./NodeContainer-zpIyuhKY.mjs";
import { t as s } from "./NodeKVS-CRVYjcYN.mjs";
import { t as m } from "./useNode-lPs0rKwe.mjs";
import { computed as _, createBlock as c, createVNode as f, defineComponent as $, guardReactiveProps as g, normalizeProps as h, openBlock as N, unref as l, withCtx as b } from "vue";
var I = /* @__PURE__ */ $({
  __name: "ImageGenerateNode",
  props: {
    node: {
      type: Object,
      required: !0
    },
    graph: {
      type: Object,
      required: !0
    }
  },
  setup(p) {
    const { $properties: o, getInputParamKVItem: u, getOutputParamKVItem: i } = m(p), n = _(() => {
      var e, t, r, a;
      return [
        u({
          label: "输入变量",
          emptyAction: "hidden"
        }),
        {
          label: "模型",
          value: (e = o.value) === null || e === void 0 || (e = e.options) === null || e === void 0 ? void 0 : e.modelName,
          emptyAction: "tip",
          emptyTip: "尚未选择"
        },
        {
          label: "图片尺寸",
          value: !((t = o.value) === null || t === void 0 || (t = t.options) === null || t === void 0) && t.width && (!((r = o.value) === null || r === void 0 || (r = r.options) === null || r === void 0) && r.height) ? `${o.value.options.width} × ${o.value.options.height}` : ""
        },
        {
          label: "提示词",
          value: (a = o.value) === null || a === void 0 || (a = a.options) === null || a === void 0 ? void 0 : a.prompt
        },
        i({ label: "输出变量" })
      ];
    });
    return (e, t) => (N(), c(l(v), h(g(e.$props)), {
      default: b(() => [f(l(s), { kvs: n.value }, null, 8, ["kvs"])]),
      _: 1
    }, 16));
  }
}), w = /* @__PURE__ */ d({ default: () => y }), y = I;
export {
  w as n,
  y as t
};
