import { a as v } from "./objectSpread2-B0BetFB8.mjs";
import "./base-node-CKuyN1x8.mjs";
import { t as h } from "./NodeContainer-zpIyuhKY.mjs";
import { t as m } from "./useNode-lPs0rKwe.mjs";
import { Fragment as f, createBlock as N, createCommentVNode as g, createElementBlock as i, createElementVNode as n, defineComponent as y, mergeProps as L, nextTick as k, openBlock as t, renderList as w, toDisplayString as d, unref as r, watch as x, withCtx as $ } from "vue";
var S = {
  key: 0,
  class: "switch-node-content"
}, b = { class: "case-item" }, C = { class: "case-header" }, B = { class: "c-label" }, j = { class: "c-type" }, q = /* @__PURE__ */ y({
  __name: "SwitchNode",
  props: {
    node: {
      type: Object,
      required: !0
    },
    graph: {
      type: Object,
      required: !0
    }
  },
  setup(l) {
    const c = l, { $node: a, updateHeight: _, containerRef: u, containerProps: p } = m(c, { onUpdateNode(e) {
      e.caseList = c.node.$caseList;
    } });
    return x(() => {
      var e;
      return (e = a.value.caseList) === null || e === void 0 ? void 0 : e.length;
    }, () => k(() => _())), (e, O) => (t(), N(r(h), L({
      ref_key: "containerRef",
      ref: u
    }, r(p)), {
      default: $(() => {
        var o;
        return [!((o = r(a).caseList) === null || o === void 0) && o.length ? (t(), i("div", S, [(t(!0), i(f, null, w(r(a).caseList, (s) => (t(), i("div", b, [n("div", C, [n("div", B, d(s.remarks || s.label), 1), n("div", j, d(s.type), 1)])]))), 256))])) : g("", !0)];
      }),
      _: 1
    }, 16));
  }
}), F = /* @__PURE__ */ v({ default: () => E }), E = q;
export {
  F as n,
  E as t
};
