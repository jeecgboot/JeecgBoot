import { a as o } from "./objectSpread2-B0BetFB8.mjs";
import { t as r } from "./NodeIcon-Dt_fCcq_.mjs";
import { createBlock as e, openBlock as t } from "vue";
var l = /* @__PURE__ */ o({ default: () => a }), a = {
  __name: "ChatMemorySetIcon",
  setup(c) {
    return (_, m) => (t(), e(r, {
      icon: "mdi:head-plus",
      color: "#4165d7"
    }));
  }
};
export {
  a as n,
  l as t
};
