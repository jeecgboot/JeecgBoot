import { a as L } from "./objectSpread2-B0BetFB8.mjs";
import { t as R } from "./_plugin-vue_export-helper-Dj7HTbfw.mjs";
import { t as U } from "./VarTextarea-BzeLBgKt.mjs";
import { t as B } from "./VarEditable-BH81LKsU.mjs";
import { t as F } from "./VarListEditor-A0nqHeND.mjs";
import { t as G } from "./VarListPicker-CrG8EHn2.mjs";
import { t as J } from "./useSettings-Cq_-E7Ut.mjs";
import "./Vars-Cgan49KR.mjs";
import { InputNumber as M, Select as z, SelectOption as K, Space as Q } from "ant-design-vue/es";
import { computed as W, createBlock as X, createCommentVNode as Y, createElementBlock as Z, createElementVNode as s, createTextVNode as u, createVNode as l, defineComponent as $, isRef as d, openBlock as H, ref as N, unref as t, withCtx as o } from "vue";
var h = { class: "http-setting" }, c = { class: "setting-item" }, ee = { class: "setting-item" }, te = { class: "api-setting" }, le = { class: "method-select" }, ae = { class: "url-input" }, se = { class: "setting-item" }, re = { class: "setting-item" }, oe = { class: "setting-item" }, ne = { class: "setting-item" }, de = { class: "setting-item" }, ue = { class: "setting-item" }, ie = /* @__PURE__ */ $({
  __name: "HTTPSetting",
  props: {
    type: {
      type: String,
      required: !0
    },
    node: {
      type: Object,
      required: !0
    },
    properties: {
      type: Object,
      required: !0
    },
    isSilentMode: {
      type: Boolean,
      required: !0
    },
    setProperties: {
      type: Function,
      required: !0
    }
  },
  setup(j) {
    const { inputParams: m, inputVarsOptions: v, outputParams: f, prevVariables: k, createOptionRef: i, isReadOnly: n } = J(j), y = i("http.url"), b = i("http.method"), C = i("http.headers"), T = i("http.requestBody.body"), _ = i("http.requestBody.type"), D = i("http.requestParams"), g = i("http.timeout"), O = i("http.retriesTimes"), q = N([{
      field: "name",
      label: "参数名",
      type: "input",
      required: !0
    }, {
      field: "value",
      label: "参数值",
      type: "var-input",
      required: !0
    }]), P = w(C), x = w(D), A = N(!0);
    function w(V) {
      return W({
        get() {
          return Object.entries(t(V)).map(([e, r]) => ({
            name: e,
            value: r
          }));
        },
        set(e) {
          const r = {};
          e.forEach((p) => {
            r[p.name] = p.value;
          }), V.value = r;
        }
      });
    }
    const I = {
      body: { tip: "HTTP请求的返回结果" },
      statusCode: { tip: "HTTP请求的返回状态码" }
    };
    return (V, e) => {
      const r = K, p = z, E = M, S = Q;
      return H(), Z("div", h, [
        s("div", c, [e[10] || (e[10] = s("div", { class: "label" }, "输入变量", -1)), l(t(G), {
          vars: t(m),
          "onUpdate:vars": e[0] || (e[0] = (a) => d(m) ? m.value = a : null),
          prevVariables: t(k),
          readonly: t(n)
        }, null, 8, [
          "vars",
          "prevVariables",
          "readonly"
        ])]),
        s("div", ee, [e[15] || (e[15] = s("div", { class: "label" }, "API", -1)), s("div", te, [s("div", le, [l(p, {
          value: t(b),
          "onUpdate:value": e[1] || (e[1] = (a) => d(b) ? b.value = a : null),
          style: { width: "120px" },
          disabled: t(n)
        }, {
          default: o(() => [
            l(r, { value: "GET" }, {
              default: o(() => [...e[11] || (e[11] = [u("GET", -1)])]),
              _: 1
            }),
            l(r, { value: "POST" }, {
              default: o(() => [...e[12] || (e[12] = [u("POST", -1)])]),
              _: 1
            }),
            l(r, { value: "PUT" }, {
              default: o(() => [...e[13] || (e[13] = [u("PUT", -1)])]),
              _: 1
            }),
            l(r, { value: "DELETE" }, {
              default: o(() => [...e[14] || (e[14] = [u("DELETE", -1)])]),
              _: 1
            })
          ]),
          _: 1
        }, 8, ["value", "disabled"])]), s("div", ae, [l(t(U), {
          class: "input-element",
          type: "input",
          value: t(y),
          "onUpdate:value": e[2] || (e[2] = (a) => d(y) ? y.value = a : null),
          varsOptions: t(v),
          readonly: t(n),
          placeholder: "请输入API地址。按下 “/” 可以选择变量"
        }, null, 8, [
          "value",
          "varsOptions",
          "readonly"
        ])])])]),
        s("div", se, [e[16] || (e[16] = s("div", { class: "label" }, "请求参数", -1)), l(t(B), {
          columns: q.value,
          data: t(x),
          "onUpdate:data": e[3] || (e[3] = (a) => d(x) ? x.value = a : null),
          varsOptions: t(v),
          readonly: t(n)
        }, null, 8, [
          "columns",
          "data",
          "varsOptions",
          "readonly"
        ])]),
        s("div", re, [e[17] || (e[17] = s("div", { class: "label" }, "请求头", -1)), A.value ? (H(), X(t(B), {
          key: 0,
          columns: q.value,
          data: t(P),
          "onUpdate:data": e[4] || (e[4] = (a) => d(P) ? P.value = a : null),
          varsOptions: t(v),
          readonly: t(n)
        }, null, 8, [
          "columns",
          "data",
          "varsOptions",
          "readonly"
        ])) : Y("", !0)]),
        s("div", oe, [
          e[23] || (e[23] = s("div", { class: "label" }, "请求体", -1)),
          l(p, {
            value: t(_),
            "onUpdate:value": e[5] || (e[5] = (a) => d(_) ? _.value = a : null),
            style: {
              width: "100%",
              "margin-bottom": "8px"
            },
            disabled: t(n)
          }, {
            default: o(() => [
              l(r, { value: "none" }, {
                default: o(() => [...e[18] || (e[18] = [u("none", -1)])]),
                _: 1
              }),
              l(r, { value: "json" }, {
                default: o(() => [...e[19] || (e[19] = [u("JSON", -1)])]),
                _: 1
              }),
              l(r, { value: "form-data" }, {
                default: o(() => [...e[20] || (e[20] = [u("form-data", -1)])]),
                _: 1
              }),
              l(r, { value: "x-www-form-urlencoded" }, {
                default: o(() => [...e[21] || (e[21] = [u("x-www-form-urlencoded", -1)])]),
                _: 1
              }),
              l(r, { value: "raw" }, {
                default: o(() => [...e[22] || (e[22] = [u("raw", -1)])]),
                _: 1
              })
            ]),
            _: 1
          }, 8, ["value", "disabled"]),
          l(t(U), {
            value: t(T),
            "onUpdate:value": e[6] || (e[6] = (a) => d(T) ? T.value = a : null),
            varsOptions: t(v),
            height: 120,
            readonly: t(n),
            placeholder: "请输入请求体。按下 “/” 可以选择变量"
          }, null, 8, [
            "value",
            "varsOptions",
            "readonly"
          ])
        ]),
        s("div", ne, [e[24] || (e[24] = s("div", { class: "label" }, "超时时间", -1)), l(S, { class: "setting-item-timeout" }, {
          default: o(() => [l(E, {
            value: t(g),
            "onUpdate:value": e[7] || (e[7] = (a) => d(g) ? g.value = a : null),
            min: 0,
            placeholder: "请输入超时时间",
            addonAfter: "秒",
            disabled: t(n)
          }, null, 8, ["value", "disabled"])]),
          _: 1
        })]),
        s("div", de, [e[25] || (e[25] = s("div", { class: "label" }, "重试次数", -1)), l(S, { class: "setting-item-timeout" }, {
          default: o(() => [l(E, {
            value: t(O),
            "onUpdate:value": e[8] || (e[8] = (a) => d(O) ? O.value = a : null),
            min: 0,
            placeholder: "请输入重试次数",
            disabled: t(n)
          }, null, 8, ["value", "disabled"])]),
          _: 1
        })]),
        s("div", ue, [e[26] || (e[26] = s("div", { class: "label" }, "输出变量", -1)), l(t(F), {
          vars: t(f),
          "onUpdate:vars": e[9] || (e[9] = (a) => d(f) ? f.value = a : null),
          fixedVars: I,
          fieldBeforeText: "body.",
          readonly: t(n)
        }, null, 8, ["vars", "readonly"])])
      ]);
    };
  }
}), Ve = /* @__PURE__ */ L({ default: () => pe }), pe = /* @__PURE__ */ R(ie, [["__scopeId", "data-v-f1f66ab3"]]);
export {
  Ve as n,
  pe as t
};
