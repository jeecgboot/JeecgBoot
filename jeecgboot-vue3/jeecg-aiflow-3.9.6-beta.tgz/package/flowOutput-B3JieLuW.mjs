function c(t, e) {
  return !t || !e || typeof t != "object" || typeof e != "object" ? [] : [...new Set(Object.entries(t).filter(([, n]) => typeof n == "string" && n.toLowerCase() === "image").flatMap(([n]) => l(e[n])))];
}
function p(t = {}) {
  const e = typeof t.outputs == "string" ? t.outputs : typeof t.content == "string" ? t.content : "";
  if (!e) return [];
  const n = c(t.outputTypes, t.outputValues);
  if (!n.length) return [{
    type: "text",
    value: e
  }];
  const o = [];
  let i = 0;
  for (; i < e.length; ) {
    let s = "", r = -1;
    for (const f of n) {
      const u = e.indexOf(f, i);
      u >= 0 && (r < 0 || u < r) && (s = f, r = u);
    }
    if (r < 0) {
      o.push({
        type: "text",
        value: e.slice(i)
      });
      break;
    }
    r > i && o.push({
      type: "text",
      value: e.slice(i, r)
    }), o.push({
      type: "image",
      value: s
    }), i = r + s.length;
  }
  return o;
}
function l(t) {
  return Array.isArray(t) ? t.flatMap(l) : typeof t == "string" && t.trim() ? [t.trim()] : [];
}
export {
  c as n,
  p as t
};
