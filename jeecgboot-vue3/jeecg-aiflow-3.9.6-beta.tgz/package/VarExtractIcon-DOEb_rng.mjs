import { a as r } from "./objectSpread2-B0BetFB8.mjs";
import { t as o } from "./NodeIcon-Dt_fCcq_.mjs";
import { createBlock as a, openBlock as t } from "vue";
var s = /* @__PURE__ */ r({ default: () => c }), c = {
  __name: "VarExtractIcon",
  setup(e) {
    return (_, n) => (t(), a(o, {
      icon: "mdi:variable",
      color: "#12c499"
    }));
  }
};
export {
  c as n,
  s as t
};
