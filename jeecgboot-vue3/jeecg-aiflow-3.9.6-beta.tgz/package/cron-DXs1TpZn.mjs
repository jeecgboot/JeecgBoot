import { i as cn, n as fi, r as ge, s as fn, t as D } from "./objectSpread2-B0BetFB8.mjs";
import { t as di } from "./dayjs.min-DQ4QC875.mjs";
function hi(m, T) {
  if (m == null) return {};
  var h = {};
  for (var l in m) if ({}.hasOwnProperty.call(m, l)) {
    if (T.includes(l)) continue;
    h[l] = m[l];
  }
  return h;
}
var mi = cn((() => {
}));
function un(m, T) {
  if (m == null) return {};
  var h, l, d = hi(m, T);
  if (Object.getOwnPropertySymbols) {
    var c = Object.getOwnPropertySymbols(m);
    for (l = 0; l < c.length; l++) h = c[l], T.includes(h) || {}.propertyIsEnumerable.call(m, h) && (d[h] = m[h]);
  }
  return d;
}
var yi = cn((() => {
  mi();
})), vi = /* @__PURE__ */ ge(((m) => {
  yi(), fi();
  var T = ["base"], h = ["padTo", "floor"];
  Object.defineProperty(m, "__esModule", { value: !0 });
  var l = class extends Error {
  }, d = class extends l {
    constructor(t) {
      super(`Invalid DateTime: ${t.toMessage()}`);
    }
  }, c = class extends l {
    constructor(t) {
      super(`Invalid Interval: ${t.toMessage()}`);
    }
  }, v = class extends l {
    constructor(t) {
      super(`Invalid Duration: ${t.toMessage()}`);
    }
  }, y = class extends l {
  }, p = class extends l {
    constructor(t) {
      super(`Invalid unit ${t}`);
    }
  }, w = class extends l {
  }, S = class extends l {
    constructor() {
      super("Zone is an abstract class");
    }
  }, f = "numeric", k = "short", O = "long", E = {
    year: f,
    month: f,
    day: f
  }, U = {
    year: f,
    month: k,
    day: f
  }, N = {
    year: f,
    month: k,
    day: f,
    weekday: k
  }, W = {
    year: f,
    month: O,
    day: f
  }, b = {
    year: f,
    month: O,
    day: f,
    weekday: O
  }, L = {
    hour: f,
    minute: f
  }, V = {
    hour: f,
    minute: f,
    second: f
  }, H = {
    hour: f,
    minute: f,
    second: f,
    timeZoneName: k
  }, P = {
    hour: f,
    minute: f,
    second: f,
    timeZoneName: O
  }, Z = {
    hour: f,
    minute: f,
    hourCycle: "h23"
  }, C = {
    hour: f,
    minute: f,
    second: f,
    hourCycle: "h23"
  }, j = {
    hour: f,
    minute: f,
    second: f,
    hourCycle: "h23",
    timeZoneName: k
  }, re = {
    hour: f,
    minute: f,
    second: f,
    hourCycle: "h23",
    timeZoneName: O
  }, zt = {
    year: f,
    month: f,
    day: f,
    hour: f,
    minute: f
  }, Ut = {
    year: f,
    month: f,
    day: f,
    hour: f,
    minute: f,
    second: f
  }, qt = {
    year: f,
    month: k,
    day: f,
    hour: f,
    minute: f
  }, Ht = {
    year: f,
    month: k,
    day: f,
    hour: f,
    minute: f,
    second: f
  }, mn = {
    year: f,
    month: k,
    day: f,
    weekday: k,
    hour: f,
    minute: f
  }, Rt = {
    year: f,
    month: O,
    day: f,
    hour: f,
    minute: f,
    timeZoneName: k
  }, Yt = {
    year: f,
    month: O,
    day: f,
    hour: f,
    minute: f,
    second: f,
    timeZoneName: k
  }, Pt = {
    year: f,
    month: O,
    day: f,
    weekday: O,
    hour: f,
    minute: f,
    timeZoneName: O
  }, Gt = {
    year: f,
    month: O,
    day: f,
    weekday: O,
    hour: f,
    minute: f,
    second: f,
    timeZoneName: O
  }, we = class {
    get type() {
      throw new S();
    }
    get name() {
      throw new S();
    }
    get ianaName() {
      return this.name;
    }
    get isUniversal() {
      throw new S();
    }
    offsetName(t, e) {
      throw new S();
    }
    formatOffset(t, e) {
      throw new S();
    }
    offset(t) {
      throw new S();
    }
    equals(t) {
      throw new S();
    }
    get isValid() {
      throw new S();
    }
  }, ct = null, ft = class dn extends we {
    static get instance() {
      return ct === null && (ct = new dn()), ct;
    }
    get type() {
      return "system";
    }
    get name() {
      return new Intl.DateTimeFormat().resolvedOptions().timeZone;
    }
    get isUniversal() {
      return !1;
    }
    offsetName(e, { format: r, locale: n }) {
      return Tr(e, r, n);
    }
    formatOffset(e, r) {
      return We(this.offset(e), r);
    }
    offset(e) {
      return -new Date(e).getTimezoneOffset();
    }
    equals(e) {
      return e.type === "system";
    }
    get isValid() {
      return !0;
    }
  }, dt = /* @__PURE__ */ new Map();
  function yn(t) {
    let e = dt.get(t);
    return e === void 0 && (e = new Intl.DateTimeFormat("en-US", {
      hour12: !1,
      timeZone: t,
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
      era: "short"
    }), dt.set(t, e)), e;
  }
  var vn = {
    year: 0,
    month: 1,
    day: 2,
    era: 3,
    hour: 4,
    minute: 5,
    second: 6
  };
  function pn(t, e) {
    const r = t.format(e).replace(/\u200E/g, ""), [, n, s, i, a, o, u, g] = /(\d+)\/(\d+)\/(\d+) (AD|BC),? (\d+):(\d+):(\d+)/.exec(r);
    return [
      i,
      n,
      s,
      a,
      o,
      u,
      g
    ];
  }
  function gn(t, e) {
    const r = t.formatToParts(e), n = [];
    for (let s = 0; s < r.length; s++) {
      const { type: i, value: a } = r[s], o = vn[i];
      i === "era" ? n[o] = a : M(o) || (n[o] = parseInt(a, 10));
    }
    return n;
  }
  var ht = /* @__PURE__ */ new Map(), me = class At extends we {
    static create(e) {
      let r = ht.get(e);
      return r === void 0 && ht.set(e, r = new At(e)), r;
    }
    static resetCache() {
      ht.clear(), dt.clear();
    }
    static isValidSpecifier(e) {
      return this.isValidZone(e);
    }
    static isValidZone(e) {
      if (!e) return !1;
      try {
        return new Intl.DateTimeFormat("en-US", { timeZone: e }).format(), !0;
      } catch (r) {
        return !1;
      }
    }
    constructor(e) {
      super(), this.zoneName = e, this.valid = At.isValidZone(e);
    }
    get type() {
      return "iana";
    }
    get name() {
      return this.zoneName;
    }
    get isUniversal() {
      return !1;
    }
    offsetName(e, { format: r, locale: n }) {
      return Tr(e, r, n, this.name);
    }
    formatOffset(e, r) {
      return We(this.offset(e), r);
    }
    offset(e) {
      if (!this.valid) return NaN;
      const r = new Date(e);
      if (isNaN(r)) return NaN;
      const n = yn(this.name);
      let [s, i, a, o, u, g, _] = n.formatToParts ? gn(n, r) : pn(n, r);
      o === "BC" && (s = -Math.abs(s) + 1);
      const x = Xe({
        year: s,
        month: i,
        day: a,
        hour: u === 24 ? 0 : u,
        minute: g,
        second: _,
        millisecond: 0
      });
      let $ = +r;
      const I = $ % 1e3;
      return $ -= I >= 0 ? I : 1e3 + I, (x - $) / 6e4;
    }
    equals(e) {
      return e.type === "iana" && e.name === this.name;
    }
    get isValid() {
      return this.valid;
    }
  }, Jt = {};
  function wn(t, e = {}) {
    const r = JSON.stringify([t, e]);
    let n = Jt[r];
    return n || (n = new Intl.ListFormat(t, e), Jt[r] = n), n;
  }
  var mt = /* @__PURE__ */ new Map();
  function yt(t, e = {}) {
    const r = JSON.stringify([t, e]);
    let n = mt.get(r);
    return n === void 0 && (n = new Intl.DateTimeFormat(t, e), mt.set(r, n)), n;
  }
  var vt = /* @__PURE__ */ new Map();
  function Tn(t, e = {}) {
    const r = JSON.stringify([t, e]);
    let n = vt.get(r);
    return n === void 0 && (n = new Intl.NumberFormat(t, e), vt.set(r, n)), n;
  }
  var pt = /* @__PURE__ */ new Map();
  function kn(t, e = {}) {
    const { base: r } = e, n = un(e, T), s = JSON.stringify([t, n]);
    let i = pt.get(s);
    return i === void 0 && (i = new Intl.RelativeTimeFormat(t, e), pt.set(s, i)), i;
  }
  var Ce = null;
  function Sn() {
    return Ce || (Ce = new Intl.DateTimeFormat().resolvedOptions().locale, Ce);
  }
  var gt = /* @__PURE__ */ new Map();
  function jt(t) {
    let e = gt.get(t);
    return e === void 0 && (e = new Intl.DateTimeFormat(t).resolvedOptions(), gt.set(t, e)), e;
  }
  var wt = /* @__PURE__ */ new Map();
  function On(t) {
    let e = wt.get(t);
    if (!e) {
      const r = new Intl.Locale(t);
      e = "getWeekInfo" in r ? r.getWeekInfo() : r.weekInfo, "minimalDays" in e || (e = D(D({}, Bt), e)), wt.set(t, e);
    }
    return e;
  }
  function Dn(t) {
    const e = t.indexOf("-x-");
    e !== -1 && (t = t.substring(0, e));
    const r = t.indexOf("-u-");
    if (r === -1) return [t];
    {
      let n, s;
      try {
        n = yt(t).resolvedOptions(), s = t;
      } catch (o) {
        const u = t.substring(0, r);
        n = yt(u).resolvedOptions(), s = u;
      }
      const { numberingSystem: i, calendar: a } = n;
      return [
        s,
        i,
        a
      ];
    }
  }
  function Mn(t, e, r) {
    return (r || e) && (t.includes("-u-") || (t += "-u"), r && (t += `-ca-${r}`), e && (t += `-nu-${e}`)), t;
  }
  function Nn(t) {
    const e = [];
    for (let r = 1; r <= 12; r++) {
      const n = Y.utc(2009, r, 1);
      e.push(t(n));
    }
    return e;
  }
  function In(t) {
    const e = [];
    for (let r = 1; r <= 7; r++) {
      const n = Y.utc(2016, 11, 13 + r);
      e.push(t(n));
    }
    return e;
  }
  function je(t, e, r, n) {
    const s = t.listingMode();
    return s === "error" ? null : s === "en" ? r(e) : n(e);
  }
  function En(t) {
    return t.numberingSystem && t.numberingSystem !== "latn" ? !1 : t.numberingSystem === "latn" || !t.locale || t.locale.startsWith("en") || jt(t.locale).numberingSystem === "latn";
  }
  var _n = class {
    constructor(t, e, r) {
      this.padTo = r.padTo || 0, this.floor = r.floor || !1;
      const { padTo: n, floor: s } = r, i = un(r, h);
      if (!e || Object.keys(i).length > 0) {
        const a = D({ useGrouping: !1 }, r);
        r.padTo > 0 && (a.minimumIntegerDigits = r.padTo), this.inf = Tn(t, a);
      }
    }
    format(t) {
      if (this.inf) {
        const e = this.floor ? Math.floor(t) : t;
        return this.inf.format(e);
      } else return G(this.floor ? Math.floor(t) : Et(t, 3), this.padTo);
    }
  }, xn = class {
    constructor(t, e, r) {
      this.opts = r, this.originalZone = void 0;
      let n;
      if (this.opts.timeZone) this.dt = t;
      else if (t.zone.type === "fixed") {
        const i = -1 * (t.offset / 60), a = i >= 0 ? `Etc/GMT+${i}` : `Etc/GMT${i}`;
        t.offset !== 0 && me.create(a).valid ? (n = a, this.dt = t) : (n = "UTC", this.dt = t.offset === 0 ? t : t.setZone("UTC").plus({ minutes: t.offset }), this.originalZone = t.zone);
      } else t.zone.type === "system" ? this.dt = t : t.zone.type === "iana" ? (this.dt = t, n = t.zone.name) : (n = "UTC", this.dt = t.setZone("UTC").plus({ minutes: t.offset }), this.originalZone = t.zone);
      const s = D({}, this.opts);
      s.timeZone = s.timeZone || n, this.dtf = yt(e, s);
    }
    format() {
      return this.originalZone ? this.formatToParts().map(({ value: t }) => t).join("") : this.dtf.format(this.dt.toJSDate());
    }
    formatToParts() {
      const t = this.dtf.formatToParts(this.dt.toJSDate());
      return this.originalZone ? t.map((e) => {
        if (e.type === "timeZoneName") {
          const r = this.originalZone.offsetName(this.dt.ts, {
            locale: this.dt.locale,
            format: this.opts.timeZoneName
          });
          return D(D({}, e), {}, { value: r });
        } else return e;
      }) : t;
    }
    resolvedOptions() {
      return this.dtf.resolvedOptions();
    }
  }, bn = class {
    constructor(t, e, r) {
      this.opts = D({ style: "long" }, r), !e && vr() && (this.rtf = kn(t, r));
    }
    format(t, e) {
      return this.rtf ? this.rtf.format(t, e) : Kn(e, t, this.opts.numeric, this.opts.style !== "long");
    }
    formatToParts(t, e) {
      return this.rtf ? this.rtf.formatToParts(t, e) : [];
    }
  }, Bt = {
    firstDay: 1,
    minimalDays: 4,
    weekend: [6, 7]
  }, A = class Pe {
    static fromOpts(e) {
      return Pe.create(e.locale, e.numberingSystem, e.outputCalendar, e.weekSettings, e.defaultToEN);
    }
    static create(e, r, n, s, i = !1) {
      const a = e || R.defaultLocale, o = a || (i ? "en-US" : Sn()), u = r || R.defaultNumberingSystem, g = n || R.defaultOutputCalendar, _ = Nt(s) || R.defaultWeekSettings;
      return new Pe(o, u, g, _, a);
    }
    static resetCache() {
      Ce = null, mt.clear(), vt.clear(), pt.clear(), gt.clear(), wt.clear();
    }
    static fromObject({ locale: e, numberingSystem: r, outputCalendar: n, weekSettings: s } = {}) {
      return Pe.create(e, r, n, s);
    }
    constructor(e, r, n, s, i) {
      const [a, o, u] = Dn(e);
      this.locale = a, this.numberingSystem = r || o || null, this.outputCalendar = n || u || null, this.weekSettings = s, this.intl = Mn(this.locale, this.numberingSystem, this.outputCalendar), this.weekdaysCache = {
        format: {},
        standalone: {}
      }, this.monthsCache = {
        format: {},
        standalone: {}
      }, this.meridiemCache = null, this.eraCache = {}, this.specifiedLocale = i, this.fastNumbersCached = null;
    }
    get fastNumbers() {
      return this.fastNumbersCached == null && (this.fastNumbersCached = En(this)), this.fastNumbersCached;
    }
    listingMode() {
      const e = this.isEnglish(), r = (this.numberingSystem === null || this.numberingSystem === "latn") && (this.outputCalendar === null || this.outputCalendar === "gregory");
      return e && r ? "en" : "intl";
    }
    clone(e) {
      return !e || Object.getOwnPropertyNames(e).length === 0 ? this : Pe.create(e.locale || this.specifiedLocale, e.numberingSystem || this.numberingSystem, e.outputCalendar || this.outputCalendar, Nt(e.weekSettings) || this.weekSettings, e.defaultToEN || !1);
    }
    redefaultToEN(e = {}) {
      return this.clone(D(D({}, e), {}, { defaultToEN: !0 }));
    }
    redefaultToSystem(e = {}) {
      return this.clone(D(D({}, e), {}, { defaultToEN: !1 }));
    }
    months(e, r = !1) {
      return je(this, e, Or, () => {
        const n = this.intl === "ja" || this.intl.startsWith("ja-");
        r &= !n;
        const s = r ? {
          month: e,
          day: "numeric"
        } : { month: e }, i = r ? "format" : "standalone";
        if (!this.monthsCache[i][e]) {
          const a = n ? (o) => this.dtFormatter(o, s).format() : (o) => this.extract(o, s, "month");
          this.monthsCache[i][e] = Nn(a);
        }
        return this.monthsCache[i][e];
      });
    }
    weekdays(e, r = !1) {
      return je(this, e, Nr, () => {
        const n = r ? {
          weekday: e,
          year: "numeric",
          month: "long",
          day: "numeric"
        } : { weekday: e }, s = r ? "format" : "standalone";
        return this.weekdaysCache[s][e] || (this.weekdaysCache[s][e] = In((i) => this.extract(i, n, "weekday"))), this.weekdaysCache[s][e];
      });
    }
    meridiems() {
      return je(this, void 0, () => Ir, () => {
        if (!this.meridiemCache) {
          const e = {
            hour: "numeric",
            hourCycle: "h12"
          };
          this.meridiemCache = [Y.utc(2016, 11, 13, 9), Y.utc(2016, 11, 13, 19)].map((r) => this.extract(r, e, "dayperiod"));
        }
        return this.meridiemCache;
      });
    }
    eras(e) {
      return je(this, e, Er, () => {
        const r = { era: e };
        return this.eraCache[e] || (this.eraCache[e] = [Y.utc(-40, 1, 1), Y.utc(2017, 1, 1)].map((n) => this.extract(n, r, "era"))), this.eraCache[e];
      });
    }
    extract(e, r, n) {
      const s = this.dtFormatter(e, r).formatToParts().find((i) => i.type.toLowerCase() === n);
      return s ? s.value : null;
    }
    numberFormatter(e = {}) {
      return new _n(this.intl, e.forceSimple || this.fastNumbers, e);
    }
    dtFormatter(e, r = {}) {
      return new xn(e, this.intl, r);
    }
    relFormatter(e = {}) {
      return new bn(this.intl, this.isEnglish(), e);
    }
    listFormatter(e = {}) {
      return wn(this.intl, e);
    }
    isEnglish() {
      return this.locale === "en" || this.locale.toLowerCase() === "en-us" || jt(this.intl).locale.startsWith("en-us");
    }
    getWeekSettings() {
      return this.weekSettings ? this.weekSettings : pr() ? On(this.locale) : Bt;
    }
    getStartOfWeek() {
      return this.getWeekSettings().firstDay;
    }
    getMinDaysInFirstWeek() {
      return this.getWeekSettings().minimalDays;
    }
    getWeekendDays() {
      return this.getWeekSettings().weekend;
    }
    equals(e) {
      return this.locale === e.locale && this.numberingSystem === e.numberingSystem && this.outputCalendar === e.outputCalendar;
    }
    toString() {
      return `Locale(${this.locale}, ${this.numberingSystem}, ${this.outputCalendar})`;
    }
  }, Tt = null, ne = class Ge extends we {
    static get utcInstance() {
      return Tt === null && (Tt = new Ge(0)), Tt;
    }
    static instance(e) {
      return e === 0 ? Ge.utcInstance : new Ge(e);
    }
    static parseSpecifier(e) {
      if (e) {
        const r = e.match(/^utc(?:([+-]\d{1,2})(?::(\d{2}))?)?$/i);
        if (r) return new Ge(et(r[1], r[2]));
      }
      return null;
    }
    constructor(e) {
      super(), this.fixed = e;
    }
    get type() {
      return "fixed";
    }
    get name() {
      return this.fixed === 0 ? "UTC" : `UTC${We(this.fixed, "narrow")}`;
    }
    get ianaName() {
      return this.fixed === 0 ? "Etc/UTC" : `Etc/GMT${We(-this.fixed, "narrow")}`;
    }
    offsetName() {
      return this.name;
    }
    formatOffset(e, r) {
      return We(this.fixed, r);
    }
    get isUniversal() {
      return !0;
    }
    offset() {
      return this.fixed;
    }
    equals(e) {
      return e.type === "fixed" && e.fixed === this.fixed;
    }
    get isValid() {
      return !0;
    }
  }, Qt = class extends we {
    constructor(t) {
      super(), this.zoneName = t;
    }
    get type() {
      return "invalid";
    }
    get name() {
      return this.zoneName;
    }
    get isUniversal() {
      return !1;
    }
    offsetName() {
      return null;
    }
    formatOffset() {
      return "";
    }
    offset() {
      return NaN;
    }
    equals() {
      return !1;
    }
    get isValid() {
      return !1;
    }
  };
  function fe(t, e) {
    if (M(t) || t === null) return e;
    if (t instanceof we) return t;
    if ($n(t)) {
      const r = t.toLowerCase();
      return r === "default" ? e : r === "local" || r === "system" ? ft.instance : r === "utc" || r === "gmt" ? ne.utcInstance : ne.parseSpecifier(r) || me.create(t);
    } else return de(t) ? ne.instance(t) : typeof t == "object" && "offset" in t && typeof t.offset == "function" ? t : new Qt(t);
  }
  var kt = {
    arab: "[٠-٩]",
    arabext: "[۰-۹]",
    bali: "[᭐-᭙]",
    beng: "[০-৯]",
    deva: "[०-९]",
    fullwide: "[０-９]",
    gujr: "[૦-૯]",
    hanidec: "[〇|一|二|三|四|五|六|七|八|九]",
    khmr: "[០-៩]",
    knda: "[೦-೯]",
    laoo: "[໐-໙]",
    limb: "[᥆-᥏]",
    mlym: "[൦-൯]",
    mong: "[᠐-᠙]",
    mymr: "[၀-၉]",
    orya: "[୦-୯]",
    tamldec: "[௦-௯]",
    telu: "[౦-౯]",
    thai: "[๐-๙]",
    tibt: "[༠-༩]",
    latn: "\\d"
  }, Kt = {
    arab: [1632, 1641],
    arabext: [1776, 1785],
    bali: [6992, 7001],
    beng: [2534, 2543],
    deva: [2406, 2415],
    fullwide: [65296, 65303],
    gujr: [2790, 2799],
    khmr: [6112, 6121],
    knda: [3302, 3311],
    laoo: [3792, 3801],
    limb: [6470, 6479],
    mlym: [3430, 3439],
    mong: [6160, 6169],
    mymr: [4160, 4169],
    orya: [2918, 2927],
    tamldec: [3046, 3055],
    telu: [3174, 3183],
    thai: [3664, 3673],
    tibt: [3872, 3881]
  }, Cn = kt.hanidec.replace(/[\[|\]]/g, "").split("");
  function Fn(t) {
    let e = parseInt(t, 10);
    if (isNaN(e)) {
      e = "";
      for (let r = 0; r < t.length; r++) {
        const n = t.charCodeAt(r);
        if (t[r].search(kt.hanidec) !== -1) e += Cn.indexOf(t[r]);
        else for (const s in Kt) {
          const [i, a] = Kt[s];
          n >= i && n <= a && (e += n - i);
        }
      }
      return parseInt(e, 10);
    } else return e;
  }
  var St = /* @__PURE__ */ new Map();
  function Vn() {
    St.clear();
  }
  function se({ numberingSystem: t }, e = "") {
    const r = t || "latn";
    let n = St.get(r);
    n === void 0 && (n = /* @__PURE__ */ new Map(), St.set(r, n));
    let s = n.get(e);
    return s === void 0 && (s = new RegExp(`${kt[r]}${e}`), n.set(e, s)), s;
  }
  var Xt = () => Date.now(), er = "system", tr = null, rr = null, nr = null, sr = 60, ir, ar = null, R = class {
    static get now() {
      return Xt;
    }
    static set now(t) {
      Xt = t;
    }
    static set defaultZone(t) {
      er = t;
    }
    static get defaultZone() {
      return fe(er, ft.instance);
    }
    static get defaultLocale() {
      return tr;
    }
    static set defaultLocale(t) {
      tr = t;
    }
    static get defaultNumberingSystem() {
      return rr;
    }
    static set defaultNumberingSystem(t) {
      rr = t;
    }
    static get defaultOutputCalendar() {
      return nr;
    }
    static set defaultOutputCalendar(t) {
      nr = t;
    }
    static get defaultWeekSettings() {
      return ar;
    }
    static set defaultWeekSettings(t) {
      ar = Nt(t);
    }
    static get twoDigitCutoffYear() {
      return sr;
    }
    static set twoDigitCutoffYear(t) {
      sr = t % 100;
    }
    static get throwOnInvalid() {
      return ir;
    }
    static set throwOnInvalid(t) {
      ir = t;
    }
    static resetCaches() {
      A.resetCache(), me.resetCache(), Y.resetCache(), Vn();
    }
  }, ie = class {
    constructor(t, e) {
      this.reason = t, this.explanation = e;
    }
    toMessage() {
      return this.explanation ? `${this.reason}: ${this.explanation}` : this.reason;
    }
  }, or = [
    0,
    31,
    59,
    90,
    120,
    151,
    181,
    212,
    243,
    273,
    304,
    334
  ], ur = [
    0,
    31,
    60,
    91,
    121,
    152,
    182,
    213,
    244,
    274,
    305,
    335
  ];
  function X(t, e) {
    return new ie("unit out of range", `you specified ${e} (of type ${typeof e}) as a ${t}, which is invalid`);
  }
  function Ot(t, e, r) {
    const n = new Date(Date.UTC(t, e - 1, r));
    t < 100 && t >= 0 && n.setUTCFullYear(n.getUTCFullYear() - 1900);
    const s = n.getUTCDay();
    return s === 0 ? 7 : s;
  }
  function lr(t, e, r) {
    return r + (Fe(t) ? ur : or)[e - 1];
  }
  function cr(t, e) {
    const r = Fe(t) ? ur : or, n = r.findIndex((i) => i < e), s = e - r[n];
    return {
      month: n + 1,
      day: s
    };
  }
  function Dt(t, e) {
    return (t - e + 7) % 7 + 1;
  }
  function Be(t, e = 4, r = 1) {
    const { year: n, month: s, day: i } = t, a = lr(n, s, i), o = Dt(Ot(n, s, i), r);
    let u = Math.floor((a - o + 14 - e) / 7), g;
    return u < 1 ? (g = n - 1, u = Ve(g, e, r)) : u > Ve(n, e, r) ? (g = n + 1, u = 1) : g = n, D({
      weekYear: g,
      weekNumber: u,
      weekday: o
    }, rt(t));
  }
  function fr(t, e = 4, r = 1) {
    const { weekYear: n, weekNumber: s, weekday: i } = t, a = Dt(Ot(n, 1, e), r), o = ke(n);
    let u = s * 7 + i - a - 7 + e, g;
    u < 1 ? (g = n - 1, u += ke(g)) : u > o ? (g = n + 1, u -= ke(n)) : g = n;
    const { month: _, day: x } = cr(g, u);
    return D({
      year: g,
      month: _,
      day: x
    }, rt(t));
  }
  function Mt(t) {
    const { year: e, month: r, day: n } = t, s = lr(e, r, n);
    return D({
      year: e,
      ordinal: s
    }, rt(t));
  }
  function dr(t) {
    const { year: e, ordinal: r } = t, { month: n, day: s } = cr(e, r);
    return D({
      year: e,
      month: n,
      day: s
    }, rt(t));
  }
  function hr(t, e) {
    if (!M(t.localWeekday) || !M(t.localWeekNumber) || !M(t.localWeekYear)) {
      if (!M(t.weekday) || !M(t.weekNumber) || !M(t.weekYear)) throw new y("Cannot mix locale-based week fields with ISO-based week fields");
      return M(t.localWeekday) || (t.weekday = t.localWeekday), M(t.localWeekNumber) || (t.weekNumber = t.localWeekNumber), M(t.localWeekYear) || (t.weekYear = t.localWeekYear), delete t.localWeekday, delete t.localWeekNumber, delete t.localWeekYear, {
        minDaysInFirstWeek: e.getMinDaysInFirstWeek(),
        startOfWeek: e.getStartOfWeek()
      };
    } else return {
      minDaysInFirstWeek: 4,
      startOfWeek: 1
    };
  }
  function Wn(t, e = 4, r = 1) {
    const n = Qe(t.weekYear), s = ee(t.weekNumber, 1, Ve(t.weekYear, e, r)), i = ee(t.weekday, 1, 7);
    return n ? s ? i ? !1 : X("weekday", t.weekday) : X("week", t.weekNumber) : X("weekYear", t.weekYear);
  }
  function Ln(t) {
    const e = Qe(t.year), r = ee(t.ordinal, 1, ke(t.year));
    return e ? r ? !1 : X("ordinal", t.ordinal) : X("year", t.year);
  }
  function mr(t) {
    const e = Qe(t.year), r = ee(t.month, 1, 12), n = ee(t.day, 1, Ke(t.year, t.month));
    return e ? r ? n ? !1 : X("day", t.day) : X("month", t.month) : X("year", t.year);
  }
  function yr(t) {
    const { hour: e, minute: r, second: n, millisecond: s } = t, i = ee(e, 0, 23) || e === 24 && r === 0 && n === 0 && s === 0, a = ee(r, 0, 59), o = ee(n, 0, 59), u = ee(s, 0, 999);
    return i ? a ? o ? u ? !1 : X("millisecond", s) : X("second", n) : X("minute", r) : X("hour", e);
  }
  function M(t) {
    return typeof t == "undefined";
  }
  function de(t) {
    return typeof t == "number";
  }
  function Qe(t) {
    return typeof t == "number" && t % 1 === 0;
  }
  function $n(t) {
    return typeof t == "string";
  }
  function Zn(t) {
    return Object.prototype.toString.call(t) === "[object Date]";
  }
  function vr() {
    try {
      return typeof Intl != "undefined" && !!Intl.RelativeTimeFormat;
    } catch (t) {
      return !1;
    }
  }
  function pr() {
    try {
      return typeof Intl != "undefined" && !!Intl.Locale && ("weekInfo" in Intl.Locale.prototype || "getWeekInfo" in Intl.Locale.prototype);
    } catch (t) {
      return !1;
    }
  }
  function An(t) {
    return Array.isArray(t) ? t : [t];
  }
  function gr(t, e, r) {
    if (t.length !== 0)
      return t.reduce((n, s) => {
        const i = [e(s), s];
        return n && r(n[0], i[0]) === n[0] ? n : i;
      }, null)[1];
  }
  function zn(t, e) {
    return e.reduce((r, n) => (r[n] = t[n], r), {});
  }
  function Te(t, e) {
    return Object.prototype.hasOwnProperty.call(t, e);
  }
  function Nt(t) {
    if (t == null) return null;
    if (typeof t != "object") throw new w("Week settings must be an object");
    if (!ee(t.firstDay, 1, 7) || !ee(t.minimalDays, 1, 7) || !Array.isArray(t.weekend) || t.weekend.some((e) => !ee(e, 1, 7))) throw new w("Invalid week settings");
    return {
      firstDay: t.firstDay,
      minimalDays: t.minimalDays,
      weekend: Array.from(t.weekend)
    };
  }
  function ee(t, e, r) {
    return Qe(t) && t >= e && t <= r;
  }
  function Un(t, e) {
    return t - e * Math.floor(t / e);
  }
  function G(t, e = 2) {
    const r = t < 0;
    let n;
    return r ? n = "-" + ("" + -t).padStart(e, "0") : n = ("" + t).padStart(e, "0"), n;
  }
  function he(t) {
    if (!(M(t) || t === null || t === ""))
      return parseInt(t, 10);
  }
  function ye(t) {
    if (!(M(t) || t === null || t === ""))
      return parseFloat(t);
  }
  function It(t) {
    if (!(M(t) || t === null || t === "")) {
      const e = parseFloat("0." + t) * 1e3;
      return Math.floor(e);
    }
  }
  function Et(t, e, r = "round") {
    const n = Math.pow(10, e);
    switch (r) {
      case "expand":
        return t > 0 ? Math.ceil(t * n) / n : Math.floor(t * n) / n;
      case "trunc":
        return Math.trunc(t * n) / n;
      case "round":
        return Math.round(t * n) / n;
      case "floor":
        return Math.floor(t * n) / n;
      case "ceil":
        return Math.ceil(t * n) / n;
      default:
        throw new RangeError(`Value rounding ${r} is out of range`);
    }
  }
  function Fe(t) {
    return t % 4 === 0 && (t % 100 !== 0 || t % 400 === 0);
  }
  function ke(t) {
    return Fe(t) ? 366 : 365;
  }
  function Ke(t, e) {
    const r = Un(e - 1, 12) + 1, n = t + (e - r) / 12;
    return r === 2 ? Fe(n) ? 29 : 28 : [
      31,
      null,
      31,
      30,
      31,
      30,
      31,
      31,
      30,
      31,
      30,
      31
    ][r - 1];
  }
  function Xe(t) {
    let e = Date.UTC(t.year, t.month - 1, t.day, t.hour, t.minute, t.second, t.millisecond);
    return t.year < 100 && t.year >= 0 && (e = new Date(e), e.setUTCFullYear(t.year, t.month - 1, t.day)), +e;
  }
  function wr(t, e, r) {
    return -Dt(Ot(t, 1, e), r) + e - 1;
  }
  function Ve(t, e = 4, r = 1) {
    const n = wr(t, e, r), s = wr(t + 1, e, r);
    return (ke(t) - n + s) / 7;
  }
  function _t(t) {
    return t > 99 ? t : t > R.twoDigitCutoffYear ? 1900 + t : 2e3 + t;
  }
  function Tr(t, e, r, n = null) {
    const s = new Date(t), i = {
      hourCycle: "h23",
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
      hour: "2-digit",
      minute: "2-digit"
    };
    n && (i.timeZone = n);
    const a = D({ timeZoneName: e }, i), o = new Intl.DateTimeFormat(r, a).formatToParts(s).find((u) => u.type.toLowerCase() === "timezonename");
    return o ? o.value : null;
  }
  function et(t, e) {
    let r = parseInt(t, 10);
    Number.isNaN(r) && (r = 0);
    const n = parseInt(e, 10) || 0, s = r < 0 || Object.is(r, -0) ? -n : n;
    return r * 60 + s;
  }
  function kr(t) {
    const e = Number(t);
    if (typeof t == "boolean" || t === "" || !Number.isFinite(e)) throw new w(`Invalid unit value ${t}`);
    return e;
  }
  function tt(t, e) {
    const r = {};
    for (const n in t) if (Te(t, n)) {
      const s = t[n];
      if (s == null) continue;
      r[e(n)] = kr(s);
    }
    return r;
  }
  function We(t, e) {
    const r = Math.trunc(Math.abs(t / 60)), n = Math.trunc(Math.abs(t % 60)), s = t >= 0 ? "+" : "-";
    switch (e) {
      case "short":
        return `${s}${G(r, 2)}:${G(n, 2)}`;
      case "narrow":
        return `${s}${r}${n > 0 ? `:${n}` : ""}`;
      case "techie":
        return `${s}${G(r, 2)}${G(n, 2)}`;
      default:
        throw new RangeError(`Value format ${e} is out of range for property format`);
    }
  }
  function rt(t) {
    return zn(t, [
      "hour",
      "minute",
      "second",
      "millisecond"
    ]);
  }
  var qn = [
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December"
  ], Sr = [
    "Jan",
    "Feb",
    "Mar",
    "Apr",
    "May",
    "Jun",
    "Jul",
    "Aug",
    "Sep",
    "Oct",
    "Nov",
    "Dec"
  ], Hn = [
    "J",
    "F",
    "M",
    "A",
    "M",
    "J",
    "J",
    "A",
    "S",
    "O",
    "N",
    "D"
  ];
  function Or(t) {
    switch (t) {
      case "narrow":
        return [...Hn];
      case "short":
        return [...Sr];
      case "long":
        return [...qn];
      case "numeric":
        return [
          "1",
          "2",
          "3",
          "4",
          "5",
          "6",
          "7",
          "8",
          "9",
          "10",
          "11",
          "12"
        ];
      case "2-digit":
        return [
          "01",
          "02",
          "03",
          "04",
          "05",
          "06",
          "07",
          "08",
          "09",
          "10",
          "11",
          "12"
        ];
      default:
        return null;
    }
  }
  var Dr = [
    "Monday",
    "Tuesday",
    "Wednesday",
    "Thursday",
    "Friday",
    "Saturday",
    "Sunday"
  ], Mr = [
    "Mon",
    "Tue",
    "Wed",
    "Thu",
    "Fri",
    "Sat",
    "Sun"
  ], Rn = [
    "M",
    "T",
    "W",
    "T",
    "F",
    "S",
    "S"
  ];
  function Nr(t) {
    switch (t) {
      case "narrow":
        return [...Rn];
      case "short":
        return [...Mr];
      case "long":
        return [...Dr];
      case "numeric":
        return [
          "1",
          "2",
          "3",
          "4",
          "5",
          "6",
          "7"
        ];
      default:
        return null;
    }
  }
  var Ir = ["AM", "PM"], Yn = ["Before Christ", "Anno Domini"], Pn = ["BC", "AD"], Gn = ["B", "A"];
  function Er(t) {
    switch (t) {
      case "narrow":
        return [...Gn];
      case "short":
        return [...Pn];
      case "long":
        return [...Yn];
      default:
        return null;
    }
  }
  function Jn(t) {
    return Ir[t.hour < 12 ? 0 : 1];
  }
  function jn(t, e) {
    return Nr(e)[t.weekday - 1];
  }
  function Bn(t, e) {
    return Or(e)[t.month - 1];
  }
  function Qn(t, e) {
    return Er(e)[t.year < 0 ? 0 : 1];
  }
  function Kn(t, e, r = "always", n = !1) {
    const s = {
      years: ["year", "yr."],
      quarters: ["quarter", "qtr."],
      months: ["month", "mo."],
      weeks: ["week", "wk."],
      days: [
        "day",
        "day",
        "days"
      ],
      hours: ["hour", "hr."],
      minutes: ["minute", "min."],
      seconds: ["second", "sec."]
    }, i = [
      "hours",
      "minutes",
      "seconds"
    ].indexOf(t) === -1;
    if (r === "auto" && i) {
      const x = t === "days";
      switch (e) {
        case 1:
          return x ? "tomorrow" : `next ${s[t][0]}`;
        case -1:
          return x ? "yesterday" : `last ${s[t][0]}`;
        case 0:
          return x ? "today" : `this ${s[t][0]}`;
      }
    }
    const a = Object.is(e, -0) || e < 0, o = Math.abs(e), u = o === 1, g = s[t], _ = n ? u ? g[1] : g[2] || g[1] : u ? s[t][0] : t;
    return a ? `${o} ${_} ago` : `in ${o} ${_}`;
  }
  function _r(t, e) {
    let r = "";
    for (const n of t) n.literal ? r += n.val : r += e(n.val);
    return r;
  }
  var Xn = {
    D: E,
    DD: U,
    DDD: W,
    DDDD: b,
    t: L,
    tt: V,
    ttt: H,
    tttt: P,
    T: Z,
    TT: C,
    TTT: j,
    TTTT: re,
    f: zt,
    ff: qt,
    fff: Rt,
    ffff: Pt,
    F: Ut,
    FF: Ht,
    FFF: Yt,
    FFFF: Gt
  }, ae = class Je {
    static create(e, r = {}) {
      return new Je(e, r);
    }
    static parseFormat(e) {
      let r = null, n = "", s = !1;
      const i = [];
      for (let a = 0; a < e.length; a++) {
        const o = e.charAt(a);
        o === "'" ? ((n.length > 0 || s) && i.push({
          literal: s || /^\s+$/.test(n),
          val: n === "" ? "'" : n
        }), r = null, n = "", s = !s) : s || o === r ? n += o : (n.length > 0 && i.push({
          literal: /^\s+$/.test(n),
          val: n
        }), n = o, r = o);
      }
      return n.length > 0 && i.push({
        literal: s || /^\s+$/.test(n),
        val: n
      }), i;
    }
    static macroTokenToFormatOpts(e) {
      return Xn[e];
    }
    constructor(e, r) {
      this.opts = r, this.loc = e, this.systemLoc = null;
    }
    formatWithSystemDefault(e, r) {
      return this.systemLoc === null && (this.systemLoc = this.loc.redefaultToSystem()), this.systemLoc.dtFormatter(e, D(D({}, this.opts), r)).format();
    }
    dtFormatter(e, r = {}) {
      return this.loc.dtFormatter(e, D(D({}, this.opts), r));
    }
    formatDateTime(e, r) {
      return this.dtFormatter(e, r).format();
    }
    formatDateTimeParts(e, r) {
      return this.dtFormatter(e, r).formatToParts();
    }
    formatInterval(e, r) {
      return this.dtFormatter(e.start, r).dtf.formatRange(e.start.toJSDate(), e.end.toJSDate());
    }
    resolvedOptions(e, r) {
      return this.dtFormatter(e, r).resolvedOptions();
    }
    num(e, r = 0, n = void 0) {
      if (this.opts.forceSimple) return G(e, r);
      const s = D({}, this.opts);
      return r > 0 && (s.padTo = r), n && (s.signDisplay = n), this.loc.numberFormatter(s).format(e);
    }
    formatDateTimeFromString(e, r) {
      const n = this.loc.listingMode() === "en", s = this.loc.outputCalendar && this.loc.outputCalendar !== "gregory", i = (I, J) => this.loc.extract(e, I, J), a = (I) => e.isOffsetFixed && e.offset === 0 && I.allowZ ? "Z" : e.isValid ? e.zone.formatOffset(e.ts, I.format) : "", o = () => n ? Jn(e) : i({
        hour: "numeric",
        hourCycle: "h12"
      }, "dayperiod"), u = (I, J) => n ? Bn(e, I) : i(J ? { month: I } : {
        month: I,
        day: "numeric"
      }, "month"), g = (I, J) => n ? jn(e, I) : i(J ? { weekday: I } : {
        weekday: I,
        month: "long",
        day: "numeric"
      }, "weekday"), _ = (I) => {
        const J = Je.macroTokenToFormatOpts(I);
        return J ? this.formatWithSystemDefault(e, J) : I;
      }, x = (I) => n ? Qn(e, I) : i({ era: I }, "era"), $ = (I) => {
        switch (I) {
          case "S":
            return this.num(e.millisecond);
          case "u":
          case "SSS":
            return this.num(e.millisecond, 3);
          case "s":
            return this.num(e.second);
          case "ss":
            return this.num(e.second, 2);
          case "uu":
            return this.num(Math.floor(e.millisecond / 10), 2);
          case "uuu":
            return this.num(Math.floor(e.millisecond / 100));
          case "m":
            return this.num(e.minute);
          case "mm":
            return this.num(e.minute, 2);
          case "h":
            return this.num(e.hour % 12 === 0 ? 12 : e.hour % 12);
          case "hh":
            return this.num(e.hour % 12 === 0 ? 12 : e.hour % 12, 2);
          case "H":
            return this.num(e.hour);
          case "HH":
            return this.num(e.hour, 2);
          case "Z":
            return a({
              format: "narrow",
              allowZ: this.opts.allowZ
            });
          case "ZZ":
            return a({
              format: "short",
              allowZ: this.opts.allowZ
            });
          case "ZZZ":
            return a({
              format: "techie",
              allowZ: this.opts.allowZ
            });
          case "ZZZZ":
            return e.zone.offsetName(e.ts, {
              format: "short",
              locale: this.loc.locale
            });
          case "ZZZZZ":
            return e.zone.offsetName(e.ts, {
              format: "long",
              locale: this.loc.locale
            });
          case "z":
            return e.zoneName;
          case "a":
            return o();
          case "d":
            return s ? i({ day: "numeric" }, "day") : this.num(e.day);
          case "dd":
            return s ? i({ day: "2-digit" }, "day") : this.num(e.day, 2);
          case "c":
            return this.num(e.weekday);
          case "ccc":
            return g("short", !0);
          case "cccc":
            return g("long", !0);
          case "ccccc":
            return g("narrow", !0);
          case "E":
            return this.num(e.weekday);
          case "EEE":
            return g("short", !1);
          case "EEEE":
            return g("long", !1);
          case "EEEEE":
            return g("narrow", !1);
          case "L":
            return s ? i({
              month: "numeric",
              day: "numeric"
            }, "month") : this.num(e.month);
          case "LL":
            return s ? i({
              month: "2-digit",
              day: "numeric"
            }, "month") : this.num(e.month, 2);
          case "LLL":
            return u("short", !0);
          case "LLLL":
            return u("long", !0);
          case "LLLLL":
            return u("narrow", !0);
          case "M":
            return s ? i({ month: "numeric" }, "month") : this.num(e.month);
          case "MM":
            return s ? i({ month: "2-digit" }, "month") : this.num(e.month, 2);
          case "MMM":
            return u("short", !1);
          case "MMMM":
            return u("long", !1);
          case "MMMMM":
            return u("narrow", !1);
          case "y":
            return s ? i({ year: "numeric" }, "year") : this.num(e.year);
          case "yy":
            return s ? i({ year: "2-digit" }, "year") : this.num(e.year.toString().slice(-2), 2);
          case "yyyy":
            return s ? i({ year: "numeric" }, "year") : this.num(e.year, 4);
          case "yyyyyy":
            return s ? i({ year: "numeric" }, "year") : this.num(e.year, 6);
          case "G":
            return x("short");
          case "GG":
            return x("long");
          case "GGGGG":
            return x("narrow");
          case "kk":
            return this.num(e.weekYear.toString().slice(-2), 2);
          case "kkkk":
            return this.num(e.weekYear, 4);
          case "W":
            return this.num(e.weekNumber);
          case "WW":
            return this.num(e.weekNumber, 2);
          case "n":
            return this.num(e.localWeekNumber);
          case "nn":
            return this.num(e.localWeekNumber, 2);
          case "ii":
            return this.num(e.localWeekYear.toString().slice(-2), 2);
          case "iiii":
            return this.num(e.localWeekYear, 4);
          case "o":
            return this.num(e.ordinal);
          case "ooo":
            return this.num(e.ordinal, 3);
          case "q":
            return this.num(e.quarter);
          case "qq":
            return this.num(e.quarter, 2);
          case "X":
            return this.num(Math.floor(e.ts / 1e3));
          case "x":
            return this.num(e.ts);
          default:
            return _(I);
        }
      };
      return _r(Je.parseFormat(r), $);
    }
    formatDurationFromString(e, r) {
      const n = this.opts.signMode === "negativeLargestOnly" ? -1 : 1, s = (g) => {
        switch (g[0]) {
          case "S":
            return "milliseconds";
          case "s":
            return "seconds";
          case "m":
            return "minutes";
          case "h":
            return "hours";
          case "d":
            return "days";
          case "w":
            return "weeks";
          case "M":
            return "months";
          case "y":
            return "years";
          default:
            return null;
        }
      }, i = (g, _) => (x) => {
        const $ = s(x);
        if ($) {
          const I = _.isNegativeDuration && $ !== _.largestUnit ? n : 1;
          let J;
          return this.opts.signMode === "negativeLargestOnly" && $ !== _.largestUnit ? J = "never" : this.opts.signMode === "all" ? J = "always" : J = "auto", this.num(g.get($) * I, x.length, J);
        } else return x;
      }, a = Je.parseFormat(r), o = a.reduce((g, { literal: _, val: x }) => _ ? g : g.concat(x), []), u = e.shiftTo(...o.map(s).filter((g) => g));
      return _r(a, i(u, {
        isNegativeDuration: u < 0,
        largestUnit: Object.keys(u.values)[0]
      }));
    }
  }, xr = /[A-Za-z_+-]{1,256}(?::?\/[A-Za-z0-9_+-]{1,256}(?:\/[A-Za-z0-9_+-]{1,256})?)?/;
  function Se(...t) {
    const e = t.reduce((r, n) => r + n.source, "");
    return RegExp(`^${e}$`);
  }
  function Oe(...t) {
    return (e) => t.reduce(([r, n, s], i) => {
      const [a, o, u] = i(e, s);
      return [
        D(D({}, r), a),
        o || n,
        u
      ];
    }, [
      {},
      null,
      1
    ]).slice(0, 2);
  }
  function De(t, ...e) {
    if (t == null) return [null, null];
    for (const [r, n] of e) {
      const s = r.exec(t);
      if (s) return n(s);
    }
    return [null, null];
  }
  function br(...t) {
    return (e, r) => {
      const n = {};
      let s;
      for (s = 0; s < t.length; s++) n[t[s]] = he(e[r + s]);
      return [
        n,
        null,
        r + s
      ];
    };
  }
  var Cr = /(?:([Zz])|([+-]\d\d)(?::?(\d\d))?)/, es = `(?:${Cr.source}?(?:\\[(${xr.source})\\])?)?`, xt = /(\d\d)(?::?(\d\d)(?::?(\d\d)(?:[.,](\d{1,30}))?)?)?/, Fr = RegExp(`${xt.source}${es}`), bt = RegExp(`(?:[Tt]${Fr.source})?`), ts = /([+-]\d{6}|\d{4})(?:-?(\d\d)(?:-?(\d\d))?)?/, rs = /(\d{4})-?W(\d\d)(?:-?(\d))?/, ns = /(\d{4})-?(\d{3})/, ss = br("weekYear", "weekNumber", "weekDay"), is = br("year", "ordinal"), as = /(\d{4})-(\d\d)-(\d\d)/, Vr = RegExp(`${xt.source} ?(?:${Cr.source}|(${xr.source}))?`), os = RegExp(`(?: ${Vr.source})?`);
  function Me(t, e, r) {
    const n = t[e];
    return M(n) ? r : he(n);
  }
  function us(t, e) {
    return [
      {
        year: Me(t, e),
        month: Me(t, e + 1, 1),
        day: Me(t, e + 2, 1)
      },
      null,
      e + 3
    ];
  }
  function Ne(t, e) {
    return [
      {
        hours: Me(t, e, 0),
        minutes: Me(t, e + 1, 0),
        seconds: Me(t, e + 2, 0),
        milliseconds: It(t[e + 3])
      },
      null,
      e + 4
    ];
  }
  function Le(t, e) {
    const r = !t[e] && !t[e + 1], n = et(t[e + 1], t[e + 2]);
    return [
      {},
      r ? null : ne.instance(n),
      e + 3
    ];
  }
  function $e(t, e) {
    return [
      {},
      t[e] ? me.create(t[e]) : null,
      e + 1
    ];
  }
  var ls = RegExp(`^T?${xt.source}$`), cs = /^-?P(?:(?:(-?\d{1,20}(?:\.\d{1,20})?)Y)?(?:(-?\d{1,20}(?:\.\d{1,20})?)M)?(?:(-?\d{1,20}(?:\.\d{1,20})?)W)?(?:(-?\d{1,20}(?:\.\d{1,20})?)D)?(?:T(?:(-?\d{1,20}(?:\.\d{1,20})?)H)?(?:(-?\d{1,20}(?:\.\d{1,20})?)M)?(?:(-?\d{1,20})(?:[.,](-?\d{1,20}))?S)?)?)$/;
  function fs(t) {
    const [e, r, n, s, i, a, o, u, g] = t, _ = e[0] === "-", x = u && u[0] === "-", $ = (I, J = !1) => I !== void 0 && (J || I && _) ? -I : I;
    return [{
      years: $(ye(r)),
      months: $(ye(n)),
      weeks: $(ye(s)),
      days: $(ye(i)),
      hours: $(ye(a)),
      minutes: $(ye(o)),
      seconds: $(ye(u), u === "-0"),
      milliseconds: $(It(g), x)
    }];
  }
  var ds = {
    GMT: 0,
    EDT: -240,
    EST: -300,
    CDT: -300,
    CST: -360,
    MDT: -360,
    MST: -420,
    PDT: -420,
    PST: -480
  };
  function Ct(t, e, r, n, s, i, a) {
    const o = {
      year: e.length === 2 ? _t(he(e)) : he(e),
      month: Sr.indexOf(r) + 1,
      day: he(n),
      hour: he(s),
      minute: he(i)
    };
    return a && (o.second = he(a)), t && (o.weekday = t.length > 3 ? Dr.indexOf(t) + 1 : Mr.indexOf(t) + 1), o;
  }
  var hs = /^(?:(Mon|Tue|Wed|Thu|Fri|Sat|Sun),\s)?(\d{1,2})\s(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\s(\d{2,4})\s(\d\d):(\d\d)(?::(\d\d))?\s(?:(UT|GMT|[ECMP][SD]T)|([Zz])|(?:([+-]\d\d)(\d\d)))$/;
  function ms(t) {
    const [, e, r, n, s, i, a, o, u, g, _, x] = t, $ = Ct(e, s, n, r, i, a, o);
    let I;
    return u ? I = ds[u] : g ? I = 0 : I = et(_, x), [$, new ne(I)];
  }
  function ys(t) {
    return t.replace(/\([^()]*\)|[\n\t]/g, " ").replace(/(\s\s+)/g, " ").trim();
  }
  var vs = /^(Mon|Tue|Wed|Thu|Fri|Sat|Sun), (\d\d) (Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec) (\d{4}) (\d\d):(\d\d):(\d\d) GMT$/, ps = /^(Monday|Tuesday|Wednesday|Thursday|Friday|Saturday|Sunday), (\d\d)-(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)-(\d\d) (\d\d):(\d\d):(\d\d) GMT$/, gs = /^(Mon|Tue|Wed|Thu|Fri|Sat|Sun) (Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec) ( \d|\d\d) (\d\d):(\d\d):(\d\d) (\d{4})$/;
  function Wr(t) {
    const [, e, r, n, s, i, a, o] = t;
    return [Ct(e, s, n, r, i, a, o), ne.utcInstance];
  }
  function ws(t) {
    const [, e, r, n, s, i, a, o] = t;
    return [Ct(e, o, r, n, s, i, a), ne.utcInstance];
  }
  var Ts = Se(ts, bt), ks = Se(rs, bt), Ss = Se(ns, bt), Os = Se(Fr), Lr = Oe(us, Ne, Le, $e), Ds = Oe(ss, Ne, Le, $e), Ms = Oe(is, Ne, Le, $e), Ns = Oe(Ne, Le, $e);
  function Is(t) {
    return De(t, [Ts, Lr], [ks, Ds], [Ss, Ms], [Os, Ns]);
  }
  function Es(t) {
    return De(ys(t), [hs, ms]);
  }
  function _s(t) {
    return De(t, [vs, Wr], [ps, Wr], [gs, ws]);
  }
  function xs(t) {
    return De(t, [cs, fs]);
  }
  var bs = Oe(Ne);
  function Cs(t) {
    return De(t, [ls, bs]);
  }
  var Fs = Se(as, os), Vs = Se(Vr), Ws = Oe(Ne, Le, $e);
  function Ls(t) {
    return De(t, [Fs, Lr], [Vs, Ws]);
  }
  var $r = "Invalid Duration", Zr = {
    weeks: {
      days: 7,
      hours: 168,
      minutes: 10080,
      seconds: 604800,
      milliseconds: 6048e5
    },
    days: {
      hours: 24,
      minutes: 1440,
      seconds: 86400,
      milliseconds: 864e5
    },
    hours: {
      minutes: 60,
      seconds: 3600,
      milliseconds: 36e5
    },
    minutes: {
      seconds: 60,
      milliseconds: 6e4
    },
    seconds: { milliseconds: 1e3 }
  }, $s = D({
    years: {
      quarters: 4,
      months: 12,
      weeks: 52,
      days: 365,
      hours: 8760,
      minutes: 525600,
      seconds: 31536e3,
      milliseconds: 31536e6
    },
    quarters: {
      months: 3,
      weeks: 13,
      days: 91,
      hours: 2184,
      minutes: 131040,
      seconds: 7862400,
      milliseconds: 78624e5
    },
    months: {
      weeks: 4,
      days: 30,
      hours: 720,
      minutes: 43200,
      seconds: 2592e3,
      milliseconds: 2592e6
    }
  }, Zr), te = 146097 / 400, Ie = 146097 / 4800, Zs = D({
    years: {
      quarters: 4,
      months: 12,
      weeks: te / 7,
      days: te,
      hours: te * 24,
      minutes: te * 24 * 60,
      seconds: te * 24 * 60 * 60,
      milliseconds: te * 24 * 60 * 60 * 1e3
    },
    quarters: {
      months: 3,
      weeks: te / 28,
      days: te / 4,
      hours: te * 24 / 4,
      minutes: te * 24 * 60 / 4,
      seconds: te * 24 * 60 * 60 / 4,
      milliseconds: te * 24 * 60 * 60 * 1e3 / 4
    },
    months: {
      weeks: Ie / 7,
      days: Ie,
      hours: Ie * 24,
      minutes: Ie * 24 * 60,
      seconds: Ie * 24 * 60 * 60,
      milliseconds: Ie * 24 * 60 * 60 * 1e3
    }
  }, Zr), ve = [
    "years",
    "quarters",
    "months",
    "weeks",
    "days",
    "hours",
    "minutes",
    "seconds",
    "milliseconds"
  ], As = ve.slice(0).reverse();
  function le(t, e, r = !1) {
    const n = {
      values: r ? e.values : D(D({}, t.values), e.values || {}),
      loc: t.loc.clone(e.loc),
      conversionAccuracy: e.conversionAccuracy || t.conversionAccuracy,
      matrix: e.matrix || t.matrix
    };
    return new Q(n);
  }
  function Ar(t, e) {
    var r;
    let n = (r = e.milliseconds) != null ? r : 0;
    for (const s of As.slice(1)) e[s] && (n += e[s] * t[s].milliseconds);
    return n;
  }
  function zr(t, e) {
    const r = Ar(t, e) < 0 ? -1 : 1;
    ve.reduceRight((n, s) => {
      if (M(e[s]))
        return n;
      if (n) {
        const i = e[n] * r, a = t[s][n], o = Math.floor(i / a);
        e[s] += o * r, e[n] -= o * a * r;
      }
      return s;
    }, null), ve.reduce((n, s) => {
      if (M(e[s]))
        return n;
      if (n) {
        const i = e[n] % 1;
        e[n] -= i, e[s] += i * t[n][s];
      }
      return s;
    }, null);
  }
  function Ur(t) {
    const e = {};
    for (const [r, n] of Object.entries(t)) n !== 0 && (e[r] = n);
    return e;
  }
  var Q = class K {
    constructor(e) {
      const r = e.conversionAccuracy === "longterm" || !1;
      let n = r ? Zs : $s;
      e.matrix && (n = e.matrix), this.values = e.values, this.loc = e.loc || A.create(), this.conversionAccuracy = r ? "longterm" : "casual", this.invalid = e.invalid || null, this.matrix = n, this.isLuxonDuration = !0;
    }
    static fromMillis(e, r) {
      return K.fromObject({ milliseconds: e }, r);
    }
    static fromObject(e, r = {}) {
      if (e == null || typeof e != "object") throw new w(`Duration.fromObject: argument expected to be an object, got ${e === null ? "null" : typeof e}`);
      return new K({
        values: tt(e, K.normalizeUnit),
        loc: A.fromObject(r),
        conversionAccuracy: r.conversionAccuracy,
        matrix: r.matrix
      });
    }
    static fromDurationLike(e) {
      if (de(e)) return K.fromMillis(e);
      if (K.isDuration(e)) return e;
      if (typeof e == "object") return K.fromObject(e);
      throw new w(`Unknown duration argument ${e} of type ${typeof e}`);
    }
    static fromISO(e, r) {
      const [n] = xs(e);
      return n ? K.fromObject(n, r) : K.invalid("unparsable", `the input "${e}" can't be parsed as ISO 8601`);
    }
    static fromISOTime(e, r) {
      const [n] = Cs(e);
      return n ? K.fromObject(n, r) : K.invalid("unparsable", `the input "${e}" can't be parsed as ISO 8601`);
    }
    static invalid(e, r = null) {
      if (!e) throw new w("need to specify a reason the Duration is invalid");
      const n = e instanceof ie ? e : new ie(e, r);
      if (R.throwOnInvalid) throw new v(n);
      return new K({ invalid: n });
    }
    static normalizeUnit(e) {
      const r = {
        year: "years",
        years: "years",
        quarter: "quarters",
        quarters: "quarters",
        month: "months",
        months: "months",
        week: "weeks",
        weeks: "weeks",
        day: "days",
        days: "days",
        hour: "hours",
        hours: "hours",
        minute: "minutes",
        minutes: "minutes",
        second: "seconds",
        seconds: "seconds",
        millisecond: "milliseconds",
        milliseconds: "milliseconds"
      }[e && e.toLowerCase()];
      if (!r) throw new p(e);
      return r;
    }
    static isDuration(e) {
      return e && e.isLuxonDuration || !1;
    }
    get locale() {
      return this.isValid ? this.loc.locale : null;
    }
    get numberingSystem() {
      return this.isValid ? this.loc.numberingSystem : null;
    }
    toFormat(e, r = {}) {
      const n = D(D({}, r), {}, { floor: r.round !== !1 && r.floor !== !1 });
      return this.isValid ? ae.create(this.loc, n).formatDurationFromString(this, e) : $r;
    }
    toHuman(e = {}) {
      if (!this.isValid) return $r;
      const r = e.showZeros !== !1, n = ve.map((s) => {
        const i = this.values[s];
        return M(i) || i === 0 && !r ? null : this.loc.numberFormatter(D(D({
          style: "unit",
          unitDisplay: "long"
        }, e), {}, { unit: s.slice(0, -1) })).format(i);
      }).filter((s) => s);
      return this.loc.listFormatter(D({
        type: "conjunction",
        style: e.listStyle || "narrow"
      }, e)).format(n);
    }
    toObject() {
      return this.isValid ? D({}, this.values) : {};
    }
    toISO() {
      if (!this.isValid) return null;
      let e = "P";
      return this.years !== 0 && (e += this.years + "Y"), (this.months !== 0 || this.quarters !== 0) && (e += this.months + this.quarters * 3 + "M"), this.weeks !== 0 && (e += this.weeks + "W"), this.days !== 0 && (e += this.days + "D"), (this.hours !== 0 || this.minutes !== 0 || this.seconds !== 0 || this.milliseconds !== 0) && (e += "T"), this.hours !== 0 && (e += this.hours + "H"), this.minutes !== 0 && (e += this.minutes + "M"), (this.seconds !== 0 || this.milliseconds !== 0) && (e += Et(this.seconds + this.milliseconds / 1e3, 3) + "S"), e === "P" && (e += "T0S"), e;
    }
    toISOTime(e = {}) {
      if (!this.isValid) return null;
      const r = this.toMillis();
      return r < 0 || r >= 864e5 ? null : (e = D(D({
        suppressMilliseconds: !1,
        suppressSeconds: !1,
        includePrefix: !1,
        format: "extended"
      }, e), {}, { includeOffset: !1 }), Y.fromMillis(r, { zone: "UTC" }).toISOTime(e));
    }
    toJSON() {
      return this.toISO();
    }
    toString() {
      return this.toISO();
    }
    [/* @__PURE__ */ Symbol.for("nodejs.util.inspect.custom")]() {
      return this.isValid ? `Duration { values: ${JSON.stringify(this.values)} }` : `Duration { Invalid, reason: ${this.invalidReason} }`;
    }
    toMillis() {
      return this.isValid ? Ar(this.matrix, this.values) : NaN;
    }
    valueOf() {
      return this.toMillis();
    }
    plus(e) {
      if (!this.isValid) return this;
      const r = K.fromDurationLike(e), n = {};
      for (const s of ve) (Te(r.values, s) || Te(this.values, s)) && (n[s] = r.get(s) + this.get(s));
      return le(this, { values: n }, !0);
    }
    minus(e) {
      if (!this.isValid) return this;
      const r = K.fromDurationLike(e);
      return this.plus(r.negate());
    }
    mapUnits(e) {
      if (!this.isValid) return this;
      const r = {};
      for (const n of Object.keys(this.values)) r[n] = kr(e(this.values[n], n));
      return le(this, { values: r }, !0);
    }
    get(e) {
      return this[K.normalizeUnit(e)];
    }
    set(e) {
      if (!this.isValid) return this;
      const r = D(D({}, this.values), tt(e, K.normalizeUnit));
      return le(this, { values: r });
    }
    reconfigure({ locale: e, numberingSystem: r, conversionAccuracy: n, matrix: s } = {}) {
      const i = {
        loc: this.loc.clone({
          locale: e,
          numberingSystem: r
        }),
        matrix: s,
        conversionAccuracy: n
      };
      return le(this, i);
    }
    as(e) {
      return this.isValid ? this.shiftTo(e).get(e) : NaN;
    }
    normalize() {
      if (!this.isValid) return this;
      const e = this.toObject();
      return zr(this.matrix, e), le(this, { values: e }, !0);
    }
    rescale() {
      if (!this.isValid) return this;
      const e = Ur(this.normalize().shiftToAll().toObject());
      return le(this, { values: e }, !0);
    }
    shiftTo(...e) {
      if (!this.isValid) return this;
      if (e.length === 0) return this;
      e = e.map((a) => K.normalizeUnit(a));
      const r = {}, n = {}, s = this.toObject();
      let i;
      for (const a of ve) if (e.indexOf(a) >= 0) {
        i = a;
        let o = 0;
        for (const g in n)
          o += this.matrix[g][a] * n[g], n[g] = 0;
        de(s[a]) && (o += s[a]);
        const u = Math.trunc(o);
        r[a] = u, n[a] = (o * 1e3 - u * 1e3) / 1e3;
      } else de(s[a]) && (n[a] = s[a]);
      for (const a in n) n[a] !== 0 && (r[i] += a === i ? n[a] : n[a] / this.matrix[i][a]);
      return zr(this.matrix, r), le(this, { values: r }, !0);
    }
    shiftToAll() {
      return this.isValid ? this.shiftTo("years", "months", "weeks", "days", "hours", "minutes", "seconds", "milliseconds") : this;
    }
    negate() {
      if (!this.isValid) return this;
      const e = {};
      for (const r of Object.keys(this.values)) e[r] = this.values[r] === 0 ? 0 : -this.values[r];
      return le(this, { values: e }, !0);
    }
    removeZeros() {
      if (!this.isValid) return this;
      const e = Ur(this.values);
      return le(this, { values: e }, !0);
    }
    get years() {
      return this.isValid ? this.values.years || 0 : NaN;
    }
    get quarters() {
      return this.isValid ? this.values.quarters || 0 : NaN;
    }
    get months() {
      return this.isValid ? this.values.months || 0 : NaN;
    }
    get weeks() {
      return this.isValid ? this.values.weeks || 0 : NaN;
    }
    get days() {
      return this.isValid ? this.values.days || 0 : NaN;
    }
    get hours() {
      return this.isValid ? this.values.hours || 0 : NaN;
    }
    get minutes() {
      return this.isValid ? this.values.minutes || 0 : NaN;
    }
    get seconds() {
      return this.isValid ? this.values.seconds || 0 : NaN;
    }
    get milliseconds() {
      return this.isValid ? this.values.milliseconds || 0 : NaN;
    }
    get isValid() {
      return this.invalid === null;
    }
    get invalidReason() {
      return this.invalid ? this.invalid.reason : null;
    }
    get invalidExplanation() {
      return this.invalid ? this.invalid.explanation : null;
    }
    equals(e) {
      if (!this.isValid || !e.isValid || !this.loc.equals(e.loc)) return !1;
      function r(n, s) {
        return n === void 0 || n === 0 ? s === void 0 || s === 0 : n === s;
      }
      for (const n of ve) if (!r(this.values[n], e.values[n])) return !1;
      return !0;
    }
  }, Ee = "Invalid Interval";
  function zs(t, e) {
    return !t || !t.isValid ? Ze.invalid("missing or invalid start") : !e || !e.isValid ? Ze.invalid("missing or invalid end") : e < t ? Ze.invalid("end before start", `The end of an interval must be after its start, but you had start=${t.toISO()} and end=${e.toISO()}`) : null;
  }
  var Ze = class B {
    constructor(e) {
      this.s = e.start, this.e = e.end, this.invalid = e.invalid || null, this.isLuxonInterval = !0;
    }
    static invalid(e, r = null) {
      if (!e) throw new w("need to specify a reason the Interval is invalid");
      const n = e instanceof ie ? e : new ie(e, r);
      if (R.throwOnInvalid) throw new c(n);
      return new B({ invalid: n });
    }
    static fromDateTimes(e, r) {
      const n = qe(e), s = qe(r), i = zs(n, s);
      return i == null ? new B({
        start: n,
        end: s
      }) : i;
    }
    static after(e, r) {
      const n = Q.fromDurationLike(r), s = qe(e);
      return B.fromDateTimes(s, s.plus(n));
    }
    static before(e, r) {
      const n = Q.fromDurationLike(r), s = qe(e);
      return B.fromDateTimes(s.minus(n), s);
    }
    static fromISO(e, r) {
      const [n, s] = (e || "").split("/", 2);
      if (n && s) {
        let i, a;
        try {
          i = Y.fromISO(n, r), a = i.isValid;
        } catch (g) {
          a = !1;
        }
        let o, u;
        try {
          o = Y.fromISO(s, r), u = o.isValid;
        } catch (g) {
          u = !1;
        }
        if (a && u) return B.fromDateTimes(i, o);
        if (a) {
          const g = Q.fromISO(s, r);
          if (g.isValid) return B.after(i, g);
        } else if (u) {
          const g = Q.fromISO(n, r);
          if (g.isValid) return B.before(o, g);
        }
      }
      return B.invalid("unparsable", `the input "${e}" can't be parsed as ISO 8601`);
    }
    static isInterval(e) {
      return e && e.isLuxonInterval || !1;
    }
    get start() {
      return this.isValid ? this.s : null;
    }
    get end() {
      return this.isValid ? this.e : null;
    }
    get lastDateTime() {
      return this.isValid && this.e ? this.e.minus(1) : null;
    }
    get isValid() {
      return this.invalidReason === null;
    }
    get invalidReason() {
      return this.invalid ? this.invalid.reason : null;
    }
    get invalidExplanation() {
      return this.invalid ? this.invalid.explanation : null;
    }
    length(e = "milliseconds") {
      return this.isValid ? this.toDuration(e).get(e) : NaN;
    }
    count(e = "milliseconds", r) {
      if (!this.isValid) return NaN;
      const n = this.start.startOf(e, r);
      let s;
      return r != null && r.useLocaleWeeks ? s = this.end.reconfigure({ locale: n.locale }) : s = this.end, s = s.startOf(e, r), Math.floor(s.diff(n, e).get(e)) + (s.valueOf() !== this.end.valueOf());
    }
    hasSame(e) {
      return this.isValid ? this.isEmpty() || this.e.minus(1).hasSame(this.s, e) : !1;
    }
    isEmpty() {
      return this.s.valueOf() === this.e.valueOf();
    }
    isAfter(e) {
      return this.isValid ? this.s > e : !1;
    }
    isBefore(e) {
      return this.isValid ? this.e <= e : !1;
    }
    contains(e) {
      return this.isValid ? this.s <= e && this.e > e : !1;
    }
    set({ start: e, end: r } = {}) {
      return this.isValid ? B.fromDateTimes(e || this.s, r || this.e) : this;
    }
    splitAt(...e) {
      if (!this.isValid) return [];
      const r = e.map(qe).filter((a) => this.contains(a)).sort((a, o) => a.toMillis() - o.toMillis()), n = [];
      let { s } = this, i = 0;
      for (; s < this.e; ) {
        const a = r[i] || this.e, o = +a > +this.e ? this.e : a;
        n.push(B.fromDateTimes(s, o)), s = o, i += 1;
      }
      return n;
    }
    splitBy(e) {
      const r = Q.fromDurationLike(e);
      if (!this.isValid || !r.isValid || r.as("milliseconds") === 0) return [];
      let { s: n } = this, s = 1, i;
      const a = [];
      for (; n < this.e; ) {
        const o = this.start.plus(r.mapUnits((u) => u * s));
        i = +o > +this.e ? this.e : o, a.push(B.fromDateTimes(n, i)), n = i, s += 1;
      }
      return a;
    }
    divideEqually(e) {
      return this.isValid ? this.splitBy(this.length() / e).slice(0, e) : [];
    }
    overlaps(e) {
      return this.e > e.s && this.s < e.e;
    }
    abutsStart(e) {
      return this.isValid ? +this.e == +e.s : !1;
    }
    abutsEnd(e) {
      return this.isValid ? +e.e == +this.s : !1;
    }
    engulfs(e) {
      return this.isValid ? this.s <= e.s && this.e >= e.e : !1;
    }
    equals(e) {
      return !this.isValid || !e.isValid ? !1 : this.s.equals(e.s) && this.e.equals(e.e);
    }
    intersection(e) {
      if (!this.isValid) return this;
      const r = this.s > e.s ? this.s : e.s, n = this.e < e.e ? this.e : e.e;
      return r >= n ? null : B.fromDateTimes(r, n);
    }
    union(e) {
      if (!this.isValid) return this;
      const r = this.s < e.s ? this.s : e.s, n = this.e > e.e ? this.e : e.e;
      return B.fromDateTimes(r, n);
    }
    static merge(e) {
      const [r, n] = e.sort((s, i) => s.s - i.s).reduce(([s, i], a) => i ? i.overlaps(a) || i.abutsStart(a) ? [s, i.union(a)] : [s.concat([i]), a] : [s, a], [[], null]);
      return n && r.push(n), r;
    }
    static xor(e) {
      let r = null, n = 0;
      const s = [], i = e.map((o) => [{
        time: o.s,
        type: "s"
      }, {
        time: o.e,
        type: "e"
      }]), a = Array.prototype.concat(...i).sort((o, u) => o.time - u.time);
      for (const o of a)
        n += o.type === "s" ? 1 : -1, n === 1 ? r = o.time : (r && +r != +o.time && s.push(B.fromDateTimes(r, o.time)), r = null);
      return B.merge(s);
    }
    difference(...e) {
      return B.xor([this].concat(e)).map((r) => this.intersection(r)).filter((r) => r && !r.isEmpty());
    }
    toString() {
      return this.isValid ? `[${this.s.toISO()} – ${this.e.toISO()})` : Ee;
    }
    [/* @__PURE__ */ Symbol.for("nodejs.util.inspect.custom")]() {
      return this.isValid ? `Interval { start: ${this.s.toISO()}, end: ${this.e.toISO()} }` : `Interval { Invalid, reason: ${this.invalidReason} }`;
    }
    toLocaleString(e = E, r = {}) {
      return this.isValid ? ae.create(this.s.loc.clone(r), e).formatInterval(this) : Ee;
    }
    toISO(e) {
      return this.isValid ? `${this.s.toISO(e)}/${this.e.toISO(e)}` : Ee;
    }
    toISODate() {
      return this.isValid ? `${this.s.toISODate()}/${this.e.toISODate()}` : Ee;
    }
    toISOTime(e) {
      return this.isValid ? `${this.s.toISOTime(e)}/${this.e.toISOTime(e)}` : Ee;
    }
    toFormat(e, { separator: r = " – " } = {}) {
      return this.isValid ? `${this.s.toFormat(e)}${r}${this.e.toFormat(e)}` : Ee;
    }
    toDuration(e, r) {
      return this.isValid ? this.e.diff(this.s, e, r) : Q.invalid(this.invalidReason);
    }
    mapEndpoints(e) {
      return B.fromDateTimes(e(this.s), e(this.e));
    }
  }, Ae = class {
    static hasDST(t = R.defaultZone) {
      const e = Y.now().setZone(t).set({ month: 12 });
      return !t.isUniversal && e.offset !== e.set({ month: 6 }).offset;
    }
    static isValidIANAZone(t) {
      return me.isValidZone(t);
    }
    static normalizeZone(t) {
      return fe(t, R.defaultZone);
    }
    static getStartOfWeek({ locale: t = null, locObj: e = null } = {}) {
      return (e || A.create(t)).getStartOfWeek();
    }
    static getMinimumDaysInFirstWeek({ locale: t = null, locObj: e = null } = {}) {
      return (e || A.create(t)).getMinDaysInFirstWeek();
    }
    static getWeekendWeekdays({ locale: t = null, locObj: e = null } = {}) {
      return (e || A.create(t)).getWeekendDays().slice();
    }
    static months(t = "long", { locale: e = null, numberingSystem: r = null, locObj: n = null, outputCalendar: s = "gregory" } = {}) {
      return (n || A.create(e, r, s)).months(t);
    }
    static monthsFormat(t = "long", { locale: e = null, numberingSystem: r = null, locObj: n = null, outputCalendar: s = "gregory" } = {}) {
      return (n || A.create(e, r, s)).months(t, !0);
    }
    static weekdays(t = "long", { locale: e = null, numberingSystem: r = null, locObj: n = null } = {}) {
      return (n || A.create(e, r, null)).weekdays(t);
    }
    static weekdaysFormat(t = "long", { locale: e = null, numberingSystem: r = null, locObj: n = null } = {}) {
      return (n || A.create(e, r, null)).weekdays(t, !0);
    }
    static meridiems({ locale: t = null } = {}) {
      return A.create(t).meridiems();
    }
    static eras(t = "short", { locale: e = null } = {}) {
      return A.create(e, null, "gregory").eras(t);
    }
    static features() {
      return {
        relative: vr(),
        localeWeek: pr()
      };
    }
  };
  function qr(t, e) {
    const r = (s) => s.toUTC(0, { keepLocalTime: !0 }).startOf("day").valueOf(), n = r(e) - r(t);
    return Math.floor(Q.fromMillis(n).as("days"));
  }
  function Us(t, e, r) {
    const n = [
      ["years", (u, g) => g.year - u.year],
      ["quarters", (u, g) => g.quarter - u.quarter + (g.year - u.year) * 4],
      ["months", (u, g) => g.month - u.month + (g.year - u.year) * 12],
      ["weeks", (u, g) => {
        const _ = qr(u, g);
        return (_ - _ % 7) / 7;
      }],
      ["days", qr]
    ], s = {}, i = t;
    let a, o;
    for (const [u, g] of n) r.indexOf(u) >= 0 && (a = u, s[u] = g(t, e), o = i.plus(s), o > e ? (s[u]--, t = i.plus(s), t > e && (o = t, s[u]--, t = i.plus(s))) : t = o);
    return [
      t,
      s,
      o,
      a
    ];
  }
  function qs(t, e, r, n) {
    let [s, i, a, o] = Us(t, e, r);
    const u = e - s, g = r.filter((x) => [
      "hours",
      "minutes",
      "seconds",
      "milliseconds"
    ].indexOf(x) >= 0);
    g.length === 0 && (a < e && (a = s.plus({ [o]: 1 })), a !== s && (i[o] = (i[o] || 0) + u / (a - s)));
    const _ = Q.fromObject(i, n);
    return g.length > 0 ? Q.fromMillis(u, n).shiftTo(...g).plus(_) : _;
  }
  var Hs = "missing Intl.DateTimeFormat.formatToParts support";
  function F(t, e = (r) => r) {
    return {
      regex: t,
      deser: ([r]) => e(Fn(r))
    };
  }
  var Hr = "[  ]", Rr = new RegExp(Hr, "g");
  function Rs(t) {
    return t.replace(/\./g, "\\.?").replace(Rr, Hr);
  }
  function Yr(t) {
    return t.replace(/\./g, "").replace(Rr, " ").toLowerCase();
  }
  function oe(t, e) {
    return t === null ? null : {
      regex: RegExp(t.map(Rs).join("|")),
      deser: ([r]) => t.findIndex((n) => Yr(r) === Yr(n)) + e
    };
  }
  function Pr(t, e) {
    return {
      regex: t,
      deser: ([, r, n]) => et(r, n),
      groups: e
    };
  }
  function nt(t) {
    return {
      regex: t,
      deser: ([e]) => e
    };
  }
  function Ys(t) {
    return t.replace(/[\-\[\]{}()*+?.,\\\^$|#\s]/g, "\\$&");
  }
  function Ps(t, e) {
    const r = se(e), n = se(e, "{2}"), s = se(e, "{3}"), i = se(e, "{4}"), a = se(e, "{6}"), o = se(e, "{1,2}"), u = se(e, "{1,3}"), g = se(e, "{1,6}"), _ = se(e, "{1,9}"), x = se(e, "{2,4}"), $ = se(e, "{4,6}"), I = (ue) => ({
      regex: RegExp(Ys(ue.val)),
      deser: ([be]) => be,
      literal: !0
    }), xe = ((ue) => {
      if (t.literal) return I(ue);
      switch (ue.val) {
        case "G":
          return oe(e.eras("short"), 0);
        case "GG":
          return oe(e.eras("long"), 0);
        case "y":
          return F(g);
        case "yy":
          return F(x, _t);
        case "yyyy":
          return F(i);
        case "yyyyy":
          return F($);
        case "yyyyyy":
          return F(a);
        case "M":
          return F(o);
        case "MM":
          return F(n);
        case "MMM":
          return oe(e.months("short", !0), 1);
        case "MMMM":
          return oe(e.months("long", !0), 1);
        case "L":
          return F(o);
        case "LL":
          return F(n);
        case "LLL":
          return oe(e.months("short", !1), 1);
        case "LLLL":
          return oe(e.months("long", !1), 1);
        case "d":
          return F(o);
        case "dd":
          return F(n);
        case "o":
          return F(u);
        case "ooo":
          return F(s);
        case "HH":
          return F(n);
        case "H":
          return F(o);
        case "hh":
          return F(n);
        case "h":
          return F(o);
        case "mm":
          return F(n);
        case "m":
          return F(o);
        case "q":
          return F(o);
        case "qq":
          return F(n);
        case "s":
          return F(o);
        case "ss":
          return F(n);
        case "S":
          return F(u);
        case "SSS":
          return F(s);
        case "u":
          return nt(_);
        case "uu":
          return nt(o);
        case "uuu":
          return F(r);
        case "a":
          return oe(e.meridiems(), 0);
        case "kkkk":
          return F(i);
        case "kk":
          return F(x, _t);
        case "W":
          return F(o);
        case "WW":
          return F(n);
        case "E":
        case "c":
          return F(r);
        case "EEE":
          return oe(e.weekdays("short", !1), 1);
        case "EEEE":
          return oe(e.weekdays("long", !1), 1);
        case "ccc":
          return oe(e.weekdays("short", !0), 1);
        case "cccc":
          return oe(e.weekdays("long", !0), 1);
        case "Z":
        case "ZZ":
          return Pr(new RegExp(`([+-]${o.source})(?::(${n.source}))?`), 2);
        case "ZZZ":
          return Pr(new RegExp(`([+-]${o.source})(${n.source})?`), 2);
        case "z":
          return nt(/[a-z_+-/]{1,256}?/i);
        case " ":
          return nt(/[^\S\n\r]/);
        default:
          return I(ue);
      }
    })(t) || { invalidReason: Hs };
    return xe.token = t, xe;
  }
  var Gs = {
    year: {
      "2-digit": "yy",
      numeric: "yyyyy"
    },
    month: {
      numeric: "M",
      "2-digit": "MM",
      short: "MMM",
      long: "MMMM"
    },
    day: {
      numeric: "d",
      "2-digit": "dd"
    },
    weekday: {
      short: "EEE",
      long: "EEEE"
    },
    dayperiod: "a",
    dayPeriod: "a",
    hour12: {
      numeric: "h",
      "2-digit": "hh"
    },
    hour24: {
      numeric: "H",
      "2-digit": "HH"
    },
    minute: {
      numeric: "m",
      "2-digit": "mm"
    },
    second: {
      numeric: "s",
      "2-digit": "ss"
    },
    timeZoneName: {
      long: "ZZZZZ",
      short: "ZZZ"
    }
  };
  function Js(t, e, r) {
    const { type: n, value: s } = t;
    if (n === "literal") {
      const u = /^\s+$/.test(s);
      return {
        literal: !u,
        val: u ? " " : s
      };
    }
    const i = e[n];
    let a = n;
    n === "hour" && (e.hour12 != null ? a = e.hour12 ? "hour12" : "hour24" : e.hourCycle != null ? e.hourCycle === "h11" || e.hourCycle === "h12" ? a = "hour12" : a = "hour24" : a = r.hour12 ? "hour12" : "hour24");
    let o = Gs[a];
    if (typeof o == "object" && (o = o[i]), o) return {
      literal: !1,
      val: o
    };
  }
  function js(t) {
    return [`^${t.map((e) => e.regex).reduce((e, r) => `${e}(${r.source})`, "")}$`, t];
  }
  function Bs(t, e, r) {
    const n = t.match(e);
    if (n) {
      const s = {};
      let i = 1;
      for (const a in r) if (Te(r, a)) {
        const o = r[a], u = o.groups ? o.groups + 1 : 1;
        !o.literal && o.token && (s[o.token.val[0]] = o.deser(n.slice(i, i + u))), i += u;
      }
      return [n, s];
    } else return [n, {}];
  }
  function Qs(t) {
    const e = (s) => {
      switch (s) {
        case "S":
          return "millisecond";
        case "s":
          return "second";
        case "m":
          return "minute";
        case "h":
        case "H":
          return "hour";
        case "d":
          return "day";
        case "o":
          return "ordinal";
        case "L":
        case "M":
          return "month";
        case "y":
          return "year";
        case "E":
        case "c":
          return "weekday";
        case "W":
          return "weekNumber";
        case "k":
          return "weekYear";
        case "q":
          return "quarter";
        default:
          return null;
      }
    };
    let r = null, n;
    return M(t.z) || (r = me.create(t.z)), M(t.Z) || (r || (r = new ne(t.Z)), n = t.Z), M(t.q) || (t.M = (t.q - 1) * 3 + 1), M(t.h) || (t.h < 12 && t.a === 1 ? t.h += 12 : t.h === 12 && t.a === 0 && (t.h = 0)), t.G === 0 && t.y && (t.y = -t.y), M(t.u) || (t.S = It(t.u)), [
      Object.keys(t).reduce((s, i) => {
        const a = e(i);
        return a && (s[a] = t[i]), s;
      }, {}),
      r,
      n
    ];
  }
  var Ft = null;
  function Ks() {
    return Ft || (Ft = Y.fromMillis(1555555555555)), Ft;
  }
  function Xs(t, e) {
    if (t.literal) return t;
    const r = Br(ae.macroTokenToFormatOpts(t.val), e);
    return r == null || r.includes(void 0) ? t : r;
  }
  function Gr(t, e) {
    return Array.prototype.concat(...t.map((r) => Xs(r, e)));
  }
  var Jr = class {
    constructor(t, e) {
      if (this.locale = t, this.format = e, this.tokens = Gr(ae.parseFormat(e), t), this.units = this.tokens.map((r) => Ps(r, t)), this.disqualifyingUnit = this.units.find((r) => r.invalidReason), !this.disqualifyingUnit) {
        const [r, n] = js(this.units);
        this.regex = RegExp(r, "i"), this.handlers = n;
      }
    }
    explainFromTokens(t) {
      if (this.isValid) {
        const [e, r] = Bs(t, this.regex, this.handlers), [n, s, i] = r ? Qs(r) : [
          null,
          null,
          void 0
        ];
        if (Te(r, "a") && Te(r, "H")) throw new y("Can't include meridiem when specifying 24-hour format");
        return {
          input: t,
          tokens: this.tokens,
          regex: this.regex,
          rawMatches: e,
          matches: r,
          result: n,
          zone: s,
          specificOffset: i
        };
      } else
        return {
          input: t,
          tokens: this.tokens,
          invalidReason: this.invalidReason
        };
    }
    get isValid() {
      return !this.disqualifyingUnit;
    }
    get invalidReason() {
      return this.disqualifyingUnit ? this.disqualifyingUnit.invalidReason : null;
    }
  };
  function jr(t, e, r) {
    return new Jr(t, r).explainFromTokens(e);
  }
  function ei(t, e, r) {
    const { result: n, zone: s, specificOffset: i, invalidReason: a } = jr(t, e, r);
    return [
      n,
      s,
      i,
      a
    ];
  }
  function Br(t, e) {
    if (!t) return null;
    const r = ae.create(e, t).dtFormatter(Ks()), n = r.formatToParts(), s = r.resolvedOptions();
    return n.map((i) => Js(i, t, s));
  }
  var Vt = "Invalid DateTime", ti = 864e13;
  function ze(t) {
    return new ie("unsupported zone", `the zone "${t.name}" is not supported`);
  }
  function Wt(t) {
    return t.weekData === null && (t.weekData = Be(t.c)), t.weekData;
  }
  function Lt(t) {
    return t.localWeekData === null && (t.localWeekData = Be(t.c, t.loc.getMinDaysInFirstWeek(), t.loc.getStartOfWeek())), t.localWeekData;
  }
  function pe(t, e) {
    const r = {
      ts: t.ts,
      zone: t.zone,
      c: t.c,
      o: t.o,
      loc: t.loc,
      invalid: t.invalid
    };
    return new Y(D(D(D({}, r), e), {}, { old: r }));
  }
  function Qr(t, e, r) {
    let n = t - e * 60 * 1e3;
    const s = r.offset(n);
    if (e === s) return [n, e];
    n -= (s - e) * 60 * 1e3;
    const i = r.offset(n);
    return s === i ? [n, s] : [t - Math.min(s, i) * 60 * 1e3, Math.max(s, i)];
  }
  function st(t, e) {
    t += e * 60 * 1e3;
    const r = new Date(t);
    return {
      year: r.getUTCFullYear(),
      month: r.getUTCMonth() + 1,
      day: r.getUTCDate(),
      hour: r.getUTCHours(),
      minute: r.getUTCMinutes(),
      second: r.getUTCSeconds(),
      millisecond: r.getUTCMilliseconds()
    };
  }
  function it(t, e, r) {
    return Qr(Xe(t), e, r);
  }
  function Kr(t, e) {
    const r = t.o, n = t.c.year + Math.trunc(e.years), s = t.c.month + Math.trunc(e.months) + Math.trunc(e.quarters) * 3, i = D(D({}, t.c), {}, {
      year: n,
      month: s,
      day: Math.min(t.c.day, Ke(n, s)) + Math.trunc(e.days) + Math.trunc(e.weeks) * 7
    }), a = Q.fromObject({
      years: e.years - Math.trunc(e.years),
      quarters: e.quarters - Math.trunc(e.quarters),
      months: e.months - Math.trunc(e.months),
      weeks: e.weeks - Math.trunc(e.weeks),
      days: e.days - Math.trunc(e.days),
      hours: e.hours,
      minutes: e.minutes,
      seconds: e.seconds,
      milliseconds: e.milliseconds
    }).as("milliseconds");
    let [o, u] = Qr(Xe(i), r, t.zone);
    return a !== 0 && (o += a, u = t.zone.offset(o)), {
      ts: o,
      o: u
    };
  }
  function _e(t, e, r, n, s, i) {
    const { setZone: a, zone: o } = r;
    if (t && Object.keys(t).length !== 0 || e) {
      const u = e || o, g = Y.fromObject(t, D(D({}, r), {}, {
        zone: u,
        specificOffset: i
      }));
      return a ? g : g.setZone(o);
    } else return Y.invalid(new ie("unparsable", `the input "${s}" can't be parsed as ${n}`));
  }
  function at(t, e, r = !0) {
    return t.isValid ? ae.create(A.create("en-US"), {
      allowZ: r,
      forceSimple: !0
    }).formatDateTimeFromString(t, e) : null;
  }
  function $t(t, e, r) {
    const n = t.c.year > 9999 || t.c.year < 0;
    let s = "";
    if (n && t.c.year >= 0 && (s += "+"), s += G(t.c.year, n ? 6 : 4), r === "year") return s;
    if (e) {
      if (s += "-", s += G(t.c.month), r === "month") return s;
      s += "-";
    } else if (s += G(t.c.month), r === "month") return s;
    return s += G(t.c.day), s;
  }
  function Xr(t, e, r, n, s, i, a) {
    let o = !r || t.c.millisecond !== 0 || t.c.second !== 0, u = "";
    switch (a) {
      case "day":
      case "month":
      case "year":
        break;
      default:
        if (u += G(t.c.hour), a === "hour") break;
        if (e) {
          if (u += ":", u += G(t.c.minute), a === "minute") break;
          o && (u += ":", u += G(t.c.second));
        } else {
          if (u += G(t.c.minute), a === "minute") break;
          o && (u += G(t.c.second));
        }
        if (a === "second") break;
        o && (!n || t.c.millisecond !== 0) && (u += ".", u += G(t.c.millisecond, 3));
    }
    return s && (t.isOffsetFixed && t.offset === 0 && !i ? u += "Z" : t.o < 0 ? (u += "-", u += G(Math.trunc(-t.o / 60)), u += ":", u += G(Math.trunc(-t.o % 60))) : (u += "+", u += G(Math.trunc(t.o / 60)), u += ":", u += G(Math.trunc(t.o % 60)))), i && (u += "[" + t.zone.ianaName + "]"), u;
  }
  var en = {
    month: 1,
    day: 1,
    hour: 0,
    minute: 0,
    second: 0,
    millisecond: 0
  }, ri = {
    weekNumber: 1,
    weekday: 1,
    hour: 0,
    minute: 0,
    second: 0,
    millisecond: 0
  }, ni = {
    ordinal: 1,
    hour: 0,
    minute: 0,
    second: 0,
    millisecond: 0
  }, ot = [
    "year",
    "month",
    "day",
    "hour",
    "minute",
    "second",
    "millisecond"
  ], si = [
    "weekYear",
    "weekNumber",
    "weekday",
    "hour",
    "minute",
    "second",
    "millisecond"
  ], ii = [
    "year",
    "ordinal",
    "hour",
    "minute",
    "second",
    "millisecond"
  ];
  function ut(t) {
    const e = {
      year: "year",
      years: "year",
      month: "month",
      months: "month",
      day: "day",
      days: "day",
      hour: "hour",
      hours: "hour",
      minute: "minute",
      minutes: "minute",
      quarter: "quarter",
      quarters: "quarter",
      second: "second",
      seconds: "second",
      millisecond: "millisecond",
      milliseconds: "millisecond",
      weekday: "weekday",
      weekdays: "weekday",
      weeknumber: "weekNumber",
      weeksnumber: "weekNumber",
      weeknumbers: "weekNumber",
      weekyear: "weekYear",
      weekyears: "weekYear",
      ordinal: "ordinal"
    }[t.toLowerCase()];
    if (!e) throw new p(t);
    return e;
  }
  function tn(t) {
    switch (t.toLowerCase()) {
      case "localweekday":
      case "localweekdays":
        return "localWeekday";
      case "localweeknumber":
      case "localweeknumbers":
        return "localWeekNumber";
      case "localweekyear":
      case "localweekyears":
        return "localWeekYear";
      default:
        return ut(t);
    }
  }
  function ai(t) {
    if (Ue === void 0 && (Ue = R.now()), t.type !== "iana") return t.offset(Ue);
    const e = t.name;
    let r = Zt.get(e);
    return r === void 0 && (r = t.offset(Ue), Zt.set(e, r)), r;
  }
  function rn(t, e) {
    const r = fe(e.zone, R.defaultZone);
    if (!r.isValid) return Y.invalid(ze(r));
    const n = A.fromObject(e);
    let s, i;
    if (M(t.year))
      s = R.now();
    else {
      for (const u of ot) M(t[u]) && (t[u] = en[u]);
      const a = mr(t) || yr(t);
      if (a) return Y.invalid(a);
      const o = ai(r);
      [s, i] = it(t, o, r);
    }
    return new Y({
      ts: s,
      zone: r,
      loc: n,
      o: i
    });
  }
  function nn(t, e, r) {
    const n = M(r.round) ? !0 : r.round, s = M(r.rounding) ? "trunc" : r.rounding, i = (o, u) => (o = Et(o, n || r.calendary ? 0 : 2, r.calendary ? "round" : s), e.loc.clone(r).relFormatter(r).format(o, u)), a = (o) => r.calendary ? e.hasSame(t, o) ? 0 : e.startOf(o).diff(t.startOf(o), o).get(o) : e.diff(t, o).get(o);
    if (r.unit) return i(a(r.unit), r.unit);
    for (const o of r.units) {
      const u = a(o);
      if (Math.abs(u) >= 1) return i(u, o);
    }
    return i(t > e ? -0 : 0, r.units[r.units.length - 1]);
  }
  function sn(t) {
    let e = {}, r;
    return t.length > 0 && typeof t[t.length - 1] == "object" ? (e = t[t.length - 1], r = Array.from(t).slice(0, t.length - 1)) : r = Array.from(t), [e, r];
  }
  var Ue, Zt = /* @__PURE__ */ new Map(), Y = class q {
    constructor(e) {
      const r = e.zone || R.defaultZone;
      let n = e.invalid || (Number.isNaN(e.ts) ? new ie("invalid input") : null) || (r.isValid ? null : ze(r));
      this.ts = M(e.ts) ? R.now() : e.ts;
      let s = null, i = null;
      if (!n)
        if (e.old && e.old.ts === this.ts && e.old.zone.equals(r)) [s, i] = [e.old.c, e.old.o];
        else {
          const a = de(e.o) && !e.old ? e.o : r.offset(this.ts);
          s = st(this.ts, a), n = Number.isNaN(s.year) ? new ie("invalid input") : null, s = n ? null : s, i = n ? null : a;
        }
      this._zone = r, this.loc = e.loc || A.create(), this.invalid = n, this.weekData = null, this.localWeekData = null, this.c = s, this.o = i, this.isLuxonDateTime = !0;
    }
    static now() {
      return new q({});
    }
    static local() {
      const [e, r] = sn(arguments), [n, s, i, a, o, u, g] = r;
      return rn({
        year: n,
        month: s,
        day: i,
        hour: a,
        minute: o,
        second: u,
        millisecond: g
      }, e);
    }
    static utc() {
      const [e, r] = sn(arguments), [n, s, i, a, o, u, g] = r;
      return e.zone = ne.utcInstance, rn({
        year: n,
        month: s,
        day: i,
        hour: a,
        minute: o,
        second: u,
        millisecond: g
      }, e);
    }
    static fromJSDate(e, r = {}) {
      const n = Zn(e) ? e.valueOf() : NaN;
      if (Number.isNaN(n)) return q.invalid("invalid input");
      const s = fe(r.zone, R.defaultZone);
      return s.isValid ? new q({
        ts: n,
        zone: s,
        loc: A.fromObject(r)
      }) : q.invalid(ze(s));
    }
    static fromMillis(e, r = {}) {
      if (de(e)) return e < -864e13 || e > ti ? q.invalid("Timestamp out of range") : new q({
        ts: e,
        zone: fe(r.zone, R.defaultZone),
        loc: A.fromObject(r)
      });
      throw new w(`fromMillis requires a numerical input, but received a ${typeof e} with value ${e}`);
    }
    static fromSeconds(e, r = {}) {
      if (de(e)) return new q({
        ts: e * 1e3,
        zone: fe(r.zone, R.defaultZone),
        loc: A.fromObject(r)
      });
      throw new w("fromSeconds requires a numerical input");
    }
    static fromObject(e, r = {}) {
      e = e || {};
      const n = fe(r.zone, R.defaultZone);
      if (!n.isValid) return q.invalid(ze(n));
      const s = A.fromObject(r), i = tt(e, tn), { minDaysInFirstWeek: a, startOfWeek: o } = hr(i, s), u = R.now(), g = M(r.specificOffset) ? n.offset(u) : r.specificOffset, _ = !M(i.ordinal), x = !M(i.year), $ = !M(i.month) || !M(i.day), I = x || $, J = i.weekYear || i.weekNumber;
      if ((I || _) && J) throw new y("Can't mix weekYear/weekNumber units with year/month/day or ordinals");
      if ($ && _) throw new y("Can't mix ordinal dates with month/day");
      const xe = J || i.weekday && !I;
      let ue, be, He = st(u, g);
      xe ? (ue = si, be = ri, He = Be(He, a, o)) : _ ? (ue = ii, be = ni, He = Mt(He)) : (ue = ot, be = en);
      let an = !1;
      for (const Ye of ue) {
        const ci = i[Ye];
        M(ci) ? an ? i[Ye] = be[Ye] : i[Ye] = He[Ye] : an = !0;
      }
      const on = (xe ? Wn(i, a, o) : _ ? Ln(i) : mr(i)) || yr(i);
      if (on) return q.invalid(on);
      const [ui, li] = it(xe ? fr(i, a, o) : _ ? dr(i) : i, g, n), Re = new q({
        ts: ui,
        zone: n,
        o: li,
        loc: s
      });
      return i.weekday && I && e.weekday !== Re.weekday ? q.invalid("mismatched weekday", `you can't specify both a weekday of ${i.weekday} and a date of ${Re.toISO()}`) : Re.isValid ? Re : q.invalid(Re.invalid);
    }
    static fromISO(e, r = {}) {
      const [n, s] = Is(e);
      return _e(n, s, r, "ISO 8601", e);
    }
    static fromRFC2822(e, r = {}) {
      const [n, s] = Es(e);
      return _e(n, s, r, "RFC 2822", e);
    }
    static fromHTTP(e, r = {}) {
      const [n, s] = _s(e);
      return _e(n, s, r, "HTTP", r);
    }
    static fromFormat(e, r, n = {}) {
      if (M(e) || M(r)) throw new w("fromFormat requires an input string and a format");
      const { locale: s = null, numberingSystem: i = null } = n, [a, o, u, g] = ei(A.fromOpts({
        locale: s,
        numberingSystem: i,
        defaultToEN: !0
      }), e, r);
      return g ? q.invalid(g) : _e(a, o, n, `format ${r}`, e, u);
    }
    static fromString(e, r, n = {}) {
      return q.fromFormat(e, r, n);
    }
    static fromSQL(e, r = {}) {
      const [n, s] = Ls(e);
      return _e(n, s, r, "SQL", e);
    }
    static invalid(e, r = null) {
      if (!e) throw new w("need to specify a reason the DateTime is invalid");
      const n = e instanceof ie ? e : new ie(e, r);
      if (R.throwOnInvalid) throw new d(n);
      return new q({ invalid: n });
    }
    static isDateTime(e) {
      return e && e.isLuxonDateTime || !1;
    }
    static parseFormatForOpts(e, r = {}) {
      const n = Br(e, A.fromObject(r));
      return n ? n.map((s) => s ? s.val : null).join("") : null;
    }
    static expandFormat(e, r = {}) {
      return Gr(ae.parseFormat(e), A.fromObject(r)).map((n) => n.val).join("");
    }
    static resetCache() {
      Ue = void 0, Zt.clear();
    }
    get(e) {
      return this[e];
    }
    get isValid() {
      return this.invalid === null;
    }
    get invalidReason() {
      return this.invalid ? this.invalid.reason : null;
    }
    get invalidExplanation() {
      return this.invalid ? this.invalid.explanation : null;
    }
    get locale() {
      return this.isValid ? this.loc.locale : null;
    }
    get numberingSystem() {
      return this.isValid ? this.loc.numberingSystem : null;
    }
    get outputCalendar() {
      return this.isValid ? this.loc.outputCalendar : null;
    }
    get zone() {
      return this._zone;
    }
    get zoneName() {
      return this.isValid ? this.zone.name : null;
    }
    get year() {
      return this.isValid ? this.c.year : NaN;
    }
    get quarter() {
      return this.isValid ? Math.ceil(this.c.month / 3) : NaN;
    }
    get month() {
      return this.isValid ? this.c.month : NaN;
    }
    get day() {
      return this.isValid ? this.c.day : NaN;
    }
    get hour() {
      return this.isValid ? this.c.hour : NaN;
    }
    get minute() {
      return this.isValid ? this.c.minute : NaN;
    }
    get second() {
      return this.isValid ? this.c.second : NaN;
    }
    get millisecond() {
      return this.isValid ? this.c.millisecond : NaN;
    }
    get weekYear() {
      return this.isValid ? Wt(this).weekYear : NaN;
    }
    get weekNumber() {
      return this.isValid ? Wt(this).weekNumber : NaN;
    }
    get weekday() {
      return this.isValid ? Wt(this).weekday : NaN;
    }
    get isWeekend() {
      return this.isValid && this.loc.getWeekendDays().includes(this.weekday);
    }
    get localWeekday() {
      return this.isValid ? Lt(this).weekday : NaN;
    }
    get localWeekNumber() {
      return this.isValid ? Lt(this).weekNumber : NaN;
    }
    get localWeekYear() {
      return this.isValid ? Lt(this).weekYear : NaN;
    }
    get ordinal() {
      return this.isValid ? Mt(this.c).ordinal : NaN;
    }
    get monthShort() {
      return this.isValid ? Ae.months("short", { locObj: this.loc })[this.month - 1] : null;
    }
    get monthLong() {
      return this.isValid ? Ae.months("long", { locObj: this.loc })[this.month - 1] : null;
    }
    get weekdayShort() {
      return this.isValid ? Ae.weekdays("short", { locObj: this.loc })[this.weekday - 1] : null;
    }
    get weekdayLong() {
      return this.isValid ? Ae.weekdays("long", { locObj: this.loc })[this.weekday - 1] : null;
    }
    get offset() {
      return this.isValid ? +this.o : NaN;
    }
    get offsetNameShort() {
      return this.isValid ? this.zone.offsetName(this.ts, {
        format: "short",
        locale: this.locale
      }) : null;
    }
    get offsetNameLong() {
      return this.isValid ? this.zone.offsetName(this.ts, {
        format: "long",
        locale: this.locale
      }) : null;
    }
    get isOffsetFixed() {
      return this.isValid ? this.zone.isUniversal : null;
    }
    get isInDST() {
      return this.isOffsetFixed ? !1 : this.offset > this.set({
        month: 1,
        day: 1
      }).offset || this.offset > this.set({ month: 5 }).offset;
    }
    getPossibleOffsets() {
      if (!this.isValid || this.isOffsetFixed) return [this];
      const e = 864e5, r = 6e4, n = Xe(this.c), s = this.zone.offset(n - e), i = this.zone.offset(n + e), a = this.zone.offset(n - s * r), o = this.zone.offset(n - i * r);
      if (a === o) return [this];
      const u = n - a * r, g = n - o * r, _ = st(u, a), x = st(g, o);
      return _.hour === x.hour && _.minute === x.minute && _.second === x.second && _.millisecond === x.millisecond ? [pe(this, { ts: u }), pe(this, { ts: g })] : [this];
    }
    get isInLeapYear() {
      return Fe(this.year);
    }
    get daysInMonth() {
      return Ke(this.year, this.month);
    }
    get daysInYear() {
      return this.isValid ? ke(this.year) : NaN;
    }
    get weeksInWeekYear() {
      return this.isValid ? Ve(this.weekYear) : NaN;
    }
    get weeksInLocalWeekYear() {
      return this.isValid ? Ve(this.localWeekYear, this.loc.getMinDaysInFirstWeek(), this.loc.getStartOfWeek()) : NaN;
    }
    resolvedLocaleOptions(e = {}) {
      const { locale: r, numberingSystem: n, calendar: s } = ae.create(this.loc.clone(e), e).resolvedOptions(this);
      return {
        locale: r,
        numberingSystem: n,
        outputCalendar: s
      };
    }
    toUTC(e = 0, r = {}) {
      return this.setZone(ne.instance(e), r);
    }
    toLocal() {
      return this.setZone(R.defaultZone);
    }
    setZone(e, { keepLocalTime: r = !1, keepCalendarTime: n = !1 } = {}) {
      if (e = fe(e, R.defaultZone), e.equals(this.zone)) return this;
      if (e.isValid) {
        let s = this.ts;
        if (r || n) {
          const i = e.offset(this.ts), a = this.toObject();
          [s] = it(a, i, e);
        }
        return pe(this, {
          ts: s,
          zone: e
        });
      } else
        return q.invalid(ze(e));
    }
    reconfigure({ locale: e, numberingSystem: r, outputCalendar: n } = {}) {
      const s = this.loc.clone({
        locale: e,
        numberingSystem: r,
        outputCalendar: n
      });
      return pe(this, { loc: s });
    }
    setLocale(e) {
      return this.reconfigure({ locale: e });
    }
    set(e) {
      if (!this.isValid) return this;
      const r = tt(e, tn), { minDaysInFirstWeek: n, startOfWeek: s } = hr(r, this.loc), i = !M(r.weekYear) || !M(r.weekNumber) || !M(r.weekday), a = !M(r.ordinal), o = !M(r.year), u = !M(r.month) || !M(r.day), g = o || u, _ = r.weekYear || r.weekNumber;
      if ((g || a) && _) throw new y("Can't mix weekYear/weekNumber units with year/month/day or ordinals");
      if (u && a) throw new y("Can't mix ordinal dates with month/day");
      let x;
      i ? x = fr(D(D({}, Be(this.c, n, s)), r), n, s) : M(r.ordinal) ? (x = D(D({}, this.toObject()), r), M(r.day) && (x.day = Math.min(Ke(x.year, x.month), x.day))) : x = dr(D(D({}, Mt(this.c)), r));
      const [$, I] = it(x, this.o, this.zone);
      return pe(this, {
        ts: $,
        o: I
      });
    }
    plus(e) {
      if (!this.isValid) return this;
      const r = Q.fromDurationLike(e);
      return pe(this, Kr(this, r));
    }
    minus(e) {
      if (!this.isValid) return this;
      const r = Q.fromDurationLike(e).negate();
      return pe(this, Kr(this, r));
    }
    startOf(e, { useLocaleWeeks: r = !1 } = {}) {
      if (!this.isValid) return this;
      const n = {}, s = Q.normalizeUnit(e);
      switch (s) {
        case "years":
          n.month = 1;
        case "quarters":
        case "months":
          n.day = 1;
        case "weeks":
        case "days":
          n.hour = 0;
        case "hours":
          n.minute = 0;
        case "minutes":
          n.second = 0;
        case "seconds":
          n.millisecond = 0;
      }
      if (s === "weeks")
        if (r) {
          const i = this.loc.getStartOfWeek(), { weekday: a } = this;
          a < i && (n.weekNumber = this.weekNumber - 1), n.weekday = i;
        } else n.weekday = 1;
      return s === "quarters" && (n.month = (Math.ceil(this.month / 3) - 1) * 3 + 1), this.set(n);
    }
    endOf(e, r) {
      return this.isValid ? this.plus({ [e]: 1 }).startOf(e, r).minus(1) : this;
    }
    toFormat(e, r = {}) {
      return this.isValid ? ae.create(this.loc.redefaultToEN(r)).formatDateTimeFromString(this, e) : Vt;
    }
    toLocaleString(e = E, r = {}) {
      return this.isValid ? ae.create(this.loc.clone(r), e).formatDateTime(this) : Vt;
    }
    toLocaleParts(e = {}) {
      return this.isValid ? ae.create(this.loc.clone(e), e).formatDateTimeParts(this) : [];
    }
    toISO({ format: e = "extended", suppressSeconds: r = !1, suppressMilliseconds: n = !1, includeOffset: s = !0, extendedZone: i = !1, precision: a = "milliseconds" } = {}) {
      if (!this.isValid) return null;
      a = ut(a);
      const o = e === "extended";
      let u = $t(this, o, a);
      return ot.indexOf(a) >= 3 && (u += "T"), u += Xr(this, o, r, n, s, i, a), u;
    }
    toISODate({ format: e = "extended", precision: r = "day" } = {}) {
      return this.isValid ? $t(this, e === "extended", ut(r)) : null;
    }
    toISOWeekDate() {
      return at(this, "kkkk-'W'WW-c");
    }
    toISOTime({ suppressMilliseconds: e = !1, suppressSeconds: r = !1, includeOffset: n = !0, includePrefix: s = !1, extendedZone: i = !1, format: a = "extended", precision: o = "milliseconds" } = {}) {
      return this.isValid ? (o = ut(o), (s && ot.indexOf(o) >= 3 ? "T" : "") + Xr(this, a === "extended", r, e, n, i, o)) : null;
    }
    toRFC2822() {
      return at(this, "EEE, dd LLL yyyy HH:mm:ss ZZZ", !1);
    }
    toHTTP() {
      return at(this.toUTC(), "EEE, dd LLL yyyy HH:mm:ss 'GMT'");
    }
    toSQLDate() {
      return this.isValid ? $t(this, !0) : null;
    }
    toSQLTime({ includeOffset: e = !0, includeZone: r = !1, includeOffsetSpace: n = !0 } = {}) {
      let s = "HH:mm:ss.SSS";
      return (r || e) && (n && (s += " "), r ? s += "z" : e && (s += "ZZ")), at(this, s, !0);
    }
    toSQL(e = {}) {
      return this.isValid ? `${this.toSQLDate()} ${this.toSQLTime(e)}` : null;
    }
    toString() {
      return this.isValid ? this.toISO() : Vt;
    }
    [/* @__PURE__ */ Symbol.for("nodejs.util.inspect.custom")]() {
      return this.isValid ? `DateTime { ts: ${this.toISO()}, zone: ${this.zone.name}, locale: ${this.locale} }` : `DateTime { Invalid, reason: ${this.invalidReason} }`;
    }
    valueOf() {
      return this.toMillis();
    }
    toMillis() {
      return this.isValid ? this.ts : NaN;
    }
    toSeconds() {
      return this.isValid ? this.ts / 1e3 : NaN;
    }
    toUnixInteger() {
      return this.isValid ? Math.floor(this.ts / 1e3) : NaN;
    }
    toJSON() {
      return this.toISO();
    }
    toBSON() {
      return this.toJSDate();
    }
    toObject(e = {}) {
      if (!this.isValid) return {};
      const r = D({}, this.c);
      return e.includeConfig && (r.outputCalendar = this.outputCalendar, r.numberingSystem = this.loc.numberingSystem, r.locale = this.loc.locale), r;
    }
    toJSDate() {
      return new Date(this.isValid ? this.ts : NaN);
    }
    diff(e, r = "milliseconds", n = {}) {
      if (!this.isValid || !e.isValid) return Q.invalid("created by diffing an invalid DateTime");
      const s = D({
        locale: this.locale,
        numberingSystem: this.numberingSystem
      }, n), i = An(r).map(Q.normalizeUnit), a = e.valueOf() > this.valueOf(), o = qs(a ? this : e, a ? e : this, i, s);
      return a ? o.negate() : o;
    }
    diffNow(e = "milliseconds", r = {}) {
      return this.diff(q.now(), e, r);
    }
    until(e) {
      return this.isValid ? Ze.fromDateTimes(this, e) : this;
    }
    hasSame(e, r, n) {
      if (!this.isValid) return !1;
      const s = e.valueOf(), i = this.setZone(e.zone, { keepLocalTime: !0 });
      return i.startOf(r, n) <= s && s <= i.endOf(r, n);
    }
    equals(e) {
      return this.isValid && e.isValid && this.valueOf() === e.valueOf() && this.zone.equals(e.zone) && this.loc.equals(e.loc);
    }
    toRelative(e = {}) {
      if (!this.isValid) return null;
      const r = e.base || q.fromObject({}, { zone: this.zone }), n = e.padding ? this < r ? -e.padding : e.padding : 0;
      let s = [
        "years",
        "months",
        "days",
        "hours",
        "minutes",
        "seconds"
      ], i = e.unit;
      return Array.isArray(e.unit) && (s = e.unit, i = void 0), nn(r, this.plus(n), D(D({}, e), {}, {
        numeric: "always",
        units: s,
        unit: i
      }));
    }
    toRelativeCalendar(e = {}) {
      return this.isValid ? nn(e.base || q.fromObject({}, { zone: this.zone }), this, D(D({}, e), {}, {
        numeric: "auto",
        units: [
          "years",
          "months",
          "days"
        ],
        calendary: !0
      })) : null;
    }
    static min(...e) {
      if (!e.every(q.isDateTime)) throw new w("min requires all arguments be DateTimes");
      return gr(e, (r) => r.valueOf(), Math.min);
    }
    static max(...e) {
      if (!e.every(q.isDateTime)) throw new w("max requires all arguments be DateTimes");
      return gr(e, (r) => r.valueOf(), Math.max);
    }
    static fromFormatExplain(e, r, n = {}) {
      const { locale: s = null, numberingSystem: i = null } = n;
      return jr(A.fromOpts({
        locale: s,
        numberingSystem: i,
        defaultToEN: !0
      }), e, r);
    }
    static fromStringExplain(e, r, n = {}) {
      return q.fromFormatExplain(e, r, n);
    }
    static buildFormatParser(e, r = {}) {
      const { locale: n = null, numberingSystem: s = null } = r, i = A.fromOpts({
        locale: n,
        numberingSystem: s,
        defaultToEN: !0
      });
      return new Jr(i, e);
    }
    static fromFormatParser(e, r, n = {}) {
      if (M(e) || M(r)) throw new w("fromFormatParser requires an input string and a format parser");
      const { locale: s = null, numberingSystem: i = null } = n, a = A.fromOpts({
        locale: s,
        numberingSystem: i,
        defaultToEN: !0
      });
      if (!a.equals(r.locale)) throw new w(`fromFormatParser called with a locale of ${a}, but the format parser was created for ${r.locale}`);
      const { result: o, zone: u, specificOffset: g, invalidReason: _ } = r.explainFromTokens(e);
      return _ ? q.invalid(_) : _e(o, u, n, `format ${r.format}`, e, g);
    }
    static get DATE_SHORT() {
      return E;
    }
    static get DATE_MED() {
      return U;
    }
    static get DATE_MED_WITH_WEEKDAY() {
      return N;
    }
    static get DATE_FULL() {
      return W;
    }
    static get DATE_HUGE() {
      return b;
    }
    static get TIME_SIMPLE() {
      return L;
    }
    static get TIME_WITH_SECONDS() {
      return V;
    }
    static get TIME_WITH_SHORT_OFFSET() {
      return H;
    }
    static get TIME_WITH_LONG_OFFSET() {
      return P;
    }
    static get TIME_24_SIMPLE() {
      return Z;
    }
    static get TIME_24_WITH_SECONDS() {
      return C;
    }
    static get TIME_24_WITH_SHORT_OFFSET() {
      return j;
    }
    static get TIME_24_WITH_LONG_OFFSET() {
      return re;
    }
    static get DATETIME_SHORT() {
      return zt;
    }
    static get DATETIME_SHORT_WITH_SECONDS() {
      return Ut;
    }
    static get DATETIME_MED() {
      return qt;
    }
    static get DATETIME_MED_WITH_SECONDS() {
      return Ht;
    }
    static get DATETIME_MED_WITH_WEEKDAY() {
      return mn;
    }
    static get DATETIME_FULL() {
      return Rt;
    }
    static get DATETIME_FULL_WITH_SECONDS() {
      return Yt;
    }
    static get DATETIME_HUGE() {
      return Pt;
    }
    static get DATETIME_HUGE_WITH_SECONDS() {
      return Gt;
    }
  };
  function qe(t) {
    if (Y.isDateTime(t)) return t;
    if (t && t.valueOf && de(t.valueOf())) return Y.fromJSDate(t);
    if (t && typeof t == "object") return Y.fromObject(t);
    throw new w(`Unknown datetime argument: ${t}, of type ${typeof t}`);
  }
  var oi = "3.7.2";
  m.DateTime = Y, m.Duration = Q, m.FixedOffsetZone = ne, m.IANAZone = me, m.Info = Ae, m.Interval = Ze, m.InvalidZone = Qt, m.Settings = R, m.SystemZone = ft, m.VERSION = oi, m.Zone = we;
})), pi = /* @__PURE__ */ ge(((m, T) => {
  var h = vi();
  l.prototype.addYear = function() {
    this._date = this._date.plus({ years: 1 });
  }, l.prototype.addMonth = function() {
    this._date = this._date.plus({ months: 1 }).startOf("month");
  }, l.prototype.addDay = function() {
    this._date = this._date.plus({ days: 1 }).startOf("day");
  }, l.prototype.addHour = function() {
    var d = this._date;
    this._date = this._date.plus({ hours: 1 }).startOf("hour"), this._date <= d && (this._date = this._date.plus({ hours: 1 }));
  }, l.prototype.addMinute = function() {
    var d = this._date;
    this._date = this._date.plus({ minutes: 1 }).startOf("minute"), this._date < d && (this._date = this._date.plus({ hours: 1 }));
  }, l.prototype.addSecond = function() {
    var d = this._date;
    this._date = this._date.plus({ seconds: 1 }).startOf("second"), this._date < d && (this._date = this._date.plus({ hours: 1 }));
  }, l.prototype.subtractYear = function() {
    this._date = this._date.minus({ years: 1 });
  }, l.prototype.subtractMonth = function() {
    this._date = this._date.minus({ months: 1 }).endOf("month").startOf("second");
  }, l.prototype.subtractDay = function() {
    this._date = this._date.minus({ days: 1 }).endOf("day").startOf("second");
  }, l.prototype.subtractHour = function() {
    var d = this._date;
    this._date = this._date.minus({ hours: 1 }).endOf("hour").startOf("second"), this._date >= d && (this._date = this._date.minus({ hours: 1 }));
  }, l.prototype.subtractMinute = function() {
    var d = this._date;
    this._date = this._date.minus({ minutes: 1 }).endOf("minute").startOf("second"), this._date > d && (this._date = this._date.minus({ hours: 1 }));
  }, l.prototype.subtractSecond = function() {
    var d = this._date;
    this._date = this._date.minus({ seconds: 1 }).startOf("second"), this._date > d && (this._date = this._date.minus({ hours: 1 }));
  }, l.prototype.getDate = function() {
    return this._date.day;
  }, l.prototype.getFullYear = function() {
    return this._date.year;
  }, l.prototype.getDay = function() {
    var d = this._date.weekday;
    return d == 7 ? 0 : d;
  }, l.prototype.getMonth = function() {
    return this._date.month - 1;
  }, l.prototype.getHours = function() {
    return this._date.hour;
  }, l.prototype.getMinutes = function() {
    return this._date.minute;
  }, l.prototype.getSeconds = function() {
    return this._date.second;
  }, l.prototype.getMilliseconds = function() {
    return this._date.millisecond;
  }, l.prototype.getTime = function() {
    return this._date.valueOf();
  }, l.prototype.getUTCDate = function() {
    return this._getUTC().day;
  }, l.prototype.getUTCFullYear = function() {
    return this._getUTC().year;
  }, l.prototype.getUTCDay = function() {
    var d = this._getUTC().weekday;
    return d == 7 ? 0 : d;
  }, l.prototype.getUTCMonth = function() {
    return this._getUTC().month - 1;
  }, l.prototype.getUTCHours = function() {
    return this._getUTC().hour;
  }, l.prototype.getUTCMinutes = function() {
    return this._getUTC().minute;
  }, l.prototype.getUTCSeconds = function() {
    return this._getUTC().second;
  }, l.prototype.toISOString = function() {
    return this._date.toUTC().toISO();
  }, l.prototype.toJSON = function() {
    return this._date.toJSON();
  }, l.prototype.setDate = function(d) {
    this._date = this._date.set({ day: d });
  }, l.prototype.setFullYear = function(d) {
    this._date = this._date.set({ year: d });
  }, l.prototype.setDay = function(d) {
    this._date = this._date.set({ weekday: d });
  }, l.prototype.setMonth = function(d) {
    this._date = this._date.set({ month: d + 1 });
  }, l.prototype.setHours = function(d) {
    this._date = this._date.set({ hour: d });
  }, l.prototype.setMinutes = function(d) {
    this._date = this._date.set({ minute: d });
  }, l.prototype.setSeconds = function(d) {
    this._date = this._date.set({ second: d });
  }, l.prototype.setMilliseconds = function(d) {
    this._date = this._date.set({ millisecond: d });
  }, l.prototype._getUTC = function() {
    return this._date.toUTC();
  }, l.prototype.toString = function() {
    return this.toDate().toString();
  }, l.prototype.toDate = function() {
    return this._date.toJSDate();
  }, l.prototype.isLastDayOfMonth = function() {
    var d = this._date.plus({ days: 1 }).startOf("day");
    return this._date.month !== d.month;
  }, l.prototype.isLastWeekdayOfMonth = function() {
    var d = this._date.plus({ days: 7 }).startOf("day");
    return this._date.month !== d.month;
  };
  function l(d, c) {
    var v = { zone: c };
    if (d ? d instanceof l ? this._date = d._date : d instanceof Date ? this._date = h.DateTime.fromJSDate(d, v) : typeof d == "number" ? this._date = h.DateTime.fromMillis(d, v) : typeof d == "string" && (this._date = h.DateTime.fromISO(d, v), this._date.isValid || (this._date = h.DateTime.fromRFC2822(d, v)), this._date.isValid || (this._date = h.DateTime.fromSQL(d, v)), this._date.isValid || (this._date = h.DateTime.fromFormat(d, "EEE, d MMM yyyy HH:mm:ss", v))) : this._date = h.DateTime.local(), !this._date || !this._date.isValid) throw new Error("CronDate: unhandled timestamp: " + JSON.stringify(d));
    c && c !== this._date.zoneName && (this._date = this._date.setZone(c));
  }
  T.exports = l;
})), gi = /* @__PURE__ */ ge(((m, T) => {
  function h(v) {
    return {
      start: v,
      count: 1
    };
  }
  function l(v, y) {
    v.end = y, v.step = y - v.start, v.count = 2;
  }
  function d(v, y, p) {
    y && (y.count === 2 ? (v.push(h(y.start)), v.push(h(y.end))) : v.push(y)), p && v.push(p);
  }
  function c(v) {
    for (var y = [], p = void 0, w = 0; w < v.length; w++) {
      var S = v[w];
      typeof S != "number" ? (d(y, p, h(S)), p = void 0) : p ? p.count === 1 ? l(p, S) : p.step === S - p.end ? (p.count++, p.end = S) : p.count === 2 ? (y.push(h(p.start)), p = h(p.end), l(p, S)) : (d(y, p), p = h(S)) : p = h(S);
    }
    return d(y, p), y;
  }
  T.exports = c;
})), wi = /* @__PURE__ */ ge(((m, T) => {
  var h = gi();
  function l(d, c, v) {
    var y = h(d);
    if (y.length === 1) {
      var p = y[0], w = p.step;
      if (w === 1 && p.start === c && p.end === v) return "*";
      if (w !== 1 && p.start === c && p.end === v - w + 1) return "*/" + w;
    }
    for (var S = [], f = 0, k = y.length; f < k; ++f) {
      var O = y[f];
      if (O.count === 1) {
        S.push(O.start);
        continue;
      }
      var w = O.step;
      if (O.step === 1) {
        S.push(O.start + "-" + O.end);
        continue;
      }
      var E = O.start == 0 ? O.count - 1 : O.count;
      O.step * E > O.end ? S = S.concat(Array.from({ length: O.end - O.start + 1 }).map(function(N, W) {
        var b = O.start + W;
        return (b - O.start) % O.step === 0 ? b : null;
      }).filter(function(N) {
        return N != null;
      })) : O.end === v - O.step + 1 ? S.push(O.start + "/" + O.step) : S.push(O.start + "-" + O.end + "/" + O.step);
    }
    return S.join(",");
  }
  T.exports = l;
})), Ti = /* @__PURE__ */ ge(((m, T) => {
  var h = pi(), l = wi(), d = 1e4;
  function c(v, y) {
    this._options = y, this._utc = y.utc || !1, this._tz = this._utc ? "UTC" : y.tz, this._currentDate = new h(y.currentDate, this._tz), this._startDate = y.startDate ? new h(y.startDate, this._tz) : null, this._endDate = y.endDate ? new h(y.endDate, this._tz) : null, this._isIterator = y.iterator || !1, this._hasIterated = !1, this._nthDayOfWeek = y.nthDayOfWeek || 0, this.fields = c._freezeFields(v);
  }
  c.map = [
    "second",
    "minute",
    "hour",
    "dayOfMonth",
    "month",
    "dayOfWeek"
  ], c.predefined = {
    "@yearly": "0 0 1 1 *",
    "@monthly": "0 0 1 * *",
    "@weekly": "0 0 * * 0",
    "@daily": "0 0 * * *",
    "@hourly": "0 * * * *"
  }, c.constraints = [
    {
      min: 0,
      max: 59,
      chars: []
    },
    {
      min: 0,
      max: 59,
      chars: []
    },
    {
      min: 0,
      max: 23,
      chars: []
    },
    {
      min: 1,
      max: 31,
      chars: ["L"]
    },
    {
      min: 1,
      max: 12,
      chars: []
    },
    {
      min: 0,
      max: 7,
      chars: ["L"]
    }
  ], c.daysInMonth = [
    31,
    29,
    31,
    30,
    31,
    30,
    31,
    31,
    30,
    31,
    30,
    31
  ], c.aliases = {
    month: {
      jan: 1,
      feb: 2,
      mar: 3,
      apr: 4,
      may: 5,
      jun: 6,
      jul: 7,
      aug: 8,
      sep: 9,
      oct: 10,
      nov: 11,
      dec: 12
    },
    dayOfWeek: {
      sun: 0,
      mon: 1,
      tue: 2,
      wed: 3,
      thu: 4,
      fri: 5,
      sat: 6
    }
  }, c.parseDefaults = [
    "0",
    "*",
    "*",
    "*",
    "*",
    "*"
  ], c.standardValidCharacters = /^[,*\d/-]+$/, c.dayOfWeekValidCharacters = /^[?,*\dL#/-]+$/, c.dayOfMonthValidCharacters = /^[?,*\dL/-]+$/, c.validCharacters = {
    second: c.standardValidCharacters,
    minute: c.standardValidCharacters,
    hour: c.standardValidCharacters,
    dayOfMonth: c.dayOfMonthValidCharacters,
    month: c.standardValidCharacters,
    dayOfWeek: c.dayOfWeekValidCharacters
  }, c._isValidConstraintChar = function(y, p) {
    return typeof p != "string" ? !1 : y.chars.some(function(w) {
      return p.indexOf(w) > -1;
    });
  }, c._parseField = function(y, p, w) {
    switch (y) {
      case "month":
      case "dayOfWeek":
        var S = c.aliases[y];
        p = p.replace(/[a-z]{3}/gi, function(E) {
          if (E = E.toLowerCase(), typeof S[E] != "undefined") return S[E];
          throw new Error('Validation error, cannot resolve alias "' + E + '"');
        });
    }
    if (!c.validCharacters[y].test(p)) throw new Error("Invalid characters, got value: " + p);
    p.indexOf("*") !== -1 ? p = p.replace(/\*/g, w.min + "-" + w.max) : p.indexOf("?") !== -1 && (p = p.replace(/\?/g, w.min + "-" + w.max));
    function f(E) {
      var U = [];
      function N(V) {
        if (V instanceof Array) for (var H = 0, P = V.length; H < P; H++) {
          var Z = V[H];
          if (c._isValidConstraintChar(w, Z)) {
            U.push(Z);
            continue;
          }
          if (typeof Z != "number" || Number.isNaN(Z) || Z < w.min || Z > w.max) throw new Error("Constraint error, got value " + Z + " expected range " + w.min + "-" + w.max);
          U.push(Z);
        }
        else {
          if (c._isValidConstraintChar(w, V)) {
            U.push(V);
            return;
          }
          var C = +V;
          if (Number.isNaN(C) || C < w.min || C > w.max) throw new Error("Constraint error, got value " + V + " expected range " + w.min + "-" + w.max);
          y === "dayOfWeek" && (C = C % 7), U.push(C);
        }
      }
      var W = E.split(",");
      if (!W.every(function(V) {
        return V.length > 0;
      })) throw new Error("Invalid list value format");
      if (W.length > 1) for (var b = 0, L = W.length; b < L; b++) N(k(W[b]));
      else N(k(E));
      return U.sort(c._sortCompareFn), U;
    }
    function k(E) {
      var U = 1, N = E.split("/");
      if (N.length > 2) throw new Error("Invalid repeat: " + E);
      return N.length > 1 ? (N[0] == +N[0] && (N = [N[0] + "-" + w.max, N[1]]), O(N[0], N[N.length - 1])) : O(E, U);
    }
    function O(E, U) {
      var N = [], W = E.split("-");
      if (W.length > 1) {
        if (W.length < 2) return +E;
        if (!W[0].length) {
          if (!W[1].length) throw new Error("Invalid range: " + E);
          return +E;
        }
        var b = +W[0], L = +W[1];
        if (Number.isNaN(b) || Number.isNaN(L) || b < w.min || L > w.max) throw new Error("Constraint error, got range " + b + "-" + L + " expected range " + w.min + "-" + w.max);
        if (b > L) throw new Error("Invalid range: " + E);
        var V = +U;
        if (Number.isNaN(V) || V <= 0) throw new Error("Constraint error, cannot repeat at every " + V + " time.");
        y === "dayOfWeek" && L % 7 === 0 && N.push(0);
        for (var H = b, P = L; H <= P; H++) N.indexOf(H) === -1 && V > 0 && V % U === 0 ? (V = 1, N.push(H)) : V++;
        return N;
      }
      return Number.isNaN(+E) ? E : +E;
    }
    return f(p);
  }, c._sortCompareFn = function(v, y) {
    var p = typeof v == "number", w = typeof y == "number";
    return p && w ? v - y : !p && w ? 1 : p && !w ? -1 : v.localeCompare(y);
  }, c._handleMaxDaysInMonth = function(v) {
    if (v.month.length === 1) {
      var y = c.daysInMonth[v.month[0] - 1];
      if (v.dayOfMonth[0] > y) throw new Error("Invalid explicit day of month definition");
      return v.dayOfMonth.filter(function(p) {
        return p === "L" ? !0 : p <= y;
      }).sort(c._sortCompareFn);
    }
  }, c._freezeFields = function(v) {
    for (var y = 0, p = c.map.length; y < p; ++y) {
      var w = c.map[y], S = v[w];
      v[w] = Object.freeze(S);
    }
    return Object.freeze(v);
  }, c.prototype._applyTimezoneShift = function(v, y, p) {
    if (p === "Month" || p === "Day") {
      var w = v.getTime();
      v[y + p](), w === v.getTime() && (v.getMinutes() === 0 && v.getSeconds() === 0 ? v.addHour() : v.getMinutes() === 59 && v.getSeconds() === 59 && v.subtractHour());
    } else {
      var S = v.getHours();
      v[y + p]();
      var f = v.getHours(), k = f - S;
      k === 2 ? this.fields.hour.length !== 24 && (this._dstStart = f) : k === 0 && v.getMinutes() === 0 && v.getSeconds() === 0 && this.fields.hour.length !== 24 && (this._dstEnd = f);
    }
  }, c.prototype._findSchedule = function(y) {
    function p(Z, C) {
      for (var j = 0, re = C.length; j < re; j++) if (C[j] >= Z) return C[j] === Z;
      return C[0] === Z;
    }
    function w(Z, C) {
      if (C < 6) {
        if (Z.getDate() < 8 && C === 1) return !0;
        var j = Z.getDate() % 7 ? 1 : 0, re = Z.getDate() - Z.getDate() % 7;
        return Math.floor(re / 7) + j === C;
      }
      return !1;
    }
    function S(Z) {
      return Z.length > 0 && Z.some(function(C) {
        return typeof C == "string" && C.indexOf("L") >= 0;
      });
    }
    y = y || !1;
    var f = y ? "subtract" : "add", k = new h(this._currentDate, this._tz), O = this._startDate, E = this._endDate, U = k.getTime(), N = 0;
    function W(Z) {
      return Z.some(function(C) {
        if (!S([C])) return !1;
        var j = Number.parseInt(C[0]) % 7;
        if (Number.isNaN(j)) throw new Error("Invalid last weekday of the month expression: " + C);
        return k.getDay() === j && k.isLastWeekdayOfMonth();
      });
    }
    for (; N < d; ) {
      if (N++, y) {
        if (O && k.getTime() - O.getTime() < 0) throw new Error("Out of the timespan range");
      } else if (E && E.getTime() - k.getTime() < 0) throw new Error("Out of the timespan range");
      var b = p(k.getDate(), this.fields.dayOfMonth);
      S(this.fields.dayOfMonth) && (b = b || k.isLastDayOfMonth());
      var L = p(k.getDay(), this.fields.dayOfWeek);
      S(this.fields.dayOfWeek) && (L = L || W(this.fields.dayOfWeek));
      var V = this.fields.dayOfMonth.length >= c.daysInMonth[k.getMonth()], H = this.fields.dayOfWeek.length === c.constraints[5].max - c.constraints[5].min + 1, P = k.getHours();
      if (!b && (!L || H)) {
        this._applyTimezoneShift(k, f, "Day");
        continue;
      }
      if (!V && H && !b) {
        this._applyTimezoneShift(k, f, "Day");
        continue;
      }
      if (V && !H && !L) {
        this._applyTimezoneShift(k, f, "Day");
        continue;
      }
      if (this._nthDayOfWeek > 0 && !w(k, this._nthDayOfWeek)) {
        this._applyTimezoneShift(k, f, "Day");
        continue;
      }
      if (!p(k.getMonth() + 1, this.fields.month)) {
        this._applyTimezoneShift(k, f, "Month");
        continue;
      }
      if (p(P, this.fields.hour)) {
        if (this._dstEnd === P && !y) {
          this._dstEnd = null, this._applyTimezoneShift(k, "add", "Hour");
          continue;
        }
      } else if (this._dstStart !== P) {
        this._dstStart = null, this._applyTimezoneShift(k, f, "Hour");
        continue;
      } else if (!p(P - 1, this.fields.hour)) {
        k[f + "Hour"]();
        continue;
      }
      if (!p(k.getMinutes(), this.fields.minute)) {
        this._applyTimezoneShift(k, f, "Minute");
        continue;
      }
      if (!p(k.getSeconds(), this.fields.second)) {
        this._applyTimezoneShift(k, f, "Second");
        continue;
      }
      if (U === k.getTime()) {
        f === "add" || k.getMilliseconds() === 0 ? this._applyTimezoneShift(k, f, "Second") : k.setMilliseconds(0);
        continue;
      }
      break;
    }
    if (N >= d) throw new Error("Invalid expression, loop limit exceeded");
    return this._currentDate = new h(k, this._tz), this._hasIterated = !0, k;
  }, c.prototype.next = function() {
    var y = this._findSchedule();
    return this._isIterator ? {
      value: y,
      done: !this.hasNext()
    } : y;
  }, c.prototype.prev = function() {
    var y = this._findSchedule(!0);
    return this._isIterator ? {
      value: y,
      done: !this.hasPrev()
    } : y;
  }, c.prototype.hasNext = function() {
    var v = this._currentDate, y = this._hasIterated;
    try {
      return this._findSchedule(), !0;
    } catch (p) {
      return !1;
    } finally {
      this._currentDate = v, this._hasIterated = y;
    }
  }, c.prototype.hasPrev = function() {
    var v = this._currentDate, y = this._hasIterated;
    try {
      return this._findSchedule(!0), !0;
    } catch (p) {
      return !1;
    } finally {
      this._currentDate = v, this._hasIterated = y;
    }
  }, c.prototype.iterate = function(y, p) {
    var w = [];
    if (y >= 0) for (var S = 0, f = y; S < f; S++) try {
      var k = this.next();
      w.push(k), p && p(k, S);
    } catch (O) {
      break;
    }
    else for (var S = 0, f = y; S > f; S--) try {
      var k = this.prev();
      w.push(k), p && p(k, S);
    } catch (U) {
      break;
    }
    return w;
  }, c.prototype.reset = function(y) {
    this._currentDate = new h(y || this._options.currentDate);
  }, c.prototype.stringify = function(y) {
    for (var p = [], w = y ? 0 : 1, S = c.map.length; w < S; ++w) {
      var f = c.map[w], k = this.fields[f], O = c.constraints[w];
      f === "dayOfMonth" && this.fields.month.length === 1 ? O = {
        min: 1,
        max: c.daysInMonth[this.fields.month[0] - 1]
      } : f === "dayOfWeek" && (O = {
        min: 0,
        max: 6
      }, k = k[k.length - 1] === 7 ? k.slice(0, -1) : k), p.push(l(k, O.min, O.max));
    }
    return p.join(" ");
  }, c.parse = function(y, p) {
    var w = this;
    typeof p == "function" && (p = {});
    function S(f, k) {
      k || (k = {}), typeof k.currentDate == "undefined" && (k.currentDate = new h(void 0, w._tz)), c.predefined[f] && (f = c.predefined[f]);
      var O = [], E = (f + "").trim().split(/\s+/);
      if (E.length > 6) throw new Error("Invalid cron expression");
      for (var U = c.map.length - E.length, N = 0, W = c.map.length; N < W; ++N) {
        var b = c.map[N], L = E[E.length > W ? N : N - U];
        if (N < U || !L) O.push(c._parseField(b, c.parseDefaults[N], c.constraints[N]));
        else {
          var V = b === "dayOfWeek" ? Z(L) : L;
          O.push(c._parseField(b, V, c.constraints[N]));
        }
      }
      for (var H = {}, N = 0, W = c.map.length; N < W; N++) {
        var P = c.map[N];
        H[P] = O[N];
      }
      return H.dayOfMonth = c._handleMaxDaysInMonth(H) || H.dayOfMonth, new c(H, k);
      function Z(C) {
        var j = C.split("#");
        if (j.length > 1) {
          var re = +j[j.length - 1];
          if (/,/.test(C)) throw new Error("Constraint error, invalid dayOfWeek `#` and `,` special characters are incompatible");
          if (/\//.test(C)) throw new Error("Constraint error, invalid dayOfWeek `#` and `/` special characters are incompatible");
          if (/-/.test(C)) throw new Error("Constraint error, invalid dayOfWeek `#` and `-` special characters are incompatible");
          if (j.length > 2 || Number.isNaN(re) || re < 1 || re > 5) throw new Error("Constraint error, invalid dayOfWeek occurrence number (#)");
          return k.nthDayOfWeek = re, j[0];
        }
        return C;
      }
    }
    return S(y, p);
  }, c.fieldsToExpression = function(y, p) {
    function w(W, b, L) {
      if (!b) throw new Error("Validation error, Field " + W + " is missing");
      if (b.length === 0) throw new Error("Validation error, Field " + W + " contains no values");
      for (var V = 0, H = b.length; V < H; V++) {
        var P = b[V];
        if (!c._isValidConstraintChar(L, P) && (typeof P != "number" || Number.isNaN(P) || P < L.min || P > L.max))
          throw new Error("Constraint error, got value " + P + " expected range " + L.min + "-" + L.max);
      }
    }
    for (var S = {}, f = 0, k = c.map.length; f < k; ++f) {
      var O = c.map[f], E = y[O];
      w(O, E, c.constraints[f]);
      for (var U = [], N = -1; ++N < E.length; ) U[N] = E[N];
      if (E = U.sort(c._sortCompareFn).filter(function(W, b, L) {
        return !b || W !== L[b - 1];
      }), E.length !== U.length) throw new Error("Validation error, Field " + O + " contains duplicate values");
      S[O] = E;
    }
    return S.dayOfMonth = c._handleMaxDaysInMonth(S) || S.dayOfMonth, new c(S, p || {});
  }, T.exports = c;
})), ki = /* @__PURE__ */ ge(((m, T) => {
  T.exports = {};
})), Si = /* @__PURE__ */ ge(((m, T) => {
  var h = Ti();
  function l() {
  }
  l._parseEntry = function(c) {
    var v = c.split(" ");
    if (v.length === 6) return { interval: h.parse(c) };
    if (v.length > 6) return {
      interval: h.parse(v.slice(0, 6).join(" ")),
      command: v.slice(6, v.length)
    };
    throw new Error("Invalid entry: " + c);
  }, l.parseExpression = function(c, v) {
    return h.parse(c, v);
  }, l.fieldsToExpression = function(c, v) {
    return h.fieldsToExpression(c, v);
  }, l.parseString = function(c) {
    for (var v = c.split(`
`), y = {
      variables: {},
      expressions: [],
      errors: {}
    }, p = 0, w = v.length; p < w; p++) {
      var S = v[p], f = null, k = S.trim();
      if (k.length > 0) {
        if (k.match(/^#/)) continue;
        if (f = k.match(/^(.*)=(.*)$/)) y.variables[f[1]] = f[2];
        else {
          var O = null;
          try {
            O = l._parseEntry("0 " + k), y.expressions.push(O.interval);
          } catch (E) {
            y.errors[k] = E;
          }
        }
      }
    }
    return y;
  }, l.parseFile = function(c, v) {
    ki().readFile(c, function(y, p) {
      if (y) {
        v(y);
        return;
      }
      return v(null, l.parseString(p.toString()));
    });
  }, T.exports = l;
})), ce = /* @__PURE__ */ fn(di()), Oi = /* @__PURE__ */ fn(Si()), Di = "__custom__";
function hn(m) {
  const T = m ? (0, ce.default)(m) : null;
  return !T || !T.isValid() ? {
    second: 0,
    minute: 0,
    hour: 0
  } : {
    second: T.second(),
    minute: T.minute(),
    hour: T.hour()
  };
}
function Mi(m) {
  const { second: T, minute: h, hour: l } = hn(m);
  return [
    {
      label: "每分钟",
      value: `${T} 0/1 * * * ?`,
      type: "minute"
    },
    {
      label: "每小时",
      value: `${T} ${h} 0/1 * * ?`,
      type: "hour"
    },
    {
      label: "每天",
      value: `${T} ${h} ${l} * * ?`,
      type: "day"
    },
    {
      label: "自定义",
      value: Di,
      type: "custom"
    }
  ];
}
function Li(m, T) {
  const h = Mi(m), l = h.find((d) => d.type === T);
  return l ? l.value : h[0].value;
}
function Ni(m, T) {
  const h = [];
  if (!m) return h;
  const l = T && T.count && T.count > 0 ? T.count : 10, d = T ? ln(T.startTime) : void 0, c = T ? ln(T.endTime) : void 0;
  if (d && c && (0, ce.default)(d).isAfter(c)) return h;
  const v = { currentDate: d ? (0, ce.default)(d).subtract(1, "second").toDate() : /* @__PURE__ */ new Date() };
  d && (v.startDate = d), c && (v.endDate = c);
  try {
    const y = Oi.default.parseExpression(m, v);
    for (let p = 0; p < l; p++) {
      let w;
      try {
        w = y.next();
      } catch (f) {
        break;
      }
      const S = typeof w.toDate == "function" ? w.toDate() : new Date(w);
      if (c && (0, ce.default)(S).isAfter(c)) break;
      h.push((0, ce.default)(S).format("YYYY-MM-DD HH:mm:ss"));
    }
  } catch (y) {
  }
  return h;
}
function ln(m) {
  if (m == null) return;
  const T = (0, ce.default)(m);
  if (T.isValid())
    return T.toDate();
}
function $i(m) {
  var T, h;
  const l = [], d = m.now ? (0, ce.default)(m.now).format("YYYY-MM-DD HH:mm:ss") : (0, ce.default)().format("YYYY-MM-DD HH:mm:ss"), c = (T = m.startTime) !== null && T !== void 0 ? T : d, v = (h = m.endTime) !== null && h !== void 0 ? h : void 0, y = m.previewCount && m.previewCount > 0 ? m.previewCount : 3, p = Ni(m.cronExp, {
    count: y,
    startTime: c,
    endTime: v
  });
  if (p.length > 0 && (l.push({
    key: "start",
    text: p[0],
    type: "start"
  }), p[1] && l.push({
    key: "second",
    text: p[1],
    type: "normal"
  }), p[2] && l.push({
    key: "third",
    text: p[2],
    type: "normal"
  }), l.push({
    key: "ellipsis",
    text: "⋮",
    type: "ellipsis"
  })), v) {
    const w = (0, ce.default)(v).format("YYYY-MM-DD HH:mm:ss");
    l.push({
      key: "end",
      text: w,
      type: "end"
    });
  } else l.push({
    key: "infinite",
    text: "永不结束",
    type: "infinite"
  });
  if (!l.length) {
    const w = d;
    l.push({
      key: "fallback",
      text: w,
      type: "start"
    }), l.push({
      key: "ellipsis",
      text: "⋮",
      type: "ellipsis"
    }), l.push({
      key: "infinite",
      text: "永不结束",
      type: "infinite"
    });
  }
  return l;
}
function Ii(m) {
  const { second: T, minute: h } = hn(m);
  return {
    time: {
      second: T,
      minute: h
    },
    hour: { mode: "every" },
    day: {
      type: "day",
      day: { mode: "every" }
    },
    month: { mode: "every" }
  };
}
function Zi(m) {
  var T, h;
  const l = m != null ? m : Ii(), d = z((T = l.time) === null || T === void 0 ? void 0 : T.second, 0, 59, 0), c = z((h = l.time) === null || h === void 0 ? void 0 : h.minute, 0, 59, 0), v = Ei(l.hour), y = _i(l.month), { dayField: p, weekField: w } = xi(l.day);
  return `${d} ${c} ${v} ${p} ${y} ${w}`;
}
function Ai(m) {
  const T = m ? m.trim().split(/\s+/) : [];
  if (T.length < 6) return null;
  const [h, l, d, c, v, y] = T, p = {
    second: z(Number(h), 0, 59, 0),
    minute: z(Number(l), 0, 59, 0)
  }, w = bi(d);
  if (!w) return null;
  const S = Ci(v);
  if (!S) return null;
  const f = Fi(c, y);
  return f ? {
    time: p,
    hour: w,
    day: f,
    month: S
  } : null;
}
function z(m, T, h, l) {
  const d = typeof m == "number" && Number.isFinite(m) ? Math.floor(m) : NaN;
  return Number.isNaN(d) ? l : d < T ? T : d > h ? h : d;
}
function Ei(m) {
  var T;
  if (!m) return "*";
  const h = {
    mode: (T = m.mode) !== null && T !== void 0 ? T : "every",
    range: m.range,
    values: m.values,
    interval: m.interval
  };
  if (h.mode === "range" && h.range && h.range.length === 2) {
    const [l, d] = h.range;
    return `${z(l, 0, 23, 0)}-${z(d, 0, 23, 23)}`;
  }
  if (h.mode === "value" && Array.isArray(h.values) && h.values.length > 0) {
    const l = Array.from(new Set(h.values.map((d) => z(d, 0, 23, 0))));
    return l.sort((d, c) => d - c), l.join(",");
  }
  return h.mode === "interval" && h.interval ? `${z(h.interval.start, 0, 23, 0)}/${z(h.interval.step, 1, 23, 1)}` : (h.mode === "every", "*");
}
function _i(m) {
  var T;
  if (!m) return "*";
  const h = {
    mode: (T = m.mode) !== null && T !== void 0 ? T : "every",
    values: m.values
  };
  if (h.mode === "value" && Array.isArray(h.values) && h.values.length > 0) {
    const l = Array.from(new Set(h.values.map((d) => z(d, 1, 12, 1))));
    return l.sort((d, c) => d - c), l.join(",");
  }
  return "*";
}
function xi(m) {
  if (((m == null ? void 0 : m.type) === "week" ? "week" : "day") == "week") {
    var T;
    const l = m == null || (T = m.week) === null || T === void 0 ? void 0 : T.values, d = Array.isArray(l) && l.length > 0 ? l : [1], c = Array.from(new Set(d.map((v) => z(v, 1, 7, 1))));
    return c.sort((v, y) => v - y), {
      dayField: "?",
      weekField: c.join(",")
    };
  }
  const h = m == null ? void 0 : m.day;
  if (h && h.mode === "range" && h.range && h.range.length === 2) {
    const [l, d] = h.range;
    return {
      dayField: `${z(l, 1, 31, 1)}-${z(d, 1, 31, 31)}`,
      weekField: "?"
    };
  }
  if (h && h.mode === "value" && Array.isArray(h.values) && h.values.length > 0) {
    const l = Array.from(new Set(h.values.map((d) => z(d, 1, 31, 1))));
    return l.sort((d, c) => d - c), {
      dayField: l.join(","),
      weekField: "?"
    };
  }
  return h && h.mode === "interval" && h.interval ? {
    dayField: `${z(h.interval.start, 1, 31, 1)}/${z(h.interval.step, 1, 31, 1)}`,
    weekField: "?"
  } : h && h.mode === "last" ? {
    dayField: "L",
    weekField: "?"
  } : {
    dayField: "*",
    weekField: "?"
  };
}
function bi(m) {
  if (!m) return null;
  if (m === "*") return { mode: "every" };
  if (m.includes("/") && !m.includes("-")) {
    const [h, l] = m.split("/"), d = Number(h), c = Number(l);
    return {
      mode: "interval",
      interval: {
        start: z(d, 0, 23, 0),
        step: z(c, 1, 23, 1)
      }
    };
  }
  if (m.includes("-")) {
    const [h, l] = m.split("-"), d = Number(h), c = Number(l);
    return {
      mode: "range",
      range: [z(d, 0, 23, 0), z(c, 0, 23, 23)]
    };
  }
  const T = lt(m, 0, 23);
  return T && T.length > 0 ? {
    mode: "value",
    values: T
  } : { mode: "every" };
}
function Ci(m) {
  if (!m) return null;
  if (m === "*") return { mode: "every" };
  const T = lt(m, 1, 12);
  return T && T.length > 0 ? {
    mode: "value",
    values: T
  } : { mode: "every" };
}
function Fi(m, T) {
  if (!T || T === "?") {
    if (!m || m === "*") return {
      type: "day",
      day: { mode: "every" }
    };
    if (m === "L") return {
      type: "day",
      day: { mode: "last" }
    };
    if (m.includes("/")) {
      const [d, c] = m.split("/"), v = Number(d), y = Number(c);
      return {
        type: "day",
        day: {
          mode: "interval",
          interval: {
            start: z(v, 1, 31, 1),
            step: z(y, 1, 31, 1)
          }
        }
      };
    }
    if (m.includes("-")) {
      const [d, c] = m.split("-"), v = Number(d), y = Number(c);
      return {
        type: "day",
        day: {
          mode: "range",
          range: [z(v, 1, 31, 1), z(y, 1, 31, 31)]
        }
      };
    }
    const l = lt(m, 1, 31);
    return l && l.length > 0 ? {
      type: "day",
      day: {
        mode: "value",
        values: l
      }
    } : {
      type: "day",
      day: { mode: "every" }
    };
  }
  const h = lt(T, 1, 7);
  return {
    type: "week",
    week: { values: h && h.length > 0 ? h : [1] }
  };
}
function lt(m, T, h) {
  if (!m) return null;
  const l = m.split(",").map((c) => z(Number(c), T, h, T)), d = Array.from(new Set(l));
  return d.sort((c, v) => c - v), d;
}
export {
  Li as a,
  Zi as i,
  Mi as n,
  Ii as o,
  $i as r,
  Ai as s,
  Di as t
};
