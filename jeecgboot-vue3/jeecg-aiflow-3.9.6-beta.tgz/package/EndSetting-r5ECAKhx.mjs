import { a as z, n as Z, t as V } from "./objectSpread2-B0BetFB8.mjs";
import { t as G } from "./CardConfigModal-DPU32vDe.mjs";
import { t as H } from "./VarTextarea-BzeLBgKt.mjs";
import { t as K } from "./VarListPicker-CrG8EHn2.mjs";
import { t as Q } from "./useSettings-Cq_-E7Ut.mjs";
import "./Vars-Cgan49KR.mjs";
import { Select as W } from "ant-design-vue/es";
import { computed as X, createBlock as Y, createCommentVNode as R, createElementBlock as S, createElementVNode as g, createTextVNode as ee, createVNode as b, defineComponent as te, isRef as h, openBlock as _, ref as re, resolveComponent as oe, unref as a, withCtx as ne } from "vue";
import { useModal as le } from "/@/components/Modal";
import ae from "/@/views/super/airag/aiapp/chat/components/CardTemplate.vue";
Z();
var ie = { class: "end-setting" }, se = { class: "setting-item" }, de = { class: "setting-item" }, ue = {
  key: 0,
  class: "setting-item"
}, pe = {
  key: 1,
  class: "setting-item"
}, ve = { key: 0 }, ce = /* @__PURE__ */ te({
  __name: "EndSetting",
  props: {
    type: {
      type: String,
      required: !0
    },
    node: {
      type: Object,
      required: !0
    },
    properties: {
      type: Object,
      required: !0
    },
    isSilentMode: {
      type: Boolean,
      required: !0
    },
    setProperties: {
      type: Function,
      required: !0
    }
  },
  setup(E) {
    const { lfRef: T, prevNodes: k, prevVariables: N, isReadOnly: x, outputParams: O, outputVarsOptions: j, createOptionRef: C } = Q(E), q = ["string", "Image"], f = C("outputContent");
    f.value == null && (f.value = "");
    const [I, { openModal: M }] = le(), d = C("outputType"), m = C("cardConfig");
    d.value || (d.value = "default");
    const P = re([
      {
        label: "JSON",
        value: "default"
      },
      {
        label: "文本",
        value: "text"
      },
      {
        label: "卡片",
        value: "card"
      }
    ]), B = X(() => j.value.map((n) => {
      const t = O.value.find((e) => e.name === n.name);
      let r = w(k.value.find((e) => e.id === (t == null ? void 0 : t.nodeId)));
      if (!r.length) {
        var o, l;
        const e = ((o = (l = T.value) === null || l === void 0 || (l = l.graphModel) === null || l === void 0 ? void 0 : l.nodes) !== null && o !== void 0 ? o : k.value).map((s) => w(s)).filter((s) => s.length);
        e.length === 1 && (r = e[0]);
      }
      return V(V({}, n), {}, { fields: r });
    }));
    function w(n) {
      var t;
      const r = n == null || (t = n.properties) === null || t === void 0 ? void 0 : t.options;
      let o = r == null ? void 0 : r.messages;
      if (typeof o == "string") try {
        o = JSON.parse(o);
      } catch (e) {
        o = [];
      }
      Array.isArray(o) || (o = []);
      let l = [];
      for (const e of o) {
        const s = L(e == null ? void 0 : e.content);
        if (s.length) {
          l = s;
          break;
        }
      }
      return Array.isArray(r == null ? void 0 : r.structuredOutputFields) && r.structuredOutputFields.length ? r.structuredOutputFields.filter((e) => e == null ? void 0 : e.field).map((e) => {
        var s;
        const u = l.find((y) => y.value === e.field), v = (s = e.label) !== null && s !== void 0 ? s : e.name;
        return A(e.field, v && v !== e.field ? v : u == null ? void 0 : u.fieldLabel);
      }) : l;
    }
    function L(n) {
      var t, r;
      if (!n || typeof n != "string") return [];
      const o = (t = (r = n.match(/```(?:json)?\s*([\s\S]*?)```/i)) === null || r === void 0 || (r = r[1]) === null || r === void 0 ? void 0 : r.trim()) !== null && t !== void 0 ? t : n.trim(), l = [o], e = o.indexOf("["), s = o.lastIndexOf("]");
      e >= 0 && s > e && l.push(o.slice(e, s + 1));
      const u = o.indexOf("{"), v = o.lastIndexOf("}");
      u >= 0 && v > u && l.push(o.slice(u, v + 1));
      for (const p of l) try {
        const c = JSON.parse(p), i = Array.isArray(c) ? c[0] : c;
        if (i && typeof i == "object" && !Array.isArray(i)) return Object.entries(i).map(([U, $]) => A(U, $));
      } catch (c) {
      }
      const y = l.find((p) => p.includes("{") && p.includes("}"));
      if (y) {
        const p = Array.from(y.matchAll(/[\\]*["']([A-Za-z_$][\w$]*)[\\]*["']\s*:\s*[\\]*["']([^"']*)[\\]*["']/g), (i) => A(i[1], i[2]));
        if (p.length) return Array.from(new Map(p.map((i) => [i.value, i])).values());
        const c = Array.from(y.matchAll(/[\\]*["']([A-Za-z_$][\w$]*)[\\]*["']\s*:/g), (i) => i[1]);
        return Array.from(new Set(c)).map((i) => A(i));
      }
      return [];
    }
    function A(n, t) {
      const r = typeof t == "string" ? t.trim() : "";
      return {
        label: r && r !== n ? `${n} / ${r}` : n,
        value: n,
        fieldLabel: r
      };
    }
    function F() {
      M(!0, {
        outputOptions: B.value,
        formData: m.value
      });
    }
    function D(n) {
      m.value = n;
    }
    function J() {
      m.value = "";
    }
    return (n, t) => {
      var r;
      const o = W, l = oe("a-button");
      return _(), S("div", ie, [
        g("div", se, [t[3] || (t[3] = g("div", { class: "label" }, "输出变量", -1)), b(a(K), {
          vars: a(O),
          "onUpdate:vars": t[0] || (t[0] = (e) => h(O) ? O.value = e : null),
          prevVariables: a(N),
          readonly: a(x),
          "allowed-types": q,
          "show-type-selector": ""
        }, null, 8, [
          "vars",
          "prevVariables",
          "readonly"
        ])]),
        g("div", de, [t[4] || (t[4] = g("div", { class: "label" }, "输出格式", -1)), b(o, {
          style: { width: "100%" },
          options: P.value,
          value: a(d),
          "onUpdate:value": t[1] || (t[1] = (e) => h(d) ? d.value = e : null),
          disabled: a(x)
        }, null, 8, [
          "options",
          "value",
          "disabled"
        ])]),
        !a(d) || a(d) === "text" ? (_(), S("div", ue, [t[5] || (t[5] = g("div", { class: "label" }, "文本内容", -1)), b(a(H), {
          value: a(f),
          "onUpdate:value": t[2] || (t[2] = (e) => h(f) ? f.value = e : null),
          varsOptions: a(j),
          readonly: a(x),
          placeholder: "请输入返回的文本内容。按下 “/” 可以选择变量"
        }, null, 8, [
          "value",
          "varsOptions",
          "readonly"
        ])])) : a(d) === "card" ? (_(), S("div", pe, [a(m) ? (_(), S("div", ve, [b(ae, {
          "template-id": (r = a(m)) === null || r === void 0 ? void 0 : r.templateId,
          "show-delete-icon": "",
          onDelete: J,
          onClick: F
        }, null, 8, ["template-id"])])) : (_(), Y(l, {
          key: 1,
          onClick: F
        }, {
          default: ne(() => [...t[6] || (t[6] = [ee("绑定卡片", -1)])]),
          _: 1
        }))])) : R("", !0),
        b(G, {
          onRegister: a(I),
          onOk: D
        }, null, 8, ["onRegister"])
      ]);
    };
  }
}), he = /* @__PURE__ */ z({ default: () => fe }), fe = ce;
export {
  he as n,
  fe as t
};
