import { a as d } from "./objectSpread2-B0BetFB8.mjs";
import "./base-node-CKuyN1x8.mjs";
import { t as v } from "./NodeContainer-zpIyuhKY.mjs";
import { t as c } from "./NodeKVS-CRVYjcYN.mjs";
import { t as s } from "./useNode-lPs0rKwe.mjs";
import { computed as m, createBlock as _, createVNode as f, defineComponent as h, guardReactiveProps as b, normalizeProps as y, openBlock as N, unref as a, withCtx as S } from "vue";
var B = /* @__PURE__ */ h({
  __name: "BraveSearchNode",
  props: {
    node: {
      type: Object,
      required: !0
    },
    graph: {
      type: Object,
      required: !0
    }
  },
  setup(u) {
    const { $properties: o, getInputParamKVItem: l, getOutputParamKVItem: p } = s(u), n = m(() => {
      var e, t;
      const r = (e = o.value) === null || e === void 0 || (e = e.options) === null || e === void 0 || (e = e.braveSearch) === null || e === void 0 ? void 0 : e.count, i = (t = o.value) === null || t === void 0 || (t = t.options) === null || t === void 0 || (t = t.braveSearch) === null || t === void 0 ? void 0 : t.country;
      return [
        l({
          label: "搜索关键词",
          emptyAction: "tip",
          emptyTip: "尚未选择输入变量"
        }),
        {
          label: "结果数量",
          value: r != null ? r : 5
        },
        {
          label: "国家/地区",
          value: i || "",
          emptyAction: "hidden"
        },
        p({ label: "输出变量" })
      ];
    });
    return (e, t) => (N(), _(a(v), y(b(e.$props)), {
      default: S(() => [f(a(c), { kvs: n.value }, null, 8, ["kvs"])]),
      _: 1
    }, 16));
  }
}), A = /* @__PURE__ */ d({ default: () => $ }), $ = B;
export {
  A as n,
  $ as t
};
