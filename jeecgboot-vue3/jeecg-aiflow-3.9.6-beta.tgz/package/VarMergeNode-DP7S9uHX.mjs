import { a as i } from "./objectSpread2-B0BetFB8.mjs";
import "./base-node-CKuyN1x8.mjs";
import { t as d } from "./NodeContainer-zpIyuhKY.mjs";
import { t as v } from "./NodeKVS-CRVYjcYN.mjs";
import { t as _ } from "./useNode-lPs0rKwe.mjs";
import { computed as c, createBlock as m, createVNode as f, defineComponent as y, guardReactiveProps as N, normalizeProps as g, openBlock as x, unref as o, withCtx as V } from "vue";
var k = /* @__PURE__ */ y({
  __name: "VarMergeNode",
  props: {
    node: {
      type: Object,
      required: !0
    },
    graph: {
      type: Object,
      required: !0
    }
  },
  setup(n) {
    const { containerProps: u, $properties: a } = _(n), l = c(() => {
      var e, r;
      return (Array.isArray((e = a.value) === null || e === void 0 || (e = e.options) === null || e === void 0 ? void 0 : e.varGroups) ? (r = a.value) === null || r === void 0 || (r = r.options) === null || r === void 0 ? void 0 : r.varGroups : []).map((t, s) => {
        const p = !t.type || t.type === "unknown";
        return {
          label: s === 0 ? "输出变量" : "",
          valueList: [{ text: t.name }, {
            text: p ? "未定义" : `<${t.type}>`,
            type: p ? "invalid" : "tip"
          }],
          separator: ""
        };
      });
    });
    return (e, r) => (x(), m(o(d), g(N(o(u))), {
      default: V(() => [f(o(v), { kvs: l.value }, null, 8, ["kvs"])]),
      _: 1
    }, 16));
  }
}), P = /* @__PURE__ */ i({ default: () => $ }), $ = k;
export {
  P as n,
  $ as t
};
