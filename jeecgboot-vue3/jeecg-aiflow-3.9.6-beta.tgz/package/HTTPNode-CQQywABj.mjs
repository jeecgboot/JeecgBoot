import { a as N } from "./objectSpread2-B0BetFB8.mjs";
import "./base-node-CKuyN1x8.mjs";
import { t as j } from "./NodeContainer-zpIyuhKY.mjs";
import { t as k } from "./NodeKVS-CRVYjcYN.mjs";
import { t as g } from "./useNode-lPs0rKwe.mjs";
import { computed as O, createBlock as V, createVNode as A, defineComponent as H, guardReactiveProps as I, normalizeProps as K, openBlock as C, unref as c, withCtx as S } from "vue";
var w = /* @__PURE__ */ H({
  __name: "HTTPNode",
  props: {
    node: {
      type: Object,
      required: !0
    },
    graph: {
      type: Object,
      required: !0
    }
  },
  setup(_) {
    const { $properties: a, getInputParamKVItem: $, getOutputParamKVItem: y } = g(_), T = O(() => {
      var u, r, i, n, e, o, t, l;
      const h = (u = a.value) === null || u === void 0 || (u = u.options) === null || u === void 0 || (u = u.http) === null || u === void 0 ? void 0 : u.method, d = (r = a.value) === null || r === void 0 || (r = r.options) === null || r === void 0 || (r = r.http) === null || r === void 0 ? void 0 : r.url, b = d ? `[${h}] ${d}` : "", p = (i = a.value) === null || i === void 0 || (i = i.options) === null || i === void 0 || (i = i.http) === null || i === void 0 ? void 0 : i.requestParams, f = p ? Object.keys(p).join(", ") : "", s = (n = a.value) === null || n === void 0 || (n = n.options) === null || n === void 0 || (n = n.http) === null || n === void 0 ? void 0 : n.headers, q = s ? Object.keys(s).join(", ") : "", v = (e = a.value) === null || e === void 0 || (e = e.options) === null || e === void 0 || (e = e.http) === null || e === void 0 || (e = e.requestBody) === null || e === void 0 ? void 0 : e.body, m = (o = a.value) === null || o === void 0 || (o = o.options) === null || o === void 0 || (o = o.http) === null || o === void 0 || (o = o.requestBody) === null || o === void 0 ? void 0 : o.type, P = m !== "none" && v ? m : "", x = (t = a.value) === null || t === void 0 || (t = t.options) === null || t === void 0 || (t = t.http) === null || t === void 0 || (t = t.requestBody) === null || t === void 0 ? void 0 : t.timeout, B = (l = a.value) === null || l === void 0 || (l = l.options) === null || l === void 0 || (l = l.http) === null || l === void 0 || (l = l.requestBody) === null || l === void 0 ? void 0 : l.retriesTimes;
      return [
        $({
          label: "输入变量",
          emptyAction: "hidden"
        }),
        {
          label: "API",
          value: b,
          emptyAction: "tip",
          emptyTip: "尚未填写"
        },
        {
          label: "请求参数",
          value: f
        },
        {
          label: "请求头",
          value: q
        },
        {
          label: "请求体类型",
          value: P
        },
        {
          label: "请求体内容",
          value: v
        },
        {
          label: "超时时间",
          value: x
        },
        {
          label: "重试次数",
          value: B
        },
        y({ label: "输出变量" })
      ];
    });
    return (u, r) => (C(), V(c(j), K(I(u.$props)), {
      default: S(() => [A(c(k), { kvs: T.value }, null, 8, ["kvs"])]),
      _: 1
    }, 16));
  }
}), L = /* @__PURE__ */ N({ default: () => z }), z = w;
export {
  L as n,
  z as t
};
