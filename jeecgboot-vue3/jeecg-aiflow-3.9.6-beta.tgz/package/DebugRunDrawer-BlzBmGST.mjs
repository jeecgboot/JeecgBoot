import { a as re } from "./objectSpread2-B0BetFB8.mjs";
import { n as ue, t as le } from "./flowOutput-B3JieLuW.mjs";
import { t as pe } from "./_plugin-vue_export-helper-Dj7HTbfw.mjs";
import { t as S } from "./asyncToGenerator-BkhZtDh9.mjs";
import { t as de } from "./NodeIcon-I60YeJ6p.mjs";
import { t as ve } from "./DebugRunForm-CsLYmHqB.mjs";
import { c as me, r as ce } from "./api-BJs6o08o.mjs";
import { t as _e } from "./runStore-ByYxqieA.mjs";
import { t as fe } from "./inputParams-BzY4b0tw.mjs";
import { t as ge } from "./ImageOutputPreview-CiW_NAHh.mjs";
import { Alert as ye, Divider as he, FormItem as be, Space as ke, Spin as xe, TabPane as Re, Tabs as we } from "ant-design-vue/es";
import { Fragment as C, computed as O, createBlock as y, createCommentVNode as N, createElementBlock as r, createElementVNode as s, createTextVNode as De, createVNode as u, defineComponent as Se, inject as j, normalizeClass as M, onUnmounted as Ce, openBlock as a, ref as c, renderList as Te, resolveComponent as G, toDisplayString as m, unref as o, withCtx as p } from "vue";
import { useMessage as Fe } from "/@/hooks/web/useMessage";
import { pick as Pe } from "lodash-es";
import { copyTextToClipboard as Ie } from "/@/hooks/web/useCopyToClipboard";
import { useEventListener as Ne } from "/@/hooks/event/useEventListener";
import { BasicDrawer as Me, useDrawerInner as Ve } from "/@/components/Drawer";
import { ApiSelect as $e } from "/@/components/Form";
var ze = {
  key: 0,
  class: "need-app-select"
}, Ae = { style: { "margin-top": "12px" } }, Ee = { class: "logs-bar" }, Oe = { class: "bar-item status" }, Be = { class: "item-content" }, Ke = { key: 3 }, Ue = { class: "bar-item" }, Je = { class: "item-content" }, Le = { key: 0 }, je = { key: 1 }, Ge = { class: "params-bar" }, Ze = { class: "params-item input" }, qe = { class: "content" }, He = { class: "params-item output" }, Qe = { class: "content" }, We = { key: 0 }, Xe = { key: 1 }, Ye = { key: 2 }, et = {
  key: 0,
  class: "node-bar"
}, tt = ["onClick"], st = { class: "node-header" }, at = { class: "icon" }, nt = { class: "airag-node-label" }, ot = { class: "time" }, it = { key: 0 }, rt = { key: 1 }, ut = { class: "params-bar" }, lt = { class: "params-item input" }, pt = { class: "content" }, dt = { class: "params-item output" }, vt = { class: "content" }, mt = { key: 0 }, ct = { key: 1 }, _t = { class: "params-bar" }, ft = { class: "params-item output" }, gt = { class: "content" }, yt = { key: 0 }, ht = { key: 1 }, bt = { key: 1 }, kt = { key: 1 }, xt = {
  key: 0,
  style: { "margin-top": "8px" }
}, Rt = /* @__PURE__ */ Se({
  __name: "DebugRunDrawer",
  props: {},
  emits: ["register"],
  setup(Dt, { emit: St }) {
    const { createMessage: h, createConfirm: Z } = Fe(), D = c(), b = j("lfRef", c()), B = j("doSubmit"), t = _e(), q = O(() => ue(t.outputTypes, t.outputValues)), H = O(() => le({
      outputs: t.outputParams,
      outputTypes: t.outputTypes,
      outputValues: t.outputValues
    })), _ = c(!1), k = c(""), K = c({}), V = c([]), $ = c(!1), x = c(""), R = c("input"), Q = (i) => {
      if (_.value) {
        h.warn("正在调试请稍后……");
        return;
      }
      if (!t.isRunning && !t.isFinished) {
        h.warn("请先调试流程");
        return;
      }
      R.value = i;
    }, w = c([]), U = O(() => {
      var i, e;
      if (!w.value.length) return !1;
      const l = (i = (e = D.value) === null || e === void 0 ? void 0 : e.formModel) !== null && i !== void 0 ? i : {};
      return w.value.every((d) => {
        const n = l[d.field];
        return n == null || n === "" || Array.isArray(n) && n.length === 0;
      });
    }), [W, { getVisible: T, closeDrawer: X }] = Ve((function() {
      var i = S(function* (e) {
        var l;
        if (k.value = "", x.value = "", !b.value) {
          k.value = "尚未初始化";
          return;
        }
        const d = b.value.getNodeDataById("start-node");
        if (!d) {
          k.value = "未找到开始节点";
          return;
        }
        const n = /^chat[A-Z]/;
        $.value = b.value.graphModel.nodes.some((P) => n.test(P.type)), V.value = [];
        const f = (l = d.properties) === null || l === void 0 ? void 0 : l.inputParams, g = fe(f);
        if (V.value = g.fields, g.schemas.length > 0) {
          K.value = { x: 1 }, w.value = g.schemas;
          return;
        }
        K.value = {}, w.value = [];
      });
      return function(e) {
        return i.apply(this, arguments);
      };
    })());
    function Y(i) {
      if (i.key !== "Enter" || i.isComposing || !(T != null && T.value) || R.value !== "input" || _.value || U.value) return;
      const e = i.target;
      e != null && e.closest('textarea, button, [role="button"], .ant-select, .ant-picker, .ant-upload, [contenteditable="true"]') || (i.preventDefault(), J());
    }
    Ne({
      name: "keydown",
      listener: Y,
      wait: 0
    });
    function J() {
      return z.apply(this, arguments);
    }
    function z() {
      return z = S(function* () {
        if ($.value && !x.value) {
          h.warn("当前流程包含需要关联应用的节点，请先选择一个智能体应用");
          return;
        }
        let i = {};
        if (D.value) try {
          i = yield D.value.validate();
        } catch (e) {
          return;
        }
        try {
          if (_.value = !0, t.start(i), L(!0), B) try {
            yield B({
              silent: !0,
              needName: !1,
              saveFn(e) {
                e = Pe(e, ["design", "chain"]), ee(e, i);
              },
              onError: () => {
                F(), _.value = !1;
              }
            });
          } catch (e) {
            F(), _.value = !1, h.error("保存失败，请稍后重试");
          } finally {
            _.value = !1;
          }
          else h.error("当前环境无法调试");
        } catch (e) {
        }
      }), z.apply(this, arguments);
    }
    function ee(i, e) {
      return A.apply(this, arguments);
    }
    function A() {
      return A = S(function* (i, e) {
        if (!b.value) {
          k.value = "尚未初始化";
          return;
        }
        try {
          R.value = "trace", _.value = !0;
          const l = {};
          x.value && (l.appId = x.value);
          const d = ce(i, e, l);
          d.onFlowStarted((n) => {
            t.beginTime = Date.now();
          }), d.onFlowFinished((n) => {
            R.value = "result", t.finish(n.success, n.message, n.outputs, n.outputTypes, n.outputValues);
          }), d.onNodeStarted((n) => {
            t.addStep({
              node: {
                id: n.id,
                type: n.type,
                text: n.text
              },
              status: "running",
              inputParams: n.inputs,
              outputParams: n.outputs
            });
          }), d.onNodeFinished((n) => {
            const f = n.success ? "success" : "fail";
            t.updateStepStatus(n.id, f, n.outputs);
          }), d.onMessage((n) => {
            t.addOutputText(n.fromNodeId, n.message);
          }), yield d.run();
        } catch (l) {
        } finally {
          _.value = !1;
        }
      }), A.apply(this, arguments);
    }
    function te() {
      return !t.isRunning;
    }
    function se() {
      if (t.isRunning) {
        h.warn("正在调试请稍后……");
        return;
      }
      F(), X();
    }
    Ce(() => {
      F();
    });
    function F() {
      R.value = "input", t.end(), L(!1);
    }
    function L(i) {
      b.value && b.value.graphModel.$J.updateEditConfig({ isSilentMode: i });
    }
    function ae() {
      const i = typeof t.outputParams == "string" ? t.outputParams : JSON.stringify(t.outputParams);
      Ie(i) ? h.success("复制成功") : prompt("复制失败，请手动复制", i);
    }
    function ne() {
      return E.apply(this, arguments);
    }
    function E() {
      return E = S(function* () {
        const i = Z({
          title: "生成",
          iconType: "info",
          content: "确定要生成测试数据吗？",
          okText: "确定",
          cancelText: "取消",
          onOk() {
            return S(function* () {
              var e, l;
              return i.update({ cancelButtonProps: { disabled: !0 } }), (e = D.value) === null || e === void 0 || (l = e.genTestData) === null || l === void 0 ? void 0 : l.call(e, V.value);
            })();
          }
        });
      }), E.apply(this, arguments);
    }
    return (i, e) => {
      const l = ye, d = be, n = he, f = G("Icon"), g = ke, P = G("a-button"), oe = xe, I = Re, ie = we;
      return a(), y(o(Me), {
        onRegister: o(W),
        width: 600,
        title: "调试",
        mask: !1,
        getContainer: !1,
        closeFunc: te,
        onClose: se
      }, {
        default: p(() => [o(T) ? (a(), y(ie, {
          key: 0,
          activeKey: R.value,
          animated: "",
          onChange: Q
        }, {
          default: p(() => [
            u(I, {
              tab: "输入",
              key: "input"
            }, {
              default: p(() => [u(oe, { spinning: _.value }, {
                default: p(() => [k.value ? (a(), y(l, {
                  key: 0,
                  message: "错误",
                  description: k.value,
                  type: "error",
                  "show-icon": ""
                }, null, 8, ["description"])) : (a(), r(C, { key: 1 }, [
                  $.value ? (a(), r("div", ze, [u(l, {
                    type: "warning",
                    message: "当前流程包含需要关联应用的节点，请选择一个智能体应用",
                    "show-icon": "",
                    style: { "margin-bottom": "12px" }
                  }), u(d, {
                    label: "关联应用",
                    labelCol: { span: 24 },
                    wrapperCol: { span: 24 }
                  }, {
                    default: p(() => [u(o($e), {
                      value: x.value,
                      "onUpdate:value": e[0] || (e[0] = (v) => x.value = v),
                      placeholder: "请选择智能体应用",
                      api: o(me),
                      params: { type: "chatSimple" },
                      labelField: "text",
                      valueField: "value",
                      showSearch: "",
                      optionFilterProp: "label",
                      style: { width: "100%" }
                    }, null, 8, ["value", "api"])]),
                    _: 1
                  })])) : N("", !0),
                  w.value.length ? (a(), r(C, { key: 1 }, [u(l, {
                    type: "info",
                    "show-icon": ""
                  }, {
                    message: p(() => [
                      e[2] || (e[2] = s("span", null, "请填写开始节点中配置的参数", -1)),
                      u(n, { type: "vertical" }),
                      u(g, {
                        class: "gen-prompt-btn",
                        onClick: ne,
                        size: 4
                      }, {
                        default: p(() => [u(f, { icon: "mdi:star-four-points" }), e[1] || (e[1] = s("span", null, "生成", -1))]),
                        _: 1
                      })
                    ]),
                    _: 1
                  }), u(ve, {
                    ref_key: "formRef",
                    ref: D,
                    schemas: w.value
                  }, null, 8, ["schemas"])], 64)) : (a(), y(l, {
                    key: 2,
                    type: "info",
                    message: "当前流程没有配置参数，可直接点击调试",
                    "show-icon": ""
                  })),
                  s("div", Ae, [u(P, {
                    block: "",
                    size: "large",
                    type: "primary",
                    preIcon: "codicon:debug-start",
                    disabled: U.value,
                    onClick: J
                  }, {
                    default: p(() => [...e[3] || (e[3] = [s("span", null, "开始调试", -1)])]),
                    _: 1
                  }, 8, ["disabled"])])
                ], 64))]),
                _: 1
              }, 8, ["spinning"])]),
              _: 1
            }),
            u(I, {
              tab: "详情",
              key: "info"
            }, {
              default: p(() => [s("div", { class: M(["logs-box", o(t).status]) }, [
                s("div", Ee, [s("div", Oe, [e[7] || (e[7] = s("div", { class: "item-title" }, "状态", -1)), s("div", Be, [o(t).isRunning ? (a(), y(g, { key: 0 }, {
                  default: p(() => [u(f, {
                    icon: "eos-icons:bubble-loading",
                    size: 14
                  }), e[4] || (e[4] = s("span", null, "调试中", -1))]),
                  _: 1
                })) : o(t).isFailed ? (a(), y(g, { key: 1 }, {
                  default: p(() => [u(f, {
                    icon: "ix:namur-failure-filled",
                    size: 14
                  }), e[5] || (e[5] = s("span", null, "调试失败", -1))]),
                  _: 1
                })) : o(t).isFinished ? (a(), y(g, { key: 2 }, {
                  default: p(() => [u(f, {
                    icon: "ix:success",
                    size: 14
                  }), e[6] || (e[6] = s("span", null, "调试成功", -1))]),
                  _: 1
                })) : (a(), r("span", Ke, m(o(t).status), 1))])]), s("div", Ue, [e[8] || (e[8] = s("div", { class: "item-title" }, "调试时间", -1)), s("div", Je, [o(t).isFinished || o(t).isFailed ? (a(), r("span", Le, m(o(t).timeText), 1)) : (a(), r("span", je, "-"))])])]),
                e[11] || (e[11] = s("div", { class: "divider-text" }, "参数", -1)),
                s("div", Ge, [s("div", Ze, [e[9] || (e[9] = s("div", { class: "title" }, "输入", -1)), s("div", qe, [s("pre", null, m(o(t).inputParams), 1)])]), s("div", He, [e[10] || (e[10] = s("div", { class: "title" }, "输出", -1)), s("div", Qe, [o(t).isRunning ? (a(), r("span", We, "-")) : o(t).isFailed ? (a(), r("span", Xe, m(o(t).resMessage), 1)) : (a(), r("pre", Ye, m(o(t).outputParams), 1))])])])
              ], 2)]),
              _: 1
            }),
            u(I, {
              tab: "追踪",
              key: "trace"
            }, {
              default: p(() => [s("div", { class: M(["logs-box", o(t).status]) }, [o(t).nodeSteps.length ? (a(), r("div", et, [(a(!0), r(C, null, Te(o(t).nodeSteps, (v) => (a(), r("div", {
                class: M([
                  "node-item",
                  v.status,
                  { expansion: v.expansion }
                ]),
                onClick: (Ct) => v.expansion = !v.expansion
              }, [s("div", st, [u(g, { class: "info" }, {
                default: p(() => [s("div", at, [u(de, { type: v.node.type }, null, 8, ["type"])]), s("span", nt, m(v.node.text), 1)]),
                _: 2
              }, 1024), s("div", ot, [v.status === "running" ? (a(), r("span", it, [u(f, {
                icon: "eos-icons:bubble-loading",
                size: 14
              })])) : (a(), r("span", rt, "耗时：" + m(v.timeText), 1))])]), s("div", ut, [s("div", lt, [e[12] || (e[12] = s("div", { class: "title" }, "输入", -1)), s("div", pt, [s("pre", null, m(v.inputParams), 1)])]), s("div", dt, [e[13] || (e[13] = s("div", { class: "title" }, "输出", -1)), s("div", vt, [v.status === "running" ? (a(), r("span", mt, "-")) : (a(), r("pre", ct, m(v.outputParams), 1))])])])], 10, tt))), 256))])) : N("", !0)], 2)]),
              _: 1
            }),
            u(I, {
              tab: "结果",
              key: "result"
            }, {
              default: p(() => [s("div", { class: M(["logs-box", o(t).status]) }, [s("div", _t, [s("div", ft, [s("div", gt, [o(t).isRunning ? (a(), r(C, { key: 0 }, [o(t).outputResult ? (a(), r("pre", yt, m(o(t).outputResult), 1)) : (a(), r("span", ht, "-"))], 64)) : o(t).isFailed ? (a(), r("span", bt, m(o(t).resMessage), 1)) : (a(), r(C, { key: 2 }, [q.value.length ? (a(), y(ge, {
                key: 0,
                segments: H.value
              }, null, 8, ["segments"])) : (a(), r("pre", kt, m(o(t).outputResult), 1))], 64))]), o(t).isFailed ? N("", !0) : (a(), r("div", xt, [u(P, {
                preIcon: "codicon:copy",
                size: "small",
                ghost: "",
                onClick: ae,
                type: "primary"
              }, {
                default: p(() => [...e[14] || (e[14] = [De("复制", -1)])]),
                _: 1
              })]))])])], 2)]),
              _: 1
            })
          ]),
          _: 1
        }, 8, ["activeKey"])) : N("", !0)]),
        _: 1
      }, 8, ["onRegister"]);
    };
  }
}), Gt = /* @__PURE__ */ re({ default: () => wt }), wt = /* @__PURE__ */ pe(Rt, [["__scopeId", "data-v-cc949f4e"]]);
export {
  Gt as n,
  wt as t
};
