import { a as b } from "./objectSpread2-B0BetFB8.mjs";
import { t as c } from "./_plugin-vue_export-helper-Dj7HTbfw.mjs";
import { t as f } from "./VarTextarea-BzeLBgKt.mjs";
import { t as z } from "./VarListPicker-CrG8EHn2.mjs";
import { t as O } from "./VarListShow-Dg1oan43.mjs";
import { t as x } from "./WaitVectorizeSetting-BKkGAxpi.mjs";
import { t as F } from "./useSettings-Cq_-E7Ut.mjs";
import "./Vars-Cgan49KR.mjs";
import { Alert as T } from "ant-design-vue/es";
import { computed as C, createElementBlock as U, createElementVNode as o, createVNode as a, defineComponent as q, isRef as i, openBlock as M, unref as e } from "vue";
var A = { class: "chat-memory-set-setting" }, I = { class: "setting-item" }, P = { class: "setting-item" }, k = { class: "setting-item" }, B = { class: "setting-item" }, R = /* @__PURE__ */ q({
  __name: "ChatMemorySetSetting",
  props: {
    type: {
      type: String,
      required: !0
    },
    node: {
      type: Object,
      required: !0
    },
    properties: {
      type: Object,
      required: !0
    },
    isSilentMode: {
      type: Boolean,
      required: !0
    },
    setProperties: {
      type: Function,
      required: !0
    }
  },
  setup(g) {
    const { inputParams: n, outputParams: _, prevVariables: w, inputVarsOptions: y, createOptionRef: l, isReadOnly: s } = F(g), u = l("title"), p = l("content"), d = l("waitForVectorize"), v = l("waitTimeout"), m = l("vectorizeFailStrategy"), S = C(() => ["string", "number"]);
    return (E, t) => {
      const V = T;
      return M(), U("div", A, [
        a(V, {
          type: "info",
          "show-icon": "",
          message: "将内容写入AI应用的记忆库，需要在AI应用中关联该流程并配置记忆库",
          style: { "margin-bottom": "10px" }
        }),
        o("div", I, [t[6] || (t[6] = o("div", { class: "label" }, "输入变量", -1)), a(e(z), {
          vars: e(n),
          "onUpdate:vars": t[0] || (t[0] = (r) => i(n) ? n.value = r : null),
          prevVariables: e(w),
          allowedTypes: S.value,
          readonly: e(s)
        }, null, 8, [
          "vars",
          "prevVariables",
          "allowedTypes",
          "readonly"
        ])]),
        o("div", P, [t[7] || (t[7] = o("div", { class: "label" }, "写入标题", -1)), a(e(f), {
          value: e(u),
          "onUpdate:value": t[1] || (t[1] = (r) => i(u) ? u.value = r : null),
          type: "input",
          width: "100%",
          varsOptions: e(y),
          placeholder: "请输入标题，按下 / 可以选择变量（留空则自动生成）",
          readonly: e(s)
        }, null, 8, [
          "value",
          "varsOptions",
          "readonly"
        ])]),
        o("div", k, [t[8] || (t[8] = o("div", { class: "label" }, "写入内容", -1)), a(e(f), {
          value: e(p),
          "onUpdate:value": t[2] || (t[2] = (r) => i(p) ? p.value = r : null),
          varsOptions: e(y),
          placeholder: "请输入写入记忆库的文本，按下 / 可以选择变量",
          height: 120,
          readonly: e(s)
        }, null, 8, [
          "value",
          "varsOptions",
          "readonly"
        ])]),
        a(x, {
          "wait-for-vectorize": e(d),
          "onUpdate:waitForVectorize": t[3] || (t[3] = (r) => i(d) ? d.value = r : null),
          "wait-timeout": e(v),
          "onUpdate:waitTimeout": t[4] || (t[4] = (r) => i(v) ? v.value = r : null),
          "vectorize-fail-strategy": e(m),
          "onUpdate:vectorizeFailStrategy": t[5] || (t[5] = (r) => i(m) ? m.value = r : null),
          readonly: e(s)
        }, null, 8, [
          "wait-for-vectorize",
          "wait-timeout",
          "vectorize-fail-strategy",
          "readonly"
        ]),
        o("div", B, [t[9] || (t[9] = o("div", { class: "label" }, "输出变量", -1)), a(e(O), { vars: e(_) }, null, 8, ["vars"])])
      ]);
    };
  }
}), Z = /* @__PURE__ */ b({ default: () => j }), j = /* @__PURE__ */ c(R, [["__scopeId", "data-v-edf391f2"]]);
export {
  Z as n,
  j as t
};
