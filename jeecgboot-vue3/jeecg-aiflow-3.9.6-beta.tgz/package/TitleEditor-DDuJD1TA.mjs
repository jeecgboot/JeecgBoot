import { a as C } from "./objectSpread2-B0BetFB8.mjs";
import { t as x } from "./asyncToGenerator-BkhZtDh9.mjs";
import { createCommentVNode as P, createElementBlock as u, createElementVNode as p, createVNode as g, defineComponent as V, normalizeClass as T, openBlock as m, resolveComponent as b, toDisplayString as q, unref as B } from "vue";
import { useDesign as N } from "/@/hooks/web/useDesign";
import { useJPrompt as k } from "/@/components/jeecg/JPrompt";
var D = { key: 0 }, I = /* @__PURE__ */ V({
  __name: "TitleEditor",
  props: {
    title: { type: String },
    promptProps: {
      type: Object,
      default: () => ({})
    },
    handleCustomEdit: { type: Function },
    disabled: {
      type: Boolean,
      default: !1
    }
  },
  emits: ["update:title"],
  setup(i, { expose: c, emit: f }) {
    const t = i, v = f, { createJPrompt: _ } = k(), { prefixCls: y } = N("modal-title-editor");
    function h() {
      t.disabled || (typeof t.handleCustomEdit == "function" ? t.handleCustomEdit() : d());
    }
    function d(r, l) {
      var o, n;
      const { promptProps: e } = t, E = (o = e == null ? void 0 : e.required) !== null && o !== void 0 ? o : !1, s = (e == null ? void 0 : e.rules) || [];
      E && s.push({
        required: !0,
        message: "这里是必填的"
      }), _({
        title: (e == null ? void 0 : e.title) || "修改标题",
        defaultValue: (n = e == null ? void 0 : e.defaultValue) !== null && n !== void 0 ? n : t.title,
        placeholder: (e == null ? void 0 : e.placeholder) || "请输入新标题",
        rules: s,
        onOk(a) {
          return x(function* () {
            v("update:title", a), r && (yield r(a));
          })();
        },
        onCancel() {
          l && l();
        }
      });
    }
    return c({ showPrompt: d }), (r, l) => {
      const o = b("Icon");
      return m(), u("div", { class: T([B(y), { "is-disabled": i.disabled }]) }, [p("div", {
        class: "text-area",
        onClick: h
      }, [p("span", null, q(i.title), 1), i.disabled ? P("", !0) : (m(), u("span", D, [g(o, { icon: "ant-design:edit" })]))])], 2);
    };
  }
}), z = /* @__PURE__ */ C({ default: () => J }), J = I;
export {
  z as n,
  J as t
};
