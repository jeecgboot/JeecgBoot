var _ = Object.create, p = Object.defineProperty, O = Object.getOwnPropertyDescriptor, P = Object.getOwnPropertyNames, g = Object.getPrototypeOf, f = Object.prototype.hasOwnProperty, a = (e, t, r) => () => {
  if (r) throw r[0];
  try {
    return e && (t = e(e = 0)), t;
  } catch (n) {
    throw r = [n], n;
  }
}, x = (e, t) => () => (t || (e((t = { exports: {} }).exports, t), e = null), t.exports), D = (e, t) => {
  let r = {};
  for (var n in e)
    p(r, n, {
      get: e[n],
      enumerable: !0
    });
  return t || p(r, Symbol.toStringTag, { value: "Module" }), r;
}, l = (e, t, r, n) => {
  if (t && typeof t == "object" || typeof t == "function")
    for (var u = P(t), c = 0, s = u.length, o; c < s; c++)
      o = u[c], !f.call(e, o) && o !== r && p(e, o, {
        get: ((v) => t[v]).bind(null, o),
        enumerable: !(n = O(t, o)) || n.enumerable
      });
  return e;
}, E = (e, t, r) => (l(e, t, "default"), r && l(r, t, "default")), M = (e, t, r) => (r = e != null ? _(g(e)) : {}, l(t || !e || !e.__esModule || !f.call(e, "default") ? p(r, "default", {
  value: e,
  enumerable: !0
}) : r, e));
function i(e) {
  "@babel/helpers - typeof";
  return i = typeof Symbol == "function" && typeof Symbol.iterator == "symbol" ? function(t) {
    return typeof t;
  } : function(t) {
    return t && typeof Symbol == "function" && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t;
  }, i(e);
}
var y = a((() => {
}));
function j(e, t) {
  if (i(e) != "object" || !e) return e;
  var r = e[Symbol.toPrimitive];
  if (r !== void 0) {
    var n = r.call(e, t || "default");
    if (i(n) != "object") return n;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (t === "string" ? String : Number)(e);
}
var w = a((() => {
  y();
}));
function m(e) {
  var t = j(e, "string");
  return i(t) == "symbol" ? t : t + "";
}
var S = a((() => {
  y(), w();
}));
function h(e, t, r) {
  return (t = m(t)) in e ? Object.defineProperty(e, t, {
    value: r,
    enumerable: !0,
    configurable: !0,
    writable: !0
  }) : e[t] = r, e;
}
var d = a((() => {
  S();
}));
function b(e, t) {
  var r = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var n = Object.getOwnPropertySymbols(e);
    t && (n = n.filter(function(u) {
      return Object.getOwnPropertyDescriptor(e, u).enumerable;
    })), r.push.apply(r, n);
  }
  return r;
}
function K(e) {
  for (var t = 1; t < arguments.length; t++) {
    var r = arguments[t] != null ? arguments[t] : {};
    t % 2 ? b(Object(r), !0).forEach(function(n) {
      h(e, n, r[n]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : b(Object(r)).forEach(function(n) {
      Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(r, n));
    });
  }
  return e;
}
var N = a((() => {
  d();
}));
export {
  D as a,
  a as i,
  N as n,
  E as o,
  x as r,
  M as s,
  K as t
};
