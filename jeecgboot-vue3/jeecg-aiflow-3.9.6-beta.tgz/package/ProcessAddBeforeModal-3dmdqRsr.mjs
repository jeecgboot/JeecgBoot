import { a as k, n as w, t as B } from "./objectSpread2-B0BetFB8.mjs";
import { t as A } from "./_plugin-vue_export-helper-Dj7HTbfw.mjs";
import { t as h } from "./asyncToGenerator-BkhZtDh9.mjs";
import { a as C, f as P, i as I, l as b, m as O, n as S, p as q, s as L, t as R } from "./api-BJs6o08o.mjs";
import { Tooltip as T } from "ant-design-vue/es";
import { createElementBlock as U, createElementVNode as x, createTextVNode as V, createVNode as i, openBlock as j, ref as _, resolveComponent as v, toDisplayString as D, withCtx as g } from "vue";
import N from "/@/components/Modal/src/BasicModal.vue";
import { useModalInner as E } from "/@/components/Modal";
import { useForm as G } from "/@/components/Form";
import H from "/@/components/Form/src/BasicForm.vue";
w();
var ie = {
  list: (e) => L(e),
  delete: (e) => C(e),
  batchDelete: (e) => I(e),
  copyFlow: (e, t) => S(e, t)
}, J = {
  updateProcess: (e) => O(e),
  releaseProcess: (e) => P(e, !1),
  unreleaseProcess: (e) => P(e, !0),
  queryById: (e) => b(e),
  saveOrUpdate(e, t = !1, r) {
    return h(function* () {
      if (t)
        return yield q(e, r), e;
      {
        const o = yield R(e, r);
        return B(B({}, e), {}, { id: o });
      }
    })();
  }
}, z = [
  {
    label: "流程名称",
    field: "name",
    required: !0,
    component: "Input",
    componentProps: {
      showCount: !0,
      maxlength: 30,
      placeholder: "请输入流程名称"
    }
  },
  {
    label: "流程图标",
    field: "icon",
    component: "JImageUpload"
  },
  {
    label: "描述",
    field: "descr",
    component: "InputTextArea",
    componentProps: {
      maxlength: 255,
      showCount: !0,
      placeholder: "请输入工作流描述"
    }
  }
], K = {
  name: "ProcessAddBeforeModal",
  components: {
    BasicForm: H,
    BasicModal: N
  },
  emits: ["ok", "register"],
  setup(e, { emit: t }) {
    const r = _("创建流程"), o = _(!1), s = _({}), [y, { resetFields: c, setFieldsValue: d, validate: p }] = G({
      schemas: z,
      showActionButtonGroup: !1,
      layout: "vertical",
      wrapperCol: { span: 24 }
    }), [u, { closeModal: m, setModalProps: n }] = E((function() {
      var l = h(function* (a) {
        yield c(), n({ confirmLoading: !1 }), o.value = !!(a != null && a.isUpdate), o.value ? r.value = "修改工作流" : r.value = "创建工作流", n({
          minHeight: 400,
          bodyStyle: { padding: "10px" }
        }), s.value = (a == null ? void 0 : a.record) || {}, d(s.value);
      });
      return function(a) {
        return l.apply(this, arguments);
      };
    })());
    function F() {
      return f.apply(this, arguments);
    }
    function f() {
      return f = h(function* () {
        try {
          n({ confirmLoading: !0 });
          let l = yield p();
          o.value ? (l.id = s.value.id, yield J.updateProcess(l), m(), t("ok", l)) : (m(), t("ok", l));
        } finally {
          n({ confirmLoading: !1 });
        }
      }), f.apply(this, arguments);
    }
    function M() {
      m();
    }
    return {
      registerModal: u,
      registerForm: y,
      title: r,
      handleOk: F,
      handleCancel: M
    };
  }
}, ce = /* @__PURE__ */ k({ default: () => Y }), Q = { style: { display: "flex" } }, W = {
  style: { color: "unset" },
  href: "https://help.jeecg.com/aigc/guide/flow",
  target: "_blank"
};
function X(e, t, r, o, s, y) {
  const c = v("Icon"), d = T, p = v("BasicForm"), u = v("BasicModal");
  return j(), U("div", null, [i(u, {
    destroyOnClose: "",
    onRegister: o.registerModal,
    canFullscreen: !1,
    width: "600px",
    title: o.title,
    onOk: o.handleOk,
    onCancel: o.handleCancel
  }, {
    title: g(() => [x("span", Q, [V(D(o.title) + " ", 1), i(d, { title: "AI工作流文档" }, {
      default: g(() => [x("a", W, [i(c, {
        style: {
          position: "relative",
          left: "2px",
          top: "1px"
        },
        icon: "ant-design:question-circle-outlined"
      })])]),
      _: 1
    })])]),
    default: g(() => [i(p, { onRegister: o.registerForm }, null, 8, ["onRegister"])]),
    _: 1
  }, 8, [
    "onRegister",
    "title",
    "onOk",
    "onCancel"
  ])]);
}
var Y = /* @__PURE__ */ A(K, [["render", X], ["__scopeId", "data-v-97890516"]]);
export {
  ie as i,
  ce as n,
  J as r,
  Y as t
};
