import { a as W } from "./objectSpread2-B0BetFB8.mjs";
import { t as q } from "./_plugin-vue_export-helper-Dj7HTbfw.mjs";
import { t as j } from "./VarListEditor-A0nqHeND.mjs";
import { t as X } from "./VarPicker-HOsUWkU-.mjs";
import { t as H } from "./VarListPicker-CrG8EHn2.mjs";
import { c as G, l as V } from "./base-node-CKuyN1x8.mjs";
import { i as K } from "./NodeContainer-zpIyuhKY.mjs";
import { t as Y } from "./useSettings-Cq_-E7Ut.mjs";
import "./Vars-Cgan49KR.mjs";
import { Alert as $, Divider as z, InputNumber as J, RadioButton as Q, RadioGroup as Z, Tag as h } from "ant-design-vue/es";
import { computed as O, createBlock as ee, createElementBlock as B, createElementVNode as n, createTextVNode as y, createVNode as l, defineComponent as te, isRef as c, openBlock as A, unref as a, watch as R, withCtx as m } from "vue";
var Ce = /* @__PURE__ */ (function(r) {
  return r.ID = "ID", r.WHEN = "WHEN", r.THEN = "THEN", r.SWITCH = "SWITCH", r.IF = "IF", r.GROUP = "GROUP", r.BREAK = "BREAK", r.CONTINUE = "CONTINUE", r.OR = "OR", r.AND = "AND", r.NOT = "NOT", r;
})({}), oe = /* @__PURE__ */ (function(r) {
  return r.CATCH = "CATCH", r.LOGIC = "LOGIC", r.CONFIG = "CONFIG", r.FOR = "FOR", r.WHILE = "WHILE", r.ITERATOR = "ITERATOR", r;
})({}), re = { class: "loop-setting" }, ae = { class: "setting-item" }, ne = {
  key: 0,
  class: "setting-item"
}, le = {
  key: 2,
  class: "setting-item"
}, se = { class: "label flex-space-between" }, ie = { class: "setting-item" }, de = { class: "label flex-space-between" }, ue = { class: "loop-var-section" }, pe = { class: "setting-item" }, ve = 1e3, me = /* @__PURE__ */ te({
  __name: "LoopSetting",
  props: {
    type: {
      type: String,
      required: !0
    },
    node: {
      type: Object,
      required: !0
    },
    properties: {
      type: Object,
      required: !0
    },
    isSilentMode: {
      type: Boolean,
      required: !0
    },
    setProperties: {
      type: Function,
      required: !0
    }
  },
  setup(r) {
    const g = r, S = {};
    Object.values(V).forEach((o) => S[o.field] = {});
    const { lfRef: E, outputParams: I, prevVariables: F, createOptionRef: b, isReadOnly: u } = Y(g), d = b("type"), f = b("maxLoopTimes"), v = b("loopParams"), P = b("loopItemsParam"), L = O(() => d.value === "array" ? V : [V[0]]), w = O(() => {
      const o = [];
      if (!E.value) return o;
      const e = E.value.graphModel, { node: t } = g, p = t.id + G, N = e.getNodeModelById(p);
      return N && N.children.forEach((x) => {
        const i = e.getNodeModelById(x);
        if (i) {
          const _ = i.type;
          let s = i.properties.outputParams;
          if (_ === K.START && (s = i.properties.inputParams), !Array.isArray(s) || s.length === 0) return;
          o.push(...s.map((C) => ({
            nodeId: i.id,
            nodeName: i.properties.text,
            field: C.field,
            name: C.name,
            type: C.type
          })));
        }
      }), o;
    }), M = O(() => {
      const { node: o } = g, e = (Array.isArray(v.value) ? v.value : []).filter((t) => t == null ? void 0 : t.name).filter((t) => (t == null ? void 0 : t.nodeId) && (t == null ? void 0 : t.field) || (t == null ? void 0 : t.customValue) || (t == null ? void 0 : t.customValue) === "").map((t) => {
        var p;
        return t.customValue || t.customValue === "" ? {
          nodeId: o.id,
          field: t.name,
          name: t.name,
          nodeName: "循环变量",
          type: t.type || "string"
        } : {
          nodeId: t.nodeId,
          field: t.field,
          name: t.name,
          nodeName: (p = t.nodeName) !== null && p !== void 0 ? p : "未知"
        };
      });
      return e.push(...w.value), e.unshift({
        nodeId: o.id,
        nodeName: "循环变量",
        field: "currentLoopTimes",
        name: "已循环次数",
        type: "number"
      }), e;
    });
    R(d, (o) => {
      const e = o != null ? o : "counted";
      o || (d.value = e), g.setProperties({ groupType: oe.WHILE });
    }, { immediate: !0 }), R(f, (o) => {
      (typeof o != "number" || !Number.isInteger(o) || o <= 0) && (f.value = 1);
    }, { immediate: !0 }), U(v), R(I, () => {
    }, {
      deep: !0,
      immediate: !0
    });
    function U(o) {
      return R(o, (e) => {
        Array.isArray(e) || (o.value = []);
      }, { immediate: !0 });
    }
    const T = [
      "string[]",
      "number[]",
      "object[]"
    ], k = O(() => P.value || {});
    function D(o) {
      if (!u.value) {
        if (o && !T.includes(o.type)) {
          P.value = {};
          return;
        }
        P.value = o || {};
      }
    }
    return (o, e) => {
      const t = Q, p = Z, N = J, x = $, i = h, _ = z;
      return A(), B("div", re, [
        n("div", ae, [e[7] || (e[7] = n("div", { class: "label" }, "循环类型", -1)), l(p, {
          value: a(d),
          "onUpdate:value": e[0] || (e[0] = (s) => c(d) ? d.value = s : null),
          "button-style": "solid",
          disabled: a(u)
        }, {
          default: m(() => [
            l(t, { value: "counted" }, {
              default: m(() => [...e[4] || (e[4] = [y("次数循环", -1)])]),
              _: 1
            }),
            l(t, { value: "infinite" }, {
              default: m(() => [...e[5] || (e[5] = [y("无限循环", -1)])]),
              _: 1
            }),
            l(t, { value: "array" }, {
              default: m(() => [...e[6] || (e[6] = [y("迭代循环", -1)])]),
              _: 1
            })
          ]),
          _: 1
        }, 8, ["value", "disabled"])]),
        a(d) === "counted" ? (A(), B("div", ne, [
          e[8] || (e[8] = n("div", { class: "label" }, "循环次数", -1)),
          l(N, {
            value: a(f),
            "onUpdate:value": e[1] || (e[1] = (s) => c(f) ? f.value = s : null),
            min: 1,
            max: ve,
            precision: 0,
            style: { width: "100%" },
            disabled: a(u)
          }, null, 8, ["value", "disabled"]),
          e[9] || (e[9] = n("p", { class: "p-tip" }, "按照设定次数执行循环，随后自动退出。", -1))
        ])) : a(d) === "infinite" ? (A(), ee(x, {
          key: 1,
          class: "setting-alert",
          type: "warning",
          "show-icon": "",
          message: "最大循环次数为1000"
        })) : (A(), B("div", le, [
          n("div", se, [e[11] || (e[11] = n("span", null, "迭代数组", -1)), l(i, { color: "blue" }, {
            default: m(() => [...e[10] || (e[10] = [y("数组类型", -1)])]),
            _: 1
          })]),
          l(a(X), {
            item: k.value,
            vars: a(F),
            allowedTypes: T,
            readonly: a(u),
            onChange: D
          }, null, 8, [
            "item",
            "vars",
            "readonly"
          ]),
          e[12] || (e[12] = n("p", { class: "p-tip" }, "仅可选择数组类型的变量，执行时按元素顺序遍历，遵循最大循环次数上限。", -1))
        ])),
        l(_, { style: { margin: "12px 0" } }),
        n("div", ie, [
          n("div", de, [e[14] || (e[14] = n("span", null, "循环变量", -1)), l(i, { color: "blue" }, {
            default: m(() => [...e[13] || (e[13] = [y("循环内可见", -1)])]),
            _: 1
          })]),
          e[15] || (e[15] = n("div", { class: "p-tip" }, "可引用已有变量或自定义新的循环变量，循环外无法访问。", -1)),
          n("div", ue, [l(a(j), {
            vars: L.value,
            fixedVars: S,
            allowAdd: !1,
            readonly: a(u)
          }, null, 8, ["vars", "readonly"]), l(a(H), {
            vars: a(v),
            "onUpdate:vars": e[2] || (e[2] = (s) => c(v) ? v.value = s : null),
            node: r.node,
            prevVariables: a(F),
            allowEditValue: "",
            readonly: a(u)
          }, null, 8, [
            "vars",
            "node",
            "prevVariables",
            "readonly"
          ])])
        ]),
        l(_, { style: { margin: "12px 0" } }),
        n("div", pe, [
          e[16] || (e[16] = n("div", { class: "label" }, "输出变量", -1)),
          e[17] || (e[17] = n("p", { class: "p-tip" }, "循环结束后输出的变量，仅支持引用循环体中节点的输出变量。", -1)),
          l(a(H), {
            vars: a(I),
            "onUpdate:vars": e[3] || (e[3] = (s) => c(I) ? I.value = s : null),
            readonly: a(u),
            prevVariables: M.value
          }, null, 8, [
            "vars",
            "readonly",
            "prevVariables"
          ])
        ]),
        l(_, { style: { margin: "12px 0" } })
      ]);
    };
  }
}), Ve = /* @__PURE__ */ W({ default: () => fe }), fe = /* @__PURE__ */ q(me, [["__scopeId", "data-v-c36d9c4b"]]);
export {
  oe as i,
  Ve as n,
  Ce as r,
  fe as t
};
