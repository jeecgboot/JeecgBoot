import { a as o } from "./objectSpread2-B0BetFB8.mjs";
import { t as e } from "./NodeIcon-Dt_fCcq_.mjs";
import { createBlock as t, defineComponent as r, openBlock as p } from "vue";
var _ = /* @__PURE__ */ r({
  __name: "LoopIcon",
  setup(n) {
    return (c, l) => (p(), t(e, {
      icon: "radix-icons:loop",
      color: "#8e6bff",
      "stroke-width": 0.5
    }));
  }
}), i = /* @__PURE__ */ o({ default: () => a }), a = _;
export {
  i as n,
  a as t
};
