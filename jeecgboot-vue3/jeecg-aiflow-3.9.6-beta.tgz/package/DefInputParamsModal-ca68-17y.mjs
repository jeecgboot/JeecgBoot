import { a as R } from "./objectSpread2-B0BetFB8.mjs";
import { t as p } from "./asyncToGenerator-BkhZtDh9.mjs";
import { t as b } from "./DebugRunForm-CsLYmHqB.mjs";
import { t as c } from "./inputParams-BzY4b0tw.mjs";
import { Alert as D } from "ant-design-vue/es";
import { createBlock as i, createElementVNode as F, defineComponent as O, nextTick as V, openBlock as l, ref as d, unref as f, watch as w, withCtx as C } from "vue";
import { useMessage as A } from "/@/hooks/web/useMessage";
import { BasicModal as B, useModal as S } from "/@/components/Modal";
var T = { style: { padding: "0 16px" } }, j = /* @__PURE__ */ O({
  __name: "DefInputParamsModal",
  props: {
    inputParams: {
      type: Array,
      required: !0
    },
    inputValues: {
      type: Object,
      default: void 0
    }
  },
  emits: ["update:inputValues"],
  setup(_, { expose: h, emit: y }) {
    const r = _, v = y, { createMessage: g } = A(), n = d(), s = d([]), [P, { openModal: M, closeModal: m }] = S();
    w(() => r.inputParams, () => {
      const e = c(r.inputParams);
      s.value = e.schemas;
    }, {
      immediate: !0,
      deep: !0
    });
    function k() {
      return o.apply(this, arguments);
    }
    function o() {
      return o = p(function* () {
        const e = c(r.inputParams);
        if (s.value = e.schemas, e.schemas.length === 0) {
          g.info("当前没有可配置的参数");
          return;
        }
        M(!0), yield V();
        const t = n.value;
        if (t) {
          var a;
          const I = (a = r.inputValues) !== null && a !== void 0 ? a : {};
          yield t.resetFields(), yield t.setFieldsValue(I), yield t.clearValidate();
        }
      }), o.apply(this, arguments);
    }
    function x() {
      return u.apply(this, arguments);
    }
    function u() {
      return u = p(function* () {
        if (!n.value) {
          m();
          return;
        }
        try {
          const e = yield n.value.validate();
          v("update:inputValues", e), m();
        } catch (e) {
        }
      }), u.apply(this, arguments);
    }
    return h({ open: k }), (e, t) => {
      const a = D;
      return l(), i(f(B), {
        onRegister: f(P),
        title: "设置默认参数",
        width: "520px",
        destroyOnClose: "",
        onOk: x
      }, {
        default: C(() => [F("div", T, [s.value.length ? (l(), i(b, {
          key: 0,
          ref_key: "inputParamFormRef",
          ref: n,
          schemas: s.value
        }, null, 8, ["schemas"])) : (l(), i(a, {
          key: 1,
          type: "info",
          "show-icon": "",
          message: "当前没有可配置的参数"
        }))])]),
        _: 1
      }, 8, ["onRegister"]);
    };
  }
}), U = /* @__PURE__ */ R({ default: () => q }), q = j;
export {
  U as n,
  q as t
};
