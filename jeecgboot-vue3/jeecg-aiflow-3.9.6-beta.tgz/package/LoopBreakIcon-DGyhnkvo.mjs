import { a as o } from "./objectSpread2-B0BetFB8.mjs";
import { t as e } from "./NodeIcon-Dt_fCcq_.mjs";
import { createBlock as r, defineComponent as t, openBlock as a } from "vue";
var c = /* @__PURE__ */ t({
  __name: "LoopBreakIcon",
  setup(_) {
    return (n, l) => (a(), r(e, {
      icon: "ic:baseline-stop-circle",
      color: "#ff5c5c",
      "stroke-width": 0
    }));
  }
}), i = /* @__PURE__ */ o({ default: () => p }), p = c;
export {
  i as n,
  p as t
};
