import { a as w, n as A, t as p } from "./objectSpread2-B0BetFB8.mjs";
import { Form as I, FormItem as S, Input as U, Select as F, Switch as C, Textarea as D } from "ant-design-vue/es";
import { createBlock as c, createCommentVNode as E, createElementVNode as O, createVNode as l, defineComponent as N, openBlock as g, ref as M, unref as y, withCtx as i } from "vue";
import { useMessage as P } from "/@/hooks/web/useMessage";
import { BasicModal as B, useModalInner as L } from "/@/components/Modal";
A();
var R = "failMessage", j = [{
  field: "failVarName",
  name: "失败变量名",
  type: "string"
}, {
  field: R,
  name: "失败提示",
  type: "string"
}];
function _() {
  return {
    name: "",
    field: "",
    type: "string",
    description: "",
    required: !1,
    failTip: ""
  };
}
function Z(d) {
  const u = [];
  for (const r of d) r != null && r.name && u.push({
    field: r.name,
    name: r.name,
    type: r.type || "string"
  });
  return [...u, ...j];
}
function ee(d, u) {
  return `${d}_${u}`;
}
var z = { style: { padding: "20px" } }, G = /* @__PURE__ */ N({
  __name: "VarDefineModal",
  emits: ["register", "ok"],
  setup(d, { emit: u }) {
    const r = u, { createMessage: v } = P(), m = M("新增变量"), e = M(_()), b = [
      {
        label: "文本",
        value: "string"
      },
      {
        label: "数字",
        value: "number"
      },
      {
        label: "布尔",
        value: "boolean"
      }
    ], [x, { setModalProps: k, closeModal: T }] = L((t) => {
      k({ maskClosable: !1 }), t != null && t.record ? (m.value = "编辑变量", e.value = p(p({}, _()), t.record)) : (m.value = "新增变量", e.value = _());
    });
    function h() {
      var t, a, s;
      const o = (t = e.value.name) === null || t === void 0 ? void 0 : t.trim();
      if (!o) {
        v.warning("请填写变量名称");
        return;
      }
      if (!e.value.type) {
        v.warning("请选择变量类型");
        return;
      }
      if (e.value.required && !(!((a = e.value.failTip) === null || a === void 0) && a.trim())) {
        v.warning("必填变量需要提供失败提示");
        return;
      }
      const f = p(p({}, e.value), {}, {
        name: o,
        field: o,
        failTip: (s = e.value.failTip) === null || s === void 0 ? void 0 : s.trim()
      });
      r("ok", f), T();
    }
    return (t, a) => {
      const s = U, o = S, f = F, V = D, $ = C, q = I;
      return g(), c(y(B), {
        title: m.value,
        canFullscreen: !1,
        width: "520px",
        onRegister: y(x),
        onOk: h
      }, {
        default: i(() => [O("div", z, [l(q, { layout: "vertical" }, {
          default: i(() => [
            l(o, {
              label: "名称",
              required: ""
            }, {
              default: i(() => [l(s, {
                value: e.value.name,
                "onUpdate:value": a[0] || (a[0] = (n) => e.value.name = n),
                maxlength: 40,
                placeholder: "请输入变量名称"
              }, null, 8, ["value"])]),
              _: 1
            }),
            l(o, {
              label: "类型",
              required: ""
            }, {
              default: i(() => [l(f, {
                value: e.value.type,
                "onUpdate:value": a[1] || (a[1] = (n) => e.value.type = n),
                options: b
              }, null, 8, ["value"])]),
              _: 1
            }),
            l(o, { label: "描述" }, {
              default: i(() => [l(V, {
                value: e.value.description,
                "onUpdate:value": a[2] || (a[2] = (n) => e.value.description = n),
                maxlength: 120,
                "show-count": "",
                placeholder: "请描述该变量的作用",
                "auto-size": ""
              }, null, 8, ["value"])]),
              _: 1
            }),
            l(o, { label: "必填" }, {
              default: i(() => [l($, {
                checked: e.value.required,
                "onUpdate:checked": a[3] || (a[3] = (n) => e.value.required = n)
              }, null, 8, ["checked"])]),
              _: 1
            }),
            e.value.required ? (g(), c(o, {
              key: 0,
              label: "失败提示",
              required: ""
            }, {
              default: i(() => [l(s, {
                value: e.value.failTip,
                "onUpdate:value": a[4] || (a[4] = (n) => e.value.failTip = n),
                maxlength: 80,
                placeholder: "请输入提取失败时的提示"
              }, null, 8, ["value"])]),
              _: 1
            })) : E("", !0)
          ]),
          _: 1
        })])]),
        _: 1
      }, 8, ["title", "onRegister"]);
    };
  }
}), ae = /* @__PURE__ */ w({ default: () => H }), H = G;
export {
  Z as a,
  j as i,
  ae as n,
  ee as o,
  R as r,
  H as t
};
