import { a as f } from "./objectSpread2-B0BetFB8.mjs";
import "./base-node-CKuyN1x8.mjs";
import { t as _ } from "./NodeContainer-zpIyuhKY.mjs";
import { t as N } from "./NodeKVS-CRVYjcYN.mjs";
import { t as h } from "./useNode-lPs0rKwe.mjs";
import { n as S } from "./cron-DXs1TpZn.mjs";
import { computed as b, createBlock as V, createVNode as k, defineComponent as x, mergeProps as y, openBlock as C, unref as n, withCtx as K } from "vue";
var O = /* @__PURE__ */ x({
  __name: "StartNode",
  props: {
    node: {
      type: Object,
      required: !0
    },
    graph: {
      type: Object,
      required: !0
    }
  },
  setup(i) {
    const { $properties: p, getInputParamKVItem: v } = h(i), s = b(() => {
      var t;
      const o = [], e = (t = p.value) === null || t === void 0 || (t = t.options) === null || t === void 0 ? void 0 : t.cronTrigger;
      if (e != null && e.enabled) {
        var l;
        const r = (l = e == null ? void 0 : e.cronExp) !== null && l !== void 0 ? l : "";
        if (r) {
          var a, u, d;
          const m = (u = (d = S((a = e == null ? void 0 : e.beginTime) !== null && a !== void 0 ? a : null).find((c) => c.value === r)) === null || d === void 0 ? void 0 : d.label) !== null && u !== void 0 ? u : "自定义";
          o.push({
            label: "定时触发",
            value: m + "执行"
          });
        }
      }
      return [...o, v({
        label: "输入字段",
        filter: (r) => r.field !== "history"
      })];
    });
    return (t, o) => (C(), V(n(_), y(t.$props, { hideAction: "" }), {
      default: K(() => [k(n(N), { kvs: s.value }, null, 8, ["kvs"])]),
      _: 1
    }, 16));
  }
}), z = /* @__PURE__ */ f({ default: () => j }), j = O;
export {
  z as n,
  j as t
};
