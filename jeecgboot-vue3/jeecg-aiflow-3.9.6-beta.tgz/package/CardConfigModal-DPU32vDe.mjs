import { a as ne } from "./objectSpread2-B0BetFB8.mjs";
import { t as ae } from "./_plugin-vue_export-helper-Dj7HTbfw.mjs";
import { t as O } from "./asyncToGenerator-BkhZtDh9.mjs";
import { Col as ie, Form as se, FormItem as de, Input as ue, Radio as re, RadioGroup as pe, Row as ve, Select as ce, Space as me, Switch as fe, Tooltip as _e } from "ant-design-vue/es";
import { Fragment as ge, computed as be, createBlock as u, createCommentVNode as v, createElementBlock as c, createElementVNode as o, createTextVNode as R, createVNode as i, defineComponent as Ce, mergeProps as k, normalizeClass as P, openBlock as a, reactive as E, ref as h, renderList as ye, resolveComponent as ke, toDisplayString as U, unref as r, withCtx as s } from "vue";
import { Form as he, message as Ue } from "ant-design-vue";
import we from "/@/components/Modal/src/BasicModal.vue";
import { useModalInner as je } from "/@/components/Modal";
import { Icon as J } from "/@/components/Icon";
var xe = { class: "card-select-panel" }, Me = ["onClick"], Ie = { class: "card-content" }, Je = { class: "card-title" }, Se = {
  key: 0,
  class: "card-top"
}, Fe = { class: "desc clamp" }, Oe = {
  key: 1,
  class: "card-top"
}, Re = { class: "desc clamp" }, Ve = {
  key: 2,
  class: "desc"
}, $e = { key: 3 }, qe = { class: "desc" }, Be = { class: "section-panel" }, Ne = { class: "stack" }, Pe = { class: "stack-parent" }, Ee = { style: {
  display: "flex",
  "align-items": "center"
} }, Le = { class: "field-control" }, Te = { class: "field-control" }, De = { class: "field-control" }, Ge = {
  key: 0,
  style: { "margin-top": "15px" },
  class: "stack-child-title"
}, ze = {
  key: 1,
  class: "field-control"
}, Ae = /* @__PURE__ */ Ce({
  __name: "CardConfigModal",
  emits: ["register", "ok"],
  setup(Ke, { emit: L }) {
    const T = L, w = h([]), p = be(() => {
      var n, e;
      return (n = (e = w.value.find((f) => f.value === t.outputContent)) === null || e === void 0 ? void 0 : e.fields) !== null && n !== void 0 ? n : [];
    }), d = E({
      title: "select",
      content: "select",
      image: "select",
      jumpUrl: "select"
    }), V = h(), $ = h({
      title: [{
        required: !0,
        message: "请填写标题的变量!"
      }],
      content: [{
        required: !0,
        message: "请填写内容的变量!"
      }],
      image: [{ required: !1 }],
      jumpUrl: [{ required: !1 }, { validator: X }],
      outputContent: [{
        required: !0,
        message: "请绑定输出变量!"
      }]
    }), m = h("template-1"), D = h([
      {
        id: "template-1",
        variant: "thumb-left",
        title: "标题",
        desc: "内容描述是一种重要的沟通和表达，它在描述事物时发挥着至关重要的作用"
      },
      {
        id: "template-2",
        variant: "thumb-right",
        title: "标题",
        desc: "内容描述是一种重要的沟通和表达，它在描述事物时发挥着至关的作用"
      },
      {
        id: "template-3",
        variant: "banner",
        title: "标题",
        desc: "内容描述是一种重要的沟通和表达，它在描述事物时发挥着至关的重要性"
      },
      {
        id: "template-4",
        variant: "text",
        title: "标题",
        desc: "内容描述是一种重要的沟通和表达，它在描述事物时发挥着至关的重要性"
      }
    ]), [G, { setModalProps: z, closeModal: A }] = je((function() {
      var n = O(function* (e) {
        if (e.outputOptions) {
          w.value = [];
          for (const g of e.outputOptions) {
            var f;
            let _ = {
              label: g.name,
              value: "{{" + g.name + "}}",
              fields: (f = g.fields) !== null && f !== void 0 ? f : []
            };
            w.value.push(_);
          }
        }
        if (e.formData) {
          var C;
          Object.assign(t, e.formData), m.value = (C = e.formData) === null || C === void 0 ? void 0 : C.templateId;
        }
        q(), z({ bodyStyle: { padding: "10px" } });
      });
      return function(e) {
        return n.apply(this, arguments);
      };
    })()), H = he.useForm, t = E({
      title: void 0,
      image: void 0,
      content: void 0,
      enableJump: !1,
      templateId: void 0,
      jumpUrl: void 0,
      outputContent: void 0
    }), { resetFields: K, validate: Q, validateInfos: b, clearValidate: W } = H(t, $, { immediate: !1 });
    function q() {
      Object.keys(d).forEach((n) => d[n] = "select");
    }
    function j(n) {
      return p.value.length > 0 && d[n] === "select";
    }
    function x(n) {
      d[n] = d[n] === "select" ? "input" : "select";
    }
    function X(n, e) {
      return t.enableJump && !e ? Promise.reject("请填写跳转路径的变量") : Promise.resolve();
    }
    function Y() {
      return S.apply(this, arguments);
    }
    function S() {
      return S = O(function* () {
        if (!m.value) return Ue.warning("请选择一个卡片样式");
        yield Q();
        const n = {
          templateId: m.value,
          title: t.title,
          image: t.image,
          content: t.content,
          enableJump: t.enableJump,
          jumpUrl: t.jumpUrl,
          outputContent: t.outputContent
        };
        T("ok", n), B();
      }), S.apply(this, arguments);
    }
    function B() {
      var n;
      K(), (n = V.value) === null || n === void 0 || n.clearValidate(), A();
    }
    function Z(n) {
      return F.apply(this, arguments);
    }
    function F() {
      return F = O(function* (n) {
        n || W("jumpUrl");
      }), F.apply(this, arguments);
    }
    return (n, e) => {
      const f = re, C = pe, g = ie, _ = ce, y = de, M = ue, I = _e, ee = fe, te = se, le = ve, N = ke("a-button"), oe = me;
      return a(), u(we, {
        destroyOnClose: "",
        onRegister: r(G),
        canFullscreen: !1,
        width: "1000px",
        title: "智能体回复卡片配置"
      }, {
        footer: s(() => [i(oe, null, {
          default: s(() => [i(N, {
            type: "primary",
            onClick: Y
          }, {
            default: s(() => [...e[22] || (e[22] = [R("保存", -1)])]),
            _: 1
          }), i(N, { onClick: B }, {
            default: s(() => [...e[23] || (e[23] = [R("取消", -1)])]),
            _: 1
          })]),
          _: 1
        })]),
        default: s(() => [i(le, { span: 24 }, {
          default: s(() => [i(g, {
            span: 10,
            style: { "border-right": "1px solid #ebedf0" }
          }, {
            default: s(() => [e[18] || (e[18] = o("div", null, [o("span", null, "选择卡片样式")], -1)), o("div", xe, [i(C, {
              value: m.value,
              "onUpdate:value": e[0] || (e[0] = (l) => m.value = l),
              class: "card-radio-group"
            }, {
              default: s(() => [(a(!0), c(ge, null, ye(D.value, (l) => (a(), c("div", {
                key: l.id,
                class: P(["card-item", ["variant-" + l.variant, { selected: m.value === l.id }]]),
                onClick: (Qe) => m.value = l.id
              }, [i(f, {
                value: l.id,
                class: "card-radio"
              }, null, 8, ["value"]), o("div", Ie, [
                o("div", Je, U(l.title), 1),
                l.variant === "thumb-left" ? (a(), c("div", Se, [e[15] || (e[15] = o("div", { class: "thumb" }, [o("div", { class: "thumb-dot" }), o("div", { class: "thumb-mountain" })], -1)), o("div", Fe, U(l.desc), 1)])) : v("", !0),
                l.variant === "thumb-right" ? (a(), c("div", Oe, [o("div", Re, U(l.desc), 1), e[16] || (e[16] = o("div", { class: "thumb" }, [o("div", { class: "thumb-dot" }), o("div", { class: "thumb-mountain" })], -1))])) : l.variant === "text" ? (a(), c("div", Ve, U(l.desc), 1)) : l.variant === "banner" ? (a(), c("div", $e, [e[17] || (e[17] = o("div", { class: "banner" }, [o("div", { class: "banner-dot" }), o("div", { class: "banner-mountain" })], -1)), o("div", qe, U(l.desc), 1)])) : v("", !0)
              ])], 10, Me))), 128))]),
              _: 1
            }, 8, ["value"])])]),
            _: 1
          }), i(g, { span: 14 }, {
            default: s(() => [o("div", Be, [e[20] || (e[20] = o("div", { class: "section-title" }, "为卡片内元素绑定数据", -1)), i(te, {
              ref_key: "formRef",
              ref: V,
              model: t,
              layout: "vertical",
              style: { "margin-top": "10px" },
              rules: $.value
            }, {
              default: s(() => [o("div", Ne, [o("div", Pe, [i(y, k({ label: "输出变量" }, r(b).outputContent), {
                default: s(() => [o("div", Ee, [i(_, {
                  value: t.outputContent,
                  "onUpdate:value": e[1] || (e[1] = (l) => t.outputContent = l),
                  options: w.value,
                  placeholder: "绑定输出变量",
                  style: { width: "100%" },
                  allowClear: "",
                  onChange: q
                }, null, 8, ["value", "options"])])]),
                _: 1
              }, 16)]), o("div", { class: P(["stack-children", { disabled: !t.outputContent }]) }, [
                i(y, k({ label: "标题" }, r(b).title), {
                  default: s(() => [o("div", Le, [j("title") ? (a(), u(_, {
                    key: 0,
                    value: t.title,
                    "onUpdate:value": e[2] || (e[2] = (l) => t.title = l),
                    options: p.value,
                    placeholder: "为标题绑定数据来源",
                    disabled: !t.outputContent,
                    showSearch: "",
                    allowClear: ""
                  }, null, 8, [
                    "value",
                    "options",
                    "disabled"
                  ])) : (a(), u(M, {
                    key: 1,
                    value: t.title,
                    "onUpdate:value": e[3] || (e[3] = (l) => t.title = l),
                    placeholder: "请输入标题字段名",
                    disabled: !t.outputContent
                  }, null, 8, ["value", "disabled"])), p.value.length ? (a(), u(I, {
                    key: 2,
                    title: d.title === "select" ? "切换为手写" : "切换为下拉选择"
                  }, {
                    default: s(() => [i(r(J), {
                      class: "mode-switch",
                      icon: d.title === "select" ? "ant-design:edit-outlined" : "ant-design:unordered-list-outlined",
                      onClick: e[4] || (e[4] = (l) => x("title"))
                    }, null, 8, ["icon"])]),
                    _: 1
                  }, 8, ["title"])) : v("", !0)])]),
                  _: 1
                }, 16),
                i(y, k({ label: "内容" }, r(b).content), {
                  default: s(() => [o("div", Te, [j("content") ? (a(), u(_, {
                    key: 0,
                    value: t.content,
                    "onUpdate:value": e[5] || (e[5] = (l) => t.content = l),
                    options: p.value,
                    placeholder: "为内容绑定数据来源",
                    disabled: !t.outputContent,
                    showSearch: "",
                    allowClear: ""
                  }, null, 8, [
                    "value",
                    "options",
                    "disabled"
                  ])) : (a(), u(M, {
                    key: 1,
                    value: t.content,
                    "onUpdate:value": e[6] || (e[6] = (l) => t.content = l),
                    placeholder: "请输入内容字段名",
                    disabled: !t.outputContent
                  }, null, 8, ["value", "disabled"])), p.value.length ? (a(), u(I, {
                    key: 2,
                    title: d.content === "select" ? "切换为手写" : "切换为下拉选择"
                  }, {
                    default: s(() => [i(r(J), {
                      class: "mode-switch",
                      icon: d.content === "select" ? "ant-design:edit-outlined" : "ant-design:unordered-list-outlined",
                      onClick: e[7] || (e[7] = (l) => x("content"))
                    }, null, 8, ["icon"])]),
                    _: 1
                  }, 8, ["title"])) : v("", !0)])]),
                  _: 1
                }, 16),
                i(y, k({ label: "图片" }, r(b).image), {
                  default: s(() => [o("div", De, [j("image") ? (a(), u(_, {
                    key: 0,
                    value: t.image,
                    "onUpdate:value": e[8] || (e[8] = (l) => t.image = l),
                    options: p.value,
                    placeholder: "为图片绑定数据来源",
                    disabled: !t.outputContent,
                    showSearch: "",
                    allowClear: ""
                  }, null, 8, [
                    "value",
                    "options",
                    "disabled"
                  ])) : (a(), u(M, {
                    key: 1,
                    value: t.image,
                    "onUpdate:value": e[9] || (e[9] = (l) => t.image = l),
                    placeholder: "请输入图片字段名",
                    disabled: !t.outputContent
                  }, null, 8, ["value", "disabled"])), p.value.length ? (a(), u(I, {
                    key: 2,
                    title: d.image === "select" ? "切换为手写" : "切换为下拉选择"
                  }, {
                    default: s(() => [i(r(J), {
                      class: "mode-switch",
                      icon: d.image === "select" ? "ant-design:edit-outlined" : "ant-design:unordered-list-outlined",
                      onClick: e[10] || (e[10] = (l) => x("image"))
                    }, null, 8, ["icon"])]),
                    _: 1
                  }, 8, ["title"])) : v("", !0)])]),
                  _: 1
                }, 16),
                i(y, k({ label: "点击卡片跳转" }, r(b).jumpUrl), {
                  default: s(() => [
                    i(ee, {
                      checked: t.enableJump,
                      "onUpdate:checked": e[11] || (e[11] = (l) => t.enableJump = l),
                      onChange: Z,
                      disabled: !t.outputContent
                    }, null, 8, ["checked", "disabled"]),
                    t.enableJump ? (a(), c("div", Ge, [...e[19] || (e[19] = [o("span", { style: {
                      color: "red",
                      "margin-right": "6px"
                    } }, "*", -1), R("跳转路径 ", -1)])])) : v("", !0),
                    t.enableJump ? (a(), c("div", ze, [j("jumpUrl") ? (a(), u(_, {
                      key: 0,
                      value: t.jumpUrl,
                      "onUpdate:value": e[12] || (e[12] = (l) => t.jumpUrl = l),
                      options: p.value,
                      placeholder: "为卡片跳转路径绑定数据来源",
                      disabled: !t.outputContent,
                      showSearch: "",
                      allowClear: ""
                    }, null, 8, [
                      "value",
                      "options",
                      "disabled"
                    ])) : (a(), u(M, {
                      key: 1,
                      value: t.jumpUrl,
                      "onUpdate:value": e[13] || (e[13] = (l) => t.jumpUrl = l),
                      placeholder: "请输入跳转路径字段名",
                      disabled: !t.outputContent
                    }, null, 8, ["value", "disabled"])), p.value.length ? (a(), u(I, {
                      key: 2,
                      title: d.jumpUrl === "select" ? "切换为手写" : "切换为下拉选择"
                    }, {
                      default: s(() => [i(r(J), {
                        class: "mode-switch",
                        icon: d.jumpUrl === "select" ? "ant-design:edit-outlined" : "ant-design:unordered-list-outlined",
                        onClick: e[14] || (e[14] = (l) => x("jumpUrl"))
                      }, null, 8, ["icon"])]),
                      _: 1
                    }, 8, ["title"])) : v("", !0)])) : v("", !0)
                  ]),
                  _: 1
                }, 16)
              ], 2)])]),
              _: 1
            }, 8, ["model", "rules"])]), e[21] || (e[21] = o("div", { class: "tip" }, [o("p", null, "提示："), o("p", null, "标题、内容、图片、跳转路径当前为 LLM 返回的变量，需手动输入配置；")], -1))]),
            _: 1
          })]),
          _: 1
        })]),
        _: 1
      }, 8, ["onRegister"]);
    };
  }
}), at = /* @__PURE__ */ ne({ default: () => He }), He = /* @__PURE__ */ ae(Ae, [["__scopeId", "data-v-28c24c32"]]);
export {
  at as n,
  He as t
};
