import { a as u } from "./objectSpread2-B0BetFB8.mjs";
import "./base-node-CKuyN1x8.mjs";
import { t as i } from "./NodeContainer-zpIyuhKY.mjs";
import { t as n } from "./NodeKVS-CRVYjcYN.mjs";
import { t as s } from "./useNode-lPs0rKwe.mjs";
import { computed as m, createBlock as v, createVNode as _, defineComponent as c, guardReactiveProps as f, normalizeProps as y, openBlock as N, unref as r, withCtx as C } from "vue";
var b = /* @__PURE__ */ c({
  __name: "CodeNode",
  props: {
    node: {
      type: Object,
      required: !0
    },
    graph: {
      type: Object,
      required: !0
    }
  },
  setup(a) {
    const { $properties: o, getInputParamKVItem: p, getOutputParamKVItem: d } = s(a), l = m(() => {
      var e, t;
      return [
        p({
          label: "输入变量",
          emptyAction: "hidden"
        }),
        {
          label: "脚本类型",
          value: (e = o.value) === null || e === void 0 || (e = e.options) === null || e === void 0 ? void 0 : e.codeType
        },
        {
          label: "脚本代码",
          value: (t = o.value) === null || t === void 0 || (t = t.options) === null || t === void 0 ? void 0 : t.code,
          emptyAction: "tip",
          emptyTip: "尚未填写"
        },
        d({
          label: "输出变量",
          emptyAction: "hidden"
        })
      ];
    });
    return (e, t) => (N(), v(r(i), y(f(e.$props)), {
      default: C(() => [_(r(n), { kvs: l.value }, null, 8, ["kvs"])]),
      _: 1
    }, 16));
  }
}), K = /* @__PURE__ */ u({ default: () => $ }), $ = b;
export {
  K as n,
  $ as t
};
