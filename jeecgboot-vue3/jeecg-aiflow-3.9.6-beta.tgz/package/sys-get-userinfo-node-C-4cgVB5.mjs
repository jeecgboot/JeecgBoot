import { a as N } from "./objectSpread2-B0BetFB8.mjs";
import { t as P } from "./_plugin-vue_export-helper-Dj7HTbfw.mjs";
import { t as $ } from "./VarListShow-Dg1oan43.mjs";
import { i as I, r as q } from "./base-node-CKuyN1x8.mjs";
import { i as S, t as B } from "./NodeContainer-zpIyuhKY.mjs";
import { t as D } from "./NodeKVS-CRVYjcYN.mjs";
import { t as V } from "./useNode-lPs0rKwe.mjs";
import { t as j } from "./useSettings-Cq_-E7Ut.mjs";
import { n as R } from "./SysGetUserinfoIcon-BlKAkVaR.mjs";
import { Alert as T, Checkbox as L, CheckboxGroup as M, Col as K, Row as Y } from "ant-design-vue/es";
import { Fragment as z, computed as k, createBlock as w, createElementBlock as h, createElementVNode as g, createTextVNode as H, createVNode as l, defineComponent as U, guardReactiveProps as J, normalizeProps as Q, openBlock as _, renderList as W, toDisplayString as x, unref as p, withCtx as u } from "vue";
import { cloneDeep as X } from "lodash-es";
var Z = { class: "sys-get-userinfo-setting" }, ee = { class: "field-key" }, te = /* @__PURE__ */ U({
  __name: "SysGetUserinfoSetting",
  props: {
    type: {
      type: String,
      required: !0
    },
    node: {
      type: Object,
      required: !0
    },
    properties: {
      type: Object,
      required: !0
    },
    isSilentMode: {
      type: Boolean,
      required: !0
    },
    setProperties: {
      type: Function,
      required: !0
    }
  },
  setup(t) {
    const r = t, { outputParams: e, options: s, updateOptions: i, isReadOnly: o } = j(r), y = k(() => {
      var n;
      const a = (n = s.value) === null || n === void 0 ? void 0 : n.fields;
      return Array.isArray(a) ? X(a) : [];
    });
    function v(n) {
      if (o.value) return;
      const a = new Set(Array.isArray(n) ? n : []), m = f.filter((d) => a.has(d.field)).map((d) => d.field);
      i({ fields: m }), r.setProperties({ outputParams: C(m) });
    }
    return (n, a) => {
      const m = T, d = L, E = K, F = Y, O = M;
      return _(), h("div", Z, [
        l(m, {
          type: "info",
          "show-icon": "",
          message: "读取当前登录用户的基本信息，需要在已登录状态下使用",
          style: { "margin-bottom": "10px" }
        }),
        a[0] || (a[0] = g("div", { class: "setting-label" }, "输出字段（勾选要传递给下游节点的用户信息）", -1)),
        l(O, {
          value: y.value,
          disabled: p(o),
          class: "fields-checkbox-group",
          onChange: v
        }, {
          default: u(() => [l(F, null, {
            default: u(() => [(_(!0), h(z, null, W(p(f), (c) => (_(), w(E, {
              key: c.field,
              span: 12,
              class: "field-col"
            }, {
              default: u(() => [l(d, { value: c.field }, {
                default: u(() => [H(x(c.name) + " ", 1), g("span", ee, "(" + x(c.field) + ")", 1)]),
                _: 2
              }, 1032, ["value"])]),
              _: 2
            }, 1024))), 128))]),
            _: 1
          })]),
          _: 1
        }, 8, ["value", "disabled"]),
        a[1] || (a[1] = g("div", {
          class: "setting-label",
          style: { "margin-top": "16px" }
        }, "输出变量", -1)),
        l($, { vars: p(e) }, null, 8, ["vars"])
      ]);
    };
  }
}), Se = /* @__PURE__ */ N({ default: () => A }), A = /* @__PURE__ */ P(te, [["__scopeId", "data-v-49065f05"]]), re = /* @__PURE__ */ U({
  __name: "SysGetUserinfoNode",
  props: {
    node: {
      type: Object,
      required: !0
    },
    graph: {
      type: Object,
      required: !0
    }
  },
  setup(t) {
    const { containerProps: r, $properties: e } = V(t), s = k(() => {
      var i, o;
      const y = Array.isArray((i = e.value) === null || i === void 0 || (i = i.options) === null || i === void 0 ? void 0 : i.fields) ? (o = e.value) === null || o === void 0 || (o = o.options) === null || o === void 0 ? void 0 : o.fields : [], v = new Map(f.map((n) => [n.field, n.name]));
      return [{
        label: "输出字段",
        value: y.map((n) => v.get(n) || n).filter(Boolean).join("、"),
        emptyAction: "tip",
        emptyTip: "尚未勾选"
      }];
    });
    return (i, o) => (_(), w(p(B), Q(J(p(r))), {
      default: u(() => [l(p(D), { kvs: s.value }, null, 8, ["kvs"])]),
      _: 1
    }, 16));
  }
}), he = /* @__PURE__ */ N({ default: () => G }), G = re, f = [
  {
    field: "username",
    name: "账号",
    type: "string",
    default: !0
  },
  {
    field: "realname",
    name: "姓名",
    type: "string",
    default: !0
  },
  {
    field: "id",
    name: "用户ID",
    type: "string"
  },
  {
    field: "orgCode",
    name: "部门编码",
    type: "string"
  },
  {
    field: "orgId",
    name: "部门ID",
    type: "string"
  },
  {
    field: "roleCode",
    name: "角色编码",
    type: "string"
  },
  {
    field: "avatar",
    name: "头像",
    type: "string"
  },
  {
    field: "workNo",
    name: "工号",
    type: "string"
  },
  {
    field: "post",
    name: "职务",
    type: "string"
  },
  {
    field: "email",
    name: "邮箱",
    type: "string"
  },
  {
    field: "phone",
    name: "手机号",
    type: "string"
  },
  {
    field: "telephone",
    name: "座机号",
    type: "string"
  },
  {
    field: "sex",
    name: "性别(1男2女)",
    type: "number"
  },
  {
    field: "birthday",
    name: "生日",
    type: "string"
  }
], oe = f.filter((t) => t.default).map((t) => t.field), b = {
  type: S.SYS_GET_USERINFO,
  label: "用户信息",
  docs: ["https://help.jeecg.com/aigc/flowNodes/nodeSysGetUserinfo"],
  components: {
    icon: R,
    setting: A
  },
  lfNode: {
    type: S.SYS_GET_USERINFO,
    view: q,
    model: I,
    component: G
  },
  params: {
    width: 332,
    height: 62
  },
  methods: {
    createNode: ne,
    checkNode: ie
  }
};
function ne(t) {
  var r;
  const e = [...oe];
  return {
    id: t.id,
    type: b.type,
    x: t.x,
    y: t.y,
    properties: {
      text: (r = t.text) !== null && r !== void 0 ? r : b.label,
      options: { fields: e },
      inputParams: [],
      outputParams: C(e)
    }
  };
}
function ie(t, r) {
  var e, s;
  const i = [], o = (e = r == null || (s = r.properties) === null || s === void 0 || (s = s.options) === null || s === void 0 ? void 0 : s.fields) !== null && e !== void 0 ? e : [];
  return (!Array.isArray(o) || o.length === 0) && i.push("请至少勾选一个输出字段"), i;
}
function C(t) {
  const r = new Set(t || []);
  return f.filter((e) => r.has(e.field)).map((e) => ({
    field: e.field,
    name: e.name,
    type: e.type
  }));
}
export {
  he as n,
  Se as r,
  b as t
};
