import { a as q } from "./objectSpread2-B0BetFB8.mjs";
import { t as b } from "./asyncToGenerator-BkhZtDh9.mjs";
import { o as U } from "./api-BJs6o08o.mjs";
import { t as z } from "./VarTextarea-BzeLBgKt.mjs";
import "./Vars-Cgan49KR.mjs";
import { Alert as D, Form as J, FormItem as L, Tag as W } from "ant-design-vue/es";
import { computed as y, createBlock as H, createTextVNode as T, createVNode as l, defineComponent as K, openBlock as Q, ref as d, resolveComponent as x, toDisplayString as X, unref as m, withCtx as u } from "vue";
import { useMessage as Y } from "/@/hooks/web/useMessage";
import { BasicModal as Z, useModalInner as $ } from "/@/components/Modal";
import { CodeEditor as ee } from "/@/components/CodeEditor";
var te = /* @__PURE__ */ K({
  __name: "AiCodeGenerateModal",
  emits: ["register", "apply"],
  setup(oe, { emit: A }) {
    const M = A, { createMessage: g } = Y(), p = d(""), r = d(""), s = d(!1), i = d({
      codeType: "javascript",
      code: "",
      inputParams: [],
      outputParams: []
    }), G = {
      javascript: "JavaScript",
      python: "Python",
      groovy: "Groovy",
      aviator: "Aviator"
    }, P = y(() => G[i.value.codeType] || i.value.codeType), w = y(() => i.value.inputParams.filter((e) => e.name).map((e) => ({
      name: e.name,
      type: e.type || "string"
    }))), S = y(() => i.value.codeType === "python" ? "python" : "javascript"), [k, { closeModal: I }] = $((e) => {
      i.value = e, p.value = "", r.value = "", s.value = !1;
    });
    function E() {
      const e = i.value.inputParams.map((a) => ({
        name: a.name,
        type: a.type || "string"
      })), t = i.value.outputParams.map((a) => ({
        field: a.field,
        type: a.type || "string"
      }));
      return {
        codeType: i.value.codeType,
        requirement: p.value,
        inputParams: e,
        outputParams: t
      };
    }
    function O() {
      return v.apply(this, arguments);
    }
    function v() {
      return v = b(function* () {
        r.value = "", s.value = !0;
        const e = yield U(E()).catch(() => {
        });
        if (!e) {
          s.value = !1;
          return;
        }
        try {
          yield R(e), r.value = C(B(r.value)), r.value || g.warning("AI 未生成有效脚本");
        } finally {
          s.value = !1;
        }
      }), v.apply(this, arguments);
    }
    function R(e) {
      return f.apply(this, arguments);
    }
    function f() {
      return f = b(function* (e) {
        const t = e.getReader(), a = new TextDecoder("UTF-8");
        let o = "";
        for (; ; ) {
          const { done: n, value: _ } = yield t.read();
          o += a.decode(_ || /* @__PURE__ */ new Uint8Array(), { stream: !n });
          const c = o.split(`

`);
          if (o = n ? "" : c.pop() || "", c.forEach(h), n) {
            o && h(o);
            break;
          }
        }
      }), f.apply(this, arguments);
    }
    function h(e) {
      const t = e.replace(/^data:\s*/, "").trim();
      if (t)
        try {
          const n = JSON.parse(t);
          if (n.event === "MESSAGE") {
            var a;
            r.value += ((a = n.data) === null || a === void 0 ? void 0 : a.message) || "";
          } else if (n.event === "ERROR") {
            var o;
            g.error(((o = n.data) === null || o === void 0 ? void 0 : o.message) || "脚本生成失败");
          }
        } catch (n) {
        }
    }
    function B(e) {
      return e.trim().replace(/^```[\w-]*\s*/, "").replace(/\s*```$/, "").trim();
    }
    function C(e) {
      if (i.value.codeType !== "aviator") return e;
      const t = e.replace(/\r?\n\s*resp\s*;?\s*$/, "").trim();
      return t && !t.endsWith(";") ? `${t};` : t;
    }
    function F(e) {
      r.value = e;
    }
    function N() {
      const e = C(r.value);
      r.value = e, M("apply", e), I();
    }
    return (e, t) => {
      const a = W, o = L, n = x("Icon"), _ = x("a-button"), c = D, V = J;
      return Q(), H(m(Z), {
        title: "AI 帮写脚本",
        width: "900px",
        okText: "应用脚本",
        canFullscreen: !1,
        confirmLoading: s.value,
        okButtonProps: { disabled: s.value || !r.value },
        onRegister: m(k),
        onOk: N
      }, {
        default: u(() => [l(V, { layout: "vertical" }, {
          default: u(() => [
            l(o, { label: "当前脚本" }, {
              default: u(() => [l(a, { color: "blue" }, {
                default: u(() => [T(X(P.value), 1)]),
                _: 1
              })]),
              _: 1
            }),
            l(o, {
              label: "需求描述",
              required: ""
            }, {
              default: u(() => [l(m(z), {
                value: p.value,
                "onUpdate:value": t[0] || (t[0] = (j) => p.value = j),
                varsOptions: w.value,
                height: 100,
                placeholder: "请描述脚本需要完成的业务逻辑，输入 / 可选择变量"
              }, null, 8, ["value", "varsOptions"])]),
              _: 1
            }),
            l(_, {
              type: "primary",
              loading: s.value,
              disabled: !p.value.trim(),
              onClick: O
            }, {
              default: u(() => [l(n, { icon: "ant-design:robot-outlined" }), t[1] || (t[1] = T(" 生成 ", -1))]),
              _: 1
            }, 8, ["loading", "disabled"]),
            l(c, {
              class: "mt-3",
              type: "warning",
              "show-icon": "",
              message: "AI 生成内容仅供参考，请检查后再应用和运行。"
            }),
            l(o, {
              class: "mt-3",
              label: "生成结果"
            }, {
              default: u(() => [l(m(ee), {
                value: r.value,
                mode: S.value,
                onChange: F
              }, null, 8, ["value", "mode"])]),
              _: 1
            })
          ]),
          _: 1
        })]),
        _: 1
      }, 8, [
        "confirmLoading",
        "okButtonProps",
        "onRegister"
      ]);
    };
  }
}), ve = /* @__PURE__ */ q({ default: () => ae }), ae = te;
export {
  ve as n,
  ae as t
};
