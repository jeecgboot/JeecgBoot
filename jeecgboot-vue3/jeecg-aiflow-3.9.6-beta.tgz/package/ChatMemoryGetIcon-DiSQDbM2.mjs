import { a as o } from "./objectSpread2-B0BetFB8.mjs";
import { t as r } from "./NodeIcon-Dt_fCcq_.mjs";
import { createBlock as t, openBlock as e } from "vue";
var i = /* @__PURE__ */ o({ default: () => a }), a = {
  __name: "ChatMemoryGetIcon",
  setup(c) {
    return (_, m) => (e(), t(r, {
      icon: "mdi:brain",
      color: "#4165d7"
    }));
  }
};
export {
  a as n,
  i as t
};
