import { computed as i } from "vue";
import * as h from "lodash-es";
import { cloneDeep as p } from "lodash-es";
import { store as f } from "/@/store";
import { defineStore as l } from "pinia";
var a = l("airag-flow-prop", {
  state: () => ({
    props: {},
    models: /* @__PURE__ */ new Map(),
    store: {},
    storeRef: /* @__PURE__ */ new Map(),
    nodeGroupMap: /* @__PURE__ */ new Map()
  }),
  actions: {
    setProps(t) {
      const { id: e, properties: r } = t;
      this.props[e] = p(r), this.models.set(e, t), this.store[e] = {};
    },
    updateProps(t, e) {
      if (t && this.models.has(t)) {
        this.props[t] = p(e);
        const r = this.models.get(t);
        r.properties = this.props[t];
      }
    },
    setProperties(t, e) {
      if (!t || !this.models.has(t)) return;
      const r = Object.keys(e);
      if (!e || r.length === 0) return;
      const s = this.models.get(t), o = p(this.getProps(t));
      r.forEach((n) => h.set(o, n, e[n])), this.props[t] = o, s.properties = o;
    },
    removeProps(t) {
      t && (delete this.props[t], this.models.delete(t), delete this.store[t], this.storeRef.delete(t));
    },
    clearProps() {
      this.props = {}, this.models.clear(), this.store = {}, this.storeRef.clear(), this.nodeGroupMap.clear();
    },
    getProps(t) {
      if (!t) return {};
      const e = this.props[t];
      return e || {};
    },
    getStore(t) {
      const e = this.store[t];
      return e || null;
    },
    createStoreRef(t, e) {
      if (this.storeRef.has(t)) return this.storeRef.get(t);
      const r = i({
        get: () => {
          const s = this.getStore(t);
          return !s || !s[e] ? null : s[e];
        },
        set: (s) => {
          const o = this.getStore(t);
          o && (o[e] = s);
        }
      });
      return this.storeRef.set(t, r), r;
    }
  }
});
function P() {
  return a(f);
}
export {
  P as n,
  a as t
};
