function f(e, t) {
  if (/^[0-9]/.test(e)) return {
    passed: !1,
    message: "不能以数字开头"
  };
  const { allowDot: l = !1 } = t != null ? t : {};
  if (l) {
    if (/^\./.test(e)) return {
      passed: !1,
      message: "不能以小数点开头"
    };
    if (/\.$/.test(e)) return {
      passed: !1,
      message: "不能以小数点结尾"
    };
    if (/\.{2}/.test(e)) return {
      passed: !1,
      message: "不能连续出现小数点"
    };
  }
  let s = "a-zA-Z_\\u4e00-\\u9fa5", a = [
    "字母",
    "数字",
    "下划线",
    "中文"
  ];
  l && (s += "\\.", a.splice(3, 0, "小数点"), s += "\\[\\]", a.splice(3, 0, "英文中括号"));
  const r = `^[${s}][0-9${s}]*$`;
  return new RegExp(r).test(e) ? {
    passed: !0,
    message: ""
  } : {
    passed: !1,
    message: "只能包含" + a.join("、")
  };
}
export {
  f as t
};
