import { a as c } from "./objectSpread2-B0BetFB8.mjs";
import "./base-node-CKuyN1x8.mjs";
import { t as m } from "./NodeContainer-zpIyuhKY.mjs";
import { t as v } from "./NodeKVS-CRVYjcYN.mjs";
import { t as _ } from "./useNode-lPs0rKwe.mjs";
import { computed as n, createBlock as f, createVNode as y, defineComponent as g, guardReactiveProps as h, normalizeProps as C, openBlock as N, unref as r, withCtx as b } from "vue";
var x = /* @__PURE__ */ g({
  __name: "ChatMemorySetNode",
  props: {
    node: {
      type: Object,
      required: !0
    },
    graph: {
      type: Object,
      required: !0
    }
  },
  setup(i) {
    const { containerProps: u, $properties: a, getInputParamKVItem: l, getOutputParamKVItem: p } = _(i), s = n(() => {
      var e;
      const t = (e = a.value) === null || e === void 0 ? void 0 : e.options;
      if (!(t != null && t.waitForVectorize)) return "";
      const o = t.vectorizeFailStrategy === "error" ? "失败中断" : "失败忽略";
      return `开启，${t.waitTimeout || 300}秒超时（${o}）`;
    }), d = n(() => {
      var e;
      const t = ((e = a.value) === null || e === void 0 || (e = e.options) === null || e === void 0 ? void 0 : e.content) || "", o = t.length > 60 ? t.substring(0, 60) + "..." : t;
      return [
        l({ label: "输入变量" }),
        {
          label: "写入内容",
          value: o,
          emptyAction: "tip",
          emptyTip: "尚未配置"
        },
        {
          label: "等待向量化",
          value: s.value,
          emptyAction: "hidden"
        },
        p({ label: "输出变量" })
      ];
    });
    return (e, t) => (N(), f(r(m), C(h(r(u))), {
      default: b(() => [y(r(v), { kvs: d.value }, null, 8, ["kvs"])]),
      _: 1
    }, 16));
  }
}), K = /* @__PURE__ */ c({ default: () => S }), S = x;
export {
  K as n,
  S as t
};
