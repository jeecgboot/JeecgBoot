import { t as $ } from "./propStore-CR0aJ5bA.mjs";
import { i as j } from "./NodeContainer-zpIyuhKY.mjs";
import { r as w } from "./utils-BH2jvfSb.mjs";
import { computed as f, inject as E, ref as M } from "vue";
import { cloneDeep as U, get as S, set as b, unionBy as T } from "lodash-es";
function z(o) {
  const h = $(), u = E("lfRef", M()), l = f(() => o.isSilentMode === !0), d = f(O), I = f(() => {
    const e = [];
    if (!u.value) return e;
    const { node: i } = o, a = w(i.id);
    if (a) {
      var s;
      const n = u.value.getNodeDataById(a);
      if (Array.isArray(n == null || (s = n.properties) === null || s === void 0 || (s = s.options) === null || s === void 0 ? void 0 : s.loopParams)) {
        const { type: v, loopParams: A } = n.properties.options;
        e.push({
          nodeId: n.id,
          nodeName: "循环变量",
          field: "currentLoopTimes",
          name: "当前循环次数",
          type: "number"
        }), v === "array" && e.push({
          nodeId: n.id,
          nodeName: "循环变量",
          field: "currentLoopItem",
          name: "当前循环项",
          type: "any"
        });
        for (const N of A) e.push({
          nodeId: n.id,
          nodeName: "循环变量",
          field: N.name,
          name: N.name,
          type: N.type || "string"
        });
      }
    }
    if (d.value.length === 0) return e;
    for (const n of d.value) {
      if (n.id === a) continue;
      let v = n.properties.outputParams;
      n.type === j.START && (v = n.properties.inputParams), !(!Array.isArray(v) || v.length === 0) && e.push(...v.map((A) => ({
        nodeId: n.id,
        nodeName: n.properties.text,
        field: A.field,
        name: A.name,
        type: A.type
      })));
    }
    return e;
  }), c = f({
    get: () => {
      const { options: e } = o.properties;
      return e;
    },
    set: (e) => {
      o.setProperties({ options: e });
    }
  }), t = f({
    get: () => {
      const { inputParams: e } = o.properties;
      return Array.isArray(e) ? e : [];
    },
    set: (e) => {
      o.setProperties({ inputParams: e });
    }
  }), r = f({
    get: () => {
      const { outputParams: e } = o.properties;
      return Array.isArray(e) ? e : [];
    },
    set: (e) => {
      o.setProperties({ outputParams: e });
    }
  }), p = f(() => t.value.filter((e) => !!e.name && !!e.field).map((e) => y(e))), m = f(() => r.value.filter((e) => !!e.name && !!e.field).map((e) => y(e)));
  function y(e) {
    var i, a;
    return {
      type: (i = (a = I.value.find((s) => s.nodeId === e.nodeId && s.field === e.field)) === null || a === void 0 ? void 0 : a.type) !== null && i !== void 0 ? i : "-",
      name: e.name
    };
  }
  function O() {
    if (!u.value) return [];
    const { graphModel: e } = u.value;
    return e.$J.getAllPrevNodes(o.node);
  }
  function P(e) {
    return f({
      get: () => S(c.value, e),
      set: (i) => V({ [e]: i })
    });
  }
  const g = [];
  function V(e) {
    g.push(e), !(g.length > 1) && R();
  }
  function R() {
    setTimeout(() => {
      g.length !== 0 && (x(g.shift()), g.length !== 0 && R());
    }, 0);
  }
  function x(e) {
    const i = Object.entries(e);
    if (i.length === 0) return;
    const a = U(c.value);
    for (const [s, n] of i) b(a, s, n);
    c.value = a;
  }
  function B(e) {
    var i;
    return h.createStoreRef((i = o.node) === null || i === void 0 ? void 0 : i.id, e);
  }
  return {
    lfRef: u,
    prevNodes: d,
    prevVariables: I,
    isReadOnly: l,
    options: c,
    inputParams: t,
    outputParams: r,
    inputVarsOptions: p,
    outputVarsOptions: m,
    updateOptions: V,
    createOptionRef: P,
    createStoreRef: B
  };
}
var L = /* @__PURE__ */ Symbol();
function C(o, h) {
  let u = null;
  function l(t) {
    return u == null && (u = h()), S(u, t);
  }
  function d(t, r = L) {
    r === L && (r = l(t)), b(o.properties, t, r);
  }
  function I(t) {
    t || (t = (O) => {
      var P;
      return O.field + "_" + ((P = O.nodeId) !== null && P !== void 0 ? P : "");
    });
    let { inputParams: r, outputParams: p } = o.properties;
    Array.isArray(r) || (r = []);
    const m = l("inputParams");
    Array.isArray(m) && (r = T(r, m, t)), d("inputParams", r), Array.isArray(p) || (p = []);
    const y = l("outputParams");
    Array.isArray(y) && (p = T(p, y, t)), d("outputParams", p);
  }
  function c(t, r) {
    if (typeof r != "function") return;
    t = `options.${t}`;
    const p = S(o.properties, t), m = l(t);
    r(p) && d(t, m);
  }
  return {
    getDefValue: l,
    updateProp: d,
    updateOption: c,
    mergeIOParams: I
  };
}
export {
  C as n,
  z as t
};
