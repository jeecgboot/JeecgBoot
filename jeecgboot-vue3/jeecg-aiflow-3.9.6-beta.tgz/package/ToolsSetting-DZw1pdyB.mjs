import { a as ee } from "./objectSpread2-B0BetFB8.mjs";
import { t as te } from "./_plugin-vue_export-helper-Dj7HTbfw.mjs";
import { t as j } from "./asyncToGenerator-BkhZtDh9.mjs";
import { t as ae } from "./VarTextarea-BzeLBgKt.mjs";
import { t as le } from "./VarListPicker-CrG8EHn2.mjs";
import { t as re } from "./VarListShow-Dg1oan43.mjs";
import { t as oe } from "./useSettings-Cq_-E7Ut.mjs";
import "./Vars-Cgan49KR.mjs";
import { Radio as se, RadioGroup as ne, Select as ie, SelectOption as ue, Tooltip as de } from "ant-design-vue/es";
import { Fragment as T, createBlock as F, createCommentVNode as C, createElementBlock as i, createElementVNode as s, createTextVNode as N, createVNode as f, defineComponent as ve, isRef as k, openBlock as n, ref as z, renderList as A, toDisplayString as _, unref as l, watch as pe, withCtx as g } from "vue";
import { defHttp as ce } from "/@/utils/http/axios";
var fe = { class: "tools-setting" }, me = { class: "setting-item" }, _e = { class: "setting-item" }, ge = { class: "setting-item" }, ye = {
  key: 0,
  style: {
    color: "#999",
    "font-size": "12px"
  }
}, he = { class: "setting-item" }, be = {
  key: 0,
  style: {
    color: "#999",
    "font-size": "12px"
  }
}, Ce = {
  key: 0,
  class: "tool-descr"
}, Pe = {
  key: 0,
  class: "setting-item"
}, Se = { class: "params-container" }, Oe = { class: "param-header" }, xe = { class: "param-name" }, Ne = {
  key: 0,
  class: "required"
}, Le = {
  key: 0,
  class: "param-type"
}, Ve = {
  key: 0,
  class: "param-descr"
}, qe = { class: "setting-item" }, ke = /* @__PURE__ */ ve({
  __name: "ToolsSetting",
  props: {
    type: {
      type: String,
      required: !0
    },
    node: {
      type: Object,
      required: !0
    },
    properties: {
      type: Object,
      required: !0
    },
    isSilentMode: {
      type: Boolean,
      required: !0
    },
    setProperties: {
      type: Function,
      required: !0
    }
  },
  setup(J) {
    const { inputParams: w, inputVarsOptions: $, outputParams: H, prevVariables: K, createOptionRef: v, updateOptions: Q, isReadOnly: y } = oe(J), L = v("tools.pluginCategory"), h = v("tools.pluginId"), U = v("tools.pluginName"), m = v("tools.toolName"), b = v("tools.toolDescr"), p = v("tools.toolParameters"), B = v("tools.endpoint"), P = v("tools.path"), S = v("tools.method"), O = v("tools.headers"), V = z([]), c = z([]), q = z(null);
    pe(L, (function() {
      var o = j(function* (e, a) {
        e && (yield W(e)), a !== void 0 && e !== a && G();
      });
      return function(e, a) {
        return o.apply(this, arguments);
      };
    })(), { immediate: !0 });
    function W(o) {
      return M.apply(this, arguments);
    }
    function M() {
      return M = j(function* (o) {
        try {
          const e = yield ce.get({
            url: "/airag/airagMcp/list",
            params: {
              category: o,
              status: "enable",
              pageNo: 1,
              pageSize: 999
            }
          });
          V.value = e.records || [], h.value && D(h.value, !0);
        } catch (e) {
          V.value = [];
        }
      }), M.apply(this, arguments);
    }
    function X() {
      G();
    }
    function D(o, e = !1) {
      if (y.value) return;
      const a = V.value.find((r) => r.id === o);
      q.value = a;
      const u = e ? m.value : "", d = a && q.value && q.value.id === a.id;
      if (e && d && c.value.length > 0) {
        if (u && c.value.find((r) => r.name === u)) {
          (!p.value || p.value.length === 0) && R(u);
          return;
        }
        return;
      }
      if (a) {
        if (U.value = a.name || "", B.value = a.endpoint || "", a.headers) try {
          O.value = JSON.parse(a.headers);
        } catch (r) {
          O.value = {};
        }
        else O.value = {};
        if (a.tools) try {
          const r = JSON.parse(a.tools);
          c.value = Array.isArray(r) ? r : [];
        } catch (r) {
          c.value = [];
        }
        else c.value = [];
      } else
        U.value = "", c.value = [], B.value = "", O.value = {};
      e || (m.value = ""), b.value = e ? b.value : "", p.value = e ? p.value : [], P.value = e ? P.value : "", S.value = e ? S.value : "", e && u && c.value.find((r) => r.name === u) && (m.value = u, R(u));
    }
    function R(o) {
      if (y.value) return;
      const e = c.value.find((a) => a.name === o);
      if (e) {
        b.value = e.description || "", P.value = e.path || "", S.value = e.method || "GET";
        const a = m.value === o, u = e.parameters || [];
        p.value = u.map((d) => {
          let r = d.defaultValue || "";
          if (a) {
            const x = p.value.find((t) => t.name === d.name);
            x && (r = x.value);
          }
          return {
            name: d.name || "",
            description: d.description || "",
            required: d.required || !1,
            type: d.type || "String",
            location: d.location || "Query",
            value: r
          };
        });
      } else
        b.value = "", p.value = [], P.value = "", S.value = "";
    }
    function Y(o, e) {
      y.value || Q({ [`tools.toolParameters[${e}].value`]: o.value });
    }
    function E(o, e) {
      var a;
      return (((a = e.children) === null || a === void 0 || (a = a[0]) === null || a === void 0 ? void 0 : a.children) || e.label).toLowerCase().indexOf(o.toLowerCase()) >= 0;
    }
    function G() {
      h.value = "", U.value = "", m.value = "", b.value = "", p.value = [], c.value = [], q.value = null, B.value = "", P.value = "", S.value = "", O.value = {};
    }
    return (o, e) => {
      const a = se, u = de, d = ne, r = ue, x = ie;
      return n(), i("div", fe, [
        s("div", me, [e[5] || (e[5] = s("div", { class: "label" }, "输入变量", -1)), f(l(le), {
          vars: l(w),
          "onUpdate:vars": e[0] || (e[0] = (t) => k(w) ? w.value = t : null),
          prevVariables: l(K),
          readonly: l(y)
        }, null, 8, [
          "vars",
          "prevVariables",
          "readonly"
        ])]),
        s("div", _e, [e[8] || (e[8] = s("div", { class: "label" }, "类型", -1)), f(d, {
          value: l(L),
          "onUpdate:value": e[1] || (e[1] = (t) => k(L) ? L.value = t : null),
          onChange: X
        }, {
          default: g(() => [f(a, { value: "plugin" }, {
            default: g(() => [...e[6] || (e[6] = [N("插件", -1)])]),
            _: 1
          }), f(a, {
            value: "mcp",
            disabled: ""
          }, {
            default: g(() => [f(u, { title: "MCP需要使用LLM节点调用，工具执行节点暂不支持" }, {
              default: g(() => [...e[7] || (e[7] = [N(" MCP（暂不支持） ", -1)])]),
              _: 1
            })]),
            _: 1
          })]),
          _: 1
        }, 8, ["value"])]),
        s("div", ge, [e[9] || (e[9] = s("div", { class: "label" }, "插件", -1)), f(x, {
          value: l(h),
          "onUpdate:value": e[2] || (e[2] = (t) => k(h) ? h.value = t : null),
          "show-search": "",
          "filter-option": E,
          placeholder: "请选择插件或MCP",
          disabled: l(y),
          onChange: e[3] || (e[3] = (t) => D(t)),
          style: { width: "100%" }
        }, {
          default: g(() => [(n(!0), i(T, null, A(V.value, (t) => (n(), F(r, {
            key: t.id,
            value: t.id,
            label: t.name + (t.descr ? " - " + t.descr : "")
          }, {
            default: g(() => [N(_(t.name) + " ", 1), t.descr ? (n(), i("span", ye, " - " + _(t.descr), 1)) : C("", !0)]),
            _: 2
          }, 1032, ["value", "label"]))), 128))]),
          _: 1
        }, 8, ["value", "disabled"])]),
        s("div", he, [
          e[10] || (e[10] = s("div", { class: "label" }, "工具", -1)),
          f(x, {
            value: l(m),
            "onUpdate:value": e[4] || (e[4] = (t) => k(m) ? m.value = t : null),
            "show-search": "",
            "filter-option": E,
            placeholder: "请选择工具",
            disabled: l(y) || !l(h),
            onChange: R,
            style: { width: "100%" }
          }, {
            default: g(() => [(n(!0), i(T, null, A(c.value, (t) => (n(), F(r, {
              key: t.name,
              value: t.name,
              label: t.name + (t.description ? " - " + t.description : "")
            }, {
              default: g(() => [N(_(t.name) + " ", 1), t.description ? (n(), i("span", be, " - " + _(t.description), 1)) : C("", !0)]),
              _: 2
            }, 1032, ["value", "label"]))), 128))]),
            _: 1
          }, 8, ["value", "disabled"]),
          l(b) ? (n(), i("div", Ce, _(l(b)), 1)) : C("", !0)
        ]),
        l(p).length > 0 ? (n(), i("div", Pe, [e[11] || (e[11] = s("div", { class: "label" }, "参数配置", -1)), s("div", Se, [(n(!0), i(T, null, A(l(p), (t, I) => (n(), i("div", {
          key: I,
          class: "param-item"
        }, [
          s("div", Oe, [s("span", xe, [N(_(t.name) + " ", 1), t.required ? (n(), i("span", Ne, "*")) : C("", !0)]), t.type ? (n(), i("span", Le, _(t.type), 1)) : C("", !0)]),
          t.description ? (n(), i("div", Ve, _(t.description), 1)) : C("", !0),
          f(l(ae), {
            value: t.value,
            "onUpdate:value": (Z) => t.value = Z,
            varsOptions: l($),
            height: 60,
            placeholder: "请输入参数值或按 / 选择变量",
            readonly: l(y),
            onBlur: () => Y(t, I)
          }, null, 8, [
            "value",
            "onUpdate:value",
            "varsOptions",
            "readonly",
            "onBlur"
          ])
        ]))), 128))])])) : C("", !0),
        s("div", qe, [e[12] || (e[12] = s("div", { class: "label" }, "输出变量", -1)), f(l(re), { vars: l(H) }, null, 8, ["vars"])])
      ]);
    };
  }
}), Fe = /* @__PURE__ */ ee({ default: () => we }), we = /* @__PURE__ */ te(ke, [["__scopeId", "data-v-9bb0e536"]]);
export {
  Fe as n,
  we as t
};
