import { a as i } from "./objectSpread2-B0BetFB8.mjs";
import "./base-node-CKuyN1x8.mjs";
import { t as d } from "./NodeContainer-zpIyuhKY.mjs";
import { t as s } from "./NodeKVS-CRVYjcYN.mjs";
import { t as v } from "./useNode-lPs0rKwe.mjs";
import { computed as c, createBlock as m, createVNode as _, defineComponent as f, guardReactiveProps as h, normalizeProps as y, openBlock as N, unref as r, withCtx as b } from "vue";
var g = /* @__PURE__ */ f({
  __name: "EnhanceJavaNode",
  props: {
    node: {
      type: Object,
      required: !0
    },
    graph: {
      type: Object,
      required: !0
    }
  },
  setup(n) {
    const { $properties: o, getInputParamKVItem: p, getOutputParamKVItem: l } = v(n), u = c(() => {
      var e, t;
      const a = ((e = o.value) === null || e === void 0 || (e = e.options) === null || e === void 0 || (e = e.enhance) === null || e === void 0 ? void 0 : e.type) === "class";
      return [
        p({
          label: "输入变量",
          emptyAction: "hidden"
        }),
        {
          label: "增强类型",
          value: a ? "类路径" : "Spring Bean"
        },
        {
          label: a ? "类路径" : "Bean 名称",
          value: (t = o.value) === null || t === void 0 || (t = t.options) === null || t === void 0 || (t = t.enhance) === null || t === void 0 ? void 0 : t.path,
          emptyAction: "tip",
          emptyTip: "尚未填写",
          width: a ? void 0 : 64
        },
        l({
          label: "输出变量",
          emptyAction: "hidden"
        })
      ];
    });
    return (e, t) => (N(), m(r(d), y(h(e.$props)), {
      default: b(() => [_(r(s), { kvs: u.value }, null, 8, ["kvs"])]),
      _: 1
    }, 16));
  }
}), E = /* @__PURE__ */ i({ default: () => $ }), $ = g;
export {
  E as n,
  $ as t
};
