import { a as e } from "./objectSpread2-B0BetFB8.mjs";
import { t as o } from "./NodeIcon-Dt_fCcq_.mjs";
import { createBlock as t, defineComponent as r, openBlock as n } from "vue";
var _ = /* @__PURE__ */ r({
  __name: "KnowledgeWriteIcon",
  setup(c) {
    return (d, l) => (n(), t(o, {
      icon: "mdi:file-document-add",
      color: "#4165d7"
    }));
  }
}), m = /* @__PURE__ */ e({ default: () => a }), a = _;
export {
  m as n,
  a as t
};
