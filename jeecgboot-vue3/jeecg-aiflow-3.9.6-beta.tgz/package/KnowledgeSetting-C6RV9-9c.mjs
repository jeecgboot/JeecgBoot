import { a as G } from "./objectSpread2-B0BetFB8.mjs";
import { t as H } from "./_plugin-vue_export-helper-Dj7HTbfw.mjs";
import { t as J } from "./VarPicker-HOsUWkU-.mjs";
import { t as Q } from "./VarListShow-Dg1oan43.mjs";
import { t as W } from "./useSettings-Cq_-E7Ut.mjs";
import "./Vars-Cgan49KR.mjs";
import { t as X } from "./data-BrtUPagO.mjs";
import { Card as Y, Col as Z, InputNumber as ee, Popover as te, Row as le, Slider as ne, Space as oe, Switch as ie, Tooltip as ae } from "ant-design-vue/es";
import { Fragment as se, computed as c, createBlock as h, createCommentVNode as I, createElementBlock as C, createElementVNode as l, createTextVNode as de, createVNode as n, defineComponent as re, isRef as _, mergeProps as K, normalizeClass as ue, openBlock as g, renderList as pe, resolveComponent as ve, toDisplayString as me, unref as t, withCtx as a } from "vue";
import { useModal as ce } from "/@/components/Modal";
import { cloneDeep as V } from "lodash-es";
import _e from "/@/views/super/airag/aiknowledge/icon/knowledge.png";
import ge from "/@/views/super/airag/aiapp/components/AiAppAddKnowledgeModal.vue";
var fe = { class: "knowledge-setting" }, we = { class: "setting-item" }, ye = { class: "setting-item" }, ke = { style: {
  display: "flex",
  "justify-content": "space-between",
  width: "100%"
} }, be = { class: "setting-item-icon" }, xe = { class: "setting-item" }, Se = { class: "setting-item" }, he = { class: "label" }, Ie = { style: {
  display: "flex",
  width: "100%",
  "justify-content": "space-between"
} }, Ce = { class: "knowledge-info" }, Ke = ["src"], Ve = { class: "setting-item" }, ze = /* @__PURE__ */ re({
  __name: "KnowledgeSetting",
  props: {
    type: {
      type: String,
      required: !0
    },
    node: {
      type: Object,
      required: !0
    },
    properties: {
      type: Object,
      required: !0
    },
    isSilentMode: {
      type: Boolean,
      required: !0
    },
    setProperties: {
      type: Function,
      required: !0
    }
  },
  setup(z) {
    const { inputParams: f, outputParams: R, prevVariables: D, createOptionRef: w, createStoreRef: N, isReadOnly: s } = W(z), v = w("knowIds"), p = w("topNumber"), y = c({
      get() {
        return f.value[0] ? f.value[0] : {
          field: "",
          nodeId: ""
        };
      },
      set(i) {
        f.value = [i];
      }
    });
    function P(i) {
      i != null && i.nodeId ? y.value = {
        field: i.field,
        nodeId: i.nodeId
      } : y.value = {
        field: "",
        nodeId: ""
      };
    }
    const d = w("similarity"), k = c({
      get() {
        return d.value !== null;
      },
      set(i) {
        d.value = i ? 0.75 : null;
      }
    }), x = c(() => ({
      min: 0,
      max: 1,
      step: 0.01,
      disabled: s.value || !k.value
    })), q = c(() => s.value ? [] : ["click"]), [L, { openModal: j }] = ce(), r = N("knowledgeDataList");
    function A() {
      j(!0, {
        knowledgeIds: v.value.join(","),
        knowledgeDataList: r.value
      });
    }
    function M(i, e) {
      v.value = V(i), r.value = V(e);
    }
    function U(i) {
      let e = v.value, u = e.findIndex((m) => m === i);
      u != -1 && (e.splice(u, 1), v.value = e, r.value.splice(u, 1));
    }
    return X(v, r), (i, e) => {
      const u = ve("Icon"), m = ee, S = ne, b = oe, B = ie, O = ae, T = te, E = Y, F = Z, $ = le;
      return g(), C("div", fe, [
        l("div", we, [e[6] || (e[6] = l("div", { class: "label" }, "查询变量", -1)), n(t(J), {
          vars: t(D),
          item: y.value,
          readonly: t(s),
          onChange: e[0] || (e[0] = (o) => P(o))
        }, null, 8, [
          "vars",
          "item",
          "readonly"
        ])]),
        l("div", ye, [l("div", ke, [e[10] || (e[10] = l("div", { class: "label" }, "知识库", -1)), l("div", be, [l("span", {
          onClick: A,
          class: "knowledge-txt pointer"
        }, [n(u, {
          icon: "ant-design:plus-outlined",
          size: "13",
          style: { "margin-right": "4px" }
        }), e[7] || (e[7] = de("添加 ", -1))]), n(T, {
          trigger: q.value,
          placement: "bottomRight",
          open: t(s) ? !1 : void 0
        }, {
          content: a(() => [l("div", xe, [e[8] || (e[8] = l("div", { class: "label" }, "Top K", -1)), n(b, null, {
            default: a(() => [n(m, {
              value: t(p),
              "onUpdate:value": e[1] || (e[1] = (o) => _(p) ? p.value = o : null),
              min: 1,
              max: 10,
              size: "small",
              style: { width: "80px" },
              disabled: t(s)
            }, null, 8, ["value", "disabled"]), n(S, {
              value: t(p),
              "onUpdate:value": e[2] || (e[2] = (o) => _(p) ? p.value = o : null),
              min: 1,
              max: 10,
              size: "small",
              style: { width: "240px" },
              disabled: t(s)
            }, null, 8, ["value", "disabled"])]),
            _: 1
          })]), l("div", Se, [l("div", he, [n(b, null, {
            default: a(() => [n(B, {
              checked: k.value,
              "onUpdate:checked": e[3] || (e[3] = (o) => k.value = o),
              size: "small",
              disabled: t(s)
            }, null, 8, ["checked", "disabled"]), e[9] || (e[9] = l("div", null, "Score 阈值", -1))]),
            _: 1
          })]), n(b, null, {
            default: a(() => [n(m, K({
              value: t(d),
              "onUpdate:value": e[4] || (e[4] = (o) => _(d) ? d.value = o : null)
            }, x.value, {
              size: "small",
              style: { width: "80px" }
            }), null, 16, ["value"]), n(S, K({
              value: t(d),
              "onUpdate:value": e[5] || (e[5] = (o) => _(d) ? d.value = o : null)
            }, x.value, {
              size: "small",
              style: { width: "240px" }
            }), null, 16, ["value"])]),
            _: 1
          })])]),
          default: a(() => [n(O, { title: "参数配置" }, {
            default: a(() => [n(u, {
              icon: "ant-design:setting",
              class: "pointer"
            })]),
            _: 1
          })]),
          _: 1
        }, 8, ["trigger", "open"])])]), n($, { span: 24 }, {
          default: a(() => [t(r) && t(r).length > 0 ? (g(!0), C(se, { key: 0 }, pe(t(r), (o) => (g(), h(F, { span: 12 }, {
            default: a(() => [n(E, {
              hoverable: "",
              class: "knowledge-card",
              "body-style": { width: "100%" }
            }, {
              default: a(() => [l("div", Ie, [l("div", Ce, [l("img", {
                class: "knowledge-img",
                src: t(_e)
              }, null, 8, Ke), l("span", { class: ue(["knowledge-name", { "knowledge-invalid-text": o.invalid }]) }, me(o.name), 3)]), t(s) ? I("", !0) : (g(), h(u, {
                key: 0,
                onClick: (De) => U(o.id),
                icon: "ant-design:close-outlined",
                size: "20",
                class: "knowledge-icon"
              }, null, 8, ["onClick"]))])]),
              _: 2
            }, 1024)]),
            _: 2
          }, 1024))), 256)) : I("", !0)]),
          _: 1
        })]),
        l("div", Ve, [e[11] || (e[11] = l("div", { class: "label" }, "输出变量", -1)), n(t(Q), { vars: t(R) }, null, 8, ["vars"])]),
        n(ge, {
          onRegister: t(L),
          onSuccess: M
        }, null, 8, ["onRegister"])
      ]);
    };
  }
}), $e = /* @__PURE__ */ G({ default: () => Re }), Re = /* @__PURE__ */ H(ze, [["__scopeId", "data-v-20c77966"]]);
export {
  $e as n,
  Re as t
};
