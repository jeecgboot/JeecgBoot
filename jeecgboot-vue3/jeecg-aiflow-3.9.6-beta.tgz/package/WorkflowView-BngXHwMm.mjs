import { a as bo, n as me, t as H } from "./objectSpread2-B0BetFB8.mjs";
import { t as ce } from "./asyncToGenerator-BkhZtDh9.mjs";
import { i as J, n as Rt, r as ut, t as le } from "./const-OjvoZKjM.mjs";
import { t as Ao } from "./AddNodeDrawer-CP_Lvrjw.mjs";
import { t as ko } from "./runStore-ByYxqieA.mjs";
import { t as Co } from "./DebugRunDrawer-BlzBmGST.mjs";
import { n as Dt, t as Lo } from "./propStore-CR0aJ5bA.mjs";
import { t as Mo } from "./NodeSettingDrawer-B1YQ1aS5.mjs";
import { c as Gt, d as Oo, f as Ro, i as M, n as ft, o as Ge, p as Do, r as O, s as fe, t as Be, u as Go } from "./base-node-CKuyN1x8.mjs";
import { i as ie, r as P, t as Bo } from "./LoopSetting-DsJrtA9E.mjs";
import { i as f, r as ht } from "./NodeContainer-zpIyuhKY.mjs";
import { a as Bt, i as mt, r as we, t as Fo } from "./SwitchSetting-DpKHaDsa.mjs";
import { a as Ft, i as gt, r as _e, t as Wo } from "./ClassifierSetting-2MuCrt1W.mjs";
import { a as Wt, o as Q, r as Ho } from "./VarDefineModal-z1TRO3AZ.mjs";
import { t as Vo } from "./ControlRender-BGZRcTnl.mjs";
import { i as qo, n as jo, o as Yo, r as Ht, t as Xo } from "./utils-BH2jvfSb.mjs";
import { t as zo } from "./LoopIcon-CX6C90KP.mjs";
import { n as Z } from "./useSettings-Cq_-E7Ut.mjs";
import { t as Uo } from "./StartIcon-T08K4SMm.mjs";
import { a as Ko, o as Vt } from "./cron-DXs1TpZn.mjs";
import { t as Jo } from "./StartSetting-V0-qDF8w.mjs";
import { t as Qo } from "./StartNode-GDM3EEEc.mjs";
import { t as Zo } from "./EndIcon-99I5v-2p.mjs";
import { t as ei } from "./EndSetting-r5ECAKhx.mjs";
import { t as ti } from "./EndNode-Cidt4E3M.mjs";
import { t as oi } from "./LLMIcon-BEHSprPN.mjs";
import { t as ii } from "./LLMSetting-DeoGcYKg.mjs";
import { t as ri } from "./LLMNode-D-MQDMmk.mjs";
import { t as ni } from "./ImageGenerateIcon-DQUxzake.mjs";
import { t as si } from "./ImageGenerateSetting-DqJHNZmH.mjs";
import { t as ai } from "./ImageGenerateNode-3dxiduAz.mjs";
import { t as di } from "./ClassifierIcon-BuM6MrIN.mjs";
import { t as li } from "./ClassifierNode-CpkBj0fl.mjs";
import { t as pi } from "./SwitchIcon-Bg6Ysqkp.mjs";
import { t as ci } from "./SwitchNode-DkmEP76W.mjs";
import { t as ui } from "./KnowledgeIcon-BD5pKKOh.mjs";
import { t as fi } from "./KnowledgeSetting-C6RV9-9c.mjs";
import { t as hi } from "./KnowledgeNode-CZqFT2TZ.mjs";
import { t as mi } from "./KnowledgeWriteIcon-CPXWBBrH.mjs";
import { t as gi } from "./KnowledgeWriteSetting-De8o5L_J.mjs";
import { t as vi } from "./KnowledgeWriteNode-D-cuq5Os.mjs";
import { t as yi } from "./CodeIcon-6-FkCcuU.mjs";
import { t as Ni } from "./CodeSetting-CzkyGFMJ.mjs";
import { t as xi } from "./CodeNode-DbyPmZGJ.mjs";
import { t as Si } from "./SubflowIcon-C5UAdCIX.mjs";
import { t as Ii } from "./SubflowSetting-duBWDvrR.mjs";
import { t as Ei } from "./SubflowNode-Ba4yEbe3.mjs";
import { t as wi } from "./EnhanceJavaIcon-BmGa-_iM.mjs";
import { t as _i } from "./EnhanceJavaSetting-Djiuwjxm.mjs";
import { t as Pi } from "./EnhanceJavaNode-Ckareoa4.mjs";
import { t as Ti } from "./HTTPIcon-CYtZ_LHg.mjs";
import { t as $i } from "./HTTPSetting-Du-tchbi.mjs";
import { t as bi } from "./HTTPNode-CQQywABj.mjs";
import { n as Ai } from "./VarMergeIcon-CoXJic1S.mjs";
import { i as ki, r as Ci, t as Li } from "./VarMergeSetting-UWN0-YHI.mjs";
import { t as Mi } from "./VarMergeNode-DP7S9uHX.mjs";
import { n as Oi } from "./VarExtractIcon-DOEb_rng.mjs";
import { t as Ri } from "./VarExtractSetting-Cmol-v_4.mjs";
import { t as Di } from "./VarExtractNode-DdSzc2C9.mjs";
import { t as Gi } from "./ToolsIcon-C2NOYrub.mjs";
import { t as Bi } from "./ToolsSetting-DZw1pdyB.mjs";
import { t as Fi } from "./ToolsNode-C-3v9gP9.mjs";
import { t as Wi } from "./BraveSearchIcon-DKUaoF1T.mjs";
import { t as Hi } from "./BraveSearchSetting-C7Bt2LNQ.mjs";
import { t as Vi } from "./BraveSearchNode-D8gmWTJF.mjs";
import { t as qi } from "./ReplyIcon-BLlEozgj.mjs";
import { t as ji } from "./ReplySetting-JoqEXV1f.mjs";
import { t as Yi } from "./ReplyNode-CjdwOC4M.mjs";
import { t as Xi } from "./SqlIcon-zXsP1aYV.mjs";
import { t as zi } from "./SqlSetting-D0zBu-8b.mjs";
import { t as Ui } from "./SqlNode-DzQXLAzg.mjs";
import { t as Ki } from "./LoopNode-C4PpVw03.mjs";
import { t as Ji } from "./LoopBreakIcon-DGyhnkvo.mjs";
import { t as Qi } from "./LoopBreakNode-CwwstpHk.mjs";
import { t as Zi } from "./LoopContinueIcon-Bqa-UTlS.mjs";
import { t as er } from "./LoopContinueNode-7mjp6NEI.mjs";
import { t as tr } from "./SetLoopVarIcon--zEj8zee.mjs";
import { t as or } from "./SetLoopVarNode-BaS8F8E7.mjs";
import { t as ir } from "./SetLoopVarSetting-C94hlvwz.mjs";
import { n as rr } from "./ChatVarGetIcon-C3iYexB5.mjs";
import { t as nr } from "./ChatVarGetSetting-DR1-IHUz.mjs";
import { t as sr } from "./ChatVarGetNode-C85cmZGf.mjs";
import { n as ar } from "./ChatVarSetIcon-DvraqWeP.mjs";
import { t as dr } from "./ChatVarSetSetting-8WP5_C23.mjs";
import { t as lr } from "./ChatVarSetNode-C66wY18V.mjs";
import { n as pr } from "./ChatMemoryGetIcon-DiSQDbM2.mjs";
import { t as cr } from "./ChatMemoryGetSetting-Du7j328D.mjs";
import { t as ur } from "./ChatMemoryGetNode-CreL0dmY.mjs";
import { n as fr } from "./ChatMemorySetIcon-DFKsC6sh.mjs";
import { t as hr } from "./ChatMemorySetSetting-DCUZdZey.mjs";
import { t as mr } from "./ChatMemorySetNode-DmOdr2AA.mjs";
import { t as gr } from "./sys-get-userinfo-node-C-4cgVB5.mjs";
import { Fragment as vr, createBlock as yr, createCommentVNode as Nr, createElementBlock as xr, createElementVNode as bt, createVNode as Se, defineComponent as Sr, guardReactiveProps as Ir, mergeProps as Er, nextTick as Ie, normalizeClass as wr, normalizeProps as At, onMounted as _r, onUnmounted as Pr, openBlock as kt, provide as Ct, reactive as Pe, ref as ue, resolveDynamicComponent as Tr, unref as W } from "vue";
import { useMessage as $r } from "/@/hooks/web/useMessage";
import { useDesign as qt } from "/@/hooks/web/useDesign";
import { cloneDeep as br, debounce as Ar, partition as Lt, throttle as kr, uniqBy as Cr } from "lodash-es";
import { useDrawer as Mt } from "/@/components/Drawer";
import { isEmpty as Lr } from "/@/utils/is";
var oe = class jt {
  constructor(e = "") {
    this.originType = "", this.anchorsNextIds = [], e && (this.id = e), this.child = [], this.maxLineNum = 25;
  }
  addChild(e) {
    this.child || (this.child = []), this.child.push(e);
  }
  get childFirstId() {
    if (!Array.isArray(this.child) || this.child.length === 0) return "";
    const e = this.child[0];
    switch (e.type) {
      case P.WHEN:
      case P.THEN:
        return e.childFirstId;
    }
    return e.id;
  }
  getElString() {
    var e, o, r, i;
    const n = this.type === P.GROUP ? "" : !((e = this.properties) === null || e === void 0) && e.tag ? `.tag('${(o = this.properties) === null || o === void 0 ? void 0 : o.tag}')` : "", a = !((r = this.properties) === null || r === void 0) && r.data ? `.data('${(i = this.properties) === null || i === void 0 ? void 0 : i.data}')` : "";
    return `${this.getElStringRaw()}${n}${a}`;
  }
  getElStringRaw() {
    if (this.type === P.ID) return this.nodeId;
    if (this.elString) return this.elString;
    switch (this.type) {
      case P.IF:
        return this.getELString_IF();
      case P.GROUP:
        return this.getELString_Group();
      case P.SWITCH:
        return this.getELString_SWITCH();
      case P.WHEN:
      case P.THEN:
        return this.getElString_WHEN_THEN();
      case f.CODE:
        return this.id;
      default:
        return this.type;
    }
  }
  insertSpace(e) {
    return `    ${e.split(`
`).join(`
    `)}`;
  }
  getElString_WHEN_THEN() {
    const e = this.child || [];
    let o = "", r = "";
    this.aliasId && (o = this.aliasId.startsWith("tag:") ? `.tag("${this.aliasId.substring(4)}")` : `.id("${this.aliasId}")`), this.childFirstId && (r = `.tag("${this.childFirstId}")`);
    const i = e.map((l) => l.getElString()), n = i.join(",");
    if (e.length === 1 && (!this.aliasId || e[0].type === P.THEN || e[0].type === P.WHEN))
      return `${n}${o}`;
    if (n.length < this.maxLineNum - 6) return `${this.type}(${n})${r || o}`;
    const a = this.insertSpace(i.join(`,
`));
    return `${this.type}(
${a}
)${r || o}`;
  }
  getELString_Group() {
    const e = this.child || [], o = e.map((x) => x.getElString()).join(",");
    if (this.groupType === ie.CONFIG) {
      var r, i, n, a;
      return `${o}${!((r = this.properties) === null || r === void 0) && r.ignoreError ? ".ignoreError(true)" : ""}${!((i = this.properties) === null || i === void 0) && i.any ? "any(true)" : ""}${!((n = this.properties) === null || n === void 0) && n.must ? `must(${(a = this.properties) === null || a === void 0 ? void 0 : a.must})` : ""}`;
    }
    if (this.groupType === ie.LOGIC) return this.elString;
    const l = this.groupType;
    if (this.groupType === ie.CATCH) return `${l}(${o}).DO(${this.exceptionNode.getElString()})`;
    const p = this.breakNode ? `.BREAK(${this.breakNode.getElString()})` : "";
    let v;
    if (this.originType === f.LOOP) v = `${this.originType}.tag('${this.id}')`;
    else {
      var h;
      v = !((h = this.startNode) === null || h === void 0) && h.nodeId ? this.startNode.getElString() : this.startNum;
    }
    return e.length === 1 ? `${l}(${v}).DO(${o})${p}` : `${l}(${v}).DO(WHEN(${o}))${p}`;
  }
  getELString_IF() {
    const e = (this.child || []).map((r) => r.getElString()), o = e.join(",");
    return o.length < this.maxLineNum - 4 ? `IF(${o})` : `IF(
${this.insertSpace(e.join(`,
`))}
)`;
  }
  getELString_SWITCH() {
    this.parseSwitchChildren();
    const e = (this.child || []).map((a) => a.getElString()), o = e.join(","), r = this.originType, i = `${r || f.SWITCH}.tag('${this.nodeId}')`, n = `.tag('${this.id}')`;
    return o.length < this.maxLineNum - 13 - this.nodeId.length ? `SWITCH(${i}).to(${o})${n}` : `SWITCH(${i}).to(
${this.insertSpace(e.join(`,
`))}
)${n}`;
  }
  parseSwitchChildren() {
    if (this.anchorsNextIds.length === 0) return;
    const e = this.child || [];
    if (!(e.length <= this.anchorsNextIds.length)) {
      for (const { nextIds: o } of this.anchorsNextIds) {
        if (o.length <= 1) continue;
        const r = new jt();
        r.type = P.WHEN;
        for (let i = 0; i < o.length; i++) {
          const n = o[i], a = e.findIndex((l) => {
            let p = l.id;
            return !p && l.child.length > 0 && (p = l.child[0].id), p === n || l.childFirstId === n;
          });
          a !== -1 && (i === 0 ? r.addChild(e.splice(a, 1, r)[0]) : r.addChild(e.splice(a, 1)[0]));
        }
      }
      this.child = e;
    }
  }
}, Mr = class {
  constructor() {
    this.stack = [], this.ebpStack = [];
  }
  peek(t) {
    return t[t.length - 1];
  }
  pop() {
    return this.stack.pop();
  }
  push(t) {
    this.stack.push(t);
  }
  clear() {
    this.stack = [];
  }
  resolve() {
    const t = this.peek(this.ebpStack), e = this.stack[t + 1];
    for (let o = t + 2; o < this.stack.length; o++) {
      const r = this.stack[o];
      e.addChild(r);
    }
    return e;
  }
  quit() {
    const t = this.resolve(), e = this.stack[this.peek(this.ebpStack)];
    for (; this.stack.length > this.peek(this.ebpStack); ) this.stack.pop();
    return this.stack.push(t), this.ebpStack.pop(), e;
  }
  create() {
    this.ebpStack.push(this.stack.length), this.stack.push(new oe());
  }
  addEndPoint(t) {
    this.stack[this.peek(this.ebpStack)] = t;
  }
  getEndPoint() {
    return this.stack[this.peek(this.ebpStack)];
  }
};
me();
var Or = class {
  constructor(t) {
    this.endPoints = {}, this.sourceNum = {}, this.nodeMap = {}, this.inGrooupNode = {}, this.elStack = new Mr(), this.startId = "start", this.endId = "end", this.CUSTOM_SWITCH_NODE = [
      f.SWITCH,
      f.CLASSIFIER,
      f.VAR_EXTRACT
    ], this.anchorNextIdsMap = t;
  }
  isEnd(t) {
    return this.endId === t;
  }
  isStart(t) {
    return this.startId === t;
  }
  getNodeById(t) {
    return this.nodeMap[t];
  }
  initEdge(t, e, o = "") {
    if (this.inGrooupNode[t] || this.inGrooupNode[e]) return;
    this.endPoints[t] || (this.endPoints[t] = []);
    const r = this.nodeMap[e];
    r.comingEdgeText = o, this.endPoints[t].push(r), this.sourceNum[e] || (this.sourceNum[e] = 0), this.sourceNum[e]++;
  }
  init(t) {
    const e = [];
    t.nodes.forEach((i) => {
      if (i.id) {
        if (this.typeFormat(i.type) === P.GROUP) {
          e.push(i);
          return;
        }
        this.initELNode(i);
      }
    }), e.forEach((i) => {
      this.initLoopELNode(i);
    });
    const o = new oe();
    o.id = this.startId, this.nodeMap[this.startId] = o;
    const r = new oe();
    r.id = this.endId, this.nodeMap[this.endId] = r, t.edges.forEach((i) => {
      var n, a;
      const l = i.sourceNodeId, p = i.targetNodeId;
      !l || !p || (this.nodeMap[l].type === P.IF ? this.parseIFEdge((n = i.text) === null || n === void 0 ? void 0 : n.value, l, p) : this.initEdge(l, p, (a = i.text) === null || a === void 0 ? void 0 : a.value));
    }), t.nodes.forEach((i) => {
      !i.id || this.inGrooupNode[i.id] || (this.endPoints[i.id] || this.initEdge(i.id, this.endId), this.sourceNum[i.id] || this.initEdge(this.startId, i.id));
    }), t.nodes.length === 0 && this.initEdge(this.startId, this.endId);
  }
  parseIFEdge(t, e, o) {
    const r = this.nodeMap[o];
    let i = this.endPoints[e];
    i || (i = [void 0, void 0]), this.isTrueText(t) ? (i[0] && (i[1] = i[0]), i[0] = r) : this.isFalseText(t) ? (i[1] && (i[0] = i[1]), i[1] = r) : i[0] ? i[1] = r : i[0] = r, this.endPoints[e] = i, this.sourceNum[o] || (this.sourceNum[o] = 0), this.sourceNum[o]++;
  }
  isTrueText(t) {
    return !![
      "是",
      "true",
      "True",
      "TRUE"
    ].find((e) => e === t);
  }
  isFalseText(t) {
    return !![
      "否",
      "false",
      "False",
      "FALSE"
    ].find((e) => e === t);
  }
  initELNode(t) {
    var e, o, r, i, n, a, l;
    t.properties = H({}, t.properties), t.properties.nodeId = t.id, t.properties.name = t.properties.text, t.properties.tag = t.id;
    const p = new oe();
    return p.id = t.id, p.type = this.typeFormat(t.type), p.originType = t.type, this.handleSwitchNode(p, t), p.properties = t.properties, p.nodeId = (e = t.properties) === null || e === void 0 ? void 0 : e.nodeId, p.name = (o = t.properties) === null || o === void 0 ? void 0 : o.name, p.groupType = (r = t.properties) === null || r === void 0 ? void 0 : r.groupType, p.data = (i = t.properties) === null || i === void 0 ? void 0 : i.data, p.aliasId = (n = t.properties) === null || n === void 0 ? void 0 : n.aliasId, p.tag = (a = t.properties) === null || a === void 0 ? void 0 : a.tag, p.startNum = (l = t.properties) === null || l === void 0 ? void 0 : l.startNum, this.nodeMap[p.id] = p, p;
  }
  handleSwitchNode(t, e) {
    if (t.type !== P.SWITCH) return;
    if (t.originType === f.VAR_EXTRACT) {
      for (const i of ["success", "fail"]) {
        const n = Q(e.id, i), a = this.anchorNextIdsMap.get(n);
        a && a.length > 0 && t.anchorsNextIds.push({
          anchorId: n,
          nextIds: a
        });
      }
      return;
    }
    const o = t.originType === f.SWITCH ? Bt : Ft, r = o.getCaseList(e);
    for (let i = 0; i < r.length; i++) {
      const n = r[i], a = o.getAnchorId(e.id, n.type, i + 1), l = this.anchorNextIdsMap.get(a);
      l && l.length > 0 && t.anchorsNextIds.push({
        anchorId: a,
        nextIds: l
      });
    }
  }
  initLoopELNode(t) {
    var e, o, r;
    !((e = t.flowData) === null || e === void 0) && e.nodes || (t.flowData = {
      nodes: [],
      edges: []
    });
    const i = this.initELNode(t);
    i.groupType == ie.LOGIC ? i.elString = this.getLogicStr(t.flowData) : i.addChild(new Yt(t.flowData, this.anchorNextIdsMap).parse()), this.nodeMap[i.id] = i, t.flowData.nodes.forEach((n) => {
      const a = n.id;
      this.inGrooupNode[a] = !0;
    }), (o = t.sourceNodeIds) === null || o === void 0 || o.forEach((n) => {
      this.initEdge(n, i.id);
    }), (r = t.targetNodeIds) === null || r === void 0 || r.forEach((n) => {
      this.initEdge(i.id, n);
    });
  }
  typeFormat(t) {
    return this.CUSTOM_SWITCH_NODE.includes(t) ? P.SWITCH : t === f.LOOP ? P.GROUP : t === "IF" ? P.IF : t === "SWITCH" ? P.SWITCH : t === "GROUP" ? P.GROUP : t === "AND" ? P.AND : t === "NOT" ? P.NOT : t === "OR" ? P.OR : t;
  }
  setSourceNum(t, e) {
    this.sourceNum[t.id] = e;
  }
  getSourceNum(t) {
    const e = this.sourceNum[t.id];
    return e || 0;
  }
  getEndNum(t) {
    const e = this.endPoints[t.id];
    return e ? e.length : 0;
  }
  getEndList(t) {
    let e = this.endPoints[t.id];
    return e || [];
  }
  push(t) {
    this.elStack.push(t);
  }
  pop() {
    return this.elStack.pop();
  }
  createStackEnv(t) {
    this.elStack.create();
    const e = new oe();
    e.id = t.id, e.type = t.type, e.originType = t.originType, e.groupType = t.groupType, e.aliasId = t.aliasId, e.name = t.name, e.data = t.data, e.tag = t.tag, e.nodeId = t.nodeId, e.child = t.child, e.comingEdgeText = t.comingEdgeText, e.elString = t.elString, e.anchorsNextIds = t.anchorsNextIds, e.startNode = t.startNode, e.breakNode = t.breakNode, e.exceptionNode = t.exceptionNode, e.startNum = t.startNum, this.elStack.push(e);
  }
  quitStackEnv() {
    return this.elStack.quit();
  }
  setStackEndPoint(t) {
    this.elStack.addEndPoint(t);
  }
  getLogicStr(t) {
    const e = {};
    t.nodes.forEach((n) => e[n.id] = n);
    const o = {};
    t.edges.forEach((n) => {
      o[n.sourceNodeId] ? o[n.sourceNodeId]++ : o[n.sourceNodeId] = 1;
    });
    const r = t.nodes.map((n) => n.id).find((n) => !o[n]), i = (n) => {
      const a = e[n], l = t.edges.filter((p) => p.targetNodeId === n).map((p) => p.sourceNodeId).map((p) => {
        const v = e[p];
        if (v.type === P.ID) {
          var h;
          return (h = v.properties) === null || h === void 0 ? void 0 : h.nodeId;
        }
        if (v.type === P.AND || v.type === P.OR || v.type === P.NOT) return i(v.id);
        throw new Error("未知的节点类型");
      }).join(",");
      return `${a.type}(${l})`;
    };
    return i(r);
  }
}, Yt = class {
  constructor(t, e) {
    this.logicFlow = t, this.context = new Or(e), this.context.init(this.logicFlow);
  }
  parse() {
    const t = this.context.startId, e = new oe();
    return e.id = t, this.parseThenChain(e), this.context.pop();
  }
  parseThenChain(t, e, o, r = "") {
    return this.context.createStackEnv({
      type: P.THEN,
      aliasId: r
    }), o && this.context.push(o), this.parseSingleNode(t, { targetNode: e }), this.context.quitStackEnv();
  }
  parseSingleNode(t, e) {
    const o = t.id, r = this.context.getEndNum(t), i = { targetNode: e.targetNode };
    if (this.context.isEnd(o))
      return this.context.setStackEndPoint(t), null;
    if (e.targetNode && e.targetNode.id === t.id)
      return this.context.setStackEndPoint(t), null;
    if (this.context.isStart(o) || this.context.push(t), P.IF === t.type) {
      const a = this.parseIF(this.context.pop());
      return this.parseSingleNode(a, i);
    }
    if (P.SWITCH === t.type) {
      const a = this.parseWhich(this.context.pop());
      return this.parseSingleNode(a, i);
    }
    if (P.GROUP === t.type) {
      let a = this.parseGroup(this.context.pop());
      if (t.groupType === ie.LOGIC && r > 0 && !this.context.isEnd(this.context.getEndList(t)[0].id)) {
        const l = this.context.pop();
        a = this.parseIF(l);
      }
      return this.parseSingleNode(a, i);
    }
    if (r === 1) return this.parseSingleNode(this.context.getEndList(t)[0], i);
    const n = this.parseWhenChain(t);
    return this.parseSingleNode(n, i);
  }
  parseBranch(t) {
    const e = this.context.getEndList(t);
    let o = this.getBranchEnd(t);
    return e.forEach((r) => {
      r.id != o.id && this.parseThenChain(r, o, void 0, t.type === P.SWITCH ? r.comingEdgeText : "");
    }), o;
  }
  parseIF(t) {
    const e = new oe();
    e.type = P.IF, this.context.createStackEnv(e), t.type === P.IF && (t.type = P.ID), this.context.push(t);
    const o = this.context.getEndList(t).filter((n) => !!n), r = o.length;
    if (r == 1) {
      let n, a;
      try {
        if (n = o[0], a = this.context.endPoints[n.id][0], !this.context.isEnd(a.id)) throw new Error();
      } catch (l) {
        throw new Error("IF 判断节点的分支数必须为2");
      }
      return this.context.push(n), a;
    }
    if (r != 2) throw new Error("IF 判断节点的分支数必须为2");
    const i = this.parseBranch(t);
    return this.context.setStackEndPoint(i), this.context.quitStackEnv();
  }
  parseWhich(t) {
    if (this.context.getEndList(t).length <= 1) throw new Error("WHICH 分支节点的分支数必须大于1");
    this.context.createStackEnv(t);
    const e = this.parseBranch(t);
    return this.context.setStackEndPoint(e), this.context.quitStackEnv();
  }
  parseWhenBase(t, e, o) {
    return this.context.createStackEnv({ type: P.WHEN }), t.forEach((r, i) => {
      r.id != e.id && this.parseThenChain(r, e, o[i]);
    }), this.context.quitStackEnv(), this.context.pop();
  }
  parseWhenChain(t) {
    this.context.createStackEnv({ type: P.WHEN });
    const e = this.context.getEndList(t), o = this.getBranchEnd(t), r = this.getBranchEnd(t, o), i = {}, n = {};
    return Object.entries(r).sort(([, a], [, l]) => a.length - l.length).forEach(([a, l]) => {
      const p = this.context.getNodeById(a);
      if (l.length == 1) return;
      const v = [];
      l.forEach((S) => {
        const E = e[S];
        i[E.id] ? v.push(i[E.id]) : v.push(E.id);
      }), l.forEach((S) => {
        const E = e[S];
        i[E.id] = a;
      });
      const h = Array.from(new Set(v)).map((S) => this.context.getNodeById(S)), x = this.parseWhenBase(h, p, h.map((S) => n[S.id]));
      n[a] = x;
    }), this.context.push(n[o.id]), this.context.setStackEndPoint(o), this.context.quitStackEnv();
  }
  parseGroup(t) {
    const e = this.context.getEndList(t);
    let o, r = !0;
    return e.forEach((i) => {
      if (i.comingEdgeText) {
        this.parseThenChain(i);
        const n = this.context.elStack.pop();
        switch (i.comingEdgeText) {
          case "START":
            t.startNode = n.child[0];
            break;
          case "BREAK":
            t.breakNode = n.child[0];
            break;
          case "EXCEPTION":
            t.exceptionNode = n.child[0];
        }
      } else
        o = i, r = !1;
    }), this.context.elStack.push(t), r ? new oe(this.context.endId) : o;
  }
  getBranchEnd(t, e) {
    const o = {};
    let r = this.context.getEndNum(t);
    const i = this.context.getEndList(t).map((a) => a.id), n = {};
    for (; ; ) for (let a = 0; a < i.length; a++) {
      const l = i[a];
      if (!l) continue;
      const p = this.context.getNodeById(l);
      if (n[p.id] || (n[p.id] = 0), n[p.id]++, o[p.id] || (o[p.id] = []), o[p.id].push(a), n[p.id] === r)
        return t.type === P.SWITCH && this.context.getEndList(t).some((v) => v.id === p.id) ? this.getBranchEnd(p) : e ? o : p;
      this.context.isEnd(p.id) || p.id === (e == null ? void 0 : e.id) ? i[a] = "" : this.context.getEndNum(p) > 1 ? i[a] = this.getBranchEnd(p).id : i[a] = this.context.getEndList(p)[0].id;
    }
  }
};
function Rr(t, e) {
  return t = br(t), new Yt(t, e).parse().getElString();
}
function Dr(t, e) {
  const o = () => W(t);
  function r() {
    const a = o();
    if (!a) return;
    a.focusOn("start-node");
    const l = -(a.graphModel.width / 2 - 332 / 2) + 20;
    a.translate(l, 0);
  }
  function i() {
    e.transformModel.zoom(!0), e.transformModel.zoom(!1);
  }
  function n(a) {
    const l = [], p = (v) => {
      const h = e.edges.filter((S) => !(S.targetNodeId !== v.id || S.targetAnchorId.endsWith(fe.LOOP_END)));
      if (h.length === 0) return;
      const x = h.flatMap((S) => {
        const E = e.nodes.find((y) => y.id === S.sourceNodeId);
        return E ? [E] : [];
      });
      x.length !== 0 && (l.push(...x), x.forEach((S) => p(S)));
    };
    return p(a), Cr(l, "id");
  }
  return {
    focusOnStartNode: r,
    repaintGraph: i,
    getAllPrevNodes: n
  };
}
var Xt, Te = class {
  constructor({ lf: t, options: e }) {
    this.lf = t;
    const { prefixCls: o } = qt("aiflow-plugin-control");
    this.prefixCls = o;
    const { use: { componentProps: r } } = e;
    r.visible = !0;
  }
  render(t, e) {
    this.destroy();
    const o = this.getControlTool();
    this.toolEl = o, e.appendChild(o), this.domContainer = e;
  }
  destroy() {
    this.domContainer && this.toolEl && this.domContainer.contains(this.toolEl) && this.domContainer.removeChild(this.toolEl);
  }
  getControlTool() {
    const t = document.createElement("div");
    return t.className = this.prefixCls, t;
  }
  register(t) {
    t.mount(this.lf, this.toolEl, this);
  }
};
Xt = Te;
Xt.pluginName = "super-control";
function Gr(t) {
  const e = Pe({ visible: !1 }), o = Pe({
    onRegister: r,
    onResetGraph: i
  });
  function r(n) {
    if (!t.value)
      return;
    const a = t.value.extension[Te.pluginName];
    a && a.register(n);
  }
  function i() {
    if (!t.value)
      return;
    const n = t.value;
    n.resetZoom(), n.graphModel.$J.focusOnStartNode();
  }
  return { SuperControl: {
    pluginName: Te.pluginName,
    componentProps: e,
    componentIs: Vo,
    superControlProps: o
  } };
}
me();
var he = 40, Br = {
  top: 100,
  right: 120,
  bottom: he,
  left: 120
}, Ee = 0.5, Fr = Dt();
function zt(t, e) {
  const o = () => W(t);
  function r(x) {
    n({
      groupId: x,
      deltaX: 0,
      deltaY: 0
    });
  }
  function i(x) {
    if (!x) return;
    const S = Fr.nodeGroupMap.get(x);
    S && r(S);
  }
  function n(x) {
    const S = o();
    if (!S) return;
    const { groupId: E, nodeId: y } = x, N = S.getNodeModelById(E);
    if (!N || !N.isRestrict || !N.autoResize) return;
    const R = y ? S.getNodeModelById(y) : void 0, L = l(N, y, a(x.deltaX, x.deltaY, R, x.nodeData));
    if (!L) return;
    const D = p(N);
    h(N, {
      minX: L.minX - D.left,
      minY: L.minY - D.top,
      maxX: L.maxX + D.right,
      maxY: L.maxY + D.bottom
    });
  }
  function a(x, S, E, y) {
    var N, R;
    if (y || (y = E == null ? void 0 : E.getData()), !y) return;
    const { x: L, y: D, properties: G } = y, re = (N = G == null ? void 0 : G.width) !== null && N !== void 0 ? N : E == null ? void 0 : E.width, ne = (R = G == null ? void 0 : G.height) !== null && R !== void 0 ? R : E == null ? void 0 : E.height;
    if (!re || !ne) return;
    const ee = L + x / 2, ge = D + S / 2;
    return {
      minX: ee - re / 2,
      minY: ge - ne / 2,
      maxX: ee + re / 2,
      maxY: ge + ne / 2
    };
  }
  function l(x, S, E) {
    const y = o();
    if (!y || !x.children || x.children.size === 0) return;
    let N;
    return x.children.forEach((R) => {
      let L;
      if (R === S && E) L = E;
      else {
        const D = y.getNodeModelById(R);
        L = D == null ? void 0 : D.getBounds();
      }
      L && (N ? (N.minX = Math.min(N.minX, L.minX), N.minY = Math.min(N.minY, L.minY), N.maxX = Math.max(N.maxX, L.maxX), N.maxY = Math.max(N.maxY, L.maxY)) : N = H({}, L));
    }), N;
  }
  function p(x) {
    var S, E, y, N, R, L;
    const D = (S = (E = x.properties) === null || E === void 0 ? void 0 : E.autoResizePadding) !== null && S !== void 0 ? S : Br;
    return typeof D == "number" ? {
      top: D,
      right: D,
      bottom: D,
      left: D
    } : {
      top: (y = D.top) !== null && y !== void 0 ? y : he,
      right: (N = D.right) !== null && N !== void 0 ? N : he,
      bottom: (R = D.bottom) !== null && R !== void 0 ? R : he,
      left: (L = D.left) !== null && L !== void 0 ? L : he
    };
  }
  const v = kr((x) => {
    e.getNodeEdges(x).forEach((S) => {
      const E = S.getData();
      delete E.startPoint, delete E.endPoint, delete E.pointsList, e.deleteEdgeById(S.id), e.addEdge(E);
    });
  }, 15);
  function h(x, S) {
    const E = S.maxX - S.minX, y = S.maxY - S.minY;
    if (E <= 0 || y <= 0) return;
    const N = S.minX + E / 2, R = S.minY + y / 2, L = Math.abs(N - x.x) > Ee || Math.abs(R - x.y) > Ee, D = Math.abs(E - x.width) > Ee || Math.abs(y - x.height) > Ee;
    !L && !D || (x.moveTo(N, R), x.width = E, x.height = y, v(x.id));
  }
  return {
    recalcGroupSize: r,
    recalcGroupSizeByNode: i,
    updateGroupSize: n
  };
}
var De = Dt(), Wr = class extends Yo {
  constructor(t) {
    super(t), this.originOnNodeMove = this.onNodeMove, this.addNodeToGroup = (e) => {
      const o = this.$lf.getNodeModelById(e.id), r = o == null ? void 0 : o.getBounds();
      if (!o || !r) return;
      const i = this.getGroupByBounds(r, e), n = this.nodeGroupMap.get(e.id);
      if (n) {
        const a = this.$lf.getNodeModelById(n), l = !i || i.id !== n, p = i && i.id !== n;
        if (!l && !p) return;
        a && (a.removeChild(e.id), a.setAllowAppendChild(!1)), this.nodeGroupMap.delete(e.id);
      }
      if (o.isGroup) {
        const a = o;
        a.children && Array.from(a.children).forEach((l) => {
          this.nodeGroupMap.set(l, e.id);
        }), this.calibrateTopGroupZIndex([e]), this.onNodeSelect({
          data: e,
          isSelected: !1,
          isMultiple: !1
        });
      }
      i && (i.isAllowAppendIn(e) ? (i.addChild(e.id), i.setAllowAppendChild(!1)) : this.$lf.emit("group:not-allowed", {
        group: i.getData(),
        node: e
      }));
    }, this.$lf = t.lf, this.graphModel = t.lf.graphModel, this.$utils = zt(this.$lf, this.graphModel), this.$lf.off("node:mousemove", this.originOnNodeMove), this.onNodeMove = this.enhancedOnNodeMove.bind(this), this.$lf.on("node:mousemove", this.onNodeMove), this.overrideNodeGroupMap();
  }
  overrideNodeGroupMap() {
    const t = this.nodeGroupMap.set.bind(this.nodeGroupMap);
    this.nodeGroupMap.set = function(r, i) {
      return De.nodeGroupMap.set(r, i), t(r, i);
    }.bind(this.nodeGroupMap);
    const e = this.nodeGroupMap.delete.bind(this.nodeGroupMap);
    this.nodeGroupMap.delete = function(r) {
      return De.nodeGroupMap.delete(r), e(r);
    }.bind(this.nodeGroupMap);
    const o = this.nodeGroupMap.clear.bind(this.nodeGroupMap);
    this.nodeGroupMap.clear = function() {
      return De.nodeGroupMap.clear(), o();
    }.bind(this.nodeGroupMap);
  }
  enhancedOnNodeMove({ deltaX: t, deltaY: e, data: o }) {
    const r = o == null ? void 0 : o.id;
    if (!r) return;
    const i = this.nodeGroupMap.get(r);
    i && this.$utils.updateGroupSize({
      groupId: i,
      nodeId: r,
      deltaX: t,
      deltaY: e,
      nodeData: o
    });
  }
};
function Hr() {
  return { plugins: [Te, Wr] };
}
var Fe = {
  type: f.START,
  label: "开始",
  docs: ["https://help.jeecg.com/aigc/flowNodes/nodeStart"],
  components: {
    icon: Uo,
    setting: Jo
  },
  lfNode: {
    type: f.START,
    view: O,
    model: M,
    component: Qo
  },
  params: {
    width: 332,
    height: 62
  },
  methods: {
    createNode: qr,
    updateNodeSetting: jr,
    checkNode: Yr,
    getDefaultAnchor(t) {
      return t.filter((e) => e.type === "right");
    }
  },
  hooks: { beforeRemoveNode() {
    return !1;
  } }
};
function Vr(t) {
  return t == null ? !1 : !Lr(t);
}
var Ut = () => ({ inputParams: [
  {
    field: "content",
    name: "用户问题",
    type: "string",
    required: !1
  },
  {
    field: "history",
    name: "历史记录",
    type: "string[]",
    required: !1
  },
  {
    field: "images",
    name: "图片",
    type: "picture",
    required: !1
  }
] });
function Kt() {
  return {
    enabled: !1,
    cronType: "day",
    cronExp: Ko(null, "day"),
    beginTime: null,
    endTime: null,
    inputParams: {},
    custom: Vt(null)
  };
}
function qr(t) {
  const e = Ut();
  return {
    id: "start-node",
    type: Fe.type,
    x: t.x,
    y: t.y,
    properties: {
      text: Fe.label,
      remarks: "",
      options: { cronTrigger: Kt() },
      inputParams: e.inputParams,
      outputParams: []
    }
  };
}
function jr(t) {
  const { mergeIOParams: e } = Z(t, Ut);
  if (e(), t.properties.options || (t.properties.options = {}), t.properties.options.cronTrigger || (t.properties.options.cronTrigger = Kt()), !t.properties.options.cronTrigger.custom) {
    var o;
    t.properties.options.cronTrigger.custom = Vt((o = t.properties.options.cronTrigger.beginTime) !== null && o !== void 0 ? o : null);
  }
  t.properties.options.cronTrigger.importParams && !t.properties.options.cronTrigger.inputParams && (t.properties.options.cronTrigger.inputParams = t.properties.options.cronTrigger.importParams, delete t.properties.options.cronTrigger.importParams);
  const r = t.properties.inputParams.find((i) => i.field === "history");
  r && (r.required = !1);
}
function Yr(t, e, o) {
  var r, i, n;
  const a = [], l = (r = e == null ? void 0 : e.properties) !== null && r !== void 0 ? r : {}, p = (i = l.options) !== null && i !== void 0 ? i : {}, v = l.inputParams, h = (n = p.cronTrigger) !== null && n !== void 0 ? n : {};
  if (h.enabled) {
    var x;
    const S = (x = h.inputParams) !== null && x !== void 0 ? x : {};
    v.find((E) => E.required && E.field !== "history" ? !Vr(S[E.field]) : !1) && a.push("定时触发器：存在必填参数未配置默认值");
  }
  return a;
}
var We = {
  type: f.END,
  label: "结束",
  docs: ["https://help.jeecg.com/aigc/flowNodes/nodeEnd"],
  components: {
    icon: Zo,
    setting: ei
  },
  lfNode: {
    type: f.END,
    view: O,
    model: M,
    component: ti
  },
  params: {
    width: 332,
    height: 62
  },
  methods: {
    createNode: Xr,
    checkNode: Ur,
    updateNodeSetting: zr,
    getDefaultAnchor(t) {
      return t.filter((e) => e.type === "left");
    }
  }
};
function Xr(t) {
  return {
    id: t.id,
    remarks: "",
    type: We.type,
    x: t.x,
    y: t.y,
    properties: {
      text: We.label,
      options: {
        outputContent: "",
        outputType: "text",
        cardConfig: null
      },
      inputParams: [],
      outputParams: []
    }
  };
}
function zr(t) {
  var e;
  const o = (e = t.properties) === null || e === void 0 ? void 0 : e.options;
  o && (o.outputType || (o.outputType = o.outputText === !0 ? "text" : "default"), delete o.outputText);
}
function Ur(t, e, { checkOutputParams: o }) {
  var r;
  const { properties: i } = e, { options: n } = i, a = n.outputContent, l = (r = n.outputType) !== null && r !== void 0 ? r : "default", p = n.cardConfig, v = [...o({
    text: "输出变量",
    required: l !== "text"
  })];
  return l === "text" && !a && v.push("返回文本不能为空"), l === "card" && !p && v.push("需要绑定卡片"), v;
}
me();
var He = {
  type: f.LLM,
  label: "LLM",
  docs: ["https://help.jeecg.com/aigc/flowNodes/nodeLLM"],
  components: {
    icon: oi,
    setting: ii
  },
  lfNode: {
    type: f.LLM,
    view: O,
    model: M,
    component: ri
  },
  params: {
    width: 332,
    height: 62
  },
  methods: {
    createNode: Kr,
    checkNode: Jr,
    updateNodeSetting: Qr
  }
}, Jt = () => ({
  options: { showToolExecution: !1 },
  inputParams: [],
  outputParams: [{
    field: "text",
    name: "回复内容",
    type: "string"
  }]
});
function Kr(t) {
  var e;
  const o = Jt();
  return {
    id: t.id,
    remarks: "",
    type: He.type,
    x: t.x,
    y: t.y,
    properties: {
      text: (e = t.text) !== null && e !== void 0 ? e : He.label,
      options: H({
        model: {
          modeId: "",
          params: {
            model: "",
            temperature: 0.7,
            timeout: 60
          }
        },
        history: 3,
        messages: [{
          role: "system",
          content: `**人物设定：**
- 你是：李白
- 人称：第一人称
- 出生地：安西都护府碎叶城
- 性格特点：豪放不羁、自信豁达、重情重义、浪漫洒脱
- 语言风格：富有想象力、优美流畅
- 经典台词：
  - “仰天大笑出门去，我辈岂是蓬蒿人。”
  - “天生我材必有用，千金散尽还复来。”`
        }, {
          role: "user",
          content: ""
        }]
      }, o.options),
      inputParams: o.inputParams,
      outputParams: o.outputParams
    }
  };
}
function Jr(t, e, { checkInputParams: o }) {
  const { properties: r } = e, { options: i } = r, n = [...o({
    text: "输入变量",
    required: !1
  })];
  if (i.model.modeId || n.push("必须选择模型"), i.structuredOutput) {
    const a = i.structuredOutputFields;
    !Array.isArray(a) || a.length === 0 ? n.push("启用结构化输出时，至少需要配置一个输出字段") : a.some((l) => !l.field) && n.push("结构化输出字段名不能为空");
  }
  return n;
}
function Qr(t) {
  var e;
  const { mergeIOParams: o, updateOption: r } = Z(t, Jt);
  o(), r("showToolExecution", (n) => typeof n != "boolean"), r("structuredOutput", (n) => typeof n != "boolean"), r("structuredOutputFields", (n) => !Array.isArray(n));
  const i = (e = t.properties) === null || e === void 0 ? void 0 : e.options;
  (i == null ? void 0 : i.systemPromptMode) === "ref" && !(i != null && i.systemPromptRefId) && (t.properties.options.systemPromptMode = "fill");
}
var Ve = {
  type: f.IMAGE_GENERATE,
  label: "图像生成",
  components: {
    icon: ni,
    setting: si
  },
  lfNode: {
    type: f.IMAGE_GENERATE,
    view: O,
    model: M,
    component: ai
  },
  params: {
    width: 332,
    height: 62
  },
  methods: {
    createNode: Zr,
    checkNode: en,
    updateNodeSetting: tn
  }
}, Qt = () => ({
  options: {
    modelId: "",
    modelName: "",
    width: 1024,
    height: 1024,
    sizeMode: "preset",
    imageCount: 1,
    watermark: !1,
    referenceImages: "",
    prompt: ""
  },
  inputParams: [],
  outputParams: [{
    field: "data",
    name: "生成图片",
    type: "string"
  }]
});
function Zr(t) {
  var e;
  const o = Qt();
  return {
    id: t.id,
    remarks: "",
    type: Ve.type,
    x: t.x,
    y: t.y,
    properties: {
      text: (e = t.text) !== null && e !== void 0 ? e : Ve.label,
      options: o.options,
      inputParams: o.inputParams,
      outputParams: o.outputParams
    }
  };
}
function en(t, e, { checkInputParams: o }) {
  var r;
  const { options: i = {} } = e.properties, n = [...o({
    text: "输入变量",
    required: !1
  })];
  return i.modelId || n.push("必须选择图像模型"), (!i.width || !i.height) && n.push("图片尺寸不能为空"), !((r = i.prompt) === null || r === void 0) && r.trim() || n.push("提示词不能为空"), n;
}
function tn(t) {
  const { mergeIOParams: e, updateOption: o } = Z(t, Qt);
  e(), o("modelName", (r) => typeof r != "string"), o("sizeMode", (r) => !["preset", "custom"].includes(r)), o("imageCount", (r) => !Number.isInteger(r) || r < 1), o("watermark", (r) => typeof r != "boolean"), o("referenceImages", (r) => typeof r != "string"), o("prompt", (r) => typeof r != "string");
}
var on = class extends M {
  get $caseList() {
    return gt(this);
  }
}, qe = {
  type: f.CLASSIFIER,
  label: "分类器",
  docs: ["https://help.jeecg.com/aigc/flowNodes/nodeClassifier"],
  components: {
    icon: di,
    setting: Wo
  },
  lfNode: {
    type: f.CLASSIFIER,
    view: O,
    model: on,
    component: li
  },
  params: {
    width: 332,
    height: 62
  },
  methods: {
    createNode: rn,
    checkNode: nn,
    updateNodeSetting: sn,
    getAnchorId: _e,
    getDefaultAnchor(t) {
      const [e, o] = t, r = [e];
      if (!this.$caseList.length) return r;
      for (let i = 0; i < this.$caseList.length; i++) {
        const n = this.$caseList[i];
        r.push({
          id: _e(this.id, n.type, i + 1),
          x: o.x,
          y: o.y + 34 + 22 * i + 22 * i,
          type: "right"
        });
      }
      return r;
    }
  }
}, Zt = () => ({ outputParams: [{
  field: "index",
  name: "分类索引",
  type: "number"
}, {
  field: "content",
  name: "分类描述",
  type: "string"
}] });
function rn(t) {
  var e;
  const o = Zt();
  return {
    id: t.id,
    remarks: "",
    type: qe.type,
    x: t.x,
    y: t.y,
    properties: {
      text: (e = t.text) !== null && e !== void 0 ? e : qe.label,
      options: {
        model: {
          modeId: "",
          params: {
            model: "",
            temperature: 0.7
          }
        },
        categories: [{
          category: "",
          next: ""
        }, {
          category: "",
          next: ""
        }],
        else: { next: "" }
      },
      inputParams: [],
      outputParams: o.outputParams
    }
  };
}
function nn(t, e, { findNextIdsByAnchorId: o }) {
  const { edges: r } = t.graphModel, { properties: i } = e, { options: n } = i, a = [];
  (!Array.isArray(n == null ? void 0 : n.categories) || n.categories.length === 0) && a.push("“分类”不能为空");
  const l = gt(e);
  for (let p = 0; p < l.length; p++) {
    const v = l[p];
    o(_e(e.id, v.type, p + 1), r).length === 0 && a.push(`“${v.label}”未连接下一个节点`);
  }
  return a;
}
function sn(t) {
  const { mergeIOParams: e } = Z(t, Zt);
  e();
  const o = t.properties.outputParams.find((r) => r.field === "content");
  o && (o.name = "分类描述");
}
var an = class extends M {
  get $caseList() {
    return mt(this);
  }
}, je = {
  type: f.SWITCH,
  label: "条件分支",
  docs: ["https://help.jeecg.com/aigc/flowNodes/nodeSwitch"],
  components: {
    icon: pi,
    setting: Fo
  },
  lfNode: {
    type: f.SWITCH,
    view: O,
    model: an,
    component: ci
  },
  params: {
    width: 332,
    height: 62
  },
  methods: {
    createNode: dn,
    checkNode: pn,
    updateNodeSetting: ln,
    getAnchorId: we,
    getDefaultAnchor(t) {
      const [e, o] = t, r = [e];
      if (!this.$caseList.length) return r;
      for (let i = 0; i < this.$caseList.length; i++) {
        const n = this.$caseList[i];
        r.push({
          id: we(this.id, n.type, i + 1),
          x: o.x,
          y: o.y + 34 + 26 * i,
          type: "right"
        });
      }
      return r;
    }
  }
}, eo = () => ({ outputParams: [{
  field: "index",
  name: "分支索引",
  type: "number"
}] });
function dn(t) {
  var e;
  const o = eo();
  return {
    id: t.id,
    remarks: "",
    type: je.type,
    x: t.x,
    y: t.y,
    properties: {
      text: (e = t.text) !== null && e !== void 0 ? e : je.label,
      options: {
        if: [{
          logic: "AND",
          conditions: [{
            nodeId: "",
            field: "",
            operator: "EQUALS",
            value: ""
          }],
          next: ""
        }],
        else: { next: "" }
      },
      inputParams: [],
      outputParams: o.outputParams
    }
  };
}
function ln(t) {
  const { mergeIOParams: e } = Z(t, eo);
  e();
}
function pn(t, e, { findNextIdsByAnchorId: o }) {
  const { edges: r } = t.graphModel, { properties: i } = e, { options: n } = i, a = [];
  (!Array.isArray(n == null ? void 0 : n.if) || n.if.length === 0) && a.push("“IF”分支条件不能为空");
  const l = mt(e);
  for (let p = 0; p < l.length; p++) {
    const v = l[p];
    o(we(e.id, v.type, p + 1), r).length === 0 && a.push(`“${v.label}”分支未连接下一个节点`);
  }
  return a;
}
var Ye = {
  type: f.KNOWLEDGE,
  label: "知识库",
  docs: ["https://help.jeecg.com/aigc/flowNodes/nodeKnow"],
  components: {
    icon: ui,
    setting: fi
  },
  lfNode: {
    type: f.KNOWLEDGE,
    view: O,
    model: M,
    component: hi
  },
  params: {
    width: 332,
    height: 62
  },
  methods: {
    createNode: cn,
    checkNode: un
  }
};
function cn(t) {
  var e;
  return {
    id: t.id,
    remarks: "",
    type: Ye.type,
    x: t.x,
    y: t.y,
    properties: {
      text: (e = t.text) !== null && e !== void 0 ? e : Ye.label,
      options: {
        knowIds: [],
        topNumber: 5,
        similarity: 0.7
      },
      inputParams: [],
      outputParams: [{
        field: "documents",
        name: "文档列表",
        type: "object[]"
      }, {
        field: "data",
        name: "文档内容",
        type: "string"
      }]
    }
  };
}
function un(t, e, { checkInputParams: o }) {
  const { properties: r } = e, { options: i } = r, n = [...o({
    text: "查询变量",
    required: !0,
    requiredName: !1
  })];
  return (!Array.isArray(i.knowIds) || i.knowIds.length === 0) && n.push("必须选择至少一个知识库"), n;
}
var Xe = {
  type: f.KNOWLEDGE_WRITE,
  label: "知识库写入",
  docs: ["https://help.jeecg.com/aigc/flowNodes/nodeKnowWrite"],
  components: {
    icon: mi,
    setting: gi
  },
  lfNode: {
    type: f.KNOWLEDGE_WRITE,
    view: O,
    model: M,
    component: vi
  },
  params: {
    width: 332,
    height: 62
  },
  methods: {
    createNode: fn,
    checkNode: mn,
    updateNodeSetting: hn
  }
};
function fn(t) {
  var e;
  return {
    id: t.id,
    remarks: "",
    type: Xe.type,
    x: t.x,
    y: t.y,
    properties: {
      text: (e = t.text) !== null && e !== void 0 ? e : Xe.label,
      options: {
        writeType: "text",
        knowIds: [],
        content: "",
        fileSources: [],
        segmentStrategy: "auto",
        separator: "\\n",
        customSeparator: "",
        maxSegment: 800,
        overlap: 10,
        textRules: [],
        waitForVectorize: !1,
        waitTimeout: 300,
        vectorizeFailStrategy: "ignore"
      },
      inputParams: [],
      outputParams: [{
        field: "documentId",
        name: "documentId",
        type: "string"
      }, {
        field: "documentIds",
        name: "documentIds",
        type: "string[]"
      }]
    }
  };
}
function hn(t) {
  t.properties.options || (t.properties.options = {});
  const e = t.properties.options;
  e.writeType == null && (e.writeType = "text"), Array.isArray(e.fileSources) || (e.fileSources = []), e.segmentStrategy == null && (e.segmentStrategy = "auto"), e.separator == null && (e.separator = "\\n"), e.customSeparator == null && (e.customSeparator = ""), e.maxSegment == null && (e.maxSegment = 800), e.overlap == null && (e.overlap = 10), Array.isArray(e.textRules) || (e.textRules = []), typeof e.waitForVectorize != "boolean" && (e.waitForVectorize = !1), (typeof e.waitTimeout != "number" || e.waitTimeout <= 0) && (e.waitTimeout = 300), e.vectorizeFailStrategy !== "error" && e.vectorizeFailStrategy !== "ignore" && (e.vectorizeFailStrategy = "ignore"), Array.isArray(t.properties.outputParams) || (t.properties.outputParams = []);
  const o = t.properties.outputParams;
  o.some((r) => r.field === "documentIds") || o.push({
    field: "documentIds",
    name: "documentIds",
    type: "string[]"
  });
}
function mn(t, e, { checkInputParams: o }) {
  const { properties: r } = e, { options: i } = r, n = [...o({
    text: "输入变量",
    required: !1,
    requiredName: !0
  })];
  return !i || !Array.isArray(i.knowIds) || i.knowIds.length === 0 ? n.push("请选择 1 个知识库") : i.knowIds.length > 1 && n.push("仅支持选择 1 个知识库"), ((i == null ? void 0 : i.writeType) || "text") === "file" ? (!Array.isArray(i == null ? void 0 : i.fileSources) || i.fileSources.length === 0) && n.push("请选择至少 1 个文件来源变量") : i != null && i.content || n.push("写入内容不能为空"), n;
}
var gn = class extends M {
  constructor(t, e) {
    super(t, e), this.id.startsWith(f.CODE + "_") || super.updateId(f.CODE + "_" + this.id);
  }
}, ze = {
  type: f.CODE,
  label: "脚本执行",
  docs: ["https://help.jeecg.com/aigc/flowNodes/nodeCode"],
  components: {
    icon: yi,
    setting: Ni
  },
  lfNode: {
    type: f.CODE,
    view: O,
    model: gn,
    component: xi
  },
  params: {
    width: 332,
    height: 62
  },
  methods: {
    createNode: vn,
    checkNode: yn,
    initNodeData() {
      this.id.startsWith(f.CODE + "_") || (this.id = f.CODE + "_" + this.id);
    }
  }
};
function vn(t) {
  var e;
  return {
    id: t.id,
    remarks: "",
    type: ze.type,
    x: t.x,
    y: t.y,
    properties: {
      text: (e = t.text) !== null && e !== void 0 ? e : ze.label,
      options: {
        codeType: "javascript",
        code: `
function main(params) {
  return {
    result: params.arg1 + '_拼接_' + params.arg2,
  }
}
`.trim()
      },
      inputParams: [{
        field: "",
        name: "arg1",
        nodeId: ""
      }, {
        field: "",
        name: "arg2",
        nodeId: ""
      }],
      outputParams: [{
        field: "result",
        name: "返回结果",
        type: "string"
      }]
    }
  };
}
function yn(t, e, { checkInputParams: o }) {
  const { properties: r } = e, { options: i } = r, n = [...o({
    text: "输入变量",
    required: !1
  })];
  return i.code || n.push("脚本内容不能为空"), n;
}
var Ue = {
  type: f.SUBFLOW,
  label: "子流程",
  docs: ["https://help.jeecg.com/aigc/flowNodes/nodeSubFlow"],
  components: {
    icon: Si,
    setting: Ii
  },
  lfNode: {
    type: f.SUBFLOW,
    view: O,
    model: M,
    component: Ei
  },
  params: {
    width: 332,
    height: 62
  },
  methods: {
    createNode: Nn,
    checkNode: xn
  }
};
function Nn(t) {
  var e;
  return {
    id: t.id,
    remarks: "",
    type: Ue.type,
    x: t.x,
    y: t.y,
    properties: {
      text: (e = t.text) !== null && e !== void 0 ? e : Ue.label,
      options: { subflowId: "" },
      inputParams: [],
      outputParams: []
    }
  };
}
function xn(t, e, { checkInputParams: o }) {
  const { properties: r } = e, { options: i } = r, n = [...o({
    text: "输入变量",
    required: !1
  })];
  return i.subflowId || n.push("必须选择子流程"), n;
}
var Ke = {
  type: f.ENHANCE_JAVA,
  label: "Java 增强",
  docs: ["https://help.jeecg.com/aigc/flowNodes/nodeJava"],
  components: {
    icon: wi,
    setting: _i
  },
  lfNode: {
    type: f.ENHANCE_JAVA,
    view: O,
    model: M,
    component: Pi
  },
  params: {
    width: 332,
    height: 62
  },
  methods: {
    createNode: Sn,
    checkNode: In
  }
};
function Sn(t) {
  var e;
  return {
    id: t.id,
    remarks: "",
    type: Ke.type,
    x: t.x,
    y: t.y,
    properties: {
      text: (e = t.text) !== null && e !== void 0 ? e : Ke.label,
      options: { enhance: {
        type: "class",
        path: ""
      } },
      inputParams: [{
        field: "",
        name: "arg1",
        nodeId: ""
      }, {
        field: "",
        name: "arg2",
        nodeId: ""
      }],
      outputParams: [{
        field: "result",
        name: "返回结果",
        type: "string"
      }]
    }
  };
}
function In(t, e, { checkInputParams: o }) {
  const { properties: r } = e, { options: i } = r, n = [...o({
    text: "输入变量",
    required: !1
  })], a = i.enhance.type === "class";
  return i.enhance.path || n.push(`${a ? "类路径" : "Spring Bean 名称"}必须填写`), n;
}
var Je = {
  type: f.HTTP,
  label: "HTTP 请求",
  docs: ["https://help.jeecg.com/aigc/flowNodes/nodeHttp"],
  components: {
    icon: Ti,
    setting: $i
  },
  lfNode: {
    type: f.HTTP,
    view: O,
    model: M,
    component: bi
  },
  params: {
    width: 332,
    height: 62
  },
  methods: {
    createNode: En,
    checkNode: _n,
    updateNodeSetting: wn
  }
}, to = () => ({
  inputParams: [],
  outputParams: [{
    field: "body",
    name: "回复内容",
    type: "string"
  }, {
    field: "statusCode",
    name: "状态码",
    type: "number"
  }]
});
function En(t) {
  var e;
  const o = to();
  return {
    id: t.id,
    remarks: "",
    type: Je.type,
    x: t.x,
    y: t.y,
    properties: {
      text: (e = t.text) !== null && e !== void 0 ? e : Je.label,
      options: { http: {
        url: "",
        method: "GET",
        headers: {},
        requestBody: {
          type: "none",
          body: ""
        },
        requestParams: {},
        timeout: 120,
        retriesTimes: 0
      } },
      inputParams: o.inputParams,
      outputParams: o.outputParams
    }
  };
}
function wn(t) {
  const { mergeIOParams: e } = Z(t, to);
  e();
  const { requestBody: o } = t.properties.options.http;
  (!o || typeof o == "string") && (t.properties.options.http.requestBody = {
    type: "none",
    body: o || ""
  });
}
function _n(t, e, { checkInputParams: o }) {
  const { properties: r } = e, { options: i } = r, n = [...o({
    text: "输入变量",
    required: !1
  })];
  return i.http.url || n.push("请求地址必须填写"), n;
}
var Qe = {
  type: f.VAR_MERGE,
  label: "变量聚合",
  docs: ["https://help.jeecg.com/aigc/flowNodes/nodeVarMerge"],
  components: {
    icon: Ai,
    setting: Li
  },
  lfNode: {
    type: f.VAR_MERGE,
    view: O,
    model: M,
    component: Mi
  },
  params: {
    width: 332,
    height: 62
  },
  methods: {
    createNode: Pn,
    checkNode: Tn
  }
};
function Pn(t) {
  var e;
  const o = [ki(1)];
  return {
    id: t.id,
    remarks: "",
    type: Qe.type,
    x: t.x,
    y: t.y,
    properties: {
      text: (e = t.text) !== null && e !== void 0 ? e : Qe.label,
      options: { varGroups: o },
      inputParams: [],
      outputParams: Ci(o)
    }
  };
}
function Tn(t, e) {
  var o, r;
  const i = [], n = (o = e == null || (r = e.properties) === null || r === void 0 || (r = r.options) === null || r === void 0 ? void 0 : r.varGroups) !== null && o !== void 0 ? o : [];
  if (!Array.isArray(n) || n.length === 0)
    return i.push("请至少配置一个输出变量"), i;
  const a = /* @__PURE__ */ new Set();
  return n.forEach((l) => {
    const p = l.name;
    if (a.has(p)) {
      i.push(`${p}的名称与其他输出变量重复`);
      return;
    }
    if (a.add(l.name), !(l != null && l.type)) {
      i.push(`${p}未确定类型，请先选择候选变量`);
      return;
    }
    const v = Array.isArray(l == null ? void 0 : l.vars) ? l.vars : [];
    if (v.length === 0) {
      i.push(`${p}至少需要一个候选变量`);
      return;
    }
    for (const h of v) if ((h == null ? void 0 : h.isCustom) !== !0 && (!(h != null && h.nodeId) || !(h != null && h.field))) {
      i.push(`${p}存在未选择的候选变量`);
      break;
    }
  }), i;
}
me();
var Ze = {
  type: f.VAR_EXTRACT,
  label: "变量提取器",
  docs: ["https://help.jeecg.com/aigc/flowNodes/nodeVarExtract"],
  components: {
    icon: Oi,
    setting: Ri
  },
  lfNode: {
    type: f.VAR_EXTRACT,
    view: O,
    model: M,
    component: Di
  },
  params: {
    width: 332,
    height: 62
  },
  methods: {
    createNode: $n,
    checkNode: An,
    updateNodeSetting: bn,
    getAnchorId: Q,
    getDefaultAnchor(t) {
      const [e, o] = t;
      return [
        e,
        H(H({}, o), {}, {
          id: Q(this.id, "success"),
          y: o.y + 34
        }),
        H(H({}, o), {}, {
          id: Q(this.id, "fail"),
          y: o.y + 60
        })
      ];
    }
  }
};
function oo() {
  const t = [];
  return {
    inputParams: [{
      field: "input",
      name: "",
      nodeId: "",
      type: "string"
    }],
    outputParams: Wt(t),
    variables: t
  };
}
function $n(t) {
  var e;
  const o = oo();
  return {
    id: t.id,
    remarks: "",
    type: Ze.type,
    x: t.x,
    y: t.y,
    properties: {
      text: (e = t.text) !== null && e !== void 0 ? e : Ze.label,
      options: {
        model: {
          modeId: "",
          params: {
            model: "",
            temperature: 0.3,
            timeout: 60
          }
        },
        variables: o.variables
      },
      inputParams: o.inputParams,
      outputParams: o.outputParams
    }
  };
}
function bn(t) {
  var e, o;
  const { mergeIOParams: r, updateProp: i } = Z(t, oo);
  r();
  const n = (e = (o = t.properties) === null || o === void 0 || (o = o.options) === null || o === void 0 ? void 0 : o.variables) !== null && e !== void 0 ? e : [];
  i("outputParams", Wt(n));
}
function An(t, e, { findNextIdsByAnchorId: o }) {
  var r, i;
  const { edges: n } = t.graphModel, { properties: a } = e, { options: l } = a, p = [], v = a == null || (r = a.inputParams) === null || r === void 0 ? void 0 : r[0];
  (!(v != null && v.nodeId) || !(v != null && v.field)) && p.push("请选择输入变量"), v != null && v.type && v.type !== "string" && p.push("输入变量仅支持 string 类型"), !(l == null || (i = l.model) === null || i === void 0) && i.modeId || p.push("必须选择模型");
  const h = Array.isArray(l == null ? void 0 : l.variables) ? l.variables : [];
  h.length === 0 && p.push("请至少添加一个提取变量");
  const x = /* @__PURE__ */ new Set();
  for (const y of h) {
    if (!y.name) {
      p.push("提取变量名称不能为空");
      continue;
    }
    x.has(y.name) ? p.push(`变量名称“${y.name}”重复`) : x.add(y.name), y.required && !y.failTip && p.push(`必填变量“${y.name}”需要失败提示`);
  }
  const S = Q(e.id, "success"), E = Q(e.id, "fail");
  return o(S, n).length === 0 && p.push("“成功”分支未连接下一个节点"), o(E, n).length === 0 && p.push("“失败”分支未连接下一个节点"), p;
}
var et = {
  type: f.TOOLS,
  label: "工具调用",
  docs: ["https://help.jeecg.com/aigc/flowNodes/nodeTools"],
  components: {
    icon: Gi,
    setting: Bi
  },
  lfNode: {
    type: f.TOOLS,
    view: O,
    model: M,
    component: Fi
  },
  params: {
    width: 332,
    height: 62
  },
  methods: {
    createNode: kn,
    checkNode: Ln,
    updateNodeSetting: Cn
  }
}, io = () => ({
  inputParams: [],
  outputParams: [{
    field: "result",
    name: "执行结果",
    type: "string"
  }]
});
function kn(t) {
  var e;
  const o = io();
  return {
    id: t.id,
    remarks: "",
    type: et.type,
    x: t.x,
    y: t.y,
    properties: {
      text: (e = t.text) !== null && e !== void 0 ? e : et.label,
      options: { tools: {
        pluginId: "",
        pluginName: "",
        pluginCategory: "plugin",
        toolName: "",
        toolDescr: "",
        toolParameters: [],
        endpoint: "",
        path: "",
        method: "",
        headers: {}
      } },
      inputParams: o.inputParams,
      outputParams: o.outputParams
    }
  };
}
function Cn(t) {
  const { mergeIOParams: e } = Z(t, io);
  e();
}
function Ln(t, e, { checkInputParams: o }) {
  const { properties: r } = e, { options: i } = r, n = [...o({
    text: "输入变量",
    required: !1
  })], a = i.tools || {};
  a.pluginId || n.push("请选择插件或MCP"), a.toolName || n.push("请选择工具"), a.path || n.push("缺少path配置"), a.method || n.push("缺少method配置");
  const l = a.toolParameters || [];
  for (const p of l) p.required && !p.value && n.push(`必填参数未配置: ${p.name}`);
  return n;
}
var tt = {
  type: f.BRAVE_SEARCH,
  label: "Brave搜索",
  docs: ["https://help.jeecg.com/aigc/flowNodes/nodeBraveSearch"],
  components: {
    icon: Wi,
    setting: Hi
  },
  lfNode: {
    type: f.BRAVE_SEARCH,
    view: O,
    model: M,
    component: Vi
  },
  params: {
    width: 332,
    height: 62
  },
  methods: {
    createNode: Mn,
    checkNode: Rn,
    updateNodeSetting: On
  }
}, ro = () => ({
  inputParams: [],
  outputParams: [{
    field: "result",
    name: "搜索结果",
    type: "object[]"
  }]
});
function Mn(t) {
  var e;
  const o = ro();
  return {
    id: t.id,
    remarks: "",
    type: tt.type,
    x: t.x,
    y: t.y,
    properties: {
      text: (e = t.text) !== null && e !== void 0 ? e : tt.label,
      options: { braveSearch: {
        count: 5,
        country: ""
      } },
      inputParams: o.inputParams,
      outputParams: o.outputParams
    }
  };
}
function On(t) {
  const { mergeIOParams: e } = Z(t, ro);
  e();
}
function Rn(t, e, { checkInputParams: o }) {
  return [...o({
    text: "搜索关键词",
    required: !0
  })];
}
var ot = {
  type: f.REPLY,
  label: "直接回复",
  docs: ["https://help.jeecg.com/aigc/flowNodes/nodeEnd"],
  components: {
    icon: qi,
    setting: ji
  },
  lfNode: {
    type: f.REPLY,
    view: O,
    model: M,
    component: Yi
  },
  params: {
    width: 332,
    height: 62
  },
  methods: {
    createNode: Dn,
    checkNode: Gn,
    updateNodeSetting: Bn
  }
};
function Dn(t) {
  var e;
  return {
    id: t.id,
    remarks: "",
    type: ot.type,
    x: t.x,
    y: t.y,
    properties: {
      text: (e = t.text) !== null && e !== void 0 ? e : ot.label,
      options: {
        content: "",
        stream: !1
      },
      inputParams: [],
      outputParams: []
    }
  };
}
function Gn(t, e, { checkInputParams: o }) {
  const { properties: r } = e, { options: i } = r, n = [...o({
    text: "输入变量",
    required: !1
  })];
  return i.content || n.push("回复内容不能为空"), n;
}
function Bn(t) {
  let { stream: e } = t.properties.options;
  e == null && (t.properties.options.stream = !1);
}
var it = {
  type: f.SQL,
  label: "SQL自定义",
  docs: ["https://help.jeecg.com/aigc/flowNodes/nodeSql"],
  components: {
    icon: Xi,
    setting: zi
  },
  lfNode: {
    type: f.SQL,
    view: O,
    model: M,
    component: Ui
  },
  params: {
    width: 332,
    height: 62
  },
  methods: {
    createNode: Wn,
    checkNode: Hn
  }
}, Fn = () => ({
  inputParams: [],
  outputParams: [{
    field: "body",
    name: "sql执行返回结果",
    type: "string"
  }]
});
function Wn(t) {
  var e;
  const o = Fn();
  return {
    id: t.id,
    remarks: "",
    type: it.type,
    x: t.x,
    y: t.y,
    properties: {
      text: (e = t.text) !== null && e !== void 0 ? e : it.label,
      options: { sql: {
        dataSourceName: "",
        dataSourceId: "",
        dataSourceCode: "",
        outputSql: ""
      } },
      inputParams: o.inputParams,
      outputParams: o.outputParams
    }
  };
}
function Hn(t, e, { checkInputParams: o }) {
  const r = [...o({
    text: "输入变量",
    required: !1
  })], { properties: i } = e, { options: n } = i;
  return n.sql.dataSourceId || r.push("数据源不能为空"), n.sql.outputSql || r.push("自定义sql不能为空"), r;
}
var rt = {
  type: f.LOOP,
  label: "循环",
  docs: ["https://help.jeecg.com/aigc/flowNodes/nodeLoop"],
  components: {
    icon: zo,
    setting: Bo
  },
  lfNode: {
    type: f.LOOP,
    view: O,
    model: M,
    component: Ki
  },
  params: {
    width: 332,
    height: 62
  },
  methods: {
    createNode: qn,
    checkNode: jn,
    getDefaultAnchor(t) {
      const e = [...t], o = `${this.id}_${Ge.LINK_BODY}`;
      return e.push({
        id: o,
        x: this.x,
        y: this.y + this.height / 2,
        type: Ge.LINK_BODY
      }), e;
    }
  },
  hooks: {
    afterAddNode(t, e) {
      Xo(t, e);
    },
    afterRemoveNode(t, e) {
      const o = t.id + Gt;
      e.deleteNode(o);
    }
  }
}, Vn = () => ({
  type: "counted",
  maxLoopTimes: 3,
  loopParams: [],
  loopItemsParam: {}
});
function qn(t) {
  var e;
  const o = Vn();
  return {
    id: t.id,
    remarks: "",
    type: rt.type,
    x: t.x,
    y: t.y,
    properties: {
      text: (e = t.text) !== null && e !== void 0 ? e : rt.label,
      groupType: no(o.type),
      options: o,
      inputParams: [],
      outputParams: []
    }
  };
}
function jn(t, e, {}) {
  var o, r, i, n;
  const a = (o = e == null || (r = e.properties) === null || r === void 0 ? void 0 : r.options) !== null && o !== void 0 ? o : {}, l = [], p = (i = a.type) !== null && i !== void 0 ? i : "counted";
  if (no(p) || l.push("请选择有效的循环类型"), p === "counted")
    Yn(a.maxLoopTimes) || l.push("请设置大于 0 的循环次数");
  else if (p === "infinite")
    Xn(t, e == null ? void 0 : e.id) || l.push("无限循环必须在循环体内添加“终止循环”节点");
  else if (p === "array") {
    var v, h, x;
    (!a.loopItemsParam || !(!((v = a.loopItemsParam) === null || v === void 0) && v.nodeId) || !(!((h = a.loopItemsParam) === null || h === void 0) && h.field)) && l.push("请选择迭代数组变量"), !((x = a.loopItemsParam) === null || x === void 0) && x.type && !`${a.loopItemsParam.type}`.endsWith("[]") && l.push("迭代变量必须是数组类型");
  }
  return (Array.isArray(e == null || (n = e.properties) === null || n === void 0 ? void 0 : n.outputParams) ? e.properties.outputParams : []).length > 0, l;
}
function Yn(t) {
  return typeof t == "number" && Number.isInteger(t) && t > 0;
}
function no(t) {
  return t === "array" ? ie.ITERATOR : ie.WHILE;
}
function Xn(t, e) {
  var o;
  if (!t || !e) return !1;
  const r = (o = t.getGraphData) === null || o === void 0 ? void 0 : o.call(t);
  if (!r) return !1;
  const i = r, n = Array.isArray(i == null ? void 0 : i.nodes) ? i.nodes : [], a = Array.isArray(i == null ? void 0 : i.edges) ? i.edges : [], l = /* @__PURE__ */ new Map();
  n.forEach((y) => {
    y != null && y.id && l.set(y.id, y.type);
  });
  const p = /* @__PURE__ */ new Map();
  a.forEach((y) => {
    var N;
    if (!(y != null && y.sourceNodeId) || !(y != null && y.targetNodeId)) return;
    const R = (N = p.get(y.sourceNodeId)) !== null && N !== void 0 ? N : [];
    R.push(y.targetNodeId), p.set(y.sourceNodeId, R);
  });
  const v = /* @__PURE__ */ new Set(), h = [e], x = Math.max(n.length * 2, 50);
  let S = 0;
  for (; h.length > 0 && S < x; ) {
    var E;
    S++;
    const y = h.shift();
    if (v.has(y)) continue;
    v.add(y);
    const N = (E = p.get(y)) !== null && E !== void 0 ? E : [];
    for (const R of N) {
      if (l.get(R) === f.LOOP_BREAK) return !0;
      v.has(R) || h.push(R);
    }
  }
  return !1;
}
var zn = class extends M {
  constructor(t, e) {
    super(t, e);
  }
  getData() {
    const t = super.getData();
    return t.properties || (t.properties = {}), t.properties.loopNodeId = Ht(this.id), t;
  }
}, nt = {
  type: f.LOOP_BREAK,
  label: "终止循环",
  components: {
    icon: Ji,
    setting: ht
  },
  lfNode: {
    type: f.LOOP_BREAK,
    view: O,
    model: zn,
    component: Qi
  },
  params: {
    width: 332,
    height: 62
  },
  methods: {
    createNode: Un,
    getDefaultAnchor(t) {
      return t.filter((e) => e.type === "left");
    }
  }
};
function Un(t) {
  var e;
  return {
    id: t.id,
    type: nt.type,
    x: t.x,
    y: t.y,
    remarks: "",
    properties: {
      text: (e = t.text) !== null && e !== void 0 ? e : nt.label,
      options: {},
      inputParams: [],
      outputParams: []
    }
  };
}
var st = {
  type: f.LOOP_CONTINUE,
  label: "继续循环",
  components: {
    icon: Zi,
    setting: ht
  },
  lfNode: {
    type: f.LOOP_CONTINUE,
    view: O,
    model: M,
    component: er
  },
  params: {
    width: 332,
    height: 62
  },
  methods: {
    createNode: Kn,
    getDefaultAnchor(t) {
      return t.filter((e) => e.type === "left");
    }
  }
};
function Kn(t) {
  var e;
  return {
    id: t.id,
    type: st.type,
    x: t.x,
    y: t.y,
    remarks: "",
    properties: {
      text: (e = t.text) !== null && e !== void 0 ? e : st.label,
      options: {},
      inputParams: [],
      outputParams: []
    }
  };
}
var Jn = class extends M {
  constructor(t, e) {
    super(t, e);
  }
  getData() {
    const t = super.getData();
    return t.properties || (t.properties = {}), t.properties.loopNodeId = Ht(this.id), t;
  }
}, at = {
  type: f.SET_LOOP_VAR,
  label: "设置循环变量",
  components: {
    icon: tr,
    setting: ir
  },
  lfNode: {
    type: f.SET_LOOP_VAR,
    view: O,
    model: Jn,
    component: or
  },
  params: {
    width: 332,
    height: 62
  },
  methods: {
    createNode: Qn,
    checkNode: Zn
  }
};
function Qn(t) {
  var e;
  return {
    id: t.id,
    type: at.type,
    x: t.x,
    y: t.y,
    remarks: "",
    properties: {
      text: (e = t.text) !== null && e !== void 0 ? e : at.label,
      options: {
        targetField: "",
        sourceVar: {}
      },
      inputParams: [],
      outputParams: []
    }
  };
}
function Zn(t, e) {
  var o, r;
  const i = (o = e == null || (r = e.properties) === null || r === void 0 ? void 0 : r.options) !== null && o !== void 0 ? o : {}, n = [];
  i.targetField || n.push("请选择要设置的循环变量");
  const a = i.sourceVar;
  return (!a || (!a.nodeId || !a.field) && !a.customValue && a.customValue !== "") && n.push("请选择或输入变量值"), n;
}
var dt = {
  type: f.CHAT_VAR_GET,
  label: "变量读取",
  docs: ["https://help.jeecg.com/aigc/flowNodes/nodeChatVarGet"],
  components: {
    icon: rr,
    setting: nr
  },
  lfNode: {
    type: f.CHAT_VAR_GET,
    view: O,
    model: M,
    component: sr
  },
  params: {
    width: 332,
    height: 62
  },
  methods: {
    createNode: es,
    checkNode: ts
  }
};
function es(t) {
  var e;
  return {
    id: t.id,
    type: dt.type,
    x: t.x,
    y: t.y,
    properties: {
      text: (e = t.text) !== null && e !== void 0 ? e : dt.label,
      options: { variables: [{ name: "" }] },
      inputParams: [],
      outputParams: []
    }
  };
}
function ts(t, e) {
  var o, r;
  const i = [], n = (o = e == null || (r = e.properties) === null || r === void 0 || (r = r.options) === null || r === void 0 ? void 0 : r.variables) !== null && o !== void 0 ? o : [];
  if (!Array.isArray(n) || n.length === 0)
    return i.push("请至少配置一个变量"), i;
  const a = /* @__PURE__ */ new Set();
  for (const l of n) {
    if (!l.name) {
      i.push("存在未填写变量名的变量");
      break;
    }
    if (a.has(l.name)) {
      i.push(`变量名"${l.name}"重复`);
      break;
    }
    a.add(l.name);
  }
  return i;
}
var lt = {
  type: f.CHAT_VAR_SET,
  label: "变量赋值",
  docs: ["https://help.jeecg.com/aigc/flowNodes/nodeChatVarSet"],
  components: {
    icon: ar,
    setting: dr
  },
  lfNode: {
    type: f.CHAT_VAR_SET,
    view: O,
    model: M,
    component: lr
  },
  params: {
    width: 332,
    height: 62
  },
  methods: {
    createNode: os,
    checkNode: is
  }
};
function os(t) {
  var e;
  return {
    id: t.id,
    type: lt.type,
    x: t.x,
    y: t.y,
    properties: {
      text: (e = t.text) !== null && e !== void 0 ? e : lt.label,
      options: { variables: [{ name: "" }] },
      inputParams: [],
      outputParams: []
    }
  };
}
function is(t, e) {
  var o, r;
  const i = [], n = (o = e == null || (r = e.properties) === null || r === void 0 || (r = r.options) === null || r === void 0 ? void 0 : r.variables) !== null && o !== void 0 ? o : [];
  if (!Array.isArray(n) || n.length === 0)
    return i.push("请至少配置一个变量"), i;
  const a = /* @__PURE__ */ new Set();
  for (const l of n) {
    if (!l.name) {
      i.push("存在未填写变量名的变量");
      break;
    }
    if (a.has(l.name)) {
      i.push(`变量名"${l.name}"重复`);
      break;
    }
    if (a.add(l.name), !(l.nodeId && l.field || l.isCustom)) {
      i.push(`变量"${l.name}"未设置值`);
      break;
    }
  }
  return i;
}
var pt = {
  type: f.CHAT_MEMORY_GET,
  label: "记忆检索",
  docs: ["https://help.jeecg.com/aigc/flowNodes/nodeChatMemoryGet"],
  components: {
    icon: pr,
    setting: cr
  },
  lfNode: {
    type: f.CHAT_MEMORY_GET,
    view: O,
    model: M,
    component: ur
  },
  params: {
    width: 332,
    height: 62
  },
  methods: {
    createNode: rs,
    checkNode: ns
  }
};
function rs(t) {
  var e;
  return {
    id: t.id,
    remarks: "",
    type: pt.type,
    x: t.x,
    y: t.y,
    properties: {
      text: (e = t.text) !== null && e !== void 0 ? e : pt.label,
      options: {
        content: "",
        topNumber: 5,
        similarity: 0.7
      },
      inputParams: [],
      outputParams: [{
        field: "documents",
        name: "文档列表",
        type: "object[]"
      }, {
        field: "data",
        name: "文档内容",
        type: "string"
      }]
    }
  };
}
function ns(t, e, { checkInputParams: o }) {
  const { properties: r } = e, { options: i } = r, n = [...o({
    text: "输入变量",
    required: !1,
    requiredName: !0
  })];
  return i != null && i.content || n.push("检索内容不能为空"), n;
}
var ct = {
  type: f.CHAT_MEMORY_SET,
  label: "记忆写入",
  docs: ["https://help.jeecg.com/aigc/flowNodes/nodeChatMemorySet"],
  components: {
    icon: fr,
    setting: hr
  },
  lfNode: {
    type: f.CHAT_MEMORY_SET,
    view: O,
    model: M,
    component: mr
  },
  params: {
    width: 332,
    height: 62
  },
  methods: {
    createNode: ss,
    checkNode: ds,
    updateNodeSetting: as
  }
};
function ss(t) {
  var e;
  return {
    id: t.id,
    remarks: "",
    type: ct.type,
    x: t.x,
    y: t.y,
    properties: {
      text: (e = t.text) !== null && e !== void 0 ? e : ct.label,
      options: {
        title: "",
        content: "",
        waitForVectorize: !1,
        waitTimeout: 300,
        vectorizeFailStrategy: "ignore"
      },
      inputParams: [],
      outputParams: [{
        field: "documentId",
        name: "documentId",
        type: "string"
      }, {
        field: "documentIds",
        name: "documentIds",
        type: "string[]"
      }]
    }
  };
}
function as(t) {
  t.properties.options || (t.properties.options = {});
  const e = t.properties.options;
  typeof e.waitForVectorize != "boolean" && (e.waitForVectorize = !1), (typeof e.waitTimeout != "number" || e.waitTimeout <= 0) && (e.waitTimeout = 300), e.vectorizeFailStrategy !== "error" && e.vectorizeFailStrategy !== "ignore" && (e.vectorizeFailStrategy = "ignore"), Array.isArray(t.properties.outputParams) || (t.properties.outputParams = []);
  const o = t.properties.outputParams;
  o.some((r) => r.field === "documentIds") || o.push({
    field: "documentIds",
    name: "documentIds",
    type: "string[]"
  });
}
function ds(t, e, { checkInputParams: o }) {
  const { properties: r } = e, { options: i } = r, n = [...o({
    text: "输入变量",
    required: !1,
    requiredName: !0
  })];
  return i != null && i.content || n.push("写入内容不能为空"), n;
}
var ls = ft.type;
function ps(t) {
  Rt.clear(), ut.clear(), le.clear(), J.clear(), t.register(ft), t.register(Be);
  const e = cs(t);
  e(Fe, { show: !1 }), e(He), e(Ve), e(qe), e(Ze), e(Qe), J.addDivider(), e(Ye), e(Xe), J.addDivider(), e(je), e(ze), e(Ke), e(Je), e(it), e(et), e(tt), J.addDivider("流程控制"), e(rt), e(qo, { show: !1 }), e(nt, { show: !1 }), e(st, { show: !1 }), e(at, { show: !1 }), e(Ue), J.addDivider(), e(ot), e(We), e(gr), J.addDivider("应用节点"), e(dt), e(lt), e(pt), e(ct);
}
function cs(t) {
  return (e, o) => {
    e.docs = us(e), le.set(e.type, e), Oo(e.lfNode, t), e.components.icon && Rt.set(e.type, e.components.icon), e.components.setting && ut.set(e.type, e.components.setting), J.add(e.type, o);
  };
}
function us(t) {
  const { docs: e } = t;
  if (e) {
    if (typeof e == "string") return e;
    if (!(!Array.isArray(e) || e.length === 0))
      return e.length > 1 ? e[1] : e[0];
  }
}
me();
var Ot = 800, fs = /* @__PURE__ */ Sr({
  __name: "WorkflowView",
  props: {
    data: {
      type: Object,
      default: () => ({})
    },
    width: {
      type: Number,
      default: 2048
    },
    height: {
      type: Number,
      default: 800
    },
    openCheckListPop: Function
  },
  emits: [
    "save",
    "close",
    "init"
  ],
  setup(t, { expose: e, emit: o }) {
    const { createWarningModal: r } = $r(), i = Go(), n = t, a = o, l = ko(), p = Lo(), { prefixCls: v } = qt("airag-work-flow-box"), h = ue(null), x = ue(null), S = ue(null), E = ue(""), y = Pe({ isSilentMode: !1 });
    Ct("lfRef", h), Ct("editConfigModel", y);
    const N = Pe({
      visible: !1,
      triggerNodeId: "",
      payload: {},
      isShow: uo,
      onAdd: fo
    }), [R, L] = Mt(), [D, G] = Mt(), re = (s) => ve.value.length > 0 ? (r({
      title: "存在问题",
      content: `存在尚未修复的节点问题，请先修复后再进行${s}`,
      okText: "立即修复",
      cancelText: "取消",
      okCancel: !0,
      maskClosable: !0,
      onOk: () => {
        var d;
        return n == null || (d = n.openCheckListPop) === null || d === void 0 ? void 0 : d.call(n);
      }
    }), !1) : !0, ne = () => {
      re("调试") && (W(G.getOpen) && G.closeDrawer(), N.visible && (N.visible = !1, N.payload = {}, N.triggerNodeId = ""), L.openDrawer(!0, {}));
    }, { SuperControl: ee } = Gr(h);
    _r(() => {
      S.value && (l.initStatus(), p.clearProps(), h.value = ge({ container: S.value }), window.addEventListener("keydown", $t), a("init", h.value));
    });
    function ge({ container: s }) {
      var d;
      h.value && h.value.destroy();
      const u = new Do(H(H({
        container: s,
        width: n.width,
        height: n.height,
        edgeType: ls,
        textEdit: !1,
        adjustEdge: !1,
        adjustEdgeStartAndEnd: !1,
        background: { backgroundColor: "#f5f6f7" },
        grid: {
          size: 10,
          type: "dot",
          config: {
            color: "#E0E0E0",
            thickness: 1
          }
        }
      }, Hr()), {}, { pluginsOptions: { [ee.pluginName]: {
        use: ee,
        debugRun: ne,
        save: () => a("save"),
        close: () => a("close")
      } } }));
      if (ps(u), ao(u), !((d = n.data) === null || d === void 0 || (d = d.nodes) === null || d === void 0) && d.length) for (const m of n.data.nodes) {
        var c;
        const g = le.get(m.type);
        typeof (g == null || (c = g.methods) === null || c === void 0 ? void 0 : c.updateNodeSetting) == "function" && g.methods.updateNodeSetting(m);
      }
      return u.render(n.data), Ie(() => po(u)), Ie(() => {
        var m;
        xo(u, (m = n.data) === null || m === void 0 ? void 0 : m.viewport) || u.graphModel.$J.focusOnStartNode();
      }), u;
    }
    const U = /* @__PURE__ */ new Map(), $e = Ar(() => U.forEach((s) => s.events.onNodeUpdated()), 50), so = function(s) {
      const d = U.get(s);
      d && (d.events.onNodeUpdated(), be());
    };
    function ao(s) {
      s.on("graph:rendered", ({ graphModel: c }) => {
        E.value = c.flowId, vo(c), setTimeout(() => yt(), 150);
      }), s.on("edge:add", (c) => {
        var m;
        if (!(!(c == null || (m = c.data) === null || m === void 0) && m.targetAnchorId)) return;
        const { sourceNodeId: g, targetNodeId: w } = c.data;
        if (g === w) {
          s.deleteEdge(c.data.id);
          return;
        }
        const { id: I, type: k, sourceAnchorId: T, targetAnchorId: _ } = c.data;
        (k !== Be.type && _.endsWith(fe.LOOP_END) || T != null && T.endsWith(fe.LOOP_START)) && s.graphModel.changeEdgeType(I, Be.type);
      });
      let d = !1;
      s.on("connection:not-allowed", () => {
        d = !0;
      }), s.on("anchor:dragend", (c) => {
        if (c.edgeModel) return;
        if (d) {
          d = !1;
          return;
        }
        if (y.isSilentMode) return;
        const { e: m, nodeModel: g, data: w } = c;
        if (!m || !g) return;
        const I = s.getPointByClient(m.clientX, m.clientY);
        if (!I) return;
        const k = I.canvasOverlayPosition.x - w.x, T = I.canvasOverlayPosition.y - w.y;
        if (Math.sqrt(k * k + T * T) < 100) return;
        const _ = I.canvasOverlayPosition.x < w.x, $ = {
          isDragend: !0,
          event: { target: { getBoundingClientRect: () => ({
            top: m.clientY,
            left: m.clientX,
            width: 0,
            height: 0,
            right: m.clientX,
            bottom: m.clientY,
            x: m.clientX,
            y: m.clientY,
            toJSON() {
            }
          }) } },
          prevData: {
            node: g,
            anchor: w,
            targetPosition: I.canvasOverlayPosition,
            dragToLeft: _
          }
        };
        s.selectElementById(g.id), s.graphModel.$J.setAddNodeDrawerVisible(!0, $, g.id);
      }), s.on("node:click", (c) => {
        Ae(c);
      });
      let u = null;
      s.on("node:dragstart", (c) => {
        u = c.data;
      }), s.on("node:drop", (c) => {
        if (u == null) return;
        if (co(c.e, (I) => (I == null ? void 0 : I.dataset) && I.dataset.hasOwnProperty("isNodeAction")) != null) {
          c.e.preventDefault(), c.e.stopPropagation();
          return;
        }
        const m = Math.abs(c.data.x - u.x), g = Math.abs(c.data.y - u.y);
        u = null;
        const w = 1;
        if (m <= w && g <= w) {
          c.e.preventDefault(), c.e.stopPropagation(), s.graphModel.selectNodeById(c.data.id), $e(), Ae(c);
          return;
        }
        s.graphModel.editConfigModel.isSilentMode && (c.e.preventDefault(), c.e.stopPropagation());
      }), s.on("node:delete", (c) => ho(c)), s.on("node:properties-change", (c) => {
        const m = U.get(c.id);
        if (!m) return;
        const g = m.node;
        Ro[g.type] && c.id === g.id && m.events.onPropertiesChange(c);
      }), s.on("graph:updated", (c) => lo(c));
    }
    function lo(s) {
      $e(), be();
    }
    const ve = ue([]);
    let vt = 0, ye = 0;
    const yt = () => be({ now: !0 });
    function be({ now: s = !1 } = {}) {
      if (ye && clearTimeout(ye), s) {
        ye = 0, Nt({ now: !0 });
        return;
      } else ye = setTimeout(() => {
        Nt();
      }, Ot);
    }
    function Nt({ now: s = !1 } = {}) {
      if (!h.value || !s && Date.now() - vt < Ot) return;
      vt = Date.now();
      const d = h.value;
      ve.value = [];
      const u = d.graphModel.nodes;
      for (const m of u) {
        var c;
        const g = le.get(m.type);
        if (typeof (g == null || (c = g.methods) === null || c === void 0 ? void 0 : c.checkNode) == "function") {
          const w = g.methods.checkNode(d, m, {
            checkInputParams: (...I) => xt(m, "input", ...I),
            checkOutputParams: (...I) => xt(m, "output", ...I),
            findNextIdsByAnchorId: pe
          });
          Array.isArray(w) && w.length > 0 && ve.value.push({
            node: m,
            nodeText: m.properties.text,
            problems: w,
            onClick: () => {
              It(), d.graphModel.selectNodeById(m.id), Ae({
                data: m,
                e: new Event("click")
              }), Me(m), d.focusOn({ id: m.id });
            }
          });
        }
      }
    }
    function xt(s, d, { required: u = !0, text: c = "", requiredName: m = !0 }) {
      var g;
      const w = [], I = d === "input", k = c || (I ? "输入参数" : "输出参数"), T = s == null || (g = s.properties) === null || g === void 0 ? void 0 : g[d + "Params"];
      if ((!Array.isArray(T) || T.length === 0) && u)
        return w.push(`${k}不能为空`), w;
      for (let _ = 0; _ < T.length; _++) {
        const $ = T[_];
        if (I && s.type === f.START) continue;
        let A = m ? !$.name : !1;
        if (!$.nodeId || !$.field || A)
          if (s.type === f.KNOWLEDGE) {
            w.push(`${k}不能为空`);
            break;
          } else w.push(`${k}的第${_ + 1}项配置不完整`);
      }
      return w;
    }
    function po(s) {
      const d = S.value.querySelector("div.lf-graph svg.lf-canvas-overlay");
      d && d.addEventListener("click", function(u) {
        if (u.target === d) {
          mo();
          return;
        }
      });
    }
    function co(s, d) {
      if (typeof (s == null ? void 0 : s.composedPath) == "function" && (s = s.composedPath()), !Array.isArray(s)) return null;
      for (let u = 0; u < s.length; u++) {
        const c = s[u];
        if (c.classList.contains("lf-canvas-overlay")) return null;
        if (d(c)) return c;
      }
      return null;
    }
    function Ae(s) {
      const d = U.get(s.data.id);
      d && (St(d), d.events.onNodeClick(s));
    }
    function uo(s) {
      const d = N.payload;
      if (typeof (d == null ? void 0 : d.isShow) == "function") return d.isShow(s);
      const u = N.triggerNodeId;
      return u ? !u.endsWith(Gt) && !p.nodeGroupMap.get(u) ? J.isShow(s) : jo(s) : J.isShow(s);
    }
    function fo(s) {
      var d, u;
      if (!h.value) return;
      const c = h.value.graphModel, m = (d = N.payload) === null || d === void 0 ? void 0 : d.prevData;
      m && (!((u = N.payload) === null || u === void 0) && u.anchor) && (m.anchor = N.payload.anchor);
      const g = {
        nodeType: s,
        prevData: m
      };
      c.$J.doAction("add-node", g);
      const w = U.get(N.triggerNodeId);
      w && w.events.onAfterAddNode(s, g), c.$J.setAddNodeDrawerVisible(!1);
    }
    let Ne = null;
    function ho(s) {
      const { model: d } = s;
      U.delete(d.id), W(G.getOpen) && Ne === d.id && G.closeDrawer(), yt();
    }
    function St(s) {
      return ke.apply(this, arguments);
    }
    function ke() {
      return ke = ce(function* (s) {
        var d;
        W(G.getOpen) && Ne === s.node.id || (W(L.getOpen) && L.closeDrawer(), Ne = s.node.id, G.closeDrawer(), ut.get((d = s.node) === null || d === void 0 ? void 0 : d.type) !== ht && (yield Ie(), G.openDrawer(!0, { node: s.node })));
      }), ke.apply(this, arguments);
    }
    function mo() {
      Ne = null, W(G.getOpen) && G.closeDrawer();
    }
    function It() {
      const s = h.value;
      if (!s) return;
      const d = s.graphModel.selectNodes;
      s.graphModel.clearSelectElements();
      for (const u of d) Me(u);
    }
    function go(s) {
      return new Promise((d) => {
        function u() {
          const c = U.get(s);
          c ? d(c) : setTimeout(u, 50);
        }
        u();
      });
    }
    function vo(s) {
      s.$J = H(H({}, Dr(h, s)), {}, {
        $groupUtils: zt(h, s),
        on(...d) {
        },
        register(d, u) {
          U.set(d.id, {
            node: d,
            events: u
          });
        },
        doAction(d, u) {
          if (!h.value) return;
          const c = h.value;
          if (d === "copy") {
            It();
            const m = p.nodeGroupMap.get(u.node.id), g = c.cloneNode(u.node.id);
            if (Ie(ce(function* () {
              W(G.getOpen) && St(yield go(g.id)), $e();
            })), m) {
              const w = c.graphModel.getNodeModelById(m);
              w && w.addChild(g.id);
            }
          } else if (d === "delete") Et(u.node);
          else if (d === "toggle-add-node-drawer") {
            const m = U.get(u.node.id);
            if (!m) return;
            c.selectElementById(u.node.id), m.events.toggleAddNodeDrawer(u, N);
          } else d === "add-node" && _t(u.nodeType, u.prevData, u.edgeType);
        },
        updateEditConfig(d) {
          h.value && (Object.assign(y, d), h.value.updateEditConfig(d));
        },
        setEdgeRunStatus(d, u) {
          if (!h.value || d.type === f.START) return;
          const c = s.getNodeIncomingEdge(d.id);
          if (!(!c || c.length === 0))
            for (const w of c)
              if (w.setProperties({ runStatus: u }), u && u !== "waiting") {
                const I = l.getStep(w.sourceNodeId);
                if ((I == null ? void 0 : I.status) === "success") {
                  const k = I.node.type === f.SWITCH ? Bt : I.node.type === f.CLASSIFIER ? Ft : null;
                  let T = "";
                  if (k) {
                    var m;
                    const _ = (m = I.outputParams) === null || m === void 0 ? void 0 : m[`${I.node.id}.index`];
                    typeof _ == "number" && (T = k.getAnchorIdByChooseIndex(I.node.id, _));
                  } else if (I.node.type === f.VAR_EXTRACT) {
                    var g;
                    const _ = `${I.node.id}.${Ho}`, $ = Object.prototype.hasOwnProperty.call((g = I.outputParams) !== null && g !== void 0 ? g : {}, _);
                    T = Q(I.node.id, $ ? "fail" : "success");
                  }
                  if (T && T !== w.sourceAnchorId) continue;
                  w.openEdgeAnimation();
                }
              } else w.closeEdgeAnimation();
        },
        getAddNodeDrawerVisible() {
          return N.visible;
        },
        setAddNodeDrawerVisible(d, u, c) {
          N.visible && !d && c && N.triggerNodeId !== c || (N.visible = d, N.payload = u || {}, N.triggerNodeId = c || "");
        }
      });
    }
    function Et(s) {
      return Ce.apply(this, arguments);
    }
    function Ce() {
      return Ce = ce(function* (s) {
        Le(s);
      }), Ce.apply(this, arguments);
    }
    function yo(s) {
      if (!h.value) return;
      const d = h.value.getNodeModelById(s);
      d && Le(d);
    }
    function Le(s) {
      var d;
      if (!h.value || !(s != null && s.id)) return;
      const u = (d = s.nodeConfig) !== null && d !== void 0 ? d : le.get(s.type);
      if (!u)
        return;
      const { hooks: c } = u;
      if (typeof (c == null ? void 0 : c.beforeRemoveNode) == "function" && !c.beforeRemoveNode(s, h.value))
        return;
      const m = s.getData();
      h.value.deleteNode(s.id) && typeof (c == null ? void 0 : c.afterRemoveNode) == "function" && c.afterRemoveNode(m, h.value);
    }
    function Me(s) {
      s != null && s.id && so(s.id);
    }
    function No(s, d) {
      if (!h.value) return;
      const u = h.value.getNodeModelById(s);
      u && u.setProperties({ text: d });
    }
    function wt(s, d, u, c) {
      return {
        x: s,
        y: d,
        width: u,
        height: c,
        left: s - u / 2,
        right: s + u / 2,
        top: d - c / 2,
        bottom: d + c / 2
      };
    }
    function _t(s, d, u) {
      return Oe.apply(this, arguments);
    }
    function Oe() {
      return Oe = ce(function* (s, d, u) {
        if (!h.value) return;
        const c = h.value, m = le.get(s);
        if (!m)
          return;
        const g = {};
        let w = null;
        if (d != null && d.node) {
          const b = d.node, B = d.anchor;
          if (d.targetPosition) {
            var I, k;
            const Y = ((I = (k = m.params) === null || k === void 0 ? void 0 : k.width) !== null && I !== void 0 ? I : 332) / 2;
            g.x = d.targetPosition.x + Y, g.y = d.targetPosition.y;
          } else {
            var T, _;
            const Y = (T = B == null ? void 0 : B.x) !== null && T !== void 0 ? T : b.x, K = (_ = B == null ? void 0 : B.y) !== null && _ !== void 0 ? _ : b.y;
            g.x = Y + (B ? 120 : b.width) + 200, g.y = K;
          }
          if (w = {
            type: u || ft.type,
            sourceNodeId: b.id,
            targetNodeId: ""
          }, B != null && B.id && (w.sourceAnchorId = B.id), b.type === f.LOOP_BODY) g.groupId = b.id;
          else {
            const Y = p.nodeGroupMap.get(b.id);
            Y && (g.groupId = Y);
          }
        } else {
          const b = c.getTransform(), B = c.container, Y = B.clientWidth, K = B.clientHeight, te = Y / 2, X = K / 2, V = (te - b.TRANSLATE_X) / b.SCALE_X, ae = (X - b.TRANSLATE_Y) / b.SCALE_Y;
          g.x = V, g.y = ae;
        }
        const { methods: $, hooks: A } = m, F = $.createNode(g);
        let C = {
          up: { y: 0 },
          down: { y: 0 }
        };
        const q = (b, B) => {
          if (B > 999) return;
          const Y = [...c.graphModel.nodes], K = 20, te = B % 2 === 0 ? "up" : "down";
          let X = C[te].y;
          if (X = X || b.y, Y.length > 0) {
            let V = K * 1.5;
            m.type === f.CLASSIFIER ? V = te === "up" ? V + 80 : V : m.type === f.SWITCH ? V = te === "up" ? V + 60 : V : m.type === f.LLM && (V = te === "up" ? V + 40 : V);
            const ae = wt(b.x, X, m.params.width, m.params.height), wo = Y.map((z) => wt(z.x, z.y, z.width, z.height));
            let de = null;
            for (const z of wo) {
              const _o = Math.abs(z.left - ae.left), Po = Math.abs(z.right - ae.right);
              if (!(_o < K || Po < K)) continue;
              const To = Math.abs(z.top - ae.top), $o = Math.abs(z.bottom - ae.bottom);
              (To < K || $o < K) && (de = z);
            }
            de ? (te === "up" ? X = de.y - de.height - V : X = de.y + de.height + V, C[te].y = X, q(b, B + 1)) : b.y = X;
          }
        };
        if (q(F, 0), typeof (A == null ? void 0 : A.beforeAddNode) == "function" && (yield A.beforeAddNode({
          node: F,
          nodeArgs: g,
          edgeArgs: w
        }, c)) === !1)
          return;
        const j = c.addNode(F);
        if (g.groupId) {
          const b = c.graphModel.getNodeModelById(g.groupId);
          b && b.addChild(j.id);
        }
        if (w) {
          const b = H(H({}, w), {}, { targetNodeId: j.id });
          d != null && d.targetPosition && (b.targetAnchorId = `${j.id}_input`), c.addEdge(b);
        }
        return typeof (A == null ? void 0 : A.afterAddNode) == "function" && (yield A.afterAddNode(j, c)), j;
      }), Oe.apply(this, arguments);
    }
    function Pt() {
      if (h.value)
        return H(H({}, h.value.getGraphData()), {}, { viewport: h.value.getTransform() });
    }
    function xo(s, d) {
      if (!d || !Number.isFinite(d.SCALE_X) || !Number.isFinite(d.TRANSLATE_X) || !Number.isFinite(d.TRANSLATE_Y)) return !1;
      s.zoom(d.SCALE_X);
      const u = s.getTransform();
      return s.translate(d.TRANSLATE_X - u.TRANSLATE_X, d.TRANSLATE_Y - u.TRANSLATE_Y), !0;
    }
    const se = /* @__PURE__ */ new Map();
    function So() {
      if (!h.value) return "";
      let { nodes: s, edges: d } = h.value.getGraphRawData();
      const u = /* @__PURE__ */ new Map();
      d = d.filter((I) => {
        var k;
        let T = !(!((k = I.targetAnchorId) === null || k === void 0) && k.endsWith(fe.LOOP_END));
        if (T) {
          var _;
          T = !(!((_ = I.sourceAnchorId) === null || _ === void 0) && _.endsWith(fe.LOOP_START));
        }
        if (T) {
          var $;
          !(($ = I.sourceAnchorId) === null || $ === void 0) && $.endsWith(Ge.LINK_BODY) && (T = !1, u.set(I.sourceNodeId, I.targetNodeId));
        }
        return T;
      });
      let c, m = /* @__PURE__ */ new Set();
      do {
        c = !1;
        for (const I of s) {
          var g;
          if (I.type !== f.LOOP) continue;
          const k = I.id;
          if (m.has(k)) continue;
          m.add(k);
          const T = u.get(k);
          if (!T) continue;
          const _ = s.find((C) => C.id === T);
          if (!_) continue;
          const $ = ((g = _.properties) !== null && g !== void 0 ? g : {}).children;
          if (!Array.isArray($) || $.length === 0) continue;
          c = !0;
          let A = [];
          if ([A, s] = Lt(s, (C) => $.includes(C.id)), A.length === 0) continue;
          let F = [];
          [F, d] = Lt(d, (C) => $.includes(C.sourceNodeId) || $.includes(C.targetNodeId)), I.flowData = {
            nodes: A,
            edges: F
          }, s = s.filter((C) => C.id !== T);
        }
      } while (c);
      const w = {
        nodes: s,
        edges: d
      };
      try {
        return Rr(w, se);
      } catch (I) {
      }
      return "";
    }
    function Io() {
      const s = Pt();
      if (!s) throw new Error("尚未初始化");
      const { nodes: d, edges: u } = s;
      if (d.length === 0) throw new Error("请添加节点");
      se.clear();
      const c = [
        f.END,
        f.SWITCH,
        f.CLASSIFIER,
        f.VAR_EXTRACT
      ], m = /* @__PURE__ */ new Map();
      for (const _ of d) if (c.includes(_.type)) {
        let $ = m.get(_.type);
        Array.isArray($) || ($ = []), $.push(_), m.set(_.type, $);
      }
      if (!m.has(f.END)) throw new Error("请添加结束节点");
      const g = m.get(f.SWITCH);
      if (Array.isArray(g) && g.length > 0) for (const _ of g) {
        const { text: $, options: A } = _.properties;
        if (!Array.isArray(A == null ? void 0 : A.if) || A.if.length === 0) break;
        const F = mt(_);
        for (let C = 0; C < F.length; C++) {
          const q = F[C], j = we(_.id, q.type, C + 1), b = pe(j, u);
          if (b.length === 0) break;
          q.type === "ELSE" ? A.else.next = b[0] : A.if[C].next = b[0], se.set(j, b);
        }
      }
      const w = m.get(f.CLASSIFIER);
      if (Array.isArray(w) && w.length > 0) for (const _ of w) {
        const { text: $, options: A } = _.properties;
        if (!Array.isArray(A == null ? void 0 : A.categories) || A.categories.length === 0) break;
        const F = gt(_);
        for (let C = 0; C < F.length; C++) {
          const q = F[C], j = _e(_.id, q.type, C + 1);
          let b = pe(j, u);
          if (b.length === 0) break;
          q.type === "ELSE" ? A.else.next = b[0] : A.categories[C].next = b[0], se.set(j, b);
        }
      }
      const I = m.get(f.VAR_EXTRACT);
      if (Array.isArray(I) && I.length > 0) for (const _ of I) {
        const $ = _.properties.options || (_.properties.options = {}), A = Q(_.id, "success"), F = Q(_.id, "fail"), C = pe(A, u), q = pe(F, u);
        if (C.length > 0) {
          var k;
          $.success = (k = $.success) !== null && k !== void 0 ? k : {}, $.success.next = C[0], se.set(A, C);
        }
        if (q.length > 0) {
          var T;
          $.fail = (T = $.fail) !== null && T !== void 0 ? T : {}, $.fail.next = q[0], se.set(F, q);
        }
      }
      return s;
    }
    function pe(s, d) {
      const u = d.filter((c) => c.sourceAnchorId === s);
      return !u || u.length === 0 ? [] : u.map((c) => c.targetNodeId);
    }
    function Eo(s) {
      Tt((d) => {
        d.graphModel.$J.updateEditConfig({ isSilentMode: s });
      });
    }
    function Tt(s) {
      return Re.apply(this, arguments);
    }
    function Re() {
      return Re = ce(function* (s) {
        h.value && (yield s(h.value));
      }), Re.apply(this, arguments);
    }
    function $t(s) {
      var d;
      if (s.key === "s" && s.ctrlKey)
        return a("save"), xe(s);
      const u = s.target, c = u == null || (d = u.tagName) === null || d === void 0 ? void 0 : d.toLowerCase(), m = c === "input" || c === "textarea" || (u == null ? void 0 : u.contentEditable) === "true";
      Tt((g) => {
        if (!m) {
          if (s.key === "z" && s.ctrlKey)
            return g.undo(), xe(s);
          if (s.key === "y" && s.ctrlKey)
            return g.redo(), xe(s);
          if (s.key === "Delete") {
            const w = g.graphModel.selectNodes;
            return w.length > 0 && Et(w[0]), xe(s);
          }
        }
      });
    }
    function xe(s) {
      s.preventDefault(), s.stopPropagation();
    }
    return Pr(() => {
      h.value && h.value.destroy(), window.removeEventListener("keydown", $t);
    }), e({
      getLogicFlow: () => h.value,
      doDebugRun: ne,
      updateText: No,
      addNode: _t,
      deleteNode: Le,
      deleteNodeById: yo,
      getGraphData: Pt,
      validateData: Io,
      getLiteFlowData: So,
      nodeChecklist: ve,
      setSilentMode: Eo,
      checkProblemCount: re,
      closeSettingDrawer: () => G.closeDrawer()
    }), (s, d) => (kt(), xr(vr, null, [
      bt("div", {
        ref_key: "containerRef",
        ref: x,
        class: wr([W(v)])
      }, [bt("div", {
        ref_key: "renderRef",
        ref: S
      }, null, 512), Se(W(i), { "flow-id": E.value }, null, 8, ["flow-id"])], 2),
      Se(Ao, At(Ir(N)), null, 16),
      Se(Co, { onRegister: W(R) }, null, 8, ["onRegister"]),
      Se(Mo, {
        isSilentMode: y.isSilentMode,
        onRegister: W(D),
        onUpdate: Me
      }, null, 8, ["isSilentMode", "onRegister"]),
      W(ee).componentProps.visible ? (kt(), yr(Tr(W(ee).componentIs), At(Er({ key: 0 }, W(ee).superControlProps)), null, 16)) : Nr("", !0)
    ], 64));
  }
}), nd = /* @__PURE__ */ bo({ default: () => hs }), hs = fs;
export {
  nd as n,
  qr as r,
  hs as t
};
